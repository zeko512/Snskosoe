/* Scoped UI modal — no native Chrome alert/confirm/prompt for Zangar decisions */
(()=>{'use strict';let active=false;const queue=[];
function show({title='تأكيد القرار',message='',input=false,initial='',placeholder='',yes='تأكيد',no='إلغاء'}){
 return new Promise(resolve=>{queue.push({title,message,input,initial,placeholder,yes,no,resolve});pump();});
}
function pump(){if(active||!queue.length)return;active=true;const d=queue.shift();const previous=document.activeElement;let done=false;
 const shade=document.createElement('div');shade.className='z35-shade';shade.setAttribute('role','presentation');
 const panel=document.createElement('section');panel.className='z35-dialog';panel.setAttribute('role','dialog');panel.setAttribute('aria-modal','true');
 const heading=document.createElement('h2');heading.textContent='👑 '+d.title;heading.id='z35-heading';panel.setAttribute('aria-labelledby',heading.id);
 const text=document.createElement('p');text.textContent=String(d.message);panel.append(heading,text);
 let field=null;if(d.input){field=document.createElement('input');field.type='text';field.value=String(d.initial);field.placeholder=d.placeholder;field.setAttribute('aria-label',d.title);panel.append(field)}
 const actions=document.createElement('div');actions.className='z35-actions';const ok=document.createElement('button');ok.className='z35-yes';ok.textContent=d.yes;
 const cancel=document.createElement('button');cancel.className='z35-no';cancel.textContent=d.no;actions.append(ok,cancel);panel.append(actions);shade.append(panel);document.body.append(shade);
 function close(v){if(done)return;done=true;shade.remove();document.removeEventListener('keydown',key);try{previous?.focus()}catch{}d.resolve(v);active=false;pump()}
 function key(ev){if(ev.key==='Escape'){ev.preventDefault();close(d.input?null:false)}if(ev.key==='Enter'&&ev.target===field){ev.preventDefault();close(field.value)}}
 document.addEventListener('keydown',key);shade.addEventListener('mousedown',ev=>{if(ev.target===shade)close(d.input?null:false)});ok.addEventListener('click',()=>close(d.input?field.value:true));cancel.addEventListener('click',()=>close(d.input?null:false));(field||ok).focus();
}
window.zangarAsk=(message,title)=>show({message,title:title||'تأكيد القرار'});
window.zangarInput=(message,initial='',title)=>show({message,title:title||'إدخال بيانات',input:true,initial,yes:'متابعة'});
})();
