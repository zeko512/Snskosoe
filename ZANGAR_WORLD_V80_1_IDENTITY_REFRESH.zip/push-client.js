/* Universal state push button: all subscriptions require direct user interaction. */
(()=>{'use strict';
 const statusText=msg=>document.querySelectorAll('[data-zpush-status]').forEach(el=>el.textContent=msg);
 const errorText=err=>{const name=err?.name||'';return name==='NotAllowedError'?'رفض المتصفح الإذن. افتح إعدادات الموقع واسمح بالإشعارات.':String(err?.message||err||'تعذّر تشغيل الإشعارات')};
 const api=async(path,body)=>{const response=await fetch(path,{method:'POST',credentials:'same-origin',headers:{'Content-Type':'application/json'},body:JSON.stringify(body||{})});const json=await response.json().catch(()=>({}));if(!response.ok)throw Error(json.error||'تعذّر الاتصال بخدمة الإشعارات');return json;};
 const z33VibeKey='zangar-vibration-enabled';
 const z33VibeEnabled=()=>localStorage.getItem(z33VibeKey)!=='off';
 async function z33SyncVibe(){try{const r=await navigator.serviceWorker.ready;r.active?.postMessage({type:'Z33_VIBRATION_SET',enabled:z33VibeEnabled()});}catch(e){}}
 document.addEventListener('change',async event=>{const el=event.target.closest('[data-zpush-vibrate]');if(!el)return;localStorage.setItem(z33VibeKey,el.checked?'on':'off');await z33SyncVibe();statusText(el.checked?'📳 الاهتزاز (ثانيتين) اتفعّل مع الإشعارات — حسب دعم الجهاز.':'🔕 الاهتزاز اتقفل. الإشعارات هتيجي بدون اهتزاز.');});
 const support=()=>('serviceWorker'in navigator)&&('PushManager'in window)&&('Notification'in window)&&window.isSecureContext;
 const keyToBytes=base64=>{const s=base64.replace(/-/g,'+').replace(/_/g,'/');return Uint8Array.from(atob(s.padEnd(Math.ceil(s.length/4)*4,'=')),c=>c.charCodeAt(0));};
 const registration=async()=>navigator.serviceWorker.register('/sw.js',{scope:'/'});
 let pushWarmup=null;
 function warmup(){if(!support())return null;if(!pushWarmup)pushWarmup=Promise.all([config(),registration(),navigator.serviceWorker.ready]).catch(err=>{pushWarmup=null;throw err});return pushWarmup;}
 async function config(){const r=await fetch('/api/push/config',{cache:'no-store',credentials:'same-origin'});if(!r.ok)throw Error('لم يتم توصيل خدمة الإشعارات');return r.json();}
 async function enable(){
  if(!support())throw Error('جهازك لا يدعم إشعارات الويب هنا. في iPhone: أضف الموقع للشاشة الرئيسية وافتحه من الأيقونة.');
  if(Notification.permission==='denied')throw Error('الإشعارات مرفوضة من المتصفح. غيّر الإذن إلى سماح من إعدادات الموقع.');
  // Browser permission request is called directly in the click handler, not on page load.
  const permission=Notification.permission==='granted'?'granted':await Notification.requestPermission();
  if(permission!=='granted')throw Error('لازم توافق على إذن إشعارات الموقع علشان تشتغل.');
  const [cfg,,reg]=await (pushWarmup||warmup());if(!cfg.enabled||!cfg.publicKey)throw Error('لسه إعداد مفاتيح إشعارات Cloudflare ناقص. اطلب من رئيس الدولة إعدادها.');
  const bytes=keyToBytes(cfg.publicKey);
  let sub=await reg.pushManager.getSubscription();
  if(sub){const oldKey=sub.options?.applicationServerKey;
   if(oldKey&&Array.from(new Uint8Array(oldKey)).join(',')!==Array.from(bytes).join(',')){await sub.unsubscribe();sub=null;}}
  if(!sub)sub=await reg.pushManager.subscribe({userVisibleOnly:true,applicationServerKey:bytes});
  await api('/api/push/subscribe',{subscription:sub.toJSON()});
  statusText('✅ إشعارات دولة الزنجر اتفعّلت على الجهاز ده. دوس «جرّب الإشعار» للتأكد.');
 }
 async function disable(){const reg=await navigator.serviceWorker.getRegistration('/');const sub=await reg?.pushManager?.getSubscription();if(sub){await api('/api/push/unsubscribe',{endpoint:sub.endpoint});await sub.unsubscribe();}statusText('تم إيقاف إشعارات الدولة على الجهاز ده.');}
 async function test(){await api('/api/push/test');statusText('✅ خدمة الإشعارات قبلت رسالة التجربة. تأكد من وصولها على جهازك فعلًا.');}
 const znpLabels={on:'🟢 شغّالة على جهازك',off:'⚪ مش مفعّلة',blocked:'🔴 محجوبة من المتصفح',unsupported:'🟠 جهازك لا يدعمها',checking:'جارِ الفحص…'};
 const znpNotes={blocked:'المتصفح حاجب إشعارات الموقع. اضغط على القفل 🔒 جنب العنوان ← إعدادات الموقع ← الإشعارات ← سماح، وبعدها ارجع هنا.',unsupported:'المتصفح ده مش بيدعم إشعارات الويب. على الآيفون: Safari ← مشاركة ← إضافة للشاشة الرئيسية ← افتح من الأيقونة (iOS 16.4+). على الأندرويد استخدم Chrome.'};
 let znpBusy=false;
 async function refreshState(){
  const cards=[...document.querySelectorAll('[data-znp]')];if(!cards.length||znpBusy)return;znpBusy=true;
  try{let state='off';
   if(!support())state='unsupported';
   else if(Notification.permission==='denied')state='blocked';
   else{try{const reg=await navigator.serviceWorker.getRegistration('/');const sub=await reg?.pushManager?.getSubscription();if(sub&&Notification.permission==='granted')state='on';}catch(e){}}
   for(const c of document.querySelectorAll('[data-znp]')){c.dataset.state=state;c.dataset.ready='1';
    const pill=c.querySelector('[data-znp-pill]');if(pill)pill.textContent=znpLabels[state];
    const note=c.querySelector('[data-znp-note]');if(note)note.textContent=znpNotes[state]||'';}
   for(const fp of document.querySelectorAll('[data-znp-fold-pill]')){fp.textContent=znpLabels[state];fp.dataset.state=state;}
  }finally{znpBusy=false;}
 }
 document.addEventListener('click',event=>{const b=event.target.closest('[data-zpush-vibe-test]');if(!b)return;
  if(typeof navigator.vibrate!=='function'){statusText('📵 المتصفح أو الجهاز ده لا يدعم الاهتزاز (الآيفون مثلًا). الاهتزاز شغال على أندرويد.');return;}
  const ok=navigator.vibrate(2000);statusText(ok?'📳 المفروض موبايلك اهتز ثانيتين دلوقتي. لو ماحسيتش بحاجة راجع وضع الصامت وإعدادات الاهتزاز.':'⚠️ المتصفح منع الاهتزاز. جرّب بعد ما تلمس الشاشة.');});
 // The SPA re-renders pages, so watch for a fresh card instead of relying on timers.
 let znpTimer=0;
 new MutationObserver(()=>{if(znpTimer)return;znpTimer=requestAnimationFrame(()=>{znpTimer=0;
  const fresh=document.querySelector('[data-znp]:not([data-ready])');
  if(fresh){refreshState();refreshPrefs();z33RenderVibe();}});}).observe(document.documentElement,{childList:true,subtree:true});
 document.addEventListener('click',async event=>{
  const btn=event.target.closest('[data-zpush]');if(!btn)return;
  event.preventDefault();const type=btn.dataset.zpush;btn.disabled=true;
  try{statusText('جارِ تجهيز إشعارات الدولة...');if(type==='enable')await enable();else if(type==='disable')await disable();else if(type==='test')await test();}
  catch(err){statusText('⚠️ '+errorText(err));}
  finally{btn.disabled=false;refreshState();}
 });
 let prefLoad=0;
 async function refreshPrefs(){
  const controls=[...document.querySelectorAll('[data-zpush-pref]')];if(!controls.length)return;
  try{const r=await fetch('/api/push/status',{cache:'no-store',credentials:'same-origin'});if(!r.ok)return;
   const value=await r.json();for(const el of controls)if(document.activeElement!==el)el.checked=value.preferences?.[el.dataset.zpushPref]!==false;
  }catch(e){}
 }
 document.addEventListener('change',async event=>{
  const el=event.target.closest('[data-zpush-pref]');if(!el)return;
  const desired=el.checked;el.disabled=true;
  try{await api('/api/push/preferences',{kind:el.dataset.zpushPref,enabled:desired});statusText('✅ تم حفظ أنواع الإشعارات اللي تحب توصلك.');}
  catch(err){el.checked=!desired;statusText('⚠️ '+errorText(err));}
  finally{el.disabled=false;}
 });
 document.addEventListener('click',event=>{if(event.target.closest('[data-page="notifications"], [data-page="services"]'))setTimeout(refreshPrefs,400);});
 function z33RenderVibe(){document.querySelectorAll('[data-zpush-vibrate]').forEach(el=>el.checked=z33VibeEnabled())}
 document.addEventListener('click',event=>{if(event.target.closest('[data-page="services"]'))setTimeout(z33RenderVibe,100)});
 window.addEventListener('hashchange',()=>setTimeout(z33RenderVibe,100));
 window.addEventListener('hashchange',()=>setTimeout(refreshPrefs,400));
 if(document.readyState==='loading')document.addEventListener('DOMContentLoaded',refreshPrefs,{once:true});else refreshPrefs();
 if(document.readyState==='loading')document.addEventListener('DOMContentLoaded',refreshState,{once:true});else refreshState();
 if(support())warmup()?.then(z33SyncVibe).catch(()=>{});if(document.readyState==='loading')document.addEventListener('DOMContentLoaded',z33RenderVibe,{once:true});else z33RenderVibe();
 // War radar: offer an unobtrusive in-page opt-in link for authenticated residents.
 if(location.pathname==='/war.html'){
  const b=document.createElement('button');b.type='button';b.dataset.zpush='enable';b.textContent='🔔 إشعارات الدولة';
  Object.assign(b.style,{position:'fixed',bottom:'7px',left:'8px',zIndex:'55',border:'1px solid #6e9d8b',background:'#143a31',color:'#dcfbe1',borderRadius:'12px',padding:'7px 10px',fontWeight:'bold',fontSize:'11px'});
  document.addEventListener('DOMContentLoaded',()=>document.body.appendChild(b),{once:true});if(document.readyState!=='loading')document.body.appendChild(b);
 }
})();
