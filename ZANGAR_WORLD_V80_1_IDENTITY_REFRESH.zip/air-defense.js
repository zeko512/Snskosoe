(()=>{'use strict';
const demo=!!window.ZANGAR_AIR_DEMO, $=id=>document.getElementById(id),root=$('app'),sc=$('scene'),rad=$('radar'),sg=sc.getContext('2d'),rg=rad.getContext('2d');
const D=Math.PI/180,PI=Math.PI,TAU=PI*2;
let observerOverride=false,minister=false,cam=false,zoom=1,nightVision=false,tracks=[],balance=0,treasury=0,aim=14,elev=40,lastServer=0,serverOffset=0,requestBusy=false,shotFX=[],lastShotAt=0,selectedTargetId=null,emergencySending=false;
let alertPhase={active:false,accelerated:false,remaining_ms:0,speed_multiplier:1},upgrades={turret:0,radar:0,lock:0},followShot=false,lockBusy=false,upgradeBusy=false,lockTimer=0;
let cityState={hp:100,facilities:[]};
const mock={balance:34000,treasury:80000,slot:-1,shots:[],tracks:[],citizenRewards:0,alert:null,upgrades:{turret:0,radar:0,lock:0,shield:0}};
function show(msg,isError=false){let el=$('message');el.textContent=msg;el.style.borderColor=isError?'#d5686e':'#6baea4';el.classList.add('show');clearTimeout(show.timer);show.timer=setTimeout(()=>el.classList.remove('show'),2900);}
function clamp(n,a,b){return Math.max(a,Math.min(b,n))}function angleDiff(a,b){return ((a-b+540)%360)-180}function normalize(a){return ((a%360)+360)%360}
function now(){return Date.now()+serverOffset}
function newMockTrack(){
 const ts=Date.now(),slot=Math.floor(ts/41000);
 if(mock.alert){
   if(mock.alert.end>ts){
     if(mock.tracks.some(t=>t.id===mock.alert.trackId))return;
     mock.alert=null;mock.slot=-1;
   }else{mock.alert=null;mock.slot=-1;}
 }

 if(slot!==mock.slot){if(mock.slot!==-1){const attempted=atmosphere.waveHits+atmosphere.waveMisses;atmosphere.stars=attempted?Math.max(1,Math.min(3,Math.round(atmosphere.waveHits/attempted*3))):1;}mock.slot=slot;atmosphere.wave++;atmosphere.combo=0;atmosphere.waveHits=0;atmosphere.waveMisses=0;const n=Math.min(5,Math.max(2,1+Math.floor(atmosphere.wave/2)));
 mock.tracks=[];for(let i=0;i<n;i++)mock.tracks.push({id:'practice-'+slot+'-'+i,az:normalize(20+Math.floor(Math.random()*310)+i*32),el:22+Math.floor(Math.random()*55),type:atmosphere.wave>3&&i%5===0?'drone':atmosphere.wave>4&&i%6===0?'decoy':atmosphere.wave>2&&i%3===0?'fast':atmosphere.wave>3&&i%4===0?'armored':'normal',facility:['المستشفى','المطار','محطة الكهرباء','مركز المدينة'][i%4],started_at:ts+i*1500,expires_at:ts+(atmosphere.wave>2&&i%3===0?26000:33000)+i*1500,status:'incoming'});
 show('🚨 موجة جديدة — '+n+' أهداف قادمة!');}
 const lost=mock.tracks.filter(v=>v.expires_at<=ts);if(lost.length){const b=sc.getBoundingClientRect();spawnBurst(b.width*(.28+Math.random()*.45),b.height*.71,'#ff9471',32);}
 if(lost.length){atmosphere.misses+=lost.length;atmosphere.waveMisses+=lost.length;atmosphere.combo=0;atmosphere.cityHp=Math.max(0,atmosphere.cityHp-lost.length*(14-Math.min(6,Number(mock.upgrades.shield||0)*2)));for(const m of lost){const b=defenseFacilities.find(x=>x.name===m.facility)||defenseFacilities[3];b.hp=Math.max(0,b.hp-24+Math.min(12,Number(mock.upgrades.shield||0)*4));}sfx('hit');}
 mock.tracks=mock.tracks.filter(v=>v.expires_at>ts);
 if(atmosphere.cityHp<=0){atmosphere.cityHp=100;atmosphere.combo=0;show('🔁 المدينة تعافت — جولة تدريب جديدة');}
}
function mockState(){newMockTrack();const a=mock.alert;return {minister,tracks:mock.tracks,points:mock.balance,treasury:mock.treasury,server_time:Date.now(),online:false,role:minister?'minister':'observer',upgrades:mock.upgrades,alert:a?{active:a.end>Date.now(),accelerated:a.accelerated,speed_multiplier:a.accelerated?5:1,expires_at:a.end,remaining_ms:Math.max(0,a.end-Date.now()),phase:a.accelerated?'critical':'watch'}:{active:false,accelerated:false,speed_multiplier:1,remaining_ms:0}};}
async function fetchData(url,init={}){const res=await fetch(url,{cache:'no-store',credentials:'same-origin',...init});let value;try{value=await res.json()}catch{throw Error('تعذر قراءة استجابة السيرفر')}if(!res.ok)throw Error(value.error||value.message||'فشل الاتصال');return value;}
async function refresh(){if(requestBusy)return;requestBusy=true;try{const state=demo?mockState():await fetchData('/api/air-defense/state');minister=!!state.minister&&!observerOverride;balance=Number(state.points||0);treasury=Number(state.treasury||0);tracks=state.tracks||[];cityState=state.city||{hp:100,facilities:[]};alertPhase=state.alert||{active:false,accelerated:false,remaining_ms:0,speed_multiplier:1};upgrades=state.upgrades||{};serverOffset=Number(state.server_time||Date.now())-Date.now();lastServer=Date.now();if(!tracks.some(x=>x.id===selectedTargetId))selectedTargetId=null;updateUI();$('status').textContent=demo?'● وضع تجريبي':'● الرادار متصل';$('status').style.color='#75f4ba';}catch(e){$('status').textContent='● تعذر الاتصال';$('status').style.color='#ff898a';show(e.message,true);}finally{requestBusy=false;}}
function currentTarget(){return tracks.find(t=>t.id===selectedTargetId&&t.expires_at>now())||tracks.find(t=>t.expires_at>now())||null;}
function updateUI(){root.classList.toggle('observer',!minister);root.classList.toggle('is-demo',demo);$('roleLabel').textContent=minister?'قيادة الدفاع • تحكم':'رادار المواطنين • المراقبة';$('observerFooter').classList.toggle('hide',minister);$('balance').textContent=balance.toLocaleString('ar-EG');$('bearing').textContent=Math.round(normalize(aim))+'°';$('elevation').textContent=Math.round(elev)+'°';$('demoBanner').textContent=demo?'نسخة تدريب بأموال افتراضية فقط':'';$('returnRadar').style.display=minister?'inline-flex':'none';$('camera').textContent=cam?'🎮 خارجي':'📷 كاميرا';$('camSight').classList.toggle('hide',!cam||!minister);$('opticsControls').classList.toggle('hide',!cam||!minister);$('emergency').style.display=minister?'inline-flex':'none';$('headnote').textContent=minister?'اضغط نقطة الصاروخ الحمراء لتثبيت الاتجاه والارتفاع، ثم FIRE':'الرادار للمشاهدة • للتحكم ادخل الرمز السري';
const target=currentTarget();if(minister){const d=target?Math.abs(angleDiff(aim,target.az)):999,e=target?Math.abs(elev-(target.el||42)):999;const locked=target&&d<=18&&e<=14;$('targetState').textContent=!target?'لا يوجد صاروخ قادم':locked?'🎯 الهدف داخل نطاق الإصابة':'🎯 حدّد الهدف من الرادار';$('targetNumbers').textContent=target?`الهدف ${target.az}° / ارتفاع ${target.el}°`:'انتظر موجة جديدة';$('targetHint').textContent=locked?'✅ اضغط FIRE للاعتراض':'اضغط النقطة الحمراء للتثبيت الدقيق';}}

function aimStep(a=0,b=0){if(!minister)return;aim=normalize(aim+a);elev=clamp(elev+b,5,83);updateUI();}
function resize(c,ctx,w,h){const dpr=Math.min(2,window.devicePixelRatio||1);const cw=Math.max(1,Math.floor(w*dpr)),ch=Math.max(1,Math.floor(h*dpr));if(c.width!==cw||c.height!==ch){c.width=cw;c.height=ch}ctx.setTransform(dpr,0,0,dpr,0,0);return [w,h]}
function drawRadar(t){let rect=rad.getBoundingClientRect();let [w,h]=resize(rad,rg,rect.width,rect.height),cx=w/2,cy=h/2,R=Math.min(w,h)*.475;rg.clearRect(0,0,w,h);let g=rg.createRadialGradient(cx,cy,3,cx,cy,R);g.addColorStop(0,'#092e2d');g.addColorStop(1,'#041517');rg.fillStyle=g;rg.fillRect(0,0,w,h);
rg.strokeStyle='#4ff1b039';rg.lineWidth=1;for(let i=1;i<=4;i++){rg.beginPath();rg.arc(cx,cy,R*i/4,0,TAU);rg.stroke()}rg.beginPath();rg.moveTo(cx-R,cy);rg.lineTo(cx+R,cy);rg.moveTo(cx,cy-R);rg.lineTo(cx,cy+R);rg.stroke();for(let k=0;k<24;k++){let a=k*TAU/24;rg.beginPath();rg.moveTo(cx+Math.sin(a)*R*.91,cy-Math.cos(a)*R*.91);rg.lineTo(cx+Math.sin(a)*R,cy-Math.cos(a)*R);rg.stroke()}
rg.save();rg.translate(cx,cy);rg.rotate(t*.00065);let wedge=rg.createConicGradient(-.48,0,0);wedge.addColorStop(0,'rgba(83,255,176,.01)');wedge.addColorStop(.07,'rgba(83,255,176,.18)');wedge.addColorStop(.14,'rgba(83,255,176,0)');wedge.addColorStop(1,'rgba(83,255,176,0)');rg.fillStyle=wedge;rg.beginPath();rg.moveTo(0,0);rg.arc(0,0,R,0,TAU);rg.fill();rg.restore();
for(const target of tracks){const progress=clamp((now()-target.started_at)/(target.expires_at-target.started_at),0,1);const v=R*(.86-.7*progress),a=target.az*D,x=cx+Math.sin(a)*v,y=cy-Math.cos(a)*v;rg.shadowColor='#ff5864';rg.shadowBlur=12;rg.fillStyle='#ff686b';rg.beginPath();rg.arc(x,y,Math.max(4,w*.017),0,TAU);rg.fill();rg.shadowBlur=0;rg.fillStyle='#ffccd4';rg.font=`bold ${Math.max(10,w*.047)}px system-ui`;rg.textAlign='center';if(minister&&target.id===selectedTargetId){rg.strokeStyle='#fff7b1';rg.lineWidth=1.7;rg.beginPath();rg.arc(x,y,Math.max(9,w*.033),0,TAU);rg.stroke();}}
if(minister&&Number(upgrades.radar||0)>0){rg.save();rg.strokeStyle='rgba(99,241,255,.29)';rg.lineWidth=1;for(let i=1;i<=Number(upgrades.radar||0);i++){rg.setLineDash([3,7]);rg.beginPath();rg.arc(cx,cy,R*(.23+i*.19),0,TAU);rg.stroke();}rg.setLineDash([]);rg.restore();}
rg.strokeStyle='#d6e5ad';rg.lineWidth=2;rg.beginPath();rg.moveTo(cx,cy);rg.lineTo(cx+Math.sin(aim*D)*R*.87,cy-Math.cos(aim*D)*R*.87);minister&&rg.stroke();rg.fillStyle='#c8f9e8';rg.beginPath();rg.arc(cx,cy,3.2,0,TAU);rg.fill();
rg.fillStyle='#93d8bf';rg.textAlign='center';rg.font=`bold ${Math.max(9,w*.034)}px system-ui`;rg.fillText('N',cx,Math.max(17,cy-R+18));}
function plate(ctx,x,y,w,h,r,fill,stroke='#111c22',lw=2){ctx.fillStyle=fill;ctx.beginPath();ctx.roundRect(x,y,w,h,r);ctx.fill();ctx.lineWidth=lw;ctx.strokeStyle=stroke;ctx.stroke();}
function ellipse(ctx,x,y,rx,ry,color){ctx.beginPath();ctx.ellipse(x,y,rx,ry,0,0,TAU);ctx.fillStyle=color;ctx.fill()}
// V67 visual and gameplay enhancement functions, injected into the existing client.
const atmosphere={sparks:[],shake:0,flash:0,cityHp:100,wave:0,intercepts:0,misses:0,combo:0,bestCombo:0,lastWave:0,waveHits:0,waveMisses:0,stars:0,muted:false,actx:null};
const defenseFacilities=[{name:'المستشفى',icon:'🏥',hp:100},{name:'المطار',icon:'✈️',hp:100},{name:'محطة الكهرباء',icon:'⚡',hp:100},{name:'مركز المدينة',icon:'🏙️',hp:100}];
function sfx(type){if(atmosphere.muted)return;try{const AC=window.AudioContext||window.webkitAudioContext;if(!AC)return;const a=atmosphere.actx||(atmosphere.actx=new AC());const t=a.currentTime,o=a.createOscillator(),v=a.createGain();o.connect(v);v.connect(a.destination);o.type=type==='fire'?'sawtooth':type==='hit'?'triangle':'sine';o.frequency.setValueAtTime(type==='fire'?210:type==='hit'?140:480,t);o.frequency.exponentialRampToValueAtTime(type==='fire'?60:type==='hit'?35:180,t+.28);v.gain.setValueAtTime(.0001,t);v.gain.exponentialRampToValueAtTime(type==='fire'?.075:type==='hit'?.095:.025,t+.03);v.gain.exponentialRampToValueAtTime(.0001,t+.35);o.start(t);o.stop(t+.37);}catch(_){}}
function spawnBurst(x,y,col='#ffcf77',count=28){for(let i=0;i<count;i++){const q=i*2.399+Math.random()*.15;const speed=28+Math.random()*170;atmosphere.sparks.push({x,y,vx:Math.cos(q)*speed,vy:Math.sin(q)*speed-35,age:0,ttl:.45+Math.random()*.6,color:col,r:1+Math.random()*4});}atmosphere.flash=.34;atmosphere.shake=11;sfx('hit')}
function pathPoly(g,pts,fill,stroke='#102027',thick=2.5){g.beginPath();g.moveTo(...pts[0]);for(let i=1;i<pts.length;i++)g.lineTo(...pts[i]);g.closePath();g.fillStyle=fill;g.fill();if(stroke){g.lineWidth=thick;g.strokeStyle=stroke;g.stroke();}}
function metal(g,x,y,w,h,c1,c2,r=12){const grd=g.createLinearGradient(x,y,x+w*.3,y+h);grd.addColorStop(0,c1);grd.addColorStop(.55,c2);grd.addColorStop(1,'#223f3c');g.fillStyle=grd;g.strokeStyle='#101c26';g.lineWidth=3;g.beginPath();g.roundRect(x,y,w,h,r);g.fill();g.stroke()}
function disk(g,x,y,r,c1='#152833',c2='#608276'){let p=g.createRadialGradient(x-r*.3,y-r*.4,1,x,y,r);p.addColorStop(0,c2);p.addColorStop(1,c1);g.fillStyle=p;g.beginPath();g.arc(x,y,r,0,Math.PI*2);g.fill();g.lineWidth=2;g.strokeStyle='#102029';g.stroke();}
function glass(g,x,y,r){g.save();g.shadowColor='#91f6ff';g.shadowBlur=15;disk(g,x,y,r,'#0b2e48','#9beaff');disk(g,x,y,r*.63,'#082e40','#71dbff');g.fillStyle='#f7ffff';g.beginPath();g.ellipse(x-r*.25,y-r*.3,r*.18,r*.26,.5,0,Math.PI*2);g.fill();g.restore();}
function track3d(g,x,y,w,h,t){g.save();g.translate(x,y);pathPoly(g,[[7,8],[w-10,4],[w+6,21],[w+3,h-4],[12,h+11],[-6,h-2]],'#111c22','#0b111a',4);metal(g,0,9,w,h-13,'#35484b','#1b2d35',22);for(let j=0;j<11;j++){const dx=(j+.5)*w/11;g.lineWidth=4;g.strokeStyle=j%2?'#1a2930':'#384f4e';g.beginPath();g.moveTo(dx,14);g.lineTo(dx-7,28);g.moveTo(dx,h-3);g.lineTo(dx+8,h+4);g.stroke();}for(let i=0;i<6;i++){let cx=23+i*(w-46)/5;disk(g,cx,h*.57,h*.24,'#23343b','#68878b');disk(g,cx,h*.57,h*.14,'#152936','#a7b8aa');disk(g,cx,h*.57,3,'#4d6b67','#bdcabe');}g.restore();}
function drawTank(g,w,h,t){
 const scale=Math.min(w/1040,h/575)*.91,xx=w*.47,yy=h*.87;
 g.save();g.translate(xx,yy);g.scale(scale,scale);
 let sh=g.createRadialGradient(0,50,10,0,50,370);sh.addColorStop(0,'rgba(0,0,0,.58)');sh.addColorStop(1,'rgba(0,0,0,0)');g.fillStyle=sh;g.beginPath();g.ellipse(0,42,340,69,0,0,Math.PI*2);g.fill();
 // Three-quarter-track perspective, with upper treads that slightly overlap the hull.
 track3d(g,-273,-62,227,103,t);track3d(g,45,-55,248,101,t);
 pathPoly(g,[[-249,-129],[205,-145],[273,-96],[261,-28],[-269,-27]],'#243d38','#0f2029',5);
 pathPoly(g,[[-250,-146],[196,-164],[250,-134],[208,-117],[-251,-111]],'#91ad87','#253f3e',4);
 pathPoly(g,[[-260,-122],[220,-142],[243,-119],[244,-64],[-266,-57]],'#415f50','#112930',4);
 for(let i=0;i<9;i++){let bx=-230+i*51;pathPoly(g,[[bx,-125],[bx+41,-128],[bx+36,-117],[bx,-114]],i%2?'#78947a':'#5f7f68','#2a4644',1.3)}
 metal(g,-223,-109,424,66,'#5f7f66','#344f48',13);metal(g,-197,-95,364,43,'#264138','#182d38',7);
 for(let i=0;i<9;i++)disk(g,-180+i*41,-61,2.2,'#071920','#b7ccbb');
 // Armor nose extrusion for 2.5-D depth.
 pathPoly(g,[[197,-105],[249,-126],[270,-102],[262,-40],[212,-45]],'#293d39','#152833',4);
 pathPoly(g,[[215,-102],[255,-113],[247,-69],[217,-62]],'#7b9781','#334f4b',2);
 // turret and all tools under a single transform: camera and barrel move in lockstep
 let heading=Math.sin(aim*D)*.20, pitch=(elev-40)*D*.42;
 g.save();g.translate(2,-164);g.rotate(heading-pitch);
 pathPoly(g,[[-145,-22],[107,-43],[143,-22],[142,24],[-145,30]],'#263b33','#101e2a',4);
 metal(g,-133,-42,258,68,'#8ca889','#3d5e50',20);metal(g,-104,-38,181,26,'#a8b99d','#68876e',9);
 pathPoly(g,[[-128,-39],[-76,-63],[96,-61],[133,-40]],'#9eb59a','#304b47',2);
 metal(g,-149,-13,100,56,'#57745c','#29483d',8);metal(g,-141,-4,81,21,'#8b9d85','#345443',4);
 // Multi-layered cannon and industrial muzzle: no separate rotation.
 metal(g,111,-31,213,26,'#a5b7bc','#536b75',12);metal(g,132,-26,172,8,'#becbd2','#6d8494',5);
 for(let i=0;i<8;i++)metal(g,144+i*19,-33,7,29,'#607782','#1e3441',3);
 metal(g,283,-42,57,49,'#6c8390','#243947',12);disk(g,336,-17,20,'#0b1a25','#556d7d');disk(g,337,-17,11,'#061017','#152f38');
 // camera crane and optics attached to turret assembly
 metal(g,-120,-125,19,94,'#97ada5','#426261',9);disk(g,-110,-122,13,'#1c3a43','#9ac6ba');
 metal(g,-171,-185,126,67,'#7c9b83','#345249',18);
 pathPoly(g,[[-166,-182],[-136,-197],[-47,-193],[-46,-167],[-168,-158]],'#9bb39b','#365b55',2);
 metal(g,-106,-176,51,51,'#38565d','#112834',12);glass(g,-80,-151,19);
 metal(g,-169,-165,26,31,'#58756a','#2d4346',10);disk(g,-157,-147,9,'#173444','#7eaaa7');
 g.restore();
 metal(g,-102,-105,196,46,'#9eae8c','#537055',5);g.fillStyle='#b62f3d';g.textAlign='center';g.font='900 37px system-ui';g.fillText('ZANGAR',-4,-72);
 g.fillStyle='#d7e6d3';g.globalAlpha=.33;g.beginPath();g.moveTo(-250,-142);g.lineTo(188,-156);g.lineTo(212,-146);g.lineTo(-249,-130);g.closePath();g.fill();g.restore();
}
function backgroundWorld(g,w,h,t){
 let sky=g.createLinearGradient(0,0,0,h);sky.addColorStop(0,'#101b36');sky.addColorStop(.33,'#31566d');sky.addColorStop(.67,'#ef9b7f');sky.addColorStop(.89,'#91b4a6');sky.addColorStop(1,'#527f6c');g.fillStyle=sky;g.fillRect(0,0,w,h);
 // cinematic radial horizon glow and atmospheric depth
 const glow=g.createRadialGradient(w*.69,h*.50,0,w*.69,h*.50,w*.62);glow.addColorStop(0,'rgba(255,217,164,.30)');glow.addColorStop(1,'rgba(255,215,160,0)');g.fillStyle=glow;g.fillRect(0,0,w,h);
 for(let i=0;i<13;i++){let x=(i*231+t*(.002+(i%3)*.0007))%(w+440)-200,y=65+(i*67)%(h*.41),a=8+i%3*7;g.fillStyle=i%2?'rgba(240,226,227,.11)':'rgba(206,232,238,.12)';g.beginPath();g.ellipse(x,y,90+a,9+a*.22,0,0,Math.PI*2);g.ellipse(x+65,y-5,58+a,13+a*.22,0,0,Math.PI*2);g.fill();}
 // far hills
 function hills(fill,level,amp,seed){g.fillStyle=fill;g.beginPath();g.moveTo(0,h);g.lineTo(0,h*level);for(let x=0;x<=w+20;x+=18)g.lineTo(x,h*level+Math.sin(x/w*11+seed)*amp+Math.sin(x/w*19+seed*.65)*amp*.38);g.lineTo(w,h);g.closePath();g.fill()}
 hills('#66847b',.68,23,1.7);hills('#3b6563',.78,19,3.9);hills('#294c4f',.87,13,.9);
 // a compact city silhouette with fake front/side dimensions
 const base=h*.745;for(let i=0;i<18;i++){const bw=18+i%4*8,bh=(35+(i*37)%108)*(h/520),x=(i*79)%(w+170)-70,y=base-bh;g.fillStyle=i%3?'#324e5c':'#425a60';g.fillRect(x,y,bw,bh);pathPoly(g,[[x+bw,y],[x+bw+10,y-8],[x+bw+10,base-8],[x+bw,base]],'#263f4d',null,0);g.fillStyle='rgba(255,224,160,.43)';for(let iy=y+10;iy<base-5;iy+=13)for(let ix=x+5;ix<x+bw-3;ix+=10){if((Math.floor(ix*7+iy*3)%5)!==0)g.fillRect(ix,iy,2,4);}}
 // forward grassy ridge / perspective promenade
 hills('#243f3c',.89,8,5.8);
 const ground=g.createLinearGradient(0,h*.83,0,h);ground.addColorStop(0,'#4c7664');ground.addColorStop(1,'#223d38');pathPoly(g,[[0,h*.92],[w,h*.92],[w,h],[0,h]],ground,null,0);
 for(let i=0;i<26;i++){let x=(i*97)%(w+100)-40,y=h*(.90+(i*13%11)*.009);g.strokeStyle='rgba(168,198,156,.15)';g.lineWidth=1;g.beginPath();g.moveTo(x,y);g.lineTo(x+7,y-6);g.stroke()}
}
function enemySprite(g,x,y,k,t,kind='normal'){
 if(kind==='drone'){
  g.save();g.translate(x,y);g.rotate(Math.sin(t*.004)*.16);g.scale(k,k);
  g.shadowColor='#66f4fb';g.shadowBlur=12;pathPoly(g,[[-23,0],[-9,-8],[9,-8],[23,0],[9,7],[-9,7]],'#86c6d8','#254b59',2);
  disk(g,0,0,8,'#163542','#a9f9ff');g.shadowBlur=0;
  for(let side of [-1,1]){const dx=side*20;g.strokeStyle='#c3edff';g.lineWidth=2;g.beginPath();g.ellipse(dx,-1,10,2+t%3,Math.sin(t*.04),0,TAU);g.stroke();}
  g.restore();return;
 }
 g.save();g.translate(x,y);g.rotate(.35+Math.sin(t*.003)*.06);g.scale(k,k);g.shadowColor='#ff7f66';g.shadowBlur=18;let flame=g.createLinearGradient(0,-45,0,-8);flame.addColorStop(0,'#ffdf9b00');flame.addColorStop(.65,'#ffb66acc');flame.addColorStop(1,'#fff5d8');pathPoly(g,[[-7,-9],[0,-39],[7,-9]],flame,null,0);g.shadowBlur=0;pathPoly(g,[[0,17],[11,-8],[4,-17],[0,-12],[-4,-17],[-11,-8]],kind==='fast'?'#ffe385':kind==='armored'?'#80cef3':kind==='decoy'?'#c394ff':kind==='alert'?'#ff4253':'#ff6c65','#752632',2);if(kind==='armored'){g.strokeStyle='#8ee5ff';g.lineWidth=2;g.beginPath();g.arc(0,0,17,0,Math.PI*2);g.stroke();}if(kind==='fast'){g.fillStyle='#ffe49c';g.fillRect(-3,-24,6,11);}pathPoly(g,[[-6,-13],[-2,-22],[2,-22],[6,-13]],'#d3e4e7','#a6c7c8',1);g.restore()}
function drawParticles(g,dt,w,h){const a=atmosphere.sparks;for(let i=a.length-1;i>=0;i--){let p=a[i];p.age+=dt;if(p.age>=p.ttl){a.splice(i,1);continue;}p.x+=p.vx*dt;p.y+=p.vy*dt;p.vy+=85*dt;g.globalAlpha=(1-p.age/p.ttl)*.95;g.fillStyle=p.color;g.shadowColor=p.color;g.shadowBlur=14;g.beginPath();g.arc(p.x,p.y,p.r*(1-p.age/p.ttl*.65),0,Math.PI*2);g.fill();g.shadowBlur=0;}g.globalAlpha=1;}

// V69: industrial air-defense outpost environment, drawn behind the tank.
function drawV69Outpost(g,w,h,t){
  if(cam)return;
  g.save();
  const floorY=h*.88;
  // Raised concrete blast platform with perspective bevel and floor markings.
  g.beginPath();g.moveTo(w*.23,floorY);g.lineTo(w*.76,floorY);g.lineTo(w*.93,h);g.lineTo(w*.08,h);g.closePath();
  let pad=g.createLinearGradient(0,floorY,0,h);pad.addColorStop(0,'#40545b');pad.addColorStop(1,'#172d36');g.fillStyle=pad;g.fill();
  g.strokeStyle='#9ab2a77a';g.lineWidth=2;g.stroke();
  g.beginPath();g.moveTo(w*.27,floorY+6);g.lineTo(w*.72,floorY+6);g.strokeStyle='#b3c8b65a';g.stroke();
  // Ground guide stripes.
  g.strokeStyle='#e1c77b55';g.lineWidth=2.5;g.beginPath();g.moveTo(w*.23,floorY+5);g.lineTo(w*.13,h);g.moveTo(w*.76,floorY+5);g.lineTo(w*.86,h);g.stroke();
  // Service perimeter safety rail, lights and command hardware behind the chassis.
  for(const side of [-1,1]){
    const x=w*(side<0?.235:.765),y=h*.77;
    g.save();g.translate(x,y);
    // Floodlight stand.
    g.strokeStyle='#21343b';g.lineWidth=Math.max(2,w*.002);g.beginPath();g.moveTo(0,25);g.lineTo(0,-64);g.stroke();
    g.fillStyle='#253f46';g.strokeStyle='#9aafa8';g.lineWidth=1.5;g.beginPath();g.roundRect(-18,-77,36,15,4);g.fill();g.stroke();
    g.fillStyle='#f1e4af';g.shadowColor='#ffe9a2';g.shadowBlur=16;g.fillRect(-13,-73,26,6);g.shadowBlur=0;
    g.restore();
  }
  // Communications rack and observation mast, behind the main vehicle.
  const mx=w*.83,my=h*.75;
  g.strokeStyle='#304653';g.lineWidth=3;g.beginPath();g.moveTo(mx,my+19);g.lineTo(mx,my-99);g.moveTo(mx-13,my-78);g.lineTo(mx+13,my-78);g.moveTo(mx-23,my-57);g.lineTo(mx+23,my-57);g.stroke();
  g.fillStyle='#7dc6b8';g.beginPath();g.arc(mx,my-101,3.4,0,Math.PI*2);g.fill();
  g.save();g.translate(mx,my-52);g.rotate(t*.0002);g.strokeStyle='#94cab9';g.lineWidth=2;g.beginPath();g.ellipse(0,0,19,6,0,0,Math.PI*2);g.stroke();g.restore();
  // Blinking status beacons.
  for(let i=0;i<3;i++){
    const x=w*(.25+i*.26),y=h*.88;
    g.fillStyle='#111f2b';g.fillRect(x-9,y-12,18,12);
    g.fillStyle=(Math.sin(t*.005+i*2)>0?'#ffc26c':'#865744');g.fillRect(x-4,y-14,8,4);
  }
  // Painted operation label on concrete, subtly visible under foreground track.
  g.save();g.translate(w*.50,h*.968);g.scale(1,.33);g.font=`900 ${Math.max(14,Math.min(32,w*.026))}px system-ui`;g.textAlign='center';g.fillStyle='#d7e9ca46';g.fillText('ZANGAR  •  AIR DEFENSE BASE',0,0);g.restore();
  g.restore();
}


// ===== V70 REALISTIC HQ: procedural painted metal, base depth, atmospheric particles =====
function v70Rivet(g,x,y,r=2){g.save();g.shadowColor='#050c12';g.shadowBlur=3;g.fillStyle='#162b30';g.beginPath();g.arc(x,y,r+1.1,0,TAU);g.fill();g.shadowBlur=0;g.fillStyle='#9bafa3';g.beginPath();g.arc(x-.5,y-.65,r*.64,0,TAU);g.fill();g.restore();}
function drawV70VehicleFinish(g,w,h,t){
 if(cam)return;
 const scale=Math.min(w/1040,h/575)*.91;
 g.save();g.translate(w*.47,h*.87);g.scale(scale,scale);
 // beveled side armor and weld seams
 g.lineWidth=2;g.strokeStyle='#b1c8ae81';g.beginPath();g.moveTo(-223,-105);g.lineTo(195,-105);g.moveTo(-225,-50);g.lineTo(190,-50);g.stroke();
 g.lineWidth=1.1;g.strokeStyle='#12282e';for(let x=-210;x<205;x+=43){g.beginPath();g.moveTo(x,-103);g.lineTo(x,-58);g.stroke();}
 for(let x=-239;x<234;x+=35){v70Rivet(g,x,-118,1.75);v70Rivet(g,x,-39,1.5);}
 // metallic abrasions placed deterministically, read as weathering rather than random noise
 g.save();g.strokeStyle='#b7c9a44c';g.lineWidth=1.1;
 for(let i=0;i<22;i++){let x=-237+((i*79)%463),y=-129+(i*17)%62;g.beginPath();g.moveTo(x,y);g.lineTo(x+3+(i%5),y-(i%3));g.stroke();}g.restore();
 // armored vent, serial tags and red caution stripes
 g.fillStyle='#20383d';g.fillRect(-198,-52,80,12);for(let i=0;i<9;i++){g.fillStyle=i%2?'#6d8a7e':'#1b2f37';g.fillRect(-193+i*8,-50,4,8);}
 g.fillStyle='#d4ddc58f';g.font='700 8px monospace';g.textAlign='left';g.fillText('ZG-70  //  SKY GUARD',91,-101);
 g.strokeStyle='#d9bc70aa';g.lineWidth=3;g.beginPath();g.moveTo(223,-90);g.lineTo(250,-67);g.stroke();
 // ground contact dust plume from the gently vibrating engine
 const puff=Math.sin(t*.0007)*1.5;g.fillStyle='rgba(179,189,165,.07)';g.beginPath();g.ellipse(-256,14+puff,55,13,0,0,TAU);g.fill();
 // turret/cannon/optics are one linked assembly; add physical detail in the SAME transform
 const heading=Math.sin(aim*D)*.20,pitch=(elev-40)*D*.42;
 g.translate(2,-164);g.rotate(heading-pitch);
 g.strokeStyle='#d5e2c47d';g.lineWidth=1.5;g.beginPath();g.moveTo(-119,-28);g.lineTo(105,-40);g.stroke();
 for(let x=-100;x<115;x+=38){v70Rivet(g,x,10,2);}
 // material bevel at the top of long bore + cable protecting camera harness
 g.strokeStyle='#d9e7e9ad';g.lineWidth=2;g.beginPath();g.moveTo(138,-31);g.lineTo(294,-40);g.stroke();
 g.strokeStyle='#253d43';g.lineWidth=3;g.beginPath();g.moveTo(-116,-111);g.quadraticCurveTo(-152,-95,-130,-42);g.stroke();
 g.strokeStyle='#88b9b6';g.lineWidth=1;g.beginPath();g.moveTo(-117,-111);g.quadraticCurveTo(-152,-95,-130,-42);g.stroke();
 // optical glass lens glints at variable light
 g.save();g.globalAlpha=.5+.3*Math.sin(t*.0025)**2;g.fillStyle='#e0faff';g.beginPath();g.ellipse(-87,-159,4,9,-.33,0,TAU);g.fill();g.restore();
 // shot recoil flash on the actual barrel muzzle
 const elapsed=Date.now()-lastShotAt;
 if(elapsed>=0&&elapsed<240){
   const p=1-elapsed/240;g.save();g.translate(342,-17);g.globalAlpha=p;g.shadowColor='#ffb45f';g.shadowBlur=29*p;g.fillStyle='#ffe5a5';g.beginPath();g.moveTo(0,-11*p);g.lineTo(59*p,0);g.lineTo(0,12*p);g.closePath();g.fill();g.fillStyle='#ff8f40';g.beginPath();g.moveTo(0,-7*p);g.lineTo(34*p,0);g.lineTo(0,7*p);g.closePath();g.fill();g.restore();
 }
 g.restore();
}
function drawV70HQScenery(g,w,h,t){
 if(cam)return;g.save();
 // layered atmospheric perspective and illuminated parade-ground approach
 const groundY=h*.82;
 const road=g.createLinearGradient(0,groundY,0,h);road.addColorStop(0,'#354a4b');road.addColorStop(1,'#142c38');
 g.fillStyle=road;g.beginPath();g.moveTo(w*.22,groundY);g.lineTo(w*.78,groundY);g.lineTo(w*.97,h);g.lineTo(w*.03,h);g.closePath();g.fill();
 g.lineWidth=1.7;g.strokeStyle='#8b9b8a59';for(let i=0;i<9;i++){const x=w*(.11+i*.1);g.beginPath();g.moveTo(x,h*.96);g.lineTo(w*.50+(x-w*.50)*.65,h*.875);g.stroke();}
 // checkpoint hangar, shadowed loading doors and service control hut
 for(const [cx,by,sw,sh] of [[.165,.77,.128,.25],[.805,.78,.12,.19]]){
  let x=w*cx,y=h*by,W=w*sw,H=h*sh;
  pathPoly(g,[[x-W*.5,y],[x+W*.49,y],[x+W*.5,y-H],[x-W*.49,y-H]],'#344a51','#172c34',2);
  pathPoly(g,[[x-W*.61,y-H],[x+W*.62,y-H],[x+W*.44,y-H-12],[x-W*.46,y-H-12]],'#64796f','#152d35',2);
  g.fillStyle='#1c333b';g.fillRect(x-W*.28,y-H*.63,W*.56,H*.63);
  for(let k=0;k<5;k++){g.strokeStyle='#82958b66';g.lineWidth=1;g.beginPath();g.moveTo(x-W*.28,y-H*.63+k*H*.11);g.lineTo(x+W*.28,y-H*.63+k*H*.11);g.stroke();}
  g.fillStyle='#e1c277';g.shadowColor='#ffe0a3';g.shadowBlur=9;g.fillRect(x-W*.41,y-H*.83,W*.12,4);g.shadowBlur=0;
 }
 // fence and guardrail, behind the tank
 g.lineWidth=1.5;for(const yy of [h*.8,h*.85]){g.strokeStyle='#a2b6ae45';g.beginPath();g.moveTo(w*.08,yy);g.lineTo(w*.9,yy);g.stroke();}
 for(let i=0;i<18;i++){let x=w*(.08+.047*i);g.strokeStyle='#647d7799';g.beginPath();g.moveTo(x,h*.78);g.lineTo(x,h*.86);g.stroke();}
 // volumetric searchlight beams sweep the fictional base
 for(let i=0;i<2;i++){
   const bx=w*(i?.8:.19),by=h*.72,angle=Math.sin(t*.0003+i*2.2)*.27,far=260;
   g.save();g.translate(bx,by);g.rotate(angle);let beam=g.createLinearGradient(0,0,0,-far);beam.addColorStop(0,'rgba(230,242,204,.16)');beam.addColorStop(1,'rgba(225,240,219,0)');g.fillStyle=beam;g.beginPath();g.moveTo(-8,0);g.lineTo(-85,-far);g.lineTo(55,-far);g.lineTo(8,0);g.fill();g.restore();
 }
 // warning beacons when an alarm is active
 if(alertPhase?.active){for(let i=0;i<2;i++){const x=w*(i?.82:.18),y=h*.73;let alpha=.25+.4*Math.sin(t*.014)**2;g.fillStyle=`rgba(255,65,72,${alpha})`;g.beginPath();g.arc(x,y-30,5,0,TAU);g.fill();}}
 g.restore();
}
function drawV70OpticalPass(g,w,h,t){
 if(!cam)return;g.save();
 if(nightVision){g.fillStyle='rgba(2,42,22,.42)';g.fillRect(0,0,w,h);g.globalCompositeOperation='screen';g.fillStyle='rgba(56,255,126,.1)';g.fillRect(0,0,w,h);g.globalCompositeOperation='source-over';}
 g.fillStyle='rgba(1,12,18,.31)';g.fillRect(w*.29,h*.14,w*.42,2);g.fillRect(w*.29,h*.84,w*.42,2);
 g.strokeStyle=nightVision?'#a0ffbdcc':'#a4f5e7b8';g.lineWidth=1.5;
 for(let i=-3;i<=3;i++){const y=h*.5+i*(h*.04);if(i===0)continue;g.beginPath();g.moveTo(w*.5-w*.06,y);g.lineTo(w*.5+w*.06,y);g.stroke();}
 const cx=w*.5,cy=h*.5;g.strokeStyle='#c3fae888';g.setLineDash([6,8]);g.beginPath();g.arc(cx,cy,44,0,TAU);g.stroke();g.setLineDash([]);
 g.textAlign='left';g.font='bold 12px monospace';g.fillStyle='#a6f8e9';g.fillText('OPTICS // '+(nightVision?'NIGHT':'DAY')+' // '+zoom+'X',w*.32,h*.16);g.restore();
}

function scene(g,t){let [w,h]=resize(sc,g,sc.getBoundingClientRect().width,sc.getBoundingClientRect().height);g.clearRect(0,0,w,h);if(!minister)return;
 g.save();if(atmosphere.shake>0){g.translate((Math.random()-.5)*atmosphere.shake,(Math.random()-.5)*atmosphere.shake);atmosphere.shake*=.88;if(atmosphere.shake<.25)atmosphere.shake=0;}
 backgroundWorld(g,w,h,t);drawV68Sky(g,w,h,t);drawV69Outpost(g,w,h,t);drawV70HQScenery(g,w,h,t);
 if(!cam){drawTank(g,w,h,t);drawV70VehicleFinish(g,w,h,t);drawV68FacilityMarkers(g,w,h);let m=g.createLinearGradient(0,h*.50,0,h);m.addColorStop(0,'#ffffff00');m.addColorStop(1,'#0514264d');g.fillStyle=m;g.fillRect(0,0,w,h);}
 else{
  // Lens vignette, horizon and digital pitch ladder for first-person targeting
  let v=g.createRadialGradient(w*.5,h*.48,1,w*.5,h*.48,w*.69);v.addColorStop(0,'rgba(0,10,22,0)');v.addColorStop(1,'rgba(1,9,23,.78)');g.fillStyle=v;g.fillRect(0,0,w,h);
  g.strokeStyle='rgba(133,248,242,.24)';g.lineWidth=1;for(let i=0;i<15;i++){let x=i*w/14;g.beginPath();g.moveTo(x,h*.45);g.lineTo(x,h*.47);g.stroke();}
  g.textAlign='center';g.font='700 12px monospace';g.fillStyle='#92fff1';g.fillText('CAMERA LINK  •  AZ '+Math.round(aim)+'°  EL '+Math.round(elev)+'°',w*.5,h*.26);
 }
 for(const target of tracks){const dur=Math.max(1,target.expires_at-target.started_at);const progress=clamp((now()-target.started_at)/dur,0,1);let x,y,scale;
 if(cam){const da=angleDiff(target.az,aim),de=(target.el||42)-elev;x=w*.5+da/75*w*.59*zoom;y=h*.50-de/55*h*.35*zoom;scale=.9+progress*1.8;if(target.type==='drone')x+=Math.sin(t*.004+progress*20)*w*.025;}
 else{let delta=angleDiff(target.az,aim);x=w*.52+delta/145*w*.52;y=h*.15+progress*h*.41;scale=.8+progress*1.4;if(target.type==='drone')x+=Math.sin(t*.004+progress*20)*w*.025;}
 if(x<0||x>w||y<0||y>h)continue;
 enemySprite(g,x,y,scale,t,target.type||'normal');
 if(selectedTargetId===target.id){g.save();let p=23+scale*13+Math.sin(t*.008)*3;g.strokeStyle='#ffe8aa';g.lineWidth=2.5;g.shadowColor='#ffc078';g.shadowBlur=13;g.setLineDash([p*.45,p*.16]);g.beginPath();g.arc(x,y,p,0,Math.PI*2);g.stroke();g.setLineDash([]);g.restore();}
 }
 for(let i=shotFX.length-1;i>=0;i--){const fx=shotFX[i],p=clamp((t-fx.at)/1080,0,1);if(p>=1){shotFX.splice(i,1);continue;}
 const sx=cam?w*.50:w*.61,sy=cam?h*.88:h*.63;let endX=cam?w*.50:w*.53+angleDiff(fx.targetAz,aim)/160*w*.45,endY=cam?h*.5:h*.3;
 let q=1-Math.pow(1-p,2),x=sx+(endX-sx)*q,y=sy+(endY-sy)*q;
 const trail=g.createLinearGradient(sx,sy,x,y);trail.addColorStop(0,'rgba(124,231,255,0)');trail.addColorStop(.75,'rgba(112,245,252,.38)');trail.addColorStop(1,'#e7ffff');g.strokeStyle=trail;g.lineWidth=4+5*(1-p);g.shadowColor='#70f7ff';g.shadowBlur=16;g.beginPath();g.moveTo(sx,sy);g.lineTo(x,y);g.stroke();g.shadowBlur=0;
 disk(g,x,y,5,'#fbfded','#b4feff');if(p>.83&&fx.success){const r=(p-.83)*320;g.save();g.globalAlpha=Math.max(0,1-(p-.83)*5);g.strokeStyle='#ffe7a2';g.lineWidth=6;g.beginPath();g.arc(endX,endY,r,0,Math.PI*2);g.stroke();g.restore();}
 }
 drawParticles(g,.016,w,h);drawV68ChaseCamera(g,w,h,t);drawV70OpticalPass(g,w,h,t);
 if(atmosphere.flash>0){g.fillStyle='rgba(255,225,190,'+Math.min(.24,atmosphere.flash*.45)+')';g.fillRect(0,0,w,h);atmosphere.flash*=.86;if(atmosphere.flash<.005)atmosphere.flash=0;}
 g.restore();}

function render(t){drawRadar(t);if(minister)scene(sg,t);requestAnimationFrame(render)}
function pickTarget(){
 const valid=tracks.filter(t=>t.status==='incoming'&&t.expires_at>now());
 return valid.find(t=>t.id===selectedTargetId)||valid.sort((a,b)=>Math.abs(angleDiff(aim,a.az))+Math.abs(elev-(a.el||40))-Math.abs(angleDiff(aim,b.az))-Math.abs(elev-(b.el||40)))[0]||null;
}
async function fire(){if(!minister)return;if(Date.now()-lastShotAt<1800){show('انتظر بين الطلقات',true);return;}const target=pickTarget();if(!target){show('مفيش صاروخ قادم حاليًا',true);return;}
const shotId=(crypto.randomUUID?crypto.randomUUID():'shot-'+Date.now()+'-'+Math.random());lastShotAt=Date.now();$('fire').disabled=true;
try{let result;if(demo){const accurate=Math.abs(angleDiff(aim,target.az))<=18&&Math.abs(elev-(target.el||42))<=14 && target.type!=='decoy';mock.balance-=accurate?500:2500;if(accurate){atmosphere.intercepts++;atmosphere.waveHits++;atmosphere.combo++;atmosphere.bestCombo=Math.max(atmosphere.combo,atmosphere.bestCombo);mock.treasury+=2000;mock.citizenRewards+=500;mock.tracks=mock.tracks.filter(x=>x.id!==target.id);if(mock.alert&&mock.alert.trackId===target.id){mock.alert=null;alertPhase={active:false,accelerated:false,speed_multiplier:1};$('mockClickNotification')?.classList.add('hide');}}if(!accurate){atmosphere.combo=0;}result={ok:true,hit:accurate,points:mock.balance,treasury:mock.treasury,notice:accurate?'اعتراض ناجح! مستخدم الدبابة +1500 والدولة +2000 وكل مواطن +500':'أخطأت الهدف: تكلفة الإطلاق 2000 وغرامة إضافية 500'};}
else result=await fetchData('/api/air-defense/fire',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({request_id:shotId,target_id:target.id,az:Math.round(normalize(aim)),el:Math.round(elev)})});
balance=result.points;treasury=result.treasury;shotFX.push({at:performance.now(),dir:aim,targetAz:target.az,success:result.hit,kind:target.type});if(followShot)show('🎥 كاميرا تتبع الصاروخ');sfx('fire');if(result.hit)setTimeout(()=>{const box=sc.getBoundingClientRect();spawnBurst(box.width*.50,box.height*(cam?.5:.29),'#ffd182',32);},760);show(result.notice);if(result.hit)selectedTargetId=null;if(!demo)await refresh();else{tracks=mock.tracks;updateUI();}}
catch(e){show(e.message,true);}finally{$('fire').disabled=false;}}
async function emergency(){if(!minister||emergencySending)return;if(!demo && !confirm('إرسال إنذار عاجل داخل لعبة ZANGAR لجميع الحسابات وإشعارات المشتركين؟'))return;emergencySending=true;$('emergency').disabled=true;try{if(demo){
  const t=Date.now(),trackId='emergency-practice-'+t;
  mock.alert={trackId,createdAt:t,end:t+600000,accelerated:false};mock.tracks=[{id:trackId,az:115,el:46,type:'alert',facility:'مركز المدينة',started_at:t,expires_at:t+600000,status:'incoming'}];
  tracks=mock.tracks;alertPhase=mockState().alert;selectedTargetId=null;updateUI();sfx('alert');
  $('mockClickNotification')?.classList.remove('hide');
  show('🚨 إرسال إنذار تدريبي: 10 دقائق لو محدش فتح إشعار الموبايل');
 }else{const r=await fetchData('/api/air-defense/emergency',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({request_id:(crypto.randomUUID?crypto.randomUUID():'alert-'+Date.now()+'-111111111')})});show('تم إرسال الإنذار داخل اللعبة إلى '+r.recipients+' حسابًا.');}}catch(e){show(e.message,true)}finally{emergencySending=false;$('emergency').disabled=false}}

function bindHold(id,dx,dy){let button=$(id),timer=null;const action=()=>aimStep(dx*(1+Number(upgrades.turret||0)*.24),dy*(1+Number(upgrades.turret||0)*.24));button.addEventListener('pointerdown',e=>{if(!minister)return;e.preventDefault();button.setPointerCapture(e.pointerId);action();timer=setInterval(action,105)});for(const event of ['pointerup','pointercancel','lostpointercapture'])button.addEventListener(event,()=>{clearInterval(timer);timer=null;});}
bindHold('aimLeft',-4,0);bindHold('aimRight',4,0);bindHold('aimUp',0,4);bindHold('aimDown',0,-4);
$('fire').addEventListener('click',fire);$('emergency').addEventListener('click',emergency);$('camera').addEventListener('click',()=>{if(!minister)return;cam=!cam;updateUI()});
// V70 command entry is INSIDE the public radar. Never authorize only by a browser flag.
async function openCommandGate(){
 if(minister)return;
 if(!demo){try{
  const access=await fetchData('/api/air-defense/state');
  if(access.minister){observerOverride=false;await refresh();show('✅ صلاحية القيادة محفوظة على حسابك');return;}
 }catch(_){/* show the code field if not currently authorized */}}
 else if(localStorage.getItem('zangar_v711_training_command')==='1'){
  observerOverride=false;minister=true;updateUI();show('✅ وضع التدريب محفوظ على هذا الجهاز');return;
 }
 $('warGate').classList.remove('hide');$('warError').textContent='';$('warCode').value='';$('warCode').focus();
}
function closeCommandGate(){$('warGate').classList.add('hide');$('warCode').value='';$('warError').textContent='';}
$('enterWar').addEventListener('click',openCommandGate);
$('warClose').addEventListener('click',closeCommandGate);
$('warGate').addEventListener('pointerdown',e=>{if(e.target===$('warGate'))closeCommandGate();});
$('warGateForm').addEventListener('submit',async e=>{
 e.preventDefault();const code=$('warCode').value.trim();const btn=$('warSubmit');
 if(!/^[0-9]{9}$/.test(code)){$('warError').textContent='الرمز مكوّن من تسعة أرقام';return;}
 btn.disabled=true;$('warError').textContent='جارٍ التحقق من رمز الدخول...';
 try{
  if(demo){let n=2166136261;for(const ch of code)n=Math.imul(n^ch.charCodeAt(0),16777619)>>>0;if(n!==1304893400)throw Error('الرمز السري غير صحيح');try{localStorage.setItem('zangar_v711_training_command','1');}catch(_){}observerOverride=false;minister=true;cam=false;updateUI();}
  else {await fetchData('/api/air-defense/unlock',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({pin:code})});observerOverride=false;await refresh();if(!minister)throw Error('افتح لوحة القيادة بالرمز الصحيح من حسابك');}
  closeCommandGate();show('✅ تم فتح مركز قيادة الدفاع');
 }catch(ex){$('warError').textContent=ex.message||'تعذر فتح القيادة';}
 finally{btn.disabled=false;}
});
$('returnRadar').addEventListener('click',async()=>{
 // View mode only. Do NOT revoke the code entitlement when the user visits the public radar.
 observerOverride=true;minister=false;cam=false;zoom=1;nightVision=false;updateUI();
 show('📡 وضع المشاهدة — افتح «دخول الحرب» للعودة للقيادة بدون إعادة كتابة الكود');
});
$('zoomMode').addEventListener('click',()=>{if(!minister||!cam)return;zoom=zoom===1?2:zoom===2?3:1;$('zoomMode').textContent='🔎 ×'+zoom;show('تكبير المنظار ×'+zoom);});
$('nightMode').addEventListener('click',()=>{if(!minister||!cam)return;nightVision=!nightVision;$('nightMode').textContent=nightVision?'☀️ رؤية عادية':'🌙 رؤية ليلية';show(nightVision?'تم تشغيل الرؤية الليلية':'الرؤية العادية');});
rad.addEventListener('pointerdown',e=>{if(!minister)return;let r=rad.getBoundingClientRect(),cx=r.width/2,cy=r.height/2,x=e.clientX-r.left-cx,y=e.clientY-r.top-cy,R=Math.min(r.width,r.height)*.475;
let best=null,dist=Infinity;for(const target of tracks){const p=clamp((now()-target.started_at)/(target.expires_at-target.started_at),0,1),radius=R*(.86-.7*p),tx=Math.sin(target.az*D)*radius,ty=-Math.cos(target.az*D)*radius,dd=Math.hypot(tx-x,ty-y);if(dd<dist){best=target;dist=dd;}}
if(best&&dist<Math.max(26,R*.18)){selectedTargetId=best.id;aim=normalize(best.az);elev=clamp(best.el||40,5,83);show('🎯 الهدف مثبت — اضغط FIRE');}else if(Math.hypot(x,y)>10){aim=normalize(Math.atan2(x,-y)/D);selectedTargetId=null;show('تم توجيه المدفع — حدد الارتفاع أو اضغط على الصاروخ');}updateUI();});

let start=null;sc.addEventListener('pointerdown',e=>{if(!minister)return;start={x:e.clientX,y:e.clientY,a:aim,b:elev};sc.setPointerCapture(e.pointerId)});sc.addEventListener('pointermove',e=>{if(!minister||!start)return;aim=normalize(start.a+(e.clientX-start.x)*.36);elev=clamp(start.b-(e.clientY-start.y)*.21,5,83);updateUI()});['pointerup','pointercancel'].forEach(e=>sc.addEventListener(e,()=>start=null));
window.addEventListener('keydown',e=>{if(!minister)return;const map={ArrowLeft:[-3,0],ArrowRight:[3,0],ArrowUp:[0,3],ArrowDown:[0,-3]};if(map[e.key]){e.preventDefault();aimStep(...map[e.key])}if(e.code==='Space'){e.preventDefault();fire()}if(e.key==='c'||e.key==='C'){$('camera').click()}});

// V67 mission HUD: no fake actual battle outcomes are presented in the public live mode.
const originalUI=updateUI;
updateUI=function(){originalUI();const count=tracks.filter(t=>t.expires_at>now()).length;
 const threat=$('threats');if(threat)threat.textContent=String(count);
 const pubThreat=$('pubThreats');if(pubThreat)pubThreat.textContent=String(count).padStart(2,'0');
 const wave=$('wave');if(wave)wave.textContent=demo?String(Math.max(1,atmosphere.wave)): 'LIVE';
 const city=$('cityHealth');if(city)city.textContent=(demo?atmosphere.cityHp:(cityState.hp??100))+'%';
 const bar=$('cityFill');if(bar)bar.style.width=(demo?atmosphere.cityHp:(cityState.hp??100))+'%';
 const stat=$('pubStatus');if(stat)stat.textContent=count?'تهديدات مرصودة':'المجال آمن';
 const combo=$('combo');if(combo)combo.textContent=demo?String(atmosphere.combo):'—';const stars=$('waveStars');if(stars)stars.textContent=demo?('★'.repeat(atmosphere.stars)+'☆'.repeat(3-atmosphere.stars)):'—';
};
$('soundBtn')?.addEventListener('click',()=>{atmosphere.muted=!atmosphere.muted;$('soundBtn').textContent=atmosphere.muted?'🔇':'🔊';show(atmosphere.muted?'الصوت مغلق':'الصوت يعمل');});
$('lockOn')?.addEventListener('click',()=>{if(!minister||lockBusy)return;const valid=tracks.filter(v=>v.expires_at>now()).sort((a,b)=>a.expires_at-b.expires_at);if(!valid.length){show('لا توجد أهداف الآن',true);return;}const target=valid[0];lockBusy=true;$('lockOn').textContent='◌ جاري التثبيت';const delay=Math.max(180,850-Number(upgrades.lock||0)*205);clearTimeout(lockTimer);lockTimer=setTimeout(()=>{lockBusy=false;$('lockOn').textContent='◎ تثبيت الهدف';if(!tracks.some(x=>x.id===target.id&&x.expires_at>now())){show('انتهى الوقت قبل التثبيت',true);return;}selectedTargetId=target.id;aim=normalize(target.az);elev=clamp(target.el||40,5,83);updateUI();sfx('lock');show('🎯 تم قفل الهدف — جاهز للإطلاق');},delay);});
let lastHudTick=0;function hudTick(t){if(t-lastHudTick>520){lastHudTick=t;const tg=currentTarget();const tm=$('timeLeft');if(tm){const ms=tg?Math.max(0,tg.expires_at-now()):0;tm.textContent=tg?(ms>=60000?Math.floor(ms/60000)+':'+String(Math.floor(ms/1000)%60).padStart(2,'0'):Math.ceil(ms/1000)+'s'):'—';}const al=$('alertBadge');if(al){const active=alertPhase?.active&&(!alertPhase.expires_at||alertPhase.expires_at>now());al.textContent=active?(alertPhase.accelerated?'🚨 خطر فوري ×5 • 15 ثانية':'⚠️ إنذار حي • مهلة 10 دقائق'):'📡 وضع المراقبة';al.classList.toggle('critical',!!(active&&alertPhase.accelerated));}const fi=$('facilityMini');if(fi)fi.textContent=demo?defenseFacilities.map(x=>x.icon+x.hp+'%').join('   '):(cityState.facilities||[]).map(x=>x.name+' '+x.hp+'%').join(' | ');
 const v=$('pubCountdown'),sp=$('pubSpeed');if(v){const target=tracks.filter(x=>x.expires_at>now()).sort((a,b)=>a.expires_at-b.expires_at)[0];const remaining=Math.max(0,(target?.expires_at||0)-now());v.textContent=target?(remaining>60000?Math.floor(remaining/60000)+':'+String(Math.floor(remaining/1000)%60).padStart(2,'0'):Math.ceil(remaining/1000)+' ثانية'):'—';}if(sp)sp.textContent=alertPhase?.accelerated?'⚡ السرعة ×5 • خطر عاجل':alertPhase?.active?'🕒 مهلة حتى 10 دقائق':'السرعة عادية';}requestAnimationFrame(hudTick);}requestAnimationFrame(hudTick);



// ===== V68 cinematic effects, facility defense, upgrades, linked notification test =====
function drawV68Sky(g,w,h,t){
  const mode=demo?(['sunset','rain','night','fog'][Math.floor(Math.max(0,atmosphere.wave-1)/2)%4]):alertPhase?.accelerated?'night':'sunset';
  if(mode==='night'){
    g.fillStyle='rgba(7,15,35,.55)';g.fillRect(0,0,w,h);
    const cx=w*.78,cy=h*.16;g.fillStyle='#f8f7da';g.shadowColor='#bdf0ff';g.shadowBlur=24;g.beginPath();g.arc(cx,cy,19,0,TAU);g.fill();g.shadowBlur=0;
    for(let i=0;i<23;i++){let x=((i*431+23)%1013)/1013*w,y=((i*67+17)%259)/600*h;g.fillStyle='rgba(224,247,255,'+(.3+.3*Math.sin(t/480+i)**2)+')';g.fillRect(x,y,1.8,1.8);}
  } else if(mode==='rain'){
    g.fillStyle='rgba(13,34,57,.22)';g.fillRect(0,0,w,h);g.strokeStyle='rgba(173,214,232,.25)';g.lineWidth=1;
    for(let i=0;i<55;i++){let x=(i*71+t*.2)%(w+30),y=(i*137+t*.41)%(h+50);g.beginPath();g.moveTo(x,y);g.lineTo(x-7,y+16);g.stroke();}
  } else if(mode==='fog'){g.fillStyle='rgba(204,219,223,.16)';g.fillRect(0,h*.16,w,h*.62);}
  if(alertPhase?.active&&alertPhase.accelerated){g.save();g.fillStyle='rgba(255,39,71,'+(.07+.06*Math.sin(t*.012)**2)+')';g.fillRect(0,0,w,h);g.restore();}
}
function drawV68FacilityMarkers(g,w,h){
 if(!demo)return;g.save();const centers=[.19,.37,.62,.80];
 defenseFacilities.forEach((f,i)=>{const x=w*centers[i],y=h*.75;i===0&&0;
   g.fillStyle=f.hp>40?'rgba(28,68,76,.8)':'rgba(107,39,43,.85)';g.beginPath();g.roundRect(x-15,y-23,30,24,4);g.fill();
   g.fillStyle=f.hp>40?'#9cebd0':'#ff827b';g.fillRect(x-12,y-29,24*Math.max(.02,f.hp/100),3);
   g.font='bold 12px system-ui';g.textAlign='center';g.fillText(f.icon,x,y-32);
   if(f.hp<45){g.globalAlpha=.32;g.fillStyle='#c5ced0';g.beginPath();g.ellipse(x+6,y-45,7,12,0,0,TAU);g.fill();g.globalAlpha=1;}
 });g.restore();
}
function drawV68ChaseCamera(g,w,h,t){
 if(!followShot||!minister||!shotFX.length)return;
 const s=shotFX[shotFX.length-1],p=clamp((t-s.at)/1080,0,1);
 if(p>=1)return;
 g.save();g.fillStyle='rgba(3,12,25,.15)';g.fillRect(0,0,w,h);
 let x=w*(.5+.11*Math.sin(p*PI)),y=h*(.65-.28*p),r=12+20*p;
 g.translate(x,y);g.rotate(-PI*.45+p*.28);g.shadowColor='#ffb773';g.shadowBlur=18;
 g.fillStyle='#f5cc9a';g.beginPath();g.moveTo(-r*.9,-r*.32);g.lineTo(r*.95,0);g.lineTo(-r*.9,r*.32);g.closePath();g.fill();
 g.fillStyle='#e57947';g.beginPath();g.moveTo(-r*.85,-r*.22);g.lineTo(-r*1.9,0);g.lineTo(-r*.85,r*.22);g.closePath();g.fill();g.shadowBlur=0;g.restore();
 g.fillStyle='#caf9fb';g.textAlign='left';g.font='bold 12px system-ui';g.fillText('◉ MISSILE CAM  •  '+Math.round(p*100)+'%',w*.08,h*.2);
}
function practiceAlertClicked(){
 if(!demo||!mock.alert||mock.alert.accelerated||mock.alert.end<=Date.now())return;
 const t=Date.now(),track=mock.tracks.find(x=>x.id===mock.alert.trackId);if(!track)return;
 const p=clamp((t-track.started_at)/(track.expires_at-track.started_at),0,.95);
 track.started_at=t-Math.min(90000,Math.floor(p*15000/(1-p)));
 track.expires_at=t+15000;mock.alert.end=t+15000;mock.alert.accelerated=true;
 alertPhase={active:true,accelerated:true,speed_multiplier:5,expires_at:mock.alert.end};
 $('mockClickNotification')?.classList.add('hide');sfx('alert');show('🚨 مواطن فتح إشعار الهاتف! السرعة ×5 • 15 ثانية للاعتراض');updateUI();
}
$('mockClickNotification')?.addEventListener('click',practiceAlertClicked);
$('followBtn')?.addEventListener('click',()=>{if(!minister)return;followShot=!followShot;$('followBtn').textContent=followShot?'🎥 التتبع: يعمل':'🎥 تتبع الصاروخ';show(followShot?'الكاميرا هتتبع الصاروخ عند الإطلاق':'تم إيقاف التتبع');});
$('facilityBtn')?.addEventListener('click',()=>{if(!minister)return;const f=$('facilityPanel');f?.classList.toggle('hide');const list=$('facilityStats');if(list)list.textContent=(demo?defenseFacilities:cityState.facilities||[]).map(x=>x.name+' '+x.hp+'%').join(' • ');});
$('closeFacility')?.addEventListener('click',()=>$('facilityPanel')?.classList.add('hide'));
$('upgradeBtn')?.addEventListener('click',()=>{if(!minister)return;renderUpgradeList();$('upgradePanel')?.classList.remove('hide');});
$('closeUpgrade')?.addEventListener('click',()=>$('upgradePanel')?.classList.add('hide'));
function renderUpgradeList(){const panel=$('upgradeList');if(!panel)return;panel.innerHTML='';
 const map={turret:['⚙️ تدوير البرج',3000,'توجيه أسرع'],radar:['📡 رادار أقوى',4500,'مساحة رصد أوضح'],lock:['🎯 تثبيت سريع',4000,'تقليل زمن القفل'],shield:['🛡️ حماية المنشآت',5500,'تقليل ضرر المدينة (تدريب فقط)']};
 for(const [kind,[name,cost,desc]] of Object.entries(map)){
  if(!demo&&kind==='shield')continue;
  const level=Number((demo?mock.upgrades:upgrades)[kind]||0),maxed=level>=3;
  const card=document.createElement('div');card.className='upgradeItem';
  const label=document.createElement('div'),btn=document.createElement('button');label.innerHTML='<b>'+name+'</b><small>'+desc+' • مستوى '+level+'/3</small>';
  btn.type='button';btn.disabled=maxed||upgradeBusy;btn.textContent=maxed?'مكتملة':'ترقية • '+((level+1)*cost).toLocaleString('ar-EG');
  btn.addEventListener('click',()=>purchaseUpgrade(kind,level+1,cost));card.append(label,btn);panel.append(card);
 }
}
async function purchaseUpgrade(kind,level,base){if(upgradeBusy||!minister)return;upgradeBusy=true;renderUpgradeList();try{
 if(demo){const cost=level*base;if(mock.balance<cost)throw Error('الرصيد التجريبي لا يكفي');mock.balance-=cost;mock.upgrades[kind]=level;upgrades=mock.upgrades;balance=mock.balance;}
 else {const reply=await fetchData('/api/air-defense/upgrade',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({request_id:(crypto.randomUUID?crypto.randomUUID():'upgrade-'+Date.now()),kind})});upgrades=reply.upgrades||{};balance=reply.points;}
 updateUI();show('✅ تم تطوير '+kind+' إلى المستوى '+level);
 }catch(e){show(e.message,true)}finally{upgradeBusy=false;renderUpgradeList();}
}
// Alert links opened after a successful page-pin entry work as a fallback to the SW click path.
async function openedAlertFallback(){if(demo)return;const u=new URL(location.href);const event=u.searchParams.get('alert'),key=u.searchParams.get('key');if(!event||!key)return;
 try{const state=await fetchData('/api/air-defense/alert/open',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({event,key})});
 if(state.alert?.active){alertPhase=state.alert;show(state.triggered?'🚨 تم تفعيل الاستجابة: سرعة ×5 • 15 ثانية':'تم فتح إنذار الدفاع الجوي');await refresh();}
 }catch(e){/* SW click or unauthenticated visitors don't unlock anything. */}
 finally{history.replaceState(null,'',location.pathname);}
}
openedAlertFallback();

if(demo)root.classList.add('is-demo');requestAnimationFrame(render);refresh();setInterval(refresh,demo?1600:3000);
})();
