'use strict';
const $=id=>document.getElementById(id),esc=s=>String(s??'').replace(/[&<>"']/g,x=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[x]));
const fmt=n=>Number(n||0).toLocaleString('ar-EG'),when=n=>new Date(n).toLocaleString('ar-EG');
let state=null,busy=false,deadline=0,submitting=false;
async function post(x){const r=await fetch('/api/education/action',{method:'POST',headers:{'Content-Type':'application/json'},credentials:'same-origin',cache:'no-store',body:JSON.stringify(x)});const j=await r.json();if(!r.ok)throw Error(j.error||'حدث خطأ في الاتصال');return j;}
function note(s,err=false){$('notice').textContent=(err?'⚠️ ':'✅ ')+s;}
function timeText(ms){let t=Math.max(0,Math.ceil(ms/1000)),h=Math.floor(t/3600),m=Math.floor(t%3600/60),s=t%60;return [h,m,s].map(x=>String(x).padStart(2,'0')).join(':')}
async function refresh(){const r=await fetch('/api/education/state',{credentials:'same-origin',cache:'no-store'});const d=await r.json();if(!r.ok)throw Error(d.error||'تعذر فتح الامتحانات');state=d;draw();}
function draw(){const d=state;if(!d)return;const exam=d.exam,attempt=d.attempt;const active=exam&&d.now<exam.closes_at;
$('period').innerHTML=`<span>الدورة رقم ${fmt(d.period.cycle+1)}</span><span class="badge">نهاية الدورة: ${when(d.period.closes_at)}</span>`;
$('publishArea').hidden=!d.canPublish||!!exam;
$('reviewArea').hidden=!d.canReview;
if(d.canPublish&&!exam)buildMinister();
if(!exam){$('examContent').innerHTML='<p class="muted">لم ينشر وزير التعليم امتحان هذه الدورة بعد. سيظهر للجميع عند نشره.</p>';deadline=0;}
else if(!attempt){deadline=0;$('examContent').innerHTML=`<p>الامتحان منشور ويحتوي على ${exam.questions.length} أسئلة. عند الضغط على بدء يبدأ عدّاد 20 دقيقة ولا يمكن إعادة المحاولة بعد تسليمها.</p><p class="muted">آخر وقت للتسليم: ${when(exam.closes_at)}</p><button class="btn primary" id="startExam" ${!active?'disabled':''}>${active?'📝 بدء الامتحان':'انتهت الدورة'}</button>`;}
else if(!attempt.submitted_at){deadline=attempt.deadline;const qs=exam.questions;
$('examContent').innerHTML=`<div class="rowline"><strong>الوقت المتبقي</strong><span class="timer" id="timer">${timeText(deadline-Date.now())}</span></div><form id="studentForm">${qs.map((q,i)=>`<div class="q"><strong>${i+1}. ${esc(q.text)}</strong>${q.type==='choice'?`<div class="choices">${q.options.map((v,j)=>`<label><input type="radio" name="q${i}" value="${j}"> ${esc(v)}</label>`).join('')}</div>`:`<label>إجابتك المقالية<input type="text" name="q${i}" maxlength="350" placeholder="اكتب الإجابة هنا"></label>`}</div>`).join('')}<div class="actionbar"><button class="btn primary" type="submit">تسليم الإجابات النهائية</button></div></form>`;
for(let i=0;i<qs.length;i++){const inp=$('studentForm').elements.namedItem('q'+i),saved=attempt.answers[i];if(!inp||saved==null)continue;if(qs[i].type==='essay')inp.value=saved;else{let el=$('studentForm').querySelector(`[name="q${i}"][value="${saved}"]`);if(el)el.checked=true;}}
}else{deadline=0;$('examContent').innerHTML=`<div class="notice"><h3>✅ تم تسليم الامتحان</h3><div class="rowline"><strong>الدرجة بالزنجر</strong><strong class="${attempt.score>=0?'good':'bad'}">${fmt(attempt.score)}</strong></div><div class="rowline"><span>الإجابات الصحيحة</span><b>${attempt.correct} من ${exam.questions.length}</b></div><div class="rowline"><span>الإجابات الخاطئة</span><b>${attempt.wrong}</b></div><p class="muted">إذا وجدت خطأً في نموذج الإجابة قدّم اعتراضًا برقم السؤال.</p>${(attempt.results||[]).map(x=>`<p>${x.correct?'✅':'❌'} سؤال ${x.question_no} — الإجابة النموذجية: <b>${esc(x.answer)}</b></p>`).join('')}</div>`;}
const appeals=d.appeals||[];
$('appeals').innerHTML=appeals.filter(x=>!d.canReview||x.citizen_name==null).slice(0,12).map(x=>`<div class="q"><strong>السؤال ${x.question_no}</strong><br><small>${esc(x.reason)}</small><p class="badge">${x.status==='pending'?'تحت المراجعة':x.status==='accepted'?'قُبلت الشكوى':'رُفضت الشكوى'}</p>${x.reply?`<p>${esc(x.reply)}</p>`:''}</div>`).join('')||'<p class="muted">لا توجد شكاوى خاصة بك هنا.</p>';
$('reviewList').innerHTML=d.canReview?appeals.filter(x=>x.status==='pending').map(x=>`<div class="q"><strong>${esc(x.citizen_name)} — السؤال ${x.question_no}</strong><p>${esc(x.reason)}</p><button type="button" class="btn gold" data-review="${esc(x.id)}">قبول وتصحيح</button> <button type="button" class="btn" data-reject="${esc(x.id)}">رفض الاعتراض</button></div>`).join('')||'<p class="muted">لا توجد شكاوى بانتظار قرار.</p>':'';
}
function buildMinister(){const wrapper=$('ministerQuestions');if(wrapper.children.length)return;wrapper.innerHTML=Array.from({length:5},(_,i)=>`<div class="q" data-minister="${i}"><strong>السؤال ${i+1}</strong><label>نوع السؤال<select class="q-type"><option value="choice">اختياري</option><option value="essay">مقالي</option></select></label><label>نص السؤال<textarea class="q-text" rows="2" maxlength="340" required placeholder="اكتب السؤال"></textarea></label><div class="q-choice"><label>الاختيارات الأربعة (اختر الإجابة الصحيحة)</label>${[0,1,2,3].map(j=>`<label><input type="radio" name="correct${i}" value="${j}" ${j===0?'checked':''}> <input class="choice-input" type="text" maxlength="180" placeholder="الاختيار ${j+1}"></label>`).join('')}</div><div class="q-essay exam-hidden"><label>الإجابة النموذجية للمقالي<input class="answer-input" type="text" maxlength="180" placeholder="الإجابة المقبولة حرفيًا بعد التنظيف"></label></div></div>`).join('');}
function collectAnswers(){const qs=state.exam.questions,f=$('studentForm');return qs.map((q,i)=>{if(q.type==='choice'){let x=f.querySelector(`input[name="q${i}"]:checked`);return x?Number(x.value):null;}return f.elements.namedItem('q'+i)?.value.trim()||'';});}
async function finish(){if(submitting||!$('studentForm'))return;submitting=true;try{const r=await post({type:'submit',answers:collectAnswers()});note(r.notice);await refresh();}catch(e){note(e.message,true);}finally{submitting=false;}}
setInterval(()=>{if(!deadline)return;const ms=deadline-Date.now(),el=$('timer');if(el)el.textContent=timeText(ms);if(ms<=0){deadline=0;if($('studentForm'))finish();}},1000);
document.addEventListener('change',e=>{if(!e.target.classList.contains('q-type'))return;const c=e.target.closest('[data-minister]');c.querySelector('.q-choice').classList.toggle('exam-hidden',e.target.value!=='choice');c.querySelector('.q-essay').classList.toggle('exam-hidden',e.target.value!=='essay');});
document.addEventListener('click',async e=>{
 const rejected=e.target.closest('[data-reject]');if(rejected){try{const reason=prompt('سبب رفض الاعتراض (8 حروف على الأقل):');if(!reason||reason.trim().length<8)return;if(!confirm('تأكيد رفض الشكوى وتسجيل السبب؟'))return;const r=await post({type:'review',appeal_id:rejected.dataset.reject,approve:false,reply:reason.trim(),fine_amount:0});note(r.notice);await refresh();}catch(err){note(err.message,true)}return;}
 if(e.target.id==='startExam'){try{const r=await post({type:'start'});note(r.notice);await refresh();}catch(err){note(err.message,true)}}
 const b=e.target.closest('[data-review]');if(!b)return;try{
  const d=await post({type:'appealDetail',appeal_id:b.dataset.review});const a=d.appeal;
  if(!confirm(`السؤال: ${d.question}\nإجابة المواطن: ${d.answer}\nالإجابة النموذجية: ${d.model_answer}\nالشكوى: ${a.reason}\n\nموافق = قبول الشكوى، إلغاء = لا تصدر قرارًا`))return;
  const reply=prompt('اكتب سبب قبول الشكوى (8 حروف على الأقل):','بعد مراجعة نموذج الإجابة تبين وجود خطأ في التصحيح');if(!reply||reply.trim().length<8)return;
  const fin=prompt('حدد غرامة وزير التعليم من 1 إلى 3000 زنجر (قرار رئاسي):','100');if(fin===null)return;
  const amount=Number(fin);if(!Number.isInteger(amount)||amount<1||amount>3000){note('الغرامة يجب أن تكون 1 إلى 3000',true);return;}
  if(!confirm('تأكيد قبول الشكوى وزيادة 600 زنجر للمواطن وخصم الغرامة المسجلة من الوزير؟'))return;
  const out=await post({type:'review',appeal_id:b.dataset.review,approve:true,reply:reply.trim(),fine_amount:amount});note(out.notice);await refresh();
 }catch(err){note(err.message,true)}
});
document.addEventListener('submit',async e=>{const f=e.target;if(!['studentForm','ministerForm','appealForm'].includes(f.id))return;e.preventDefault();if(busy)return;busy=true;try{
 if(f.id==='studentForm'){await finish();}
 if(f.id==='ministerForm'){
  const questions=Array.from(document.querySelectorAll('[data-minister]')).map(c=>{const type=c.querySelector('.q-type').value,text=c.querySelector('.q-text').value.trim();if(type==='choice')return {text,type,options:Array.from(c.querySelectorAll('.choice-input')).map(x=>x.value.trim()),answer:Number(c.querySelector('input[type=radio]:checked')?.value??0)};return {text,type,answer:c.querySelector('.answer-input').value.trim()};});
  if(!confirm('تأكيد نشر الامتحان للدورة الحالية؟ لا يمكن تغيير الإجابات بعد النشر إلا عبر الاعتراض.'))return;
  const r=await post({type:'publish',questions});note(r.notice);await refresh();
 }
 if(f.id==='appealForm'){const v=Object.fromEntries(new FormData(f));const r=await post({type:'appeal',question_no:Number(v.question_no),reason:v.reason.trim()});note(r.notice);f.reset();await refresh();}
 }catch(err){note(err.message,true)}finally{busy=false;}});
refresh().then(()=>note('البيانات متصلة ✅')).catch(e=>note(e.message,true));
