/* The president gate is verified on the SERVER on every request, never by this button. */
document.addEventListener('click',async event=>{
 const b=event.target.closest('[data-z65-delete-id]');if(!b)return;
 event.preventDefault();event.stopImmediatePropagation();
 const id=b.dataset.z65DeleteId,name=b.dataset.z65DeleteName||'هذا الحساب';
 const reason=prompt('سبب حذف حساب «'+name+'» من الدولة (5 حروف على الأقل):');
 if(reason===null)return;if(reason.trim().length<5){alert('اكتب سببًا لا يقل عن 5 حروف');return}
 if(!confirm('تأكيد حذف «'+name+'» من قائمة المواطنين وإبطال جلساته وتحرير Guest الخاص به؟\nسيتاح الاسترجاع من لوحة V64.'))return;
 b.disabled=true;
 try{
  const r=await fetch('/api/z64/action',{method:'POST',credentials:'same-origin',headers:{'Content-Type':'application/json'},body:JSON.stringify({type:'account_archive',user_id:id,reason:reason.trim().slice(0,180),confirm:'ARCHIVE'})});
  const v=await r.json();if(!r.ok||v.ok===false)throw Error(v.message||v.error||'تعذّر حذف الحساب');
  alert('تم حذف الحساب من الدولة وتحرير مكانه. سيتم تحديث العدد الآن.');location.reload();
 }catch(e){alert('لم يتم الحذف: '+e.message);b.disabled=false}
},true);
