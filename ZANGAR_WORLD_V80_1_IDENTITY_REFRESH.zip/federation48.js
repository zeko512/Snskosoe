'use strict';
// Update 49: two-step presidency gate, central military support, secure transactions. All monetary actions and permissions are decided on the server.
const $=id=>document.getElementById(id);
const esc=x=>String(x??'').replace(/[&<>"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));
const num=n=>Number(n||0).toLocaleString('ar-EG');
const day=t=>new Date(t).toLocaleString('ar-EG');
const symbols={home:'🏛️',oasis:'🌴',mountains:'⛰️',falcons:'🦅',islands:'🏝️',sands:'🏜️',noor:'🌟',barq:'⚡'};
const tabNames=['overview','economy','people','army','development','provinces','manage','history','services'];
const fakeNames=['آدم','حسن','مروان','سامي','عمر','يوسف','كريم','زياد','نور','مالك','علي','فارس','ياسين','طه','رامي','محمود','عادل','سيف','هاني','إسلام','إبراهيم','طارق','خالد','محمد','أحمد','مصطفى','عبدالله','فادي','باسم','أيمن','شريف','حازم','معتز','مؤمن','كامل','عاصم','جمال','نبيل','رياض','أسامة','شادي','سليمان','عاطف','سمير','مازن','بلال','حسام','حمزة','حسين','مهند'];
const staffSurnames=['النجار','السيد','المنصوري','الشريف','عامر','فهمي','راشد','كمال','حمدي','الزهراني','توفيق','مراد','سالم','جابر','البكري','هاشم','يونس','رزق','عبدالرحمن','إسماعيل'];
let firstProvinceLoad=true;
let state=null,selected=new URL(location.href).searchParams.get('province')||'home',tab=(['army','development'].includes(new URL(location.href).searchParams.get('tab'))?new URL(location.href).searchParams.get('tab'):'overview'),busy=false,refreshing=null;
const province=id=>state?.provinces?.find(p=>p.id===id);
const residents=p=>p.id==='home'?(state?.member_count||[]).reduce((n,x)=>n+Number(x.num||0),0):Number(state?.member_count?.find(x=>x.province_id===p.id)?.num||0);
const canControl=p=>Boolean(p&&(p.can_manage||state?.admin));
// Generate idempotent action IDs even in WebViews lacking crypto.randomUUID.
function requestId(){
 if(typeof crypto!=='undefined'&&typeof crypto.randomUUID==='function')return crypto.randomUUID();
 if(typeof crypto==='undefined'||typeof crypto.getRandomValues!=='function')throw Error('متصفحك لا يدعم إنشاء رقم عملية آمن، استخدم Chrome محدثًا.');
 const b=new Uint8Array(16);crypto.getRandomValues(b);b[6]=(b[6]&15)|64;b[8]=(b[8]&63)|128;
 const h=Array.from(b,x=>x.toString(16).padStart(2,'0')).join('');
 return h.slice(0,8)+'-'+h.slice(8,12)+'-'+h.slice(12,16)+'-'+h.slice(16,20)+'-'+h.slice(20);
}

// Cloudflare D1 .all() returns {results:[...]}; renderers require arrays.
// Normalize older/cached API payloads too so one malformed collection never disables a tab.
const asRows=value=>Array.isArray(value)?value:(value&&typeof value==='object'&&Array.isArray(value.results)?value.results:[]);
const stateRowFields=['provinces','ledger','members','available_citizens','member_count'];
function normalizeState(data){if(!data||typeof data!=='object')throw Error('تعذر تحميل بيانات الاتحاد');for(const field of stateRowFields){data[field]=asRows(data[field]);}if(!data.provinces.length)throw Error('لم تصل بيانات المحافظات. حاول تحديث الصفحة.');return data;}

async function api(url,body){const r=await fetch(url,{credentials:'same-origin',cache:'no-store',...(body?{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify(body)}:{})});const d=await r.json();if(!r.ok||d.ok===false)throw Error(d.error||'حصل خطأ في الاتصال');return d;}
function notify(message,error=false){$('notice').textContent=(error?'⚠️ ':'✓ ')+message;$('notice').classList.toggle('err',error);}
function switchTab(name,scroll=true){
 if(!tabNames.includes(name))return;
 const changed=tab!==name;
 tab=name;
 document.querySelectorAll('.tab-view[data-view]').forEach(el=>{
  const active=el.dataset.view===name;
  el.hidden=!active;
  el.style.display=active?'grid':'none';
 });
 document.querySelectorAll('[data-tab]').forEach(el=>{const active=el.dataset.tab===name;el.classList.toggle('active',active);if(el.tagName==='BUTTON')el.setAttribute('aria-pressed',String(active));});
 if(changed&&state)renderActive();
 if(scroll)requestAnimationFrame(()=>document.querySelector(`.tab-view[data-view="${name}"]`)?.scrollIntoView({behavior:'smooth',block:'start'}));
}

function selectProvince(id){if(!province(id))return;selected=id;tab='overview';history.replaceState(null,'',location.pathname+'?province='+encodeURIComponent(id));render();document.getElementById('provinceDetail')?.scrollIntoView({behavior:'smooth',block:'start'});}
async function refresh(quiet=false){
 if(refreshing)return refreshing;
 refreshing=(async()=>{
  const [d,civic]=await Promise.all([api('/api/federation/state'),api('/api/z62/state')]);state=normalizeState(d);state.civic=civic;
  if(!new URL(location.href).searchParams.has('province')&&state.my_governor)selected=state.my_governor;
  if(!province(selected))selected=state.my_governor||'home';
  render();
  if(firstProvinceLoad){firstProvinceLoad=false;if(state.my_governor&&!new URL(location.href).searchParams.has('province'))requestAnimationFrame(()=>document.getElementById('provinceDetail')?.scrollIntoView({behavior:'smooth',block:'start'}));}
  if(!quiet)notify('تم تحديث بيانات الدول بنجاح');
 })();
 try{return await refreshing;}finally{refreshing=null;}
}
async function action(payload,confirmation){
 if(busy)return;
 if(confirmation&&!window.confirm(confirmation))return;
 busy=true;document.body.classList.add('operation-running');
 try{
  const out=await api('/api/federation/action',payload);
  // A succeeded transaction must never be reported as failed only because state refresh timed out.
  notify(out.notice||'تمت العملية بنجاح');
  try{if(refreshing)await refreshing;await refresh(true)}
  catch(e){console.warn('Transaction succeeded; state refresh deferred:',e);notify('تم حفظ العملية في السيرفر، لكن تحديث الرصيد اتأخر. اضغط تحديث قبل أي شراء جديد.',true)}
 }catch(e){notify(e.message,true)}finally{busy=false;document.body.classList.remove('operation-running')}
}
const panel=(title,body,desc='')=>`<article class="section-panel"><h2>${title}</h2>${desc?`<p class="muted">${desc}</p>`:''}${body}</article>`;
const kpi=(label,val,green=false)=>`<div class="kpi ${green?'green':''}"><span>${label}</span><strong>${val}</strong></div>`;
const cardButtons=()=>state.provinces.map(p=>`<button class="country-tile ${p.id===selected?'active':''}" type="button" data-province="${p.id}" aria-label="عرض ${esc(p.name)}"><span class="country-icon">${symbols[p.id]}</span><strong>${esc(p.name)}</strong><small>${p.id==='home'?'عاصمة الدولة':p.governor_name?'👑 '+esc(p.governor_name):'بانتظار تعيين محافظ'}</small><div class="country-micro"><span>💰 ${num(p.treasury)}</span><span>👥 ${num(residents(p)+(p.virtual_workers||0))}</span></div></button>`).join('');
function head(p){const home=p.id==='home';return `<div class="selected-banner"><div class="banner-main"><div class="banner-copy"><span class="overline">${home?'🇿🇳 عاصمة دولة الزنجر • بيانات موحّدة مع اللعبة الأصلية':'🏛️ محافظة إدارية في دولة الزنجر'}</span><h2>${symbols[p.id]} ${esc(p.name)}</h2><p>${home?'هذه هي دولة الزنجر الأصلية نفسها، بخزينتها وكل خدماتها ومواطنيها الحقيقيين.':p.governor_name?'المحافظ: '+esc(p.governor_name):'بانتظار تعيين الرئيس'}</p><span class="royal-role">${canControl(p)?'🏛️ إدارة المحافظة متاحة لك':'👁️ زيارة المحافظة • عرض فقط'}</span>${home?'<a class="btn primary capital-gateway" href="/state.html">🇿🇳 دخول اللعبة الرئيسية وكافة خدماتها ←</a>':''}${!home&&p.can_manage?'<button class="btn primary" type="button" data-tab="manage" data-focus="renameForm">🏷️ تغيير اسم المحافظة</button>':''}</div><div class="banner-seal"><img src="/assets/crest.svg" alt="شعار دولة الزنجر"></div></div><div class="banner-foot"><span>💰 الخزينة <strong>${num(p.treasury)}</strong></span><span>📈 الاقتصاد <strong>${num(p.economy)}</strong></span><span>👥 المواطنون <strong>${num(residents(p))}</strong></span><span>👷 العاملون <strong>${num(p.virtual_workers||0)}</strong></span></div></div>`;}
function overview(p){
 const civic=state?.civic?.provinces?.find(x=>x.id===p.id);
 const lead=p.id==='home'?'العاصمة الأصلية ومحافظات الدولة':'محافظة داخل دولة الزنجر الواحدة';
 let body=`<div class="highlight-panel"><span class="overline">${lead}</span><h2>مرحبًا بك في ${esc(p.name)}</h2><p>التنافس الآن على التنمية والخدمات وتحسين الاقتصاد، دون حروب بين المواطنين والمحافظات.</p><div class="actions">${p.id==='home'?'<a href="/state.html" class="btn primary">🏠 دخول الدولة الأصلية</a>':''}<button class="btn primary" data-tab="development">🏗️ التنمية والمجلس المحلي</button><button class="btn" data-tab="economy">💰 الاقتصاد</button><button class="btn" data-tab="people">👥 المواطنون</button><button class="btn" data-tab="army">🛡️ الجيش الوطني</button></div></div><div class="kpi-grid">${kpi('الخزينة',num(p.treasury),true)}${kpi('القوة الاقتصادية',num(p.economy))}${kpi('المواطنون',num(residents(p)))}${kpi('العاملون',num(p.virtual_workers||0))}${kpi('ترتيب المحافظة',civic?String(state.civic.provinces.findIndex(x=>x.id===p.id)+1)+'/8':'—')}${kpi('نقاط التنمية',num(civic?.score||0))}</div>`;
 body+=panel('🏛️ ملف المحافظة',`<p>المدينة الرئيسية: <b>${esc(civic?.capital||'')}</b> • المحافظ: <b>${esc(p.governor_name||'لم يُعيَّن بعد')}</b> • أعضاء المجلس: <b>${num(civic?.council?.length||0)}</b></p>`);
 body+=panel('💎 الإنتاج والميزانية',`<div class="work-cards"><div class="work-stat">المصروف الإداري اليومي<strong>4,000 زنجر</strong></div><div class="work-stat">دخل ساعة الإنتاج<strong>${num(p.virtual_hourly_amount)} زنجر</strong></div></div>`);
 $('overviewBody').innerHTML=body;
}
function economy(p){const home=p.id==='home',staff=p.virtual_workers||0;let html=panel('💰 المؤشرات الاقتصادية',`<div class="kpi-grid">${kpi('خزينة الدولة',num(p.treasury),true)}${kpi('القوة الاقتصادية',num(p.economy))}${kpi('مصروف الإدارة يوميًا','−4,000')}${kpi('إنتاج العاملين المتراكم',num(p.virtual_total||0),true)}</div><p class="muted">${home?'رصيد الخزينة المعروض هو رصيد خزينة اللعبة الأصلية نفسه، وليس نسخة منفصلة.':'الخزينة منفصلة عن محفظة الرئيس والمواطن، والدخل ينتقل إلى خزينة الدولة.'}</p>`);
 html+=panel('🏗️ دورة الإنتاج',`<div class="work-cards"><div class="work-stat">حالة العمال<strong>${p.virtual_on_shift?'🟢 الوردية نشطة':'🌙 راحة'}</strong><small>${home?'إنتاج مستمر كل ساعة':'ساعة عمل ثم ساعة راحة'}</small></div><div class="work-stat">الدخل عند اكتمال ساعة عمل<strong>${num(p.virtual_hourly_amount)} زنجر</strong><small>${num(staff)} موظفًا • ${num(p.virtual_individual_hourly)} زنجر لكل موظف</small></div></div>`);
 html+=panel('🏦 البنوك والتجارة',`<div class="links-grid"><a href="/state.html">🏠 الدولة الرئيسية</a><a href="/economy46.html">📊 التحليل الاقتصادي</a><a href="/loans44.html">💳 القروض</a></div>`);
 if(canControl(p))html+=panel('🏗️ مشروعات '+esc(p.name),`<p>كل مشروع يُموّل من خزينة الدولة ويضيف إيرادات مستقبلية.</p><div class="actions">${[['farm','🌾 مزرعة','8,000 / ربح يومي 500'],['factory','🏭 مصنع','15,000 / ربح يومي 1,100'],['port','⚓ مركز تجاري','30,000 / ربح يومي 1,900']].map(([k,label,detail])=>`<button class="btn" type="button" data-invest="${k}">${label} · <small>${detail}</small></button>`).join('')}</div>`);
 $('economyBody').innerHTML=html;
}
function citizen(p){const member=p.id===state.my_province,staff=Number(p.virtual_workers||0),rate=Number(p.virtual_individual_hourly||0),perPerson=Math.floor(Number(p.virtual_total||0)/Math.max(staff,1));
 let html=panel('👥 سجل المواطنين',`<div class="real-vs-virtual"><b>${num(residents(p))}</b> مواطنًا مسجلًا بحساب حقيقي • <b>${num(staff)}</b> موظفًا في نظام الإنتاج. الموظفون شخصيات من اللعبة، وليسوا حسابات لأشخاص متصلين.</div>${!state.citizen?'<p>سجّل الدخول من الرئيسية للانضمام إلى الدولة والمساهمة.</p>':`<p>محافظتك: <b class="emphasis">${esc(province(state.my_province)?.name||'دولة الزنجر')}</b></p><div class="actions"><button type="button" class="btn primary" data-action="join" data-target="${p.id}" ${member?'disabled':''}>📍 ${member?'محافظتك الحالية':'الانضمام إلى هذه المحافظة'}</button></div><form id="contributeForm"><input type="hidden" name="province_id" value="${p.id}"><div class="mini-grid"><div class="field"><label>مبلغ المساهمة بالزنجر</label><input type="number" name="amount" min="1" max="1000000" value="2000" required></div><div class="field" style="align-self:end"><button type="submit" class="btn green">🤝 دعم الخزينة</button></div></div></form>`}`);
 $('citizenPanel').innerHTML=html;
 const cards=Array.from({length:staff},(_,i)=>({n:fakeNames[(i+Object.keys(symbols).indexOf(p.id)*13)%fakeNames.length],i})).map(({n,i})=>`<div class="worker"><span class="avatar">${['🧑‍🌾','👷','🧑‍🔧','🧑‍💼','👩‍🍳','🧑‍💻','👩‍💼','👨‍🔬'][i%8]}</span><strong>${esc(n)} ${esc(staffSurnames[(i+Object.keys(symbols).indexOf(p.id)*3)%staffSurnames.length])} <span class="worker-number">${String(i+1).padStart(2,'0')}</span></strong><span class="staff-earnings">💰 ${num(perPerson)} زنجر</span><small>إجمالي ما جمعه • ${num(rate)} لكل ساعة إنتاج</small><span class="worker-tag ${p.virtual_on_shift?'':'off'}">${p.virtual_on_shift?'🟢 يعمل الآن':'🌙 ساعة راحة'}</span></div>`).join('');
 $('virtualPanel').innerHTML=panel(`👷 فريق العمل (${num(staff)})`,`<div class="staff-summary"><div><span>الإنتاج التراكمي</span><strong>${num(p.virtual_total||0)} زنجر</strong></div><div><span>الإنتاج لكل ساعة نشطة</span><strong>${num(p.virtual_hourly_amount||0)} زنجر</strong></div><div><span>نظام العمل</span><strong>${p.id==='home'?'كل ساعة':'ساعة عمل وساعة راحة'}</strong></div></div><p class="muted">هؤلاء موظفون داخل اللعبة فقط، والإيرادات مسجلة بالخزينة. رصيد كل موظف أدناه هو نصيبه من إنتاج الفريق.</p><div class="worker-grid">${cards}</div>`);
}
// Army view is intentionally composed in isolated sections: a malformed old battle or transfer must not hide the whole army tab.
function army(p){$('armyBody').innerHTML=panel('🛡️ الأمن الوطني','<p class="muted">مهام سلمية لتنظيم الحماية المدنية والتدريب وخدمة المجتمع. المنظومة العسكرية السابقة ليست ضمن اللعبة الحالية.</p>');}
function provincesList(p){$('provincesBody').innerHTML=panel('🌍 باقي المحافظات',`<p>تقدر تزور المحافظات وتشوف تطوير الخدمات والاقتصاد فيها. الإدارة للمحافظ أو الرئاسة.</p><div class="country-strip">${cardButtons()}</div><div class="links-grid"><a href="/state.html">🏠 الدولة الرئيسية وخدماتها</a><a href="/economy46.html">📊 الاقتصاد العام</a><a href="/loans44.html">🏦 القروض</a><a href="/education-exams.html">📚 التعليم</a></div>`);}
function tickClocks(){document.querySelectorAll('[data-countdown]').forEach(el=>{const end=Number(el.dataset.countdown);el.textContent=fmtLeft(end-Date.now());});}

function assignmentPanel(){
 const node=$('assignmentPanel');if(!state.admin){node.innerHTML='';node.hidden=true;return;}node.hidden=false;
 const list=asRows(state.available_citizens).map(x=>`<option value="${esc(x.id)}">${esc(x.name)}</option>`).join('');
 const targets=asRows(state.provinces).filter(x=>x.id!=='home').map(x=>`<option value="${esc(x.id)}">${esc(x.name)} — ${esc(x.governor_name||'بدون محافظ')}</option>`).join('');
 node.innerHTML=panel('🏛️ تعيين المحافظين',`<p>الرئاسة المركزية تعيّن المحافظ مباشرة، والمجلس المحلي يدير مشروعات خدمية.</p><form id="appointForm"><div class="mini-grid"><div class="field"><label>المحافظة</label><select name="province_id">${targets}</select></div><div class="field"><label>المحافظ الجديد</label><select name="user_id">${list}</select></div></div><button class="btn primary" type="submit">🏛️ تعيين المحافظ</button></form><hr class="divider"><form id="unappointForm"><div class="field"><label>إنهاء تكليف محافظ</label><select name="province_id">${state.provinces.filter(x=>x.id!=='home'&&x.governor_id).map(x=>`<option value="${esc(x.id)}">${esc(x.name)} — ${esc(x.governor_name)}</option>`).join('')}</select></div><button type="submit" class="btn">إنهاء التكليف</button></form>`);
}
function governance(p){
 const control=canControl(p);let content='';
 if(control){
  content+=panel('🏛️ مكتب محافظ '+esc(p.name),`<p>صلاحياتك الآن إدارية وخدمية. إدارة المشروع والمجلس في قسم التنمية والمجلس المحلي.</p><button class="btn primary" data-tab="development">🏗️ فتح قسم التنمية</button>${p.id!=='home'?`<form id="renameForm"><div class="field"><label>تعديل اسم المحافظة</label><input name="name" value="${esc(p.name)}" minlength="3" maxlength="35" required></div><button class="btn" type="submit">حفظ الاسم</button></form>`:''}`);
 }else content+=panel('🔒 الصلاحيات الإدارية',`<p class="muted">هذه المحافظة تابعة للدولة الواحدة. القرارات الخاصة بالمحافظ والرئاسة فقط.</p>`);
 if(state.admin){
  const users=asRows(state.available_citizens).map(x=>`<option value="${esc(x.id)}">${esc(x.name)}</option>`).join('');
  content+=panel('💰 دعم إداري من الرئاسة',`<p>يمكن دعم ميزانيات المحافظات أو أرصدة المواطنين دون إضافة قوات عسكرية.</p><form id="grantFunds49"><div class="field"><label>دعم خزينة المحافظة</label><input name="amount" type="number" min="1" max="10000000" value="10000" required></div><button class="btn green" type="submit">إضافة دعم مالي</button></form><form id="grantWallet49"><div class="mini-grid"><div class="field"><label>المواطن</label><select name="user_id">${users}</select></div><div class="field"><label>مبلغ المنحة</label><input name="amount" type="number" min="1" max="10000000" value="5000" required></div></div><button class="btn primary" type="submit">إضافة لمحفظة المواطن</button></form>`);
  content+=panel('🏛️ المساعدة والعفو',`<form id="aidForm" class="mini-grid"><div class="field"><label>مساعدة من الخزينة المركزية</label><input name="amount" type="number" min="1" max="1000000" value="5000" required></div><button class="btn green" type="submit">إرسال المساعدة</button></form><form id="pardonForm"><div class="field"><label>العفو عن مواطن</label><select name="user_id">${asRows(state.members).map(m=>`<option value="${esc(m.id)}">${esc(m.name)}</option>`).join('')}</select></div><button class="btn" type="submit">الإفراج من السجن</button></form>`);
 }
 $('commandPanel').innerHTML=content;
}
function historyPanel(){
 const events=Array.isArray(state.ledger)?state.ledger:[];
 $('events').innerHTML=events.filter(e=>e&&e.province_id===selected).map(e=>`<div class="entry"><strong>${esc(e.province_name)}</strong> · ${esc(e.note)}<br><b class="${Number(e.delta)>=0?'good':'danger'}">${Number(e.delta)>=0?'+':''}${num(e.delta)} زنجر</b><time>${day(e.created_at)}</time></div>`).join('')||'<p class="muted">لا توجد عمليات مسجلة لهذه الدولة بعد.</p>';
 if($('battles'))$('battles').innerHTML=battles.filter(b=>b&&(b.attacker===selected||b.defender===selected)).map(b=>`<div class="entry"><strong>${esc(province(b.attacker)?.name||'')}</strong> ضد <strong>${esc(province(b.defender)?.name||'')}</strong><br>🏆 المنتصر: ${esc(province(b.winner)?.name||'')}<br>غنائم: <b class="good">${num(b.loot)} زنجر</b><time>${day(b.created_at)}</time></div>`).join('')||'<p class="muted">لا توجد معارك مسجلة لهذه الدولة بعد.</p>';
}
// Render only the active tab. Previous builds rendered up to 11 panels and all 190 workers
// on every refresh, even when none was visible, which caused lags on some phones.

// Update 62 — civic services, councils and governor authority; preserves original visual design.
function civicPanel(p){
 const admin=state?.civic, c=admin?.provinces?.find(x=>x.id===p.id);
 if(!c){$('developmentBody').innerHTML=panel('التنمية', '<p>جارٍ تحميل الخدمات المحلية...</p>');return;}
 const governor=c.can_manage,canPropose=governor||c.is_council;
 const provinceRank=admin.provinces.findIndex(x=>x.id===p.id)+1;
 let body=panel('🏛️ المحافظة والمنافسة الإيجابية',`<div class="kpi-grid">${kpi('الترتيب العام',provinceRank+' / 8')}${kpi('مؤشر التنمية',num(c.score))}${kpi('المشروعات المنفذة',num(c.projects_count))}${kpi('عدد المواطنين',num(c.population))}${kpi('الخدمات العامة',num(c.services))}${kpi('القوة الإنتاجية',num(c.production))}</div><p class="muted">المدينة الرئيسية: ${esc(c.capital)} • التعليم: ${num(c.education)} • الصحة: ${num(c.health)} • مؤشرات التنمية محسوبة من المشروعات والأنشطة الفعلية.</p>`);
 body+=panel('👥 المجلس المحلي',`<p class="muted">${c.council.length?'أعضاء المجلس الحاليون: '+c.council.map(x=>esc(x.name)+' ('+(x.office==='deputy'?'نائب المحافظ':'عضو المجلس')+')').join('، '):'لم يُعيَّن أعضاء المجلس بعد.'}</p>${governor&&c.council.length?`<div class="actions">${c.council.map(x=>`<button type="button" class="btn" data-civic="council_remove" data-user="${esc(x.user_id)}">إعفاء ${esc(x.name)}</button>`).join('')}</div>`:''}${governor?`<form id="z62Assign"><div class="mini-grid"><div class="field"><label>اختر مواطنًا من المحافظة</label><select name="user_id" required>${asRows(state.members).filter(x=>x.province_id===p.id&&x.id!==p.governor_id).map(x=>`<option value="${esc(x.id)}">${esc(x.name)}</option>`).join('')}</select></div><div class="field"><label>المنصب</label><select name="office"><option value="council">عضو المجلس</option><option value="deputy">نائب المحافظ</option></select></div></div><button class="btn primary" type="submit">تعيين عضو</button></form><form id="z62Capital"><div class="field"><label>المدينة الرئيسية</label><input name="capital" maxlength="45" minlength="3" value="${esc(c.capital)}" required></div><button class="btn" type="submit">حفظ المدينة الرئيسية</button></form>`:''}`);
 if(canPropose)body+=panel('🏗️ اقتراح مشروع خدمي',`<form id="z62Propose"><div class="field"><label>نوع المشروع</label><select name="kind">${[['school','🏫 مدرسة — 12,000'],['hospital','🏥 مركز صحي — 18,000'],['road','🛣️ طريق — 10,000'],['park','🌳 حديقة — 6,500'],['water','💧 شبكة مياه — 14,000'],['transport','🚌 نقل — 16,000']].map(([x,t])=>`<option value="${x}">${t}</option>`).join('')}</select></div><div class="field"><label>عنوان المشروع</label><input name="title" maxlength="65" minlength="5" required></div><div class="field"><label>الوصف وأهميته</label><textarea name="description" rows="2" minlength="10" maxlength="220" required></textarea></div><button class="btn primary" type="submit">إرسال المقترح</button></form>`);
 body+=panel('📋 المشروعات والقرارات',c.projects.slice(0,35).map(proj=>{const proposed=proj.status==='proposed',yes=Number(proj.votes?.yes_votes||0),no=Number(proj.votes?.no_votes||0);return `<div class="entry"><strong>${esc(proj.title)}</strong> • ${num(proj.cost)} زنجر<br><small>${esc(proj.description)}</small><p>${proj.status==='completed'?'✅ منفذ':proj.status==='rejected'?'❌ مرفوض':'🕒 مقترح'} • الموافقة: ${num(yes)} • المعارضة: ${num(no)}</p><div class="actions">${proposed&&(c.is_council||governor)?`<button class="btn green" data-civic="project_vote" data-project="${esc(proj.id)}" data-vote="yes">👍 أوافق</button><button class="btn" data-civic="project_vote" data-project="${esc(proj.id)}" data-vote="no">👎 أرفض</button>`:''}${proposed&&governor?`<button class="btn primary" data-civic="project_approve" data-project="${esc(proj.id)}">✅ اعتماد وتمويل</button><button class="btn" data-civic="project_reject" data-project="${esc(proj.id)}">رفض</button>`:''}</div></div>`}).join('')||'<p class="muted">لا توجد مشروعات مقترحة حاليًا.</p>');
 $('developmentBody').innerHTML=body;
}
async function z62Do(payload,confirmation){if(confirmation&&!confirm(confirmation))return;try{const out=await api('/api/z62/action',{...payload,province_id:selected});notify(out.notice||'تم حفظ القرار');await refresh(true)}catch(e){notify(e.message,true)}}
document.addEventListener('submit',e=>{
 const f=e.target;if(!['z62Assign','z62Capital','z62Propose'].includes(f.id))return;e.preventDefault();
 const d=Object.fromEntries(new FormData(f).entries());
 if(f.id==='z62Assign')return z62Do({...d,type:'council_assign'},'تأكيد تعيين عضو مجلس المحافظة؟');
 if(f.id==='z62Capital')return z62Do({...d,type:'capital_set'});
 return z62Do({...d,type:'project_propose',request_id:requestId()});
});
document.addEventListener('click',e=>{const item=e.target.closest('[data-civic]');if(!item)return;const type=item.dataset.civic,z={type,project_id:item.dataset.project};if(type==='project_vote')z.vote=item.dataset.vote;if(type==='council_remove')z.user_id=item.dataset.user;return z62Do(z,type==='project_approve'?'اعتماد المشروع وصرف ميزانيته من خزينة المحافظة؟':type==='council_remove'?'هل تؤكد إعفاء هذا العضو من مجلس المحافظة؟':undefined);});

function renderActive(){
 if(!state)return;
 const p=province(selected);if(!p)return;
 const jobs={
  overview:()=>overview(p),economy:()=>economy(p),people:()=>citizen(p),
  army:()=>army(p),development:()=>civicPanel(p),provinces:()=>provincesList(p),
  manage:()=>{assignmentPanel();governance(p)},history:()=>historyPanel()
 };
 // Preserve access to the old services panel if someone uses its tab.
 if(!jobs[tab])return;
 try{jobs[tab]();}
 catch(e){
  console.error('Zangar province tab:',tab,e);
  const ids={overview:'overviewBody',economy:'economyBody',people:'citizenPanel',army:'armyBody',development:'developmentBody',wars:'warsBody',radar:'radarBody',allies:'alliesBody',provinces:'provincesBody',manage:'commandPanel',history:'events'};
  const node=$(ids[tab]);if(node)node.innerHTML=panel('⚠️ القسم',`<p class="muted">حدث خطأ في القسم؛ حدّث الصفحة وحاول مرة أخرى.</p>${state.admin?`<small>${esc(e?.message||'')}</small>`:''}`);
 }
 try{tickClocks();}catch(e){console.warn('Timer or army status skipped',e)}
}
function render(){
 if(!state)return;
 $('state').hidden=false;
 const p=province(selected);if(!p){notify('لم نتمكن من العثور على هذه الدولة',true);return;}
 document.title=p.name+' | محافظات الزنجر';
 document.body.classList.toggle('governor-home',!!state.my_governor && selected===state.my_governor);
 $('provinceCards').innerHTML=cardButtons();$('provinceDetail').innerHTML=head(p);
 switchTab(tab,false);if(state)renderActive();
}

const forms=['sendUnits49','grantUnit49','grantFunds49','grantWallet49','appointForm','unappointForm','renameForm','contributeForm','recruitForm','warForm','fineForm','jailForm','aidForm','pardonForm','adminQuickFunds','adminQuickUnits'];
document.addEventListener('click',e=>{const tr=e.target.closest('[data-transfer]');if(tr)return action({type:'resolve_units',transfer_id:tr.dataset.transfer,accept:tr.dataset.accept==='1'},'هل تؤكد هذا القرار بخصوص عرض القوات؟');});
document.addEventListener('click',e=>{const target=e.target.closest('[data-province]');if(target)return selectProvince(target.dataset.province);const tabBtn=e.target.closest('[data-tab]');if(tabBtn){switchTab(tabBtn.dataset.tab);if(tabBtn.dataset.focus)requestAnimationFrame(()=>document.getElementById(tabBtn.dataset.focus)?.scrollIntoView({behavior:'smooth',block:'center'}));return;}const focusBtn=e.target.closest('[data-focus]');if(focusBtn){document.getElementById(focusBtn.dataset.focus)?.scrollIntoView({behavior:'smooth',block:'center'});return;}const invest=e.target.closest('[data-invest]');if(invest)return action({type:'invest',province_id:selected,kind:invest.dataset.invest,request_id:requestId()},'تأكيد شراء المشروع وخصم قيمته من خزينة الدولة؟');const act=e.target.closest('[data-action]');if(act?.dataset.action==='rebuild49')return action({type:'rebuild',province_id:selected,request_id:requestId()},'إعادة تعويض وحدات آخر معركة من خزينة الدولة مرة واحدة فقط. موافق؟');if(act?.dataset.action==='join')return action({type:'join',province_id:act.dataset.target},'هل تريد الانتقال لهذه المحافظة؟ يمكنك تغييرها مجددًا بعد 7 أيام.');});
document.addEventListener('click',e=>{const btn=e.target.closest('[data-z54]');if(!btn)return;const type=btn.dataset.z54,body={type,province_id:selected};if(btn.dataset.plan)body.plan_id=btn.dataset.plan;if(btn.dataset.target)body.target=btn.dataset.target;if(type==='alliance_reply')body.accept=btn.dataset.accept==='1';const words={start_war_now:'سيبدأ الهجوم الآن دون انتظار الحلفاء. متأكد؟',reduce_rest:'تقليل راحة دولتك مرة واحدة إلى 15 دقيقة كحد أقصى؟',alliance_end:'إنهاء التحالف مع هذه الدولة؟',alliance_reply:'تأكيد الرد على طلب التحالف؟'};action(body,words[type]||'تأكيد الإجراء؟');});
document.addEventListener('submit',e=>{const f=e.target;if(f.id==='allianceRequest54'){e.preventDefault();const d=Object.fromEntries(new FormData(f));return action({...d,type:'alliance_request',province_id:selected},'إرسال طلب التحالف؟');}if(f.matches('.alliedSupportForm')){e.preventDefault();const d=Object.fromEntries(new FormData(f));return action({...d,type:'allied_support',province_id:selected,plan_id:f.dataset.plan},'سيتم حجز القوات المشاركة في الحرب ولا يمكن استعادتها أثناء المعركة. تؤكد؟');}});
setInterval(tickClocks,1000);
document.addEventListener('submit',e=>{const f=e.target;if(!forms.includes(f.id))return;e.preventDefault();const d=Object.fromEntries(new FormData(f).entries());
 if(f.id==='sendUnits49')return action({...d,type:'send_units',province_id:selected,request_id:requestId()},'ستُحجز القوات حتى يقبل رئيس الدولة المستلمة. هل تؤكد؟');
 if(f.id==='grantUnit49')return action({...d,type:'grant_unit',province_id:selected,request_id:requestId()},'إضافة القوات مجانًا من الرئاسة لهذه الدولة بدون خصم من جيش الزنجر. تؤكد؟');
 if(f.id==='grantFunds49')return action({...d,type:'grant_funds',province_id:selected,request_id:requestId()},'إضافة أموال جديدة للخزينة بلا خصم من محفظتك. تؤكد؟');
 if(f.id==='grantWallet49')return action({...d,type:'grant_wallet',province_id:selected,request_id:requestId()},'إضافة أموال جديدة إلى محفظة المواطن المختار. تؤكد؟');
 if(f.id==='adminQuickFunds')return action({...d,type:'grant_funds',request_id:requestId()},'إضافة أموال للمحافظة المختارة من الرئاسة المركزية. تؤكد؟');
 if(f.id==='adminQuickUnits')return action({...d,type:'grant_unit',request_id:requestId()},'إضافة قوات مجانية للمحافظة المختارة من الرئاسة المركزية. تؤكد؟');
 if(f.id==='appointForm')return action({...d,type:'appoint'},'تأكيد تعيين هذا المواطن محافظًا؟');
 if(f.id==='unappointForm')return action({...d,type:'unappoint'},'هل تريد إنهاء تكليف المحافظ الحالي؟');
 if(f.id==='renameForm')return action({...d,type:'rename',province_id:selected},'تأكيد تغيير اسم الدولة؟');
 if(f.id==='contributeForm')return action({...d,type:'contribute',request_id:requestId()},'سيُخصم '+d.amount+' زنجر من محفظتك، هل تؤكد؟');
 if(f.id==='recruitForm')return action({...d,type:'recruit',province_id:selected,request_id:requestId()},'هل تؤكد شراء القوات وخصم قيمتها من خزينة دولتك؟');
 if(f.id==='warForm'){if(Number(d.soldiers)<10){notify('لازم تختار على الأقل 10 جنود للحرب. لو مخزونك أقل، اشتري جنود من الجيش أولًا.',true);return;}const target=province(d.target),remaining=Number(target?.war_lock_until||0)-Date.now();if(remaining>0){notify('الدولة المستهدفة في راحة. انتظر '+fmtLeft(remaining)+' ثم حاول.',true);return;}return action({...d,type:'prepare_war',province_id:selected,request_id:requestId()},'إعلان الحرب يستدعي حلفاءك. لديك 10 دقائق استعداد أو ابدأ فورًا؛ بعدها راحة 10 دقائق. متأكد؟');}
 if(f.id==='fineForm')return action({...d,type:'fine',province_id:selected},'هل تؤكد الغرامة على المواطن؟');
 if(f.id==='jailForm')return action({...d,type:'jail',province_id:selected},'هل تؤكد الحكم بالسجن الافتراضي؟');
 if(f.id==='aidForm')return action({...d,type:'aid',province_id:selected,request_id:requestId()},'المساعدة ستُخصم من خزينة الزنجر المركزية. تأكيد؟');
 if(f.id==='pardonForm')return action({...d,type:'pardon'},'هل تريد الإفراج عن هذا المواطن؟');
});
$('refreshBtn').onclick=()=>refresh().catch(e=>notify(e.message,true));
refresh(true).then(()=>notify('أهلًا بك في دولة الزنجر ومحافظاتها الثماني!')).catch(e=>notify(e.message,true));
let z57Poll=0;
setInterval(()=>{
 if(document.hidden||busy||refreshing||document.activeElement?.closest('form'))return;
 // Only poll live warfare periodically. Regular pages rely on refresh button, return-to-tab and successful actions.
 if(!['development'].includes(tab))return;
 if(Date.now()-z57Poll<120000)return;
 z57Poll=Date.now();refresh(true).catch(e=>console.warn('Province civic refresh:',e));
},30000);
document.addEventListener('visibilitychange',()=>{if(!document.hidden&&!busy&&!refreshing)refresh(true).catch(()=>{})});

function warRisk49(){const f=document.getElementById('warForm'),out=document.getElementById('z49WarRisk');if(!f||!out||!f.elements)return;const v=Object.fromEntries(new FormData(f).entries()),t=province(v.target);if(!t)return;const power=x=>Number(x.soldiers||0)+20*Number(x.missiles||0)+15*Number(x.planes||0)+25*Number(x.ships||0);const attacking=power(v),defending=power(t),ratio=attacking/Math.max(1,defending);out.textContent=ratio<.65?'🚨 خطر شديد: جيشك المرسل أضعف بكثير من '+t.name+' (نسبة القوة تقريبًا '+Math.round(ratio*100)+'%). فكّر في شراء قوات أولًا.':ratio<1?'⚠️ العدو أقوى من الجيش الذي سترسله: '+t.name+' — القوة الهجومية '+Math.round(ratio*100)+'% من قوة دفاعه.':'✅ جيشك المرسل لا يقل عن قوة '+t.name+' الظاهرة، لكن النصر ليس مضمونًا.';out.style.borderColor=ratio<1?'#e68b63':'#41b58c';const warning=$('targetWar55');if(warning){const left=Number(t.war_lock_until||0)-Date.now();warning.textContent=left>0?'⏳ الدولة المستهدفة في راحة '+fmtLeft(left)+'، اختر دولة أخرى أو انتظر.':'✅ الدولة المستهدفة جاهزة حاليًا (لو لم تكن لديها حرب معلّقة).';}}
document.addEventListener('input',e=>{if(e.target.closest('#warForm'))warRisk49();});
document.addEventListener('change',e=>{if(e.target.closest('#warForm'))warRisk49();});
