// Rebuilds _worker.js from src/worker/*.js (plain concatenation in filename order).
// Run: node build-worker.mjs        (or: node build-worker.mjs --check  to verify _worker.js is up to date)
import fs from 'node:fs';
const dir='src/worker/',files=fs.readdirSync(dir).filter(f=>f.endsWith('.js')).sort();
const out=files.map(f=>fs.readFileSync(dir+f,'utf8')).join('');
if(process.argv.includes('--check')){const cur=fs.readFileSync('_worker.js','utf8');if(cur!==out){console.error('_worker.js is OUT OF DATE; run node build-worker.mjs');process.exit(1);}console.log('OK: _worker.js matches src/worker ('+files.length+' files)');}
else{fs.writeFileSync('_worker.js',out);console.log('Built _worker.js from '+files.length+' files, '+out.length+' chars');}
