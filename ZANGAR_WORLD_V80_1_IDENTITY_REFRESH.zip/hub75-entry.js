// ZANGAR WORLD V75 — زر «مركز المواطن» في الشريط العلوي + الجولة التعريفية لأول دخول.
(()=>{'use strict';
 const KEY='z75-tour-done';
 const STEPS=[
  {i:'🇿🇳',t:'أهلًا بك في دولة الزنجر',p:'هنا بتبني ثروتك ومكانتك: شغل، تجارة، شركات، ومنصب لو اجتهدت. خد دقيقة نعرّفك أهم الأماكن.'},
  {i:'🎁',t:'صندوق اليوم والأيام المتتالية',p:'افتح صندوقك اليومي من مركز تطور الاتحاد، وكل يوم تدخل فيه ورا بعض بيزوّد مكافأة الـ streak.'},
  {i:'🎯',t:'المهام اليومية والترتيب',p:'مركز المواطن (زر 🎯 فوق) فيه مهام بسيطة بتدّيك زنجر، وترتيب الأغنى والأنشط في الأسبوع.'},
  {i:'🚀',t:'جاهز تبدأ؟',p:'اكتشف الوظائف والبنك والبورصة والشات. وتقدر تعيد الجولة دي في أي وقت من مركز المواطن.'}
 ];
 const esc=s=>String(s).replace(/[&<>"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));
 const store={get(){try{return localStorage.getItem(KEY)}catch(e){return null}},set(){try{localStorage.setItem(KEY,'1')}catch(e){}}};
 function finish(){store.set();fetch('/api/v75/onboarding',{method:'POST',credentials:'same-origin',headers:{'Content-Type':'application/json'},body:'{}'}).catch(()=>{});}
 function start(){
  if(document.querySelector('.z75-tour'))return;
  let n=0;const el=document.createElement('div');el.className='z75-tour';el.setAttribute('role','dialog');el.setAttribute('aria-modal','true');
  const draw=()=>{const s=STEPS[n],last=n===STEPS.length-1;
   el.innerHTML=`<div class="z75-tour-card"><div class="z75-tour-ico">${s.i}</div><h3>${esc(s.t)}</h3><p>${esc(s.p)}</p><div class="z75-dots">${STEPS.map((_,k)=>`<i class="${k===n?'on':''}"></i>`).join('')}</div><div class="z75-tour-actions">${last?'':'<button type="button" data-skip>تخطي</button>'}<button type="button" class="go" data-next>${last?'يلا نبدأ':'التالي'}</button></div></div>`;};
  const close=()=>{el.remove();finish();};
  el.addEventListener('click',e=>{if(e.target.closest('[data-skip]'))return close();if(e.target.closest('[data-next]')){if(n>=STEPS.length-1)return close();n++;draw();}});
  draw();document.body.appendChild(el);
 }
 window.Z75Tour={start};
 // زر مركز المواطن (التطبيق بيعيد رسم الشريط، فنراقب ونضيفه تاني لو اختفى)
 let raf=0;
 const ensureBtn=()=>{raf=0;const bar=document.querySelector('.topbar .top-actions');if(!bar||bar.querySelector('#z75-hub-link'))return;
  const a=document.createElement('a');a.id='z75-hub-link';a.className='icon-btn';a.href='/hub75.html';a.title='مركز المواطن';a.setAttribute('aria-label','مركز المواطن');a.textContent='🎯';bar.prepend(a);};
 const watch=()=>{const app=document.getElementById('app');if(!app)return;ensureBtn();new MutationObserver(()=>{if(!raf)raf=requestAnimationFrame(ensureBtn)}).observe(app,{childList:true,subtree:true});};
 // الجولة: مرة واحدة لكل جهاز، وبعدها نسأل السيرفر مرة (خفيفة) عشان مانعيدهاش لو شافها من جهاز تاني
 async function auto(){
  if(store.get())return;
  try{const r=await fetch('/api/v75/onboarding',{credentials:'same-origin',cache:'no-store'});if(!r.ok)return;const j=await r.json();
   if(j.done){store.set();return}setTimeout(start,1200);}catch(e){}
 }
 const boot=()=>{watch();if(location.pathname.endsWith('/state.html')||location.pathname==='/state')auto();};
 if(document.readyState==='loading')document.addEventListener('DOMContentLoaded',boot);else boot();
})();
