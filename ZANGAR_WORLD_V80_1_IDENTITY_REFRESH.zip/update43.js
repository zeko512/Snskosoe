/* Zangar Update 43: present the confirmed server reward and grant reminders. */
(()=>{'use strict';
 const css=document.createElement('style');css.textContent=`
 .z43-victory-bg{position:fixed;inset:0;background:#000b;z-index:7000;display:grid;place-items:center;padding:18px;backdrop-filter:blur(7px)}
 .z43-victory-card{max-width:530px;width:100%;padding:25px 20px;background:linear-gradient(155deg,#26355c,#0b182e);border:2px solid #e4ba60;border-radius:27px;text-align:center;color:#fff0d4;box-shadow:0 25px 80px #000c;font-family:Tahoma,Arial}
 .z43-victory-card h2{font-size:clamp(22px,5vw,34px);color:#ffe29f}.z43-victory-card .emoji{font-size:76px;animation:z43pop .8s ease-out}
 .z43-victory-stat{background:#ffffff10;border:1px solid #edc56b55;border-radius:14px;margin:9px 0;padding:12px;font-weight:700}
 .z43-victory-card button{border:0;background:#f1d37e;color:#222;border-radius:12px;padding:13px 23px;font-weight:bold;font-size:16px;cursor:pointer}
 @keyframes z43pop{0%{transform:scale(.2) rotate(-20deg)}70%{transform:scale(1.2)}100%{transform:scale(1)}}`;
 document.head.append(css);
 window.z43Victory=payload=>{if(payload?.result!=='victory'||!payload.battle_id||payload.reward_confirmed!==true)return;
  const bg=document.createElement('div');bg.className='z43-victory-bg';bg.setAttribute('role','presentation');
  const fmt=n=>Number(n||0).toLocaleString('ar-EG');
  bg.innerHTML=`<div class="z43-victory-card" role="dialog" aria-modal="true" aria-label="انتصار دولة الزنجر"><div class="emoji">🏆</div><h2>دولة الزنجر انتصرت!</h2><div class="z43-victory-stat">🏛️ خزينة الدولة: +${fmt(payload.treasury_reward)} زنجر</div><div class="z43-victory-stat">👥 كل مواطن: +${fmt(payload.citizen_reward)} زنجر</div><div class="z43-victory-stat">👑 قائد الحرب: +${fmt(payload.leader_reward)} زنجر إضافية</div><p>المكافآت مؤكد صرفها من السيرفر مرة واحدة لهذه المعركة.</p><button type="button">متابعة الدولة ✓</button></div>`;
  const close=()=>bg.remove();bg.querySelector('button').addEventListener('click',close);bg.addEventListener('click',e=>{if(e.target===bg)close()});document.body.append(bg);
 };
 // Visible-page fallback; automatic background notifications are handled by the Cloudflare scheduler + Push.
 let lastGrantAlert='';async function grantReminder(){
  if(document.hidden||typeof mode==='undefined'||mode!=='online'||typeof me!=='function'||!me())return;
  const at=Number(me().claim_at||0),now=Date.now();if(!at||now-at<3600000)return;
  const key=me().id+':'+at;if(lastGrantAlert===key)return;lastGrantAlert=key;
  if(typeof toast==='function')toast('🪙 منحة الدولة جاهزة للاستلام! افتح الرئيسية واضغط استلام.');
 }
 setInterval(grantReminder,60000);setTimeout(grantReminder,4500);
})();
