export default {async fetch(request,env,ctx){
 const path=new URL(request.url).pathname;
 if(path==='/_worker.js')return new Response('Not Found',{status:404});
 // Radar is public: authorization is checked only by API commands and server-side state filtering.
 if(request.method==='GET'&&path==='/air-defense-entry.html'){
  const next=new URL('/air-defense.html'+new URL(request.url).search,request.url);
  return new Response(null,{status:302,headers:{Location:next.href,'Cache-Control':'no-store'}});
 }

 // Old links (/state?release=...) must open Guest login on a new phone.
 // Check cookie presence here without a heavy DB read; the app validates its session.
 if(request.method==='GET' && (path==='/state'||path==='/state.html') && !cookieValue(request,'zangar_session')){
  return new Response(null,{status:302,headers:{Location:new URL('/',request.url).href,'Cache-Control':'no-store'}});
 }

 if(Z63_BLOCKED_PAGES.has(path))return new Response('هذا القسم أزيل من ZANGAR WORLD V63',{status:410,headers:{'Content-Type':'text/plain; charset=utf-8','Cache-Control':'no-store'}});
 if(path.startsWith('/api/')){
  const response=await onRequest({request,env,waitUntil:ctx?.waitUntil?.bind(ctx)});
  // Make public-read caches fresh after successful citizen/admin actions in this isolate.
  if(request.method==='POST'&&response.ok&&!['/api/push/cron','/api/push/preferences','/api/push/subscribe','/api/push/unsubscribe'].includes(path))z32PublicCache.clear();
  if(request.method==='POST' && response.ok && env.DB && zPushConfigured(env) && !['/api/push/cron','/api/push/test','/api/push/subscribe','/api/push/unsubscribe','/api/push/preferences'].includes(path)){
   const pending=zPushDeliverQueue(env.DB,env,path==='/api/air-defense/emergency'?300:24).catch(e=>console.error('Push queue:',String(e)));
   if(ctx?.waitUntil)ctx.waitUntil(pending);else await pending;
  }
  return response;
 }
 // Static assets are needed to render the maintenance gate. No protected content is embedded in them.
 // Public code/images/fonts/service worker NEVER spend D1 rows to be served.
 if(path==='/guest6394.js'){const response=await env.ASSETS.fetch(request);const headers=new Headers(response.headers);headers.set('Cache-Control','no-store, no-cache, must-revalidate');return new Response(response.body,{status:response.status,statusText:response.statusText,headers});}
 if(/\.(?:css|js|svg|png|jpg|jpeg|webp|ico|webmanifest|txt|map)$/i.test(path)||path.startsWith('/assets/'))return env.ASSETS.fetch(request);
 if(env.DB&&(request.method==='GET'||request.method==='HEAD') && (path!=='/'&&/\.html$/i.test(path))){
  try{
   // Maintenance display uses a short public cache. API permissions remain enforced live.
   const maintenance=await z32PublicRead('maintenance-home',15000,()=>isMaintenance(env.DB));
   if(maintenance&&!(await maintenanceAllowed(request,env.DB,env)))return new Response(maintenanceHtml(),{status:503,headers:{'Content-Type':'text/html; charset=utf-8','Cache-Control':'no-store','X-Robots-Tag':'noindex','Retry-After':'60'}});
  }catch(e){
   // D1 free-tier limits must not turn static website files into 503 responses.
   // Personal data remains unavailable until D1 recovers; never invent offline balances.
   console.error('Zangar static maintenance check:',String(e));
  }
 }
 return env.ASSETS.fetch(request)
}};
