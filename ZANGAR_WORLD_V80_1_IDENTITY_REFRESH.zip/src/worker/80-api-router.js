async function onRequest(context){const request=context.request,db=context.env.DB;if(!db)return err(503,'قاعدة البيانات غير مرتبطة بعد. اتبع ملف README لتفعيل Cloudflare D1.');let path=new URL(request.url).pathname,method=request.method;
try{
 if(path.startsWith('/api/v75/'))return await z75Route(request,db,method,path);
 if(path.startsWith('/api/v78/'))return await z78Route(request,db,context.env,method,path);
  if(path.startsWith('/api/v80/'))return await z80Route(request,db,context.env,method,path);
 if(method==='POST'&&path==='/api/air-defense/alert/open')return await z68AlertOpen(request,db);
 if(method==='POST'&&path==='/api/air-defense/unlock')return await z660AirUnlock(request,db);
 if(method==='POST'&&path==='/api/air-defense/lock')return await z70CommandLock(request,db);
 if(method==='POST'&&path==='/api/air-defense/revoke')return await z711RevokeAir(request,db);
 if(method==='POST'&&path==='/api/code-access/revoke')return await z711RevokeOther(request,db);
 if(path.startsWith('/api/air-defense/')&&path!='/api/air-defense/state'&&!(await (async()=>{const u=await getMe(request,db);return await z70CommandAllowed(request,db,u);})()))return err(403,'التحكم يتطلب تسجيل الدخول وفتح لوحة القيادة بالرمز السري');
 if(method==='POST'&&path==='/api/air-defense/upgrade')return await z68UpgradeBuy(request,db);
 if(method==='POST'&&path==='/api/air-defense/emergency')return await z660Emergency(request,db);
 if(method==='GET'&&path==='/api/air-defense/state')return await z659AirState(request,db);
 if(method==='POST'&&path==='/api/air-defense/fire')return await z659AirFire(request,db);
 if(['/api/missions46/state','/api/missions46/claim','/api/ai46/state','/api/ai46/action','/api/zangar-ai/chat','/api/central53/personal'].includes(path)||path.startsWith('/api/ai46/'))return err(410,'تمت إزالة هذا القسم في الإصدار V63.9');
 if(Z63_COMBAT_APIS.has(path)||path.startsWith('/api/war/'))return err(410,'أزيل نظام القتال من ZANGAR WORLD V63');
 if(method==='GET'&&path==='/api/version')return json({version:'80.0',previous_version:'79.0',air_defense:true,peace_mode:true,government:false,parliament:false,guest_slots:30,approval_required:false,direct_registration:true});
 if(false&&method==='GET'&&path==='/api/version')return json({version:'65.7',previous_version:'65.3',peace_mode:true,government:false,parliament:false,guest_slots:30,approval_required:false,direct_registration:true});
 if(method==='GET'&&path==='/api/version')return json({version:'65.3',previous_version:'65',peace_mode:true,government:false,parliament:false,guest_slots:30,economy:true,social:true,light_mode:false,approval_required:true});
 // Fast paths keep login and initial load independent from legacy government/approval migrations.
 if(method==='GET'&&path==='/api/session60')return await z60SessionStatus(request,db);
 if(method==='GET'&&path==='/api/bootstrap'){
   // Keep V71.1 fast bootstrap unchanged. V72 schema migrates on /api/world, radar or cron.
   const token=cookieValue(request,'zangar_session');
   if(!/^[a-f0-9]{64}$/.test(token))return json({me:null,auth_required:true,users:[],version:'65.7'});
   const me=await getMe(request,db);
   if(!me)return json({me:null,auth_required:true,users:[],version:'65.7'});
   try{return await bootstrap(request,db);}
   catch(e){
     if(!/no such table/i.test(String(e)))throw e;
     await z68EnsureGameSchema(db);
     return await bootstrap(request,db);
   }
 }
 if(method==='POST'&&(path==='/api/z67/register'||path==='/api/z67/login')){
   const p=await request.json();
   return path.endsWith('/register')?await z67Register(request,db,p):await z67Login(request,db,p);
 }
 // Fast route for the three common citizen actions: avoid 12+ old migration checks before each click.
 if(method==='GET'&&path==='/api/world'){
   await z68EnsureGameSchema(db);await z42Ensure(db);await z659AirEnsure(db);return await zWorld(request,db);
 }
 if(method==='GET'&&path==='/api/citizen/snapshot'){
   const current=await getMe(request,db);
   if(!current)return err(401,'سجل الدخول أولًا');
   return json({ok:true,citizen:await z657CitizenSnapshot(db,current.id)});
 }
 if(method==='GET'&&path==='/api/z639/avatar')return await z639Avatar(request,db);
 if(method==='POST'&&path==='/api/action'){
   const sz=Number(request.headers.get('Content-Length')||0);
   if(sz>MAX_BODY)return err(413,'الطلب أكبر من المسموح');
   const raw=await request.clone().text();
   if(raw.length>MAX_BODY)return err(413,'الطلب أكبر من المسموح');
   const payload=JSON.parse(raw||'{}');
   if(['claim','profile','avatar'].includes(String(payload.type||'')))
      return await z657FastCitizenAction(request,db,context.env,payload);
 }
 // Bank wallet, withdrawal and interest take a small, atomic transaction path.
 if(method==='GET'&&path==='/api/bank/receipt'){
   const user=await getMe(request,db);if(!user)return err(401,'سجل الدخول أولًا');
   await z68BankEnsure(db);const rid=new URL(request.url).searchParams.get('id')||'';
   const found=await z68BankReceipt(db,rid,user.id);return found?json(await z68BankSnapshot(db,user.id,found)):err(404,'العملية لم تُسجّل');
 }
 if(method==='POST'&&path==='/api/world/action'){
   const origin=request.headers.get('Origin'),site=new URL(request.url).origin;if(origin&&origin!==site)return err(403,'المصدر غير مسموح');
   const raw=await request.clone().text();if(raw.length>MAX_BODY)return err(413,'الطلب أكبر من المسموح');
   const payload=JSON.parse(raw||'{}');
   if(['savingDeposit','savingWithdraw','savingInterest'].includes(String(payload.type||'')))return await z80BankGate(request,db,context.env,payload);
 }
 // The old approval system is disabled, but old accepted accounts and audit rows stay untouched.
 if(path.startsWith('/api/z66/'))return err(410,'تم إلغاء طلبات الانضمام؛ التسجيل والدخول الآن مباشرة من الصفحة الرئيسية');
 if(method==='POST'&&path==='/api/head/control'){await z68EnsureGameSchema(db);if(await z40ResetIsActive(db))return err(423,'التصفير جارٍ؛ معاملات الإدارة الخاصة متوقفة حتى النهاية');if(!isAdmin(await getMe(request,db)))return err(403,'افتح الرئاسة بالتحقق الجديد بخطوتين أولًا');const payload=await request.json();return await z34Head(request,db,context.env,payload);}
 if(method==='GET'&&path==='/api/push/config')return json({enabled:zPushConfigured(context.env),publicKey:context.env.VAPID_PUBLIC_KEY||'',can_test:true});
 if(method==='GET'&&path==='/api/session60'){await ensureZangarSchema(db);await z639Ensure(db);await z64Ensure(db);return await z60SessionStatus(request,db);}
 if(method==='GET'&&path==='/api/health'){let check=await db.prepare("SELECT COUNT(*) AS n FROM sqlite_master WHERE type='table' AND name IN ('users','econ_assets','econ_market','econ_requests','econ_auctions')").first();if(Number(check?.n)!==5){await ensureZangarSchema(db);check=await db.prepare("SELECT COUNT(*) AS n FROM sqlite_master WHERE type='table' AND name IN ('users','econ_assets','econ_market','econ_requests','econ_auctions')").first();}return json({ok:check?.n===5,db:true,economy_ready:check?.n===5,auto_setup:true,version:Z41_BUILD});}
 await z68EnsureGameSchema(db);
 if(method==='GET'&&path==='/api/z66/status')return await z66Check(request,db);
 if(method==='GET'&&path==='/api/z66/admin/requests')return await z66AdminList(request,db);
 if(method==='GET'&&path==='/api/z66/admin/inbox')return await z66AdminInbox(request,db);
 if(method==='GET'&&path==='/api/z639/slots')return await z639PublicSlots(db);
 if(method==='GET'&&path==='/api/z639/challenge')return await z639Challenge(db,request);
 if(method==='GET'&&path==='/api/z639/avatar')return await z639Avatar(request,db);
 if(false&&method==='GET'&&path==='/api/recovery60/admin')return await z60RecoveryAdmin(request,db,{type:'list'});
 if(method==='GET'&&['/api/season39/status','/api/season40/status'].includes(path))return await z39SeasonStatus(request,db);
 if(method==='POST'&&!['/api/season40/reset','/api/season39/reset','/api/maintenance/unlock','/api/auth'].includes(path)&&await z40ResetIsActive(db))return err(423,'جاري تصفير الموسم الثاني؛ معاملات الدولة موقوفة لحماية الأرصدة والمواطنين حتى اكتمال العملية.');
 if(method==='GET'&&path==='/api/maintenance/status'){const maintenance=await isMaintenance(db);return json({maintenance,allowed:maintenance?await maintenanceAllowed(request,db,context.env):true});}

 const underMaintenance=await isMaintenance(db);
 if(underMaintenance && path!=='/api/maintenance/unlock' && path!=='/api/push/cron' && !(await maintenanceAllowed(request,db,context.env))) return err(503,'الدولة تحت الصيانة مؤقتًا. حدّث الصفحة لعرض شاشة الصيانة.');
 if(method==='GET'&&path==='/api/version')return json({version:'63.9',previous_version:'63',peace_mode:true,government:true,guest_slots:30});
 if(method==='GET'&&path==='/api/push/config')return await zPushRequest(request,db,context.env,'config');
 if(method==='GET'&&path==='/api/push/status')return await zPushRequest(request,db,context.env,'status');
 if(method==='GET'&&path==='/api/push/latest'){const logged=await getMe(request,db);if(!logged)return err(401,'سجل دخولك');const latest=await db.prepare('SELECT id,title,body,kind,created_at FROM z_notifications WHERE user_id=? AND created_at>=? ORDER BY created_at DESC LIMIT 1').bind(logged.id,Date.now()-360000).first();return json({notification:latest||null});}
 if(method==='GET'&&path==='/api/war/alert')return json({emergency_until:0,planned_until:0,planned_minutes:0,threat_hour:0,threat_until:0,now:Date.now(),peace_mode:true});
 if(false&&method==='GET'&&path==='/api/war/alert'){const alert=await db.prepare('SELECT emergency_until FROM z_war_state WHERE id=1').first();const planned=await db.prepare('SELECT minutes,arrival_at FROM z_war_planned_alerts WHERE arrival_at>? ORDER BY created_at DESC LIMIT 1').bind(Date.now()).first();const threat=await db.prepare("SELECT hour_slot,ends_at FROM z_war_threats WHERE status='inbound' AND ends_at>? ORDER BY started_at DESC LIMIT 1").bind(Date.now()).first();return json({emergency_until:Number(alert?.emergency_until||0),planned_until:Number(planned?.arrival_at||0),planned_minutes:Number(planned?.minutes||0),threat_hour:threat?.hour_slot||0,threat_until:Number(threat?.ends_at||0),now:Date.now()});}
 if(method==='GET'&&path==='/api/war/access')return json({authorized:false,peace_mode:true});
 if(method==='GET'&&path==='/api/war/state'){await z39WarUpgrade(db);await z38WarEnsure(db);const resp=await zWarStatus(request,db,context.env,context.waitUntil);if(!resp.ok)return resp;const d=await resp.json();return json({...d,peace_mode:true,authorized:false,armed:false,shots_left:0,threat:null,planned_warning:null,emergency_until:0});}
 if(method==='GET'&&path==='/api/modern/state')return await zModernState(request,db);
 if(method==='GET'&&path==='/api/finance/state')return await zFinanceState(request,db);
 if(method==='GET'&&path==='/api/bootstrap'){const u=await getMe(request,db);if(u){await z43GrantSweep(db,Date.now(),u.id);await z44LoanSweep(db,Date.now(),u.id);await z78DailyReward(db,u);}return await bootstrap(request,db);}
 if(method==='GET'&&path==='/api/z63/state')return err(410,'تم إلغاء الحكومة والبرلمان في V64');
 if(method==='GET'&&path==='/api/z64/state')return await z64State(request,db);
 if(method==='GET'&&path==='/api/z65/state')return await z65State(request,db);
 if(method==='GET'&&path==='/api/z62/state'){await z63ExpireGovernors(db);return await z62State(request,db);}
 if(method==='GET'&&path==='/api/federation/state'){await z63ExpireGovernors(db);return await z46State(request,db);}
 if(method==='GET'&&path==='/api/z59/state')return await z59State(request,db);
 if(method==='GET'&&path==='/api/z59/account-audit')return await z59AccountAudit(request,db);
 if(method==='GET'&&path==='/api/central53/personal')return await z53Personal(request,db);
 if(method==='GET'&&path==='/api/economy46/state')return await z46EconomyState(request,db);
 if(method==='GET'&&path==='/api/audit46/state')return await z46AuditState(request,db);
 if(method==='GET'&&path==='/api/missions46/state')return await z46MissionState(request,db);
 if(method==='GET'&&path==='/api/loans44/state')return await z44LoansState(request,db);
 if(method==='GET'&&path==='/api/state/budget42')return await z42Budget(request,db);
 if(method==='GET'&&path==='/api/billing/state')return await z38BillState(request,db);
 if(method==='GET'&&path==='/api/chat/state')return await chatState(request,db);
 if(method==='GET'&&path==='/api/charity/state'){await z33Ensure(db);return await z33CharityState(request,db)}
 if(method==='GET'&&path==='/api/campaign/state'){await z33Ensure(db);await z39WarUpgrade(db);await z38WarEnsure(db);return await z33WarState(request,db)}
 if(method==='GET'&&path==='/api/education/state')return await z36EducationState(request,db);
 if(method==='GET'&&path==='/api/jobs36/state')return await z36JobsState(request,db);
 if(method==='GET'&&path==='/api/world')return await zWorld(request,db);
 if(method==='GET'&&/^\/api\/chat\/voice\/[0-9a-f-]{36}$/.test(path))return await zVoice(request,db,path.split('/').pop());
 if(method==='GET'&&/^\/api\/chat\/image\/[0-9a-f-]{36}$/.test(path))return await zImage(request,db,path.split('/').pop());
 if(false&&method==='GET'&&path==='/api/auth/challenge'){
  let name=crop(new URL(request.url).searchParams.get('name'),35),key=norm(name);
  if(!name)return err(400,'اكتب اسم المواطن');
  const account=await db.prepare('SELECT salt,passhash FROM users WHERE name_key=?').bind(key).first();
  if(!account)return err(401,'الحساب غير موجود؛ اختر إنشاء حساب أولًا.');
  return json({scheme:account.passhash.startsWith('v2:')?'v2':'legacy',salt:account.salt});
 }
 // The scheduler authenticates with a secret header and cannot receive citizen sessions.
 if(method==='POST'&&path==='/api/push/cron'){
  const token=request.headers.get('X-Zangar-Cron-Secret')||'',secret=String(context.env.PUSH_CRON_SECRET||'');
  if(!secret||token.length<24||!eqSecure(await digest(token),await digest(secret)))return err(403,'غير مسموح');
  await z38WarEnsure(db);await z39WarUpgrade(db);await z38BillCron(db);const now=Date.now(),created=[],business_paid=await zBusinessPayDue(db,now);await z33Ensure(db);await zStockTick(db);await z36EducationSettle(db,now);await z36WorldTick(db,now);await z46Tick(db,now);
  await z659AirEnsure(db);await z72ReminderSweep(db,now);await z43GrantSweep(db,now);await z44LoanSweep(db,now);await z74Ensure(db);await z74AirSweep(db,now);try{await z78Sweep(db,now);}catch(e){console.warn('z78 sweep',String(e));}const delivered=await zPushDrain(db,context.env);
  return json({ok:true,created,business_paid,delivered});
 }
 if(method!=='POST')return err(404,'خدمة غير موجودة');
 const origin=request.headers.get('Origin'),site=new URL(request.url).origin;if(origin&&origin!==site)return err(403,'طلب من مصدر مختلف غير مسموح');
 let len=num(request.headers.get('Content-Length')||0);if(len>MAX_BODY)return err(413,'الطلب أكبر من المسموح');let text=await request.text();if(text.length>MAX_BODY)return err(413,'الطلب أكبر من المسموح');let p=JSON.parse(text||'{}');
 // Secure action gate: legacy forms or manual HTTP requests can never reactivate combat.
 if(['/api/war/action','/api/campaign/action','/api/season39/reset','/api/season40/reset'].includes(path))return err(403,Z62_PEACE_MESSAGE);
 if(path==='/api/federation/action'&&Z62_COMBAT_ACTIONS.has(String(p.type||'')))return err(403,Z62_PEACE_MESSAGE);
 if(path==='/api/z59/action'&&(String(p.type||'').startsWith('treaty_')||(['research','building'].includes(String(p.type||''))&&['radar','training','military'].includes(String(p.kind||'')))))return err(403,'أرشيف عسكري معطل، والتطوير الخدمي متاح في المحافظات');
 if(path==='/api/central53/action')return err(403,Z62_PEACE_MESSAGE);
 if(path==='/api/sovereign/control'&&/war|battle|missile|army|attack|soldier|reinforcement|military/i.test(String(p.type||'')))return err(403,Z62_PEACE_MESSAGE);
 if(path==='/api/head/control'&&/war|battle|missile|army|attack|soldier|reinforcement|military/i.test(String(p.type||'')))return err(403,Z62_PEACE_MESSAGE);
 if(path==='/api/z66/apply')return await z66Apply(request,db,p);
 if(path==='/api/z66/login')return await z66Login(request,db,p);
 if(path==='/api/z66/admin/login')return await z66AdminLogin(request,db,p);
 if(path==='/api/z66/admin/decision')return await z66Decision(request,db,p);
 if(path==='/api/z66/admin/logout')return await z66AdminLogout(request,db);
 if(path==='/api/z639/enter')return await z639GuestEnter(request,db,p);
 if(path==='/api/auth'&&await z40ResetIsActive(db)&&p.intent!=='login'&&p.intent!=='logout')return err(423,'تسجيل الحسابات الجديدة متوقف أثناء تصفير الموسم');
 if(false&&path==='/api/recovery60/request')return await z60RecoveryRequest(request,db,p);
 if(path==='/api/recovery60/reset')return await z60RecoveryReset(request,db,p);
 if(path==='/api/recovery60/admin')return await z60RecoveryAdmin(request,db,p);
 if(path==='/api/maintenance/unlock')return await maintenanceUnlock(request,db,context.env,p);
 if(path==='/api/site/maintenance')return await setMaintenance(request,db,p);
 // All account-changing requests are blocked during imprisonment, including code unlocks and admin decisions.
 if(path==='/api/presence42')return await z42Presence(request,db,p.active!==false);
 const current=await getMe(request,db);if(current&&await prisonActive(db,current.id) && path!=='/api/billing/action' && !['/api/push/subscribe','/api/push/unsubscribe','/api/push/test','/api/push/preferences'].includes(path) && !(path==='/api/auth'&&p.intent==='logout')&&!(path==='/api/world/action'&&p.type==='appealCreate'))return err(403,'أنت في السجن حاليًا؛ يمكنك مشاهدة الموقع فقط حتى انتهاء المدة، ولا تستلم منحة الساعة.');
 if(path==='/api/auth')return await auth(request,db,p);
 if(path==='/api/season39/reset'||path==='/api/season40/reset')return err(403,'حماية تحديث 62: التصفير محظور لمنع خسارة حسابات المواطنين');
 if(path==='/api/push/preferences')return await zPushRequest(request,db,context.env,'preferences',p);
 if(path==='/api/push/subscribe')return await zPushRequest(request,db,context.env,'subscribe',p);
 if(path==='/api/push/unsubscribe')return await zPushRequest(request,db,context.env,'unsubscribe',p);
 if(path==='/api/push/test')return await zPushRequest(request,db,context.env,'test',p);
 if(path==='/api/sovereign/control'){if(!isAdmin(current))return err(403,'افتح الرئاسة بخطوتين أولًا');return await z37Sovereign(request,db,context.env,p);}
 if(path==='/api/billing/action')return await z38BillAction(request,db,p);
 if(path==='/api/charity/action'){await z33Ensure(db);return await z33CharityAction(request,db,p)}
 if(path==='/api/campaign/action'){await z33Ensure(db);await z39WarUpgrade(db);await z38WarEnsure(db);return await z33WarAction(request,db,p)}
 if(path==='/api/war/unlock')return err(403,Z62_PEACE_MESSAGE);
 if(path==='/api/war/action'){await z39WarUpgrade(db);await z38WarEnsure(db);return await zWarAction(request,db,p,context.env,context.waitUntil);}
 if(path==='/api/modern/action')return await zModernAction(request,db,p);
 if(path==='/api/finance/action')return await zFinanceAction(request,db,p);
 if(path==='/api/z63/action')return err(410,'تم إلغاء الحكومة والبرلمان في V64');
 if(path==='/api/z64/action')return await z64Action(request,db,p);
 if(path==='/api/z65/action')return await z65Action(request,db,p);
 if(path==='/api/z62/action'){await z63ExpireGovernors(db);return await z62Action(request,db,p);}
 if(path==='/api/federation/action')return await z46Action(request,db,p);
 if(path==='/api/z59/action')return await z59Action(request,db,p);
 if(path==='/api/missions46/claim')return await z46MissionClaim(request,db,p);
 if(path==='/api/zangar-ai/chat')return await z46AI(request,db,context.env,p);
 if(path==='/api/loans44/action')return await z44LoansAction(request,db,p);
 if(path==='/api/modern/password')return await zChangePassword(request,db,p);
 if(path==='/api/courier/action')return await zCourierAction(request,db,p);
 if(path==='/api/education/action')return await z36EducationAction(request,db,p);
 if(path==='/api/jobs36/action'&&String(p.type||'')==='ally_support')return err(403,Z62_PEACE_MESSAGE);
 if(path==='/api/jobs36/action')return await z36JobsAction(request,db,p);
 if(path==='/api/world/action')return await zWorldAction(request,db,p);
 if(path==='/api/police/unlock')return await unlockPolice(request,db,p);
 if(path==='/api/prison/action')return await prisonAction(request,db,p);
 if(path==='/api/chat/action')return await chatAction(request,db,p);
 if(path==='/api/action')return await action(request,db,p);
 if(path==='/api/economy/action')return await economyAction(request,db,p);
 if(path==='/api/admin/unlock')return await unlockAdmin(request,db,context.env,p);
 if(path==='/api/presidency49/gate')return await z49Gate(request,db,p,context.env);
 if(path==='/api/central53/action')return await z53Action(request,db,p);
 if(path==='/api/roles42/redeem')return await z42CodeRedeem(request,db,p);
 if(path==='/api/state/budget42')return await z42Budget(request,db,p);
 if(path==='/api/admin/message42')return await z42Message(request,db,p);
  if(path==='/api/department/unlock')return await unlockDepartment(request,db,p);
  if(path==='/api/inbox/seen')return await markInboxSeen(request,db);
 return err(404,'خدمة غير موجودة');
}catch(e){console.error('Zangar API:',e);if(e instanceof SyntaxError)return err(400,'بيانات JSON غير صحيحة');if(/D1_ERROR:|SQLITE_ERROR|SQLITE_CONSTRAINT|SQLITE_BUSY|SQLITE_LOCKED/i.test(String(e?.message||''))&&!/^[\u0600-\u06FF]/.test(String(e?.message||'')))return err(409,'تعذّر إتمام العملية في قاعدة البيانات. لم تُؤكد عملية الشراء؛ حدّث الرصيد قبل المحاولة مرة أخرى.');return err(400,e.message||'حدث خطأ غير متوقع')}
}

// NEW ZANGAR STATE — Update 4 economy module (Cloudflare D1; server-authoritative)
const ECON_ASSETS = {
 shop:{name:'متجر تجاري',price:8500,cycle:3*3600000,reward:180,emoji:'🛒',output:'بضاعة',qty:3},
 restaurant:{name:'مطعم الزنجر',price:13500,cycle:3*3600000,reward:260,emoji:'🍗',output:'وجبة زنجر',qty:2},
 transport:{name:'شركة توصيل',price:4200,cycle:2*3600000,reward:120,emoji:'🚚'},
 mine:{name:'منجم معادن',price:10500,cycle:4*3600000,reward:220,emoji:'⛏️',output:'حديد',qty:3},
 fish:{name:'قارب صيد',price:5500,cycle:2*3600000,reward:125,emoji:'🎣',output:'سمك',qty:3},
 ranch:{name:'مزرعة حيوانات',price:18500,cycle:4*3600000,reward:300,emoji:'🐔',output:'بيض',qty:4},
 construction:{name:'شركة مقاولات',price:28500,cycle:6*3600000,reward:500,emoji:'🏗️',output:'مواد بناء',qty:2},
 factory:{name:'مصنع منتجات',price:48000,cycle:8*3600000,reward:850,emoji:'🏭',output:'منتج مصنع',qty:4},
 megamall:{name:'المجمع التجاري الضخم',price:200000,cycle:4*3600000,reward:16000,emoji:'🏬'},
 industrycity:{name:'المدينة الصناعية',price:400000,cycle:4*3600000,reward:32000,emoji:'🏭'},
 investtowers:{name:'الأبراج الاستثمارية',price:600000,cycle:4*3600000,reward:48000,emoji:'🏙️'},
 nationalair:{name:'شركة الطيران الوطنية',price:800000,cycle:4*3600000,reward:64000,emoji:'✈️'},
 empiretrade:{name:'الإمبراطورية التجارية',price:1000000,cycle:4*3600000,reward:130000,emoji:'💎'}
};
for(const item of Object.values(ECON_ASSETS)){item.cycle=86400000;item.reward=Math.floor(item.price*.15)}
const ECON_SEEDS={wheat:{name:'قمح',cost:240,cycle:45*60000,qty:5,item:'قمح'},tomato:{name:'طماطم',cost:510,cycle:2*3600000,qty:6,item:'طماطم'},strawberry:{name:'فراولة',cost:1100,cycle:4*3600000,qty:6,item:'فراولة'}};
const ECON_GOODS={'قمح':105,'طماطم':175,'فراولة':320,'بضاعة':125,'وجبة زنجر':220,'حديد':245,'سمك':175,'بيض':120,'مواد بناء':450,'منتج مصنع':350};
const ECON_JOBS={courier:{name:'مندوب توصيل',reward:360,cooldown:40*60000},cashier:{name:'كاشير',reward:290,cooldown:45*60000},farmer:{name:'عامل مزرعة',reward:420,cooldown:60*60000},builder:{name:'عامل بناء',reward:500,cooldown:75*60000}};
const ECON_STOCKS={ZNGR:{name:'شركات الزنجر',base:1440},OASIS:{name:'واحة الزنجر',base:864},GOLD:{name:'الصناعات الذهبية',base:2460},TECH:{name:'تقنيات الزنجر',base:3800},FOOD:{name:'مطاعم الزنجر',base:1750},SHIP:{name:'شركة التوصيل',base:1250},BUILD:{name:'عمران الزنجر',base:2950},ENERGY:{name:'طاقة الواحة',base:4200},MED:{name:'القطاع الطبي',base:3100},SPORT:{name:'رياضة الزنجر',base:980}};
function econPrice(sym,now=Date.now()){let item=ECON_STOCKS[sym];if(!item)throw Error('سهم غير معروف');let tick=Math.floor(now/3600000),seed=sym==='ZNGR'?1:sym==='OASIS'?4:8;return Math.round(item.base*(1+0.14*Math.sin(tick*.53+seed)+0.055*Math.sin(tick*.19+seed*2)));}
async function economyBootstrap(db,u){const config=await z45LoanConfig(db);const empty={loan_config:config,asset_taxes:[],assets:[],inventory:[],market:[],auctions:[],requests:[],loans:[],shares:[],job_ready_at:0,prices:Object.fromEntries(Object.keys(ECON_STOCKS).map(k=>[k,econPrice(k)]))};let market=await z32PublicRead('economy-market',60000,()=>db.prepare("SELECT id,seller_id,seller_name,item,quantity,unit_price,created_at FROM econ_market WHERE status='open' ORDER BY created_at DESC LIMIT 100").all());empty.market=market.results;let auctionRows=await z32PublicRead('economy-auctions',60000,()=>db.prepare("SELECT * FROM econ_auctions WHERE status='open' ORDER BY created_at DESC LIMIT 60").all());empty.auctions=auctionRows.results;
 if(!u)return empty;
 let [a,i,r,l,s,j]=await Promise.all([
 db.prepare('SELECT * FROM econ_assets WHERE user_id=? ORDER BY created_at DESC').bind(u.id).all(),
 db.prepare('SELECT item,quantity FROM econ_inventory WHERE user_id=? AND quantity>0 ORDER BY item').bind(u.id).all(),
 (isAdmin(u)?db.prepare('SELECT * FROM econ_requests ORDER BY created_at DESC LIMIT 120').all():db.prepare('SELECT * FROM econ_requests WHERE user_id=? ORDER BY created_at DESC LIMIT 80').bind(u.id).all()),
 db.prepare('SELECT * FROM econ_loans WHERE user_id=? ORDER BY created_at DESC LIMIT 15').bind(u.id).all(),
 db.prepare('SELECT symbol,quantity FROM econ_shares WHERE user_id=?').bind(u.id).all(),
 db.prepare('SELECT ready_at FROM econ_job_cooldowns WHERE user_id=?').bind(u.id).first()
 ]);const taxRows=await db.prepare('SELECT asset_id FROM z_asset_tax_paid WHERE owner_id=?').bind(u.id).all();const paidIds=new Set(taxRows.results.map(x=>x.asset_id));
 const businessRows=await db.prepare('SELECT business_key,next_at FROM z_business_income WHERE owner_id=?').bind(u.id).all();const business_income=Object.fromEntries(businessRows.results.map(r=>[r.business_key,Number(r.next_at)]));
 const asset_taxes=a.results.map(asset=>({id:asset.id,kind:asset.kind,price:asset.kind==='land'?95000:Number(ECON_ASSETS[asset.kind]?.price||0),paid:paidIds.has(asset.id)})).filter(x=>x.price>0);
 return {...empty,business_income,asset_taxes,assets:a.results,inventory:i.results,requests:r.results,loans:l.results,shares:s.results,job_ready_at:j?.ready_at||0};}
async function econBalance(db,user,amount,reason,now=Date.now()){
 amount=Math.trunc(amount);if(!Number.isSafeInteger(amount)||amount===0)throw Error('مبلغ غير صالح');
 const row=await db.prepare('UPDATE users SET points=points+? WHERE id=? AND (? > 0 OR points+?>=0) RETURNING points').bind(amount,user,amount,amount).first();
 if(!row)throw Error('رصيد النقاط غير كافٍ');await addTx(db,user,amount,reason,now);return row;
}
async function econSpendWithStateTax(db,u,amount,reason,now=Date.now()){
 amount=Math.ceil(Number(amount)||0);if(!Number.isInteger(amount)||amount<=0)throw Error('مبلغ شراء غير صالح');
 const stateTax=Math.max(1,Math.ceil(amount*(await z78TaxRate(db,u)))),total=amount+stateTax;
 const row=await db.prepare('UPDATE users SET points=points-? WHERE id=? AND points>=? RETURNING points').bind(total,u.id,total).first();
 if(!row)throw Error('رصيد النقاط غير كافٍ');
 await addTx(db,u.id,-total,reason+' + دعم اقتصاد الدولة '+stateTax+' نقطة',now);
 await stateEconomyAdd(db,stateTax,reason,u.name,now);
 return {total,stateTax};
}
async function econInventory(db,user,item,delta){
 if(!ECON_GOODS[item]||!Number.isInteger(delta)||delta===0||Math.abs(delta)>1000)throw Error('منتج أو كمية غير صالحة');
 let result=delta<0
  ?await db.prepare('UPDATE econ_inventory SET quantity=quantity+? WHERE user_id=? AND item=? AND quantity>=? RETURNING quantity').bind(delta,user,item,-delta).first()
  :await db.prepare('INSERT INTO econ_inventory(user_id,item,quantity) VALUES(?,?,?) ON CONFLICT(user_id,item) DO UPDATE SET quantity=quantity+excluded.quantity RETURNING quantity').bind(user,item,delta).first();
 if(!result)throw Error('كمية المنتجات غير كافية');return result;
}
async function economyAction(req,db,p){ const u=await getMe(req,db);if(!u)return err(401,'سجّل دخولك أولًا');const now=Date.now(),type=p.type,admin=isAdmin(u),assetId=crop(p.asset_id,80);
 await zBusinessPayDue(db,now,u.id);
 let sus=await db.prepare('SELECT until_at FROM suspensions WHERE user_id=?').bind(u.id).first();if(sus&&sus.until_at>now)return err(403,'عضويتك موقوفة مؤقتًا');
if(await prisonActive(db,u.id,now))return err(403,'أنت في السجن: لا يمكنك العمل أو الدفع أو استلام النقاط حتى انتهاء المدة.');
if(['plant','buildHouse','buyOffer','buyAsset','repay','bidAuction','stocks'].includes(type) && (type!=='stocks'||p.side==='buy'))await visaPayment(db,u,p.payment_method);
 switch(type){
 case 'job':{if(['cashier','farmer','builder'].includes(p.job))throw Error('الوظيفة الآن لعبة تفاعلية من مركز ألعاب الوظائف');if(p.job==='courier')throw Error('مندوب التوصيل يكسب من إنهاء لعبة زنجر راش، افتح زر اللعبة من الوظائف');let job=ECON_JOBS[p.job];if(!job)throw Error('الوظيفة غير موجودة');let got=await db.prepare('INSERT INTO econ_job_cooldowns(user_id,ready_at) VALUES(?,?) ON CONFLICT(user_id) DO UPDATE SET ready_at=excluded.ready_at WHERE econ_job_cooldowns.ready_at<=? RETURNING ready_at').bind(u.id,now+job.cooldown,now).first();if(!got)throw Error('انتهيت من عمل منذ قليل، انتظر حتى موعد الوظيفة التالية');await zTreasuryPay(db,u.id,job.reward,'أجر وظيفة '+job.name,'ميزانية الدولة',now);await activity(db,u.name,'عمل بوظيفة '+job.name,now);break;}
 case 'landRequest':{if(u.points<104500)throw Error('الأرض 95,000 + ضريبة ملكية 10% = 104,500 زنجر؛ اجمع المبلغ أولًا');let existing=await db.prepare("SELECT id FROM econ_requests WHERE user_id=? AND kind='land' AND status='pending'").bind(u.id).first();if(existing)throw Error('لديك طلب أرض ينتظر مراجعة الرئاسة');let count=await db.prepare("SELECT COUNT(*) n FROM econ_assets WHERE user_id=? AND kind='land'").bind(u.id).first();if(count.n>=3)throw Error('الحد الأقصى 3 أراضٍ لكل مواطن');await db.prepare('INSERT INTO econ_requests(id,user_id,user_name,kind,amount,message,status,reply,created_at) VALUES(?,?,?,?,?,?,?,?,?)').bind(id(),u.id,u.name,'land',95000,'طلب شراء أرض خاصة','pending','',now).run();await activity(db,u.name,'قدّم طلب شراء أرض خاصّة بموافقة الرئاسة',now);break;}
 case 'loanRequest':{let amount=Number(p.amount),msg=crop(p.message,300),cfg=await z45LoanConfig(db);if(!cfg.open)throw Error('طلبات القروض متوقفة مؤقتًا بقرار الرئاسة');if(!Number.isInteger(amount)||amount<3000||amount>cfg.max)throw Error('القرض بين 3,000 و'+cfg.max.toLocaleString('en-US')+' زنجر');let unpaid=await db.prepare('SELECT COUNT(*) n FROM econ_loans WHERE user_id=? AND repaid<principal').bind(u.id).first(),pending=await db.prepare("SELECT id FROM econ_requests WHERE user_id=? AND kind='loan' AND status='pending'").bind(u.id).first();if(unpaid.n||pending||u.points<0)throw Error('لديك قرض مستحق أو رصيد سالب؛ سدّد الدين قبل طلب قرض جديد');if(msg.length<8)throw Error('اكتب سبب القرض');await db.prepare('INSERT INTO econ_requests(id,user_id,user_name,kind,amount,message,status,reply,created_at) VALUES(?,?,?,?,?,?,?,?,?)').bind(id(),u.id,u.name,'loan',amount,msg,'pending','',now).run();break;}
 case 'contact':{let msg=crop(p.message,400);if(msg.length<8)throw Error('اكتب رسالة من 8 حروف على الأقل');let pending=await db.prepare("SELECT COUNT(*) n FROM econ_requests WHERE user_id=? AND kind='message' AND status='pending'").bind(u.id).first();if(pending.n>=3)throw Error('لديك 3 رسائل معلّقة؛ انتظر رد الرئاسة');await db.prepare('INSERT INTO econ_requests(id,user_id,user_name,kind,amount,message,status,reply,created_at) VALUES(?,?,?,?,?,?,?,?,?)').bind(id(),u.id,u.name,'message',0,msg,'pending','',now).run();break;}
 case 'decision':{let target=await db.prepare("SELECT * FROM econ_requests WHERE id=? AND status='pending'").bind(crop(p.id,80)).first();if(!target)throw Error('الطلب انتهت مراجعته بالفعل');if(!admin && !(target.kind==='loan'&&z36Finance(u)))throw Error('اعتماد الأراضي للرئاسة، والقروض لوزير المالية أو الرئاسة');let approve=p.approve===true,reply=crop(p.reply,250),newStatus=approve?'approved':'rejected';
 if(approve&&target.kind==='land'){
  let count=await db.prepare("SELECT COUNT(*) n FROM econ_assets WHERE user_id=? AND kind='land'").bind(target.user_id).first();if(count.n>=3)throw Error('وصل المواطن إلى 3 أراضٍ');
  let balance=await db.prepare('SELECT points FROM users WHERE id=?').bind(target.user_id).first();if(!balance||balance.points<104500)throw Error('رصيد مقدم الطلب لم يعد كافيًا؛ ارفضه أو اطلب منه إعادة جمع النقاط');
 }
 if(approve&&target.kind==='loan'){const cfg=await z45LoanConfig(db);if(!cfg.open||Number(target.amount)>cfg.max)throw Error('القروض مغلقة أو قيمة الطلب أكبر من الحد الحالي');let due=await db.prepare('SELECT COUNT(*) n FROM econ_loans WHERE user_id=? AND repaid<principal').bind(target.user_id).first();if(due.n)throw Error('لدى المواطن قرض قائم');}
 let claimed=await db.prepare("UPDATE econ_requests SET status=?,reply=? WHERE id=? AND status='pending' RETURNING id").bind(newStatus,reply,target.id).first();if(!claimed)throw Error('الطلب تمت معالجته');
 if(approve&&target.kind==='land'){const landId=id();await econBalance(db,target.user_id,-104500,'شراء أرض 95,000 + ضريبة ملكية 10%',now);await db.prepare('INSERT INTO econ_assets(id,user_id,kind,level,created_at,last_at,meta) VALUES(?,?,?,?,?,?,?)').bind(landId,target.user_id,'land',1,now,0,'{}').run();await db.prepare('INSERT OR IGNORE INTO z_asset_tax_paid(asset_id,owner_id,paid_at) VALUES(?,?,?)').bind(landId,target.user_id,now).run();await stateEconomyAdd(db,9500,'ضريبة ملكية أرض',target.user_name,now);}
 if(approve&&target.kind==='loan'){await db.prepare('INSERT INTO econ_loans(id,user_id,principal,repaid,created_at,due_at) VALUES(?,?,?,?,?,?)').bind(id(),target.user_id,target.amount,0,now,now+5*86400000).run();await zTreasuryPay(db,target.user_id,target.amount,'قرض الرئاسة (يُرد بدون فائدة)',u.name,now);}
 await activity(db,u.name,(approve?'وافق على':'رفض')+' طلب '+target.user_name+' — '+target.kind,now);break;}
 case 'assetOwnershipTax':{
  const asset=await db.prepare('SELECT id,kind FROM econ_assets WHERE id=? AND user_id=?').bind(assetId,u.id).first();if(!asset)throw Error('الممتلكات غير موجودة');
  const value=asset.kind==='land'?95000:Number(ECON_ASSETS[asset.kind]?.price||0);if(value<=0)throw Error('نوع الملكية غير معروف');
  const tax=Math.ceil(value*.10),paid=await db.prepare('UPDATE users SET points=points-? WHERE id=? AND points>=? AND NOT EXISTS(SELECT 1 FROM z_asset_tax_paid WHERE asset_id=? AND owner_id=?) RETURNING points').bind(tax,u.id,tax,asset.id,u.id).first();
  if(!paid)throw Error('الضريبة مدفوعة سابقًا أو رصيدك لا يكفي');
  await db.prepare('INSERT OR IGNORE INTO z_asset_tax_paid(asset_id,owner_id,paid_at) VALUES(?,?,?)').bind(asset.id,u.id,now).run();await addTx(db,u.id,-tax,'ضريبة ملكية 10% على '+asset.kind,now);await stateEconomyAdd(db,tax,'ضريبة ملكية '+asset.kind,u.name,now);break;
 }

 case 'repay':{let amount=Number(p.amount),loan=await db.prepare('SELECT * FROM econ_loans WHERE id=? AND user_id=?').bind(crop(p.id,80),u.id).first();if(!loan||loan.repaid>=loan.principal)throw Error('لا يوجد قرض مستحق');let remain=loan.principal-loan.repaid;if(!Number.isInteger(amount)||amount<1||amount>remain)throw Error('مبلغ سداد غير صحيح');await econBalance(db,u.id,-amount,'سداد جزء من قرض الرئاسة',now);await zTreasuryReceive(db,amount,'سداد قرض حكومي',u.name,now);await db.prepare('UPDATE econ_loans SET repaid=repaid+? WHERE id=?').bind(amount,loan.id).run();break;}
 case 'buyAsset':{let k=crop(p.kind,30),a=ECON_ASSETS[k];if(!a)throw Error('المشروع غير موجود');const projectTax=Math.max(1,Math.ceil(a.price*.10)),projectTotal=a.price+projectTax;let newId=id();let statements=[
 db.prepare("INSERT INTO econ_assets(id,user_id,kind,level,created_at,last_at,meta) SELECT ?,? ,?,1,?,?, '{}' FROM users WHERE id=? AND points>=?").bind(newId,u.id,k,now,now,u.id,projectTotal),
 db.prepare('UPDATE users SET points=points-? WHERE id=? AND EXISTS (SELECT 1 FROM econ_assets WHERE id=?)').bind(projectTotal,u.id,newId),
 db.prepare('INSERT INTO transactions(id,user_id,amount,note,created_at) SELECT ?,? ,?,?,? FROM econ_assets WHERE id=?').bind(id(),u.id,-projectTotal,'تأسيس '+a.name+' +10% ضريبة الدولة',now,newId)
 ];try{let result=await db.batch(statements);if(!result[0].meta?.changes)throw Error('الرصيد غير كافٍ أو تعذر افتتاح المشروع');}catch(err){if(/UNIQUE|constraint/i.test(String(err.message)))throw Error('المشروع موجود لديك بالفعل');throw err;}await db.prepare('INSERT OR IGNORE INTO z_asset_tax_paid(asset_id,owner_id,paid_at) VALUES(?,?,?)').bind(newId,u.id,now).run();/* Investment yield is now the single 15%-per-day claim. */await zTreasuryReceive(db,a.price,'شراء مشروع من الدولة: '+a.name,u.name,now);await stateEconomyAdd(db,projectTax,'رسوم تأسيس '+a.name,u.name,now);await activity(db,u.name,'افتتح '+a.name,now);break;}
 case 'collectAsset':{let asset=await db.prepare('SELECT * FROM econ_assets WHERE id=? AND user_id=?').bind(assetId,u.id).first(),a=asset&&ECON_ASSETS[asset.kind];if(!a)throw Error('هذا المشروع ليس لك');if(asset.last_at && now-asset.last_at<a.cycle)throw Error('المشروع لا يزال في دورة العمل');let change=await db.prepare('UPDATE econ_assets SET last_at=? WHERE id=? AND user_id=? AND (last_at=0 OR last_at<=?) RETURNING id').bind(now,asset.id,u.id,now-a.cycle).first();if(!change)throw Error('الدورة لم تنتهِ بعد');await zTreasuryPay(db,u.id,a.reward,'صافي أرباح '+a.name,'ميزانية الدولة',now);if(a.output)await econInventory(db,u.id,a.output,a.qty);break;}
 case 'plant':{let seed=ECON_SEEDS[p.seed];if(!seed)throw Error('نوع البذور غير صحيح');let asset=await db.prepare("SELECT * FROM econ_assets WHERE id=? AND user_id=? AND kind='land'").bind(assetId,u.id).first();if(!asset)throw Error('لا تملك هذه الأرض');let meta=JSON.parse(asset.meta||'{}');if(meta.crop)throw Error('يوجد محصول مزروع بالفعل؛ احصده أولًا');await econSpendWithStateTax(db,u,seed.cost,'شراء بذور '+seed.name,now);meta.crop=p.seed;meta.planted=now;await db.prepare('UPDATE econ_assets SET meta=? WHERE id=? AND user_id=?').bind(JSON.stringify(meta),asset.id,u.id).run();break;}
 case 'harvest':{let asset=await db.prepare("SELECT * FROM econ_assets WHERE id=? AND user_id=? AND kind='land'").bind(assetId,u.id).first();if(!asset)throw Error('الأرض غير موجودة');let meta=JSON.parse(asset.meta||'{}'),seed=ECON_SEEDS[meta.crop];if(!seed)throw Error('لا يوجد محصول جاهز');if(now-meta.planted<seed.cycle)throw Error('المحصول لم ينضج بعد');delete meta.crop;delete meta.planted;let did=await db.prepare('UPDATE econ_assets SET meta=? WHERE id=? AND user_id=? AND meta=? RETURNING id').bind(JSON.stringify(meta),asset.id,u.id,asset.meta).first();if(!did)throw Error('تم حصاد هذا المحصول بالفعل');await econInventory(db,u.id,seed.item,seed.qty);await activity(db,u.name,'حصد '+seed.name,now);break;}
 case 'buildHouse':{let a=await db.prepare("SELECT * FROM econ_assets WHERE id=? AND user_id=? AND kind='land'").bind(assetId,u.id).first();if(!a)throw Error('الأرض غير موجودة');let meta=JSON.parse(a.meta||'{}');if(meta.house)throw Error('بنيت بيتًا على هذه الأرض بالفعل');await econSpendWithStateTax(db,u,38000,'بناء منزل للإيجار على الأرض',now);meta.house=true;meta.rent_at=now;await db.prepare('UPDATE econ_assets SET meta=? WHERE id=?').bind(JSON.stringify(meta),a.id).run();break;}
 case 'rent':{let a=await db.prepare("SELECT * FROM econ_assets WHERE id=? AND user_id=? AND kind='land'").bind(assetId,u.id).first();if(!a)throw Error('الأرض غير موجودة');let meta=JSON.parse(a.meta||'{}');if(!meta.house)throw Error('يجب بناء منزل أولًا');if(now-(meta.rent_at||now)<6*3600000)throw Error('لم يحِن موعد الإيجار بعد');meta.rent_at=now;let success=await db.prepare('UPDATE econ_assets SET meta=? WHERE id=? AND user_id=? AND meta=? RETURNING id').bind(JSON.stringify(meta),a.id,u.id,a.meta).first();if(!success)throw Error('تم تحصيل الإيجار');await zTreasuryPay(db,u.id,1200,'دخل إيجار المنزل','ميزانية الدولة',now);break;}
 case 'sellGoods':{let item=crop(p.item,40),q=Number(p.quantity),base=ECON_GOODS[item];if(!base||!Number.isInteger(q)||q<1||q>100)throw Error('منتج أو كمية غير صالحة');await econInventory(db,u.id,item,-q);await zTreasuryPay(db,u.id,base*q,'بيع '+q+' × '+item+' في سوق الدولة','ميزانية الدولة',now);break;}
 case 'listGoods':{let item=crop(p.item,40),q=Number(p.quantity),unit=Number(p.unit_price);if(!ECON_GOODS[item]||!Number.isInteger(q)||q<1||q>100||!Number.isInteger(unit)||unit<10||unit>5000)throw Error('بيانات العرض غير صالحة');let listed=await db.prepare("SELECT COUNT(*) n FROM econ_market WHERE seller_id=? AND status='open'").bind(u.id).first();if(listed.n>=10)throw Error('الحد الأقصى 10 عروض مفتوحة');await econInventory(db,u.id,item,-q);await db.prepare('INSERT INTO econ_market(id,seller_id,seller_name,item,quantity,unit_price,status,created_at) VALUES(?,?,?,?,?,?,?,?)').bind(id(),u.id,u.name,item,q,unit,'open',now).run();break;}
 case 'cancelOffer':{let offer=await db.prepare("UPDATE econ_market SET status='cancelled' WHERE id=? AND seller_id=? AND status='open' RETURNING item,quantity").bind(crop(p.id,80),u.id).first();if(!offer)throw Error('العرض غير متاح');await econInventory(db,u.id,offer.item,offer.quantity);break;}
 case 'buyOffer':{let offer=await db.prepare("SELECT * FROM econ_market WHERE id=? AND status='open'").bind(crop(p.id,80)).first();if(!offer||offer.seller_id===u.id)throw Error('العرض غير متاح لك');let price=offer.quantity*offer.unit_price;if(price>500000)throw Error('العرض يتجاوز حد التعامل');if(u.points<price)throw Error('رصيدك لا يكفي');let taken=await db.prepare("UPDATE econ_market SET status='sold' WHERE id=? AND status='open' RETURNING id").bind(offer.id).first();if(!taken)throw Error('العرض تم بيعه بالفعل');await econSpendWithStateTax(db,u,price,'شراء من '+offer.seller_name+' — '+offer.item,now);await econInventory(db,u.id,offer.item,offer.quantity);await econBalance(db,offer.seller_id,Math.floor(price*.95),'بيع في سوق المواطنين: '+offer.item,now);await stateEconomyAdd(db,price-Math.floor(price*.95),'عمولة سوق المواطنين',u.name,now);break;}
 case 'createAuction':{let item=crop(p.item,40),qty=Number(p.quantity),min=Number(p.start_price);if(!ECON_GOODS[item]||!Number.isInteger(qty)||qty<1||qty>50||!Number.isInteger(min)||min<100||min>100000)throw Error('بيانات المزاد غير صالحة');let n=await db.prepare("SELECT COUNT(*) n FROM econ_auctions WHERE seller_id=? AND status='open'").bind(u.id).first();if(n.n>=3)throw Error('ثلاث مزادات مفتوحة كحد أقصى');await econInventory(db,u.id,item,-qty);await db.prepare('INSERT INTO econ_auctions(id,seller_id,seller_name,item,quantity,start_price,bid,highest_bidder,ends_at,status,created_at) VALUES(?,?,?,?,?,?,?,?,?,?,?)').bind(id(),u.id,u.name,item,qty,min,0,'',now+2*3600000,'open',now).run();break;}
 case 'bidAuction':{let idv=crop(p.id,80),row=await db.prepare("SELECT * FROM econ_auctions WHERE id=? AND status='open' AND ends_at>?").bind(idv,now).first(),bid=Number(p.amount);if(!row||row.seller_id===u.id)throw Error('المزاد غير متاح لك');let next=Math.max(row.start_price,row.bid+Math.max(100,Math.ceil(row.bid*.05)));if(!Number.isInteger(bid)||bid<next||bid>250000)throw Error('المزايدة أقل من الحد الأدنى أو أعلى من الحد');if(u.points<bid+Math.ceil(bid*.10))throw Error('رصيدك لا يكفي قيمة المزايدة + ضريبة 10%');let got=await db.prepare("UPDATE econ_auctions SET bid=?,highest_bidder=? WHERE id=? AND status='open' AND bid=? AND ends_at>? RETURNING id").bind(bid,u.id,idv,row.bid,now).first();if(!got)throw Error('سبقك مزايد آخر؛ حدّث الصفحة');await econSpendWithStateTax(db,u,bid,'حجز نقاط مزايدة: '+row.item,now);if(row.highest_bidder)await econBalance(db,row.highest_bidder,row.bid,'استرداد قيمة مزايدة تجاوزها شخص آخر',now);break;}
 case 'settleAuction':{let row=await db.prepare("SELECT * FROM econ_auctions WHERE id=? AND status='open' AND ends_at<=?").bind(crop(p.id,80),now).first();if(!row)throw Error('المزاد لم ينتهِ أو تم تسويته');let got=await db.prepare("UPDATE econ_auctions SET status='closed' WHERE id=? AND status='open' RETURNING id").bind(row.id).first();if(!got)throw Error('المزاد تمت تسويته');if(row.highest_bidder){await econInventory(db,row.highest_bidder,row.item,row.quantity);await econBalance(db,row.seller_id,Math.floor(row.bid*.95),'ربح مزاد: '+row.item,now);await stateEconomyAdd(db,row.bid-Math.floor(row.bid*.95),'عمولة مزاد الدولة',u.name,now);}else await econInventory(db,row.seller_id,row.item,row.quantity);break;}
 case 'stocks':{let sym=crop(p.symbol,10),qty=Number(p.quantity),side=p.side,price=await zStockPrice(db,sym);if(!Number.isInteger(qty)||qty<1||qty>25||!['buy','sell'].includes(side))throw Error('تداول غير صحيح');if(side==='buy'){let total=Math.ceil(price*qty*1.03);await econSpendWithStateTax(db,u,total,'شراء '+qty+' سهم '+sym+' شامل رسوم تداول 3% وضريبة 10%',now);await db.prepare('INSERT INTO econ_shares(user_id,symbol,quantity) VALUES(?,?,?) ON CONFLICT(user_id,symbol) DO UPDATE SET quantity=quantity+excluded.quantity').bind(u.id,sym,qty).run();}else{let current=await db.prepare('SELECT quantity FROM econ_shares WHERE user_id=? AND symbol=?').bind(u.id,sym).first();if(!current||current.quantity<qty)throw Error('لا تملك هذا العدد من الأسهم');let changed=await db.prepare('UPDATE econ_shares SET quantity=quantity-? WHERE user_id=? AND symbol=? AND quantity>=? RETURNING quantity').bind(qty,u.id,sym,qty).first();if(!changed)throw Error('أسهم غير كافية');await zTreasuryPay(db,u.id,Math.floor(price*qty*.97),'بيع '+qty+' سهم '+sym+' بعد 3% رسوم','ميزانية الدولة',now);}break;}
 default:return err(400,'عملية تجارية غير معروفة')}
 return json({ok:true});
}

// ZANGAR 18: additions only; all balances are virtual in-game زنجر.
const ZCARD_TIERS={classic:{price:0,rate:0,title:'كلاسيك'},gold:{price:200,rate:1,title:'ذهبي'},platinum:{price:350,rate:4,title:'بلاتيني'},royal:{price:750,rate:10,title:'ملكي'}};
async function zModernState(req,db){
 await zStockTick(db);
 const u=await getMe(req,db);if(!u)return err(401,'سجّل دخولك أولًا');
 const [cards,decision,listing,mine,saving,stocks,positions,chat]=await Promise.all([
 db.prepare('SELECT p.*,c.kind,c.number FROM z_card_profiles p JOIN cards c ON c.id=p.card_id WHERE p.user_id=? ORDER BY p.created_at DESC').bind(u.id).all(),
 db.prepare('SELECT d.id,d.title,d.kind,d.detail,d.created_at,a.name AS author FROM z_edu_decisions d JOIN users a ON a.id=d.author_id ORDER BY d.created_at DESC LIMIT 35').all(),
 db.prepare("SELECT l.*,u.name AS owner_name,a.kind AS asset_kind FROM z_property_listings l JOIN users u ON u.id=l.owner_id JOIN econ_assets a ON a.id=l.asset_id WHERE l.status='open' ORDER BY l.created_at DESC LIMIT 60").all(),
 db.prepare("SELECT id,kind,level FROM econ_assets WHERE user_id=? AND kind IN ('land','shop','restaurant','residence','factory') ORDER BY created_at DESC LIMIT 25").bind(u.id).all(),
 db.prepare('SELECT balance,interest_at FROM z_savings WHERE user_id=?').bind(u.id).first(),
 db.prepare('SELECT * FROM z_stock_state ORDER BY symbol').all(),
 db.prepare('SELECT symbol,quantity FROM econ_shares WHERE user_id=?').bind(u.id).all(),
 db.prepare('SELECT paid_until FROM z_chat_access WHERE user_id=?').bind(u.id).first()]);
 const recent=await db.prepare('SELECT symbol,price,created_at FROM z_stock_history ORDER BY created_at DESC LIMIT 500').all();
 const history=Object.fromEntries(Object.keys(ECON_STOCKS).map(sym=>[sym,[]]));for(const item of recent.results.reverse())if(history[item.symbol])history[item.symbol].push(item);
 const creditCards=cards.results.map(r=>({...r,number:r.number?.replace(/\d(?=\d{4})/g,'•')||''}));
 return json({cards:creditCards,decisions:decision.results,can_education:await hasDepartment(db,u,'education'),properties:listing.results,my_assets:mine.results,savings:saving||{balance:0,interest_at:0},stocks:stocks.results,holdings:positions.results,history,chat_paid_until:chat?.paid_until||0,points:u.points,rank:u.rank,job:u.job});
}
