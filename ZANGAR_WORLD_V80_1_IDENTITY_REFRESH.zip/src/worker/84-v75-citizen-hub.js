// ZANGAR WORLD V75 — مركز المواطن: مهام يومية + سلسلة أيام (streak) + ترتيب المواطنين + جولة التعريف.
// يعتمد على الصندوق اليومي الموجود (z59_daily_chests) ولا يغيّر أي منطق قديم.
// المكافآت تنزل بنفس أسلوب الصندوق: INSERT واحد + Trigger يضيف النقاط والمعاملة (ذري، ومحمي بـ UNIQUE ضد التكرار).
const Z75_STREAK_STEP=30;      // مكافأة كل يوم متتالي (تزيد حتى سقف الأيام)
const Z75_STREAK_CAP_DAYS=7;   // أقصى مضاعف: 7 × 30 = 210 زنجر/يوم
const Z75_MISSIONS=[
 {id:'chest',title:'🎁 افتح صندوق اليوم',desc:'من مركز تطور الاتحاد',reward:30,target:1},
 {id:'chat',title:'💬 اتكلم مع المواطنين',desc:'ابعت 3 رسائل في الشات',reward:40,target:3},
 {id:'job',title:'👷 خلّص جلسة شغل',desc:'اكسب مكافأة من لعبة الوظائف',reward:60,target:1},
 {id:'transfer',title:'💸 حوّل لمواطن',desc:'حوّل 10 زنجر أو أكتر لأي مواطن',reward:30,target:1}
];
let z75InitPromise=null;
async function z75Ensure(db){
 if(z75InitPromise)return z75InitPromise;
 z75InitPromise=(async()=>{
  for(const sql of [
   `CREATE TABLE IF NOT EXISTS z75_mission_claims(id TEXT PRIMARY KEY,user_id TEXT NOT NULL,day INTEGER NOT NULL,mission TEXT NOT NULL,reward INTEGER NOT NULL CHECK(reward BETWEEN 1 AND 500),created_at INTEGER NOT NULL,UNIQUE(user_id,day,mission))`,
   `CREATE INDEX IF NOT EXISTS idx_z75_mission_day ON z75_mission_claims(day,user_id)`,
   `CREATE TRIGGER IF NOT EXISTS z75_mission_credit AFTER INSERT ON z75_mission_claims BEGIN UPDATE users SET points=points+NEW.reward WHERE id=NEW.user_id; INSERT INTO transactions(id,user_id,amount,note,created_at) VALUES(lower(hex(randomblob(16))),NEW.user_id,NEW.reward,'مكافأة مهمة يومية',NEW.created_at); END`,
   `CREATE TABLE IF NOT EXISTS z75_streak_claims(id TEXT PRIMARY KEY,user_id TEXT NOT NULL,day INTEGER NOT NULL,streak INTEGER NOT NULL,reward INTEGER NOT NULL CHECK(reward BETWEEN 1 AND 1000),created_at INTEGER NOT NULL,UNIQUE(user_id,day))`,
   `CREATE TRIGGER IF NOT EXISTS z75_streak_credit AFTER INSERT ON z75_streak_claims BEGIN UPDATE users SET points=points+NEW.reward WHERE id=NEW.user_id; INSERT INTO transactions(id,user_id,amount,note,created_at) VALUES(lower(hex(randomblob(16))),NEW.user_id,NEW.reward,'مكافأة الأيام المتتالية',NEW.created_at); END`,
   `CREATE TABLE IF NOT EXISTS z75_onboarding(user_id TEXT PRIMARY KEY,done_at INTEGER NOT NULL)`
  ])await db.prepare(sql).run();
 })().catch(e=>{z75InitPromise=null;throw e});
 return z75InitPromise;
}
async function z75Count(db,sql,...args){try{const r=await db.prepare(sql).bind(...args).first();return Number(r?.n||0)}catch(e){if(/no such table/i.test(String(e)))return 0;throw e}}
// عدد ما أنجزه المواطن اليوم لكل مهمة (التحقق كله على السيرفر)
async function z75Progress(db,u,day){
 const start=day*86400000,end=start+86400000;
 const [chest,chat,job,transfer]=await Promise.all([
  z75Count(db,'SELECT COUNT(*) n FROM z59_daily_chests WHERE user_id=? AND day=?',u.id,day),
  z75Count(db,'SELECT COUNT(*) n FROM chat_messages WHERE sender_id=? AND created_at>=? AND created_at<?',u.id,start,end),
  z75Count(db,'SELECT COUNT(*) n FROM z36_job_rewards WHERE user_id=? AND amount>0 AND created_at>=? AND created_at<?',u.id,start,end),
  z75Count(db,"SELECT COUNT(*) n FROM transactions WHERE user_id=? AND amount<=-10 AND note LIKE 'تحويل إلى %' AND created_at>=? AND created_at<?",u.id,start,end)
 ]);
 return {chest,chat,job,transfer};
}
async function z75Streak(db,u,day){
 const rows=await db.prepare('SELECT day FROM z59_daily_chests WHERE user_id=? AND day>=? ORDER BY day DESC').bind(u.id,day-60).all();
 const days=new Set((rows.results||[]).map(r=>Number(r.day)));
 const chestToday=days.has(day);
 let cur=chestToday?day:day-1,n=0;
 while(days.has(cur)){n++;cur--}
 return {streak:n,chestToday};
}
async function z75Boards(db,day){
 return await z32PublicRead('z75-boards',60000,async()=>{
  const rich=await db.prepare('SELECT name,job,points FROM users ORDER BY points DESC,joined ASC LIMIT 10').all();
  const since=day-6;
  const weekly=await db.prepare(`SELECT * FROM (SELECT u.name,u.job,COALESCE(m.n,0)*10+COALESCE(c.n,0)*15 AS score FROM users u LEFT JOIN (SELECT user_id,COUNT(*) n FROM z75_mission_claims WHERE day>=? GROUP BY user_id) m ON m.user_id=u.id LEFT JOIN (SELECT user_id,COUNT(*) n FROM z59_daily_chests WHERE day>=? GROUP BY user_id) c ON c.user_id=u.id) WHERE score>0 ORDER BY score DESC LIMIT 10`).bind(since,since).all();
  return {rich:rich.results||[],weekly:weekly.results||[]};
 });
}
async function z75Hub(db,u){
 await z59Ensure(db);await z75Ensure(db);
 const now=Date.now(),day=Math.floor(now/86400000);
 const [prog,st,claimed,bonus,boards,rank,onb]=await Promise.all([
  z75Progress(db,u,day),z75Streak(db,u,day),
  db.prepare('SELECT mission FROM z75_mission_claims WHERE user_id=? AND day=?').bind(u.id,day).all(),
  db.prepare('SELECT reward FROM z75_streak_claims WHERE user_id=? AND day=?').bind(u.id,day).first(),
  z75Boards(db,day),
  z75Count(db,'SELECT COUNT(*)+1 n FROM users WHERE points>?',u.points),
  z75Count(db,'SELECT COUNT(*) n FROM z75_onboarding WHERE user_id=?',u.id)
 ]);
 const got=new Set((claimed.results||[]).map(r=>r.mission));
 const missions=Z75_MISSIONS.map(m=>({id:m.id,title:m.title,desc:m.desc,reward:m.reward,target:m.target,current:Math.min(prog[m.id]||0,m.target),done:(prog[m.id]||0)>=m.target,claimed:got.has(m.id)}));
 const stepsToday=Math.min(st.chestToday?st.streak:st.streak+1,Z75_STREAK_CAP_DAYS);
 return {ok:true,day,me:{name:u.name,points:u.points,job:u.job,rich_rank:rank},
  streak:{current:st.streak,chest_today:st.chestToday,claimed_today:!!bonus,bonus_today:stepsToday*Z75_STREAK_STEP,claimable:st.chestToday&&!bonus,cap_days:Z75_STREAK_CAP_DAYS},
  missions,boards,onboarding_done:!!onb};
}
async function z75ClaimMission(db,u,mission){
 await z59Ensure(db);await z75Ensure(db);
 const def=Z75_MISSIONS.find(m=>m.id===mission);if(!def)return err(400,'مهمة غير معروفة');
 const now=Date.now(),day=Math.floor(now/86400000),prog=await z75Progress(db,u,day);
 if((prog[def.id]||0)<def.target)return err(409,'لسه ماكملتش المهمة دي النهاردة');
 const row=await db.prepare('INSERT OR IGNORE INTO z75_mission_claims(id,user_id,day,mission,reward,created_at) VALUES(?,?,?,?,?,?) RETURNING reward').bind(uuid(),u.id,day,def.id,def.reward,now).first();
 if(!row)return err(409,'استلمت مكافأة المهمة دي النهاردة');
 return json({ok:true,reward:def.reward,notice:'✅ استلمت '+def.reward+' زنجر'});
}
async function z75ClaimStreak(db,u){
 await z59Ensure(db);await z75Ensure(db);
 const now=Date.now(),day=Math.floor(now/86400000),st=await z75Streak(db,u,day);
 if(!st.chestToday)return err(409,'افتح صندوق اليوم الأول من مركز تطور الاتحاد');
 const reward=Math.min(st.streak,Z75_STREAK_CAP_DAYS)*Z75_STREAK_STEP;
 const row=await db.prepare('INSERT OR IGNORE INTO z75_streak_claims(id,user_id,day,streak,reward,created_at) VALUES(?,?,?,?,?,?) RETURNING reward').bind(uuid(),u.id,day,st.streak,reward,now).first();
 if(!row)return err(409,'استلمت مكافأة الأيام المتتالية النهاردة');
 return json({ok:true,reward,streak:st.streak,notice:'🔥 '+st.streak+' يوم متتالي — استلمت '+reward+' زنجر'});
}
async function z75Route(request,db,method,path){
 const u=await getMe(request,db);if(!u)return err(401,'سجّل دخولك الأول');
 if(method==='GET'&&path==='/api/v75/hub')return json(await z75Hub(db,u));
 if(method==='GET'&&path==='/api/v75/onboarding'){await z75Ensure(db);return json({ok:true,done:(await z75Count(db,'SELECT COUNT(*) n FROM z75_onboarding WHERE user_id=?',u.id))>0})}
 if(method!=='POST')return err(405,'طريقة غير مسموحة');
 let p={};try{p=await request.json()}catch(e){}
 if(path==='/api/v75/mission')return await z75ClaimMission(db,u,crop(p.mission,20));
 if(path==='/api/v75/streak')return await z75ClaimStreak(db,u);
 if(path==='/api/v75/onboarding'){await z75Ensure(db);await db.prepare('INSERT OR IGNORE INTO z75_onboarding(user_id,done_at) VALUES(?,?)').bind(u.id,Date.now()).run();return json({ok:true})}
 return err(404,'غير موجود');
}
