// V65.7: low-latency citizen actions. Do not run migrations for each ordinary click.
// Existing citizens already have the account, session and economy tables from registration.
async function z657CitizenSnapshot(db,userId){
 await z659AirEnsure(db);
 const row=await db.prepare('SELECT u.id,u.name,u.points-COALESCE(d.amount,0) AS points,u.claim_at,u.dob,u.bio,u.avatar FROM users u LEFT JOIN z660_air_debts d ON d.user_id=u.id WHERE u.id=?').bind(userId).first();
 if(!row)return null;
 const avatar=String(row.avatar||'');
 if(avatar.startsWith('data:image/')){
   let sig=2166136261;
   for(let i=0;i<avatar.length;i+=17)sig=Math.imul(sig^avatar.charCodeAt(i),16777619);
   sig=Math.imul(sig^avatar.length,16777619);
   row.avatar='/api/z639/avatar?user='+encodeURIComponent(row.id)+'&v='+(sig>>>0).toString(36);
 }
 return row;
}
async function z657FastCitizenAction(req,db,env,p){
 const origin=req.headers.get('Origin'),site=new URL(req.url).origin;
 if(origin&&origin!==site)return err(403,'طلب من مصدر مختلف غير مسموح');
 const current=await getMe(req,db);
 if(!current)return err(401,'سجل حسابك أولًا');
 // Preserve the existing season-reset, maintenance, prison and suspension gates.
 try{const reset=await db.prepare('SELECT phase FROM z40_reset_progress WHERE id=1').first();
   if(reset&&['clearing','finalizing'].includes(reset.phase))return err(423,'جاري تصفير الموسم؛ المعاملات متوقفة لحماية الأرصدة');
 }catch(e){if(!/no such table/i.test(String(e?.message||e)))throw e;}
 if(await isMaintenance(db)&&!(await maintenanceAllowed(req,db,env)))return err(503,'الدولة تحت الصيانة مؤقتًا');
 if(await prisonActive(db,current.id))return err(403,'أنت في السجن حاليًا؛ لا يمكنك استلام منحة أو تعديل الحساب');
 const result=await action(req,db,p);
 if(!result.ok)return result;
 try{
  const citizen=await z657CitizenSnapshot(db,current.id);
  if(citizen)return json({ok:true,citizen});
 }catch(e){console.warn('V65.7 saved but snapshot unavailable:',String(e));}
 return result;
}

// V65.8: bank commands execute as ONE SQLite INSERT with validation and balanced
// wallet+savings updates in the SAME trigger transaction. No half-credit or double reward.
const Z68_BANK_INTERVAL=3*60*60*1000;
const Z68_BANK_RATE=0.10;
let z68BankSchemaPromise=null;
async function z68BankEnsure(db){
 if(!z68BankSchemaPromise)z68BankSchemaPromise=(async()=>{
  await z78Ensure(db);
  await db.batch([
   db.prepare(`CREATE TABLE IF NOT EXISTS z68_bank_moves(id TEXT PRIMARY KEY,user_id TEXT NOT NULL,kind TEXT NOT NULL CHECK(kind IN ('deposit','withdraw','interest')),amount INTEGER NOT NULL CHECK(amount>0),created_at INTEGER NOT NULL)`),
   db.prepare(Z78_BANK_CHECK_TRIGGER.replace('CREATE TRIGGER','CREATE TRIGGER IF NOT EXISTS')),
   db.prepare(Z78_BANK_APPLY_TRIGGER.replace('CREATE TRIGGER','CREATE TRIGGER IF NOT EXISTS'))
  ]);
 })().catch(e=>{z68BankSchemaPromise=null;throw e});
 return z68BankSchemaPromise;
}
async function z68BankReceipt(db,id,userId){
 const row=await db.prepare('SELECT id,user_id,kind,amount,created_at FROM z68_bank_moves WHERE id=?').bind(id).first();
 if(!row||row.user_id!==userId)return null;
 return row;
}
async function z68BankSnapshot(db,userId,receipt){
 await z659AirEnsure(db);
 const data=await db.prepare('SELECT u.points-COALESCE(d.amount,0) AS points,COALESCE(s.balance,0) AS savings,COALESCE(s.interest_at,0) AS interest_at FROM users u LEFT JOIN z_savings s ON s.user_id=u.id LEFT JOIN z660_air_debts d ON d.user_id=u.id WHERE u.id=?').bind(userId).first();
 return {...data,ok:true,interest:receipt?.kind==='interest'?receipt.amount:0,receipt_id:receipt?.id||'',bank_kind:receipt?.kind||'',interest_rate:(await z78InterestPct(db,{id:userId,...(await db.prepare('SELECT role,job FROM users WHERE id=?').bind(userId).first()||{})})),interest_interval_ms:Z68_BANK_INTERVAL};
}
async function z68BankAction(req,db,env,p){
 const u=await getMe(req,db);if(!u)return err(401,'سجّل الدخول أولًا');
 if(await isMaintenance(db)&&!(await maintenanceAllowed(req,db,env)))return err(503,'الدولة تحت الصيانة');
 if(await prisonActive(db,u.id))return err(403,'حسابك في السجن؛ المعاملات متوقفة');
 const suspended=await db.prepare('SELECT until_at FROM suspensions WHERE user_id=?').bind(u.id).first();
 if(suspended&&Number(suspended.until_at)>Date.now())return err(403,'الحساب موقوف مؤقتًا');
 try{if(await z40ResetIsActive(db))return err(423,'تصفير الموسم جارٍ، المعاملات متوقفة');}
 catch(e){if(!/no such table/i.test(String(e.message)))throw e;}
 const requested=String(p.type||'');const kind=({savingDeposit:'deposit',savingWithdraw:'withdraw',savingInterest:'interest'})[requested];
 if(!kind)return err(400,'نوع عملية البنك غير صحيح');
 await z68BankEnsure(db);
 const rid=/^[a-zA-Z0-9-]{8,85}$/.test(String(p.request_id||''))?String(p.request_id):crypto.randomUUID();
 const old=await z68BankReceipt(db,rid,u.id);
 if(old){if(old.kind!==kind || (kind!=='interest'&&old.amount!==Number(p.amount)))return err(409,'رقم عملية مستخدم لقيمة مختلفة');return json(await z68BankSnapshot(db,u.id,old));}
 const raw=Number(p.amount);let amount=raw,now=Date.now();
 if(kind==='interest'){
  const row=await db.prepare('SELECT balance,interest_at FROM z_savings WHERE user_id=?').bind(u.id).first();
  if(!row || Number(row.interest_at||0)>now-Z68_BANK_INTERVAL)return err(409,'مكافأة التوفير كل 3 ساعات');
  amount=Math.floor(Number(row.balance||0)*(await z78InterestPct(db,u,now))/100);
  if(amount<1)return err(400,'رصيد التوفير أقل من المطلوب');
 }else if(!Number.isSafeInteger(amount)||amount<100||amount>100000)return err(400,'اختار مبلغًا بين 100 و100000 زنجر');
 try{await db.prepare('INSERT INTO z68_bank_moves(id,user_id,kind,amount,created_at) VALUES(?,?,?,?,?)').bind(rid,u.id,kind,amount,now).run();}
 catch(e){
  const previous=await z68BankReceipt(db,rid,u.id);
  if(previous&&previous.kind===kind)return json(await z68BankSnapshot(db,u.id,previous));
  const message=String(e.message||e);if(/رصيد التوفير|رصيد المحفظة|مكافأة التوفير|مبلغ البنك|الحساب غير متاح/i.test(message))return err(409,message.replace(/^.*?(رصيد التوفير|رصيد المحفظة|مكافأة التوفير|مبلغ البنك|الحساب غير متاح)/,'$1').slice(0,180));
  throw e;
 }
 return json(await z68BankSnapshot(db,u.id,{kind,id:rid,amount}));
}
// Stop re-running dozens of migrations before EVERY unrelated user click.
// A single indexed schema check distinguishes databases already running V65.
const Z68_REQUIRED_TABLES=['users','site_settings','sessions','transactions','z_savings','z_companies','z_notifications','z42_presence','z64_businesses','z63_elections'];
let z68SchemaReadyPromise=null;
async function z68EnsureGameSchema(db){
 if(!z68SchemaReadyPromise)z68SchemaReadyPromise=(async()=>{
  const names=Z68_REQUIRED_TABLES;
  let check=null;
  try{check=await db.prepare(`SELECT COUNT(*) AS n FROM sqlite_master WHERE type='table' AND name IN (${names.map(()=>'?').join(',')})`).bind(...names).first();}catch(e){console.warn('Schema check:',String(e));}
  if(Number(check?.n)===names.length)return;
  await ensureZangarSchema(db);await z639Ensure(db);await z33Ensure(db);await z39Ensure(db);await z42Ensure(db);await z43Ensure(db);await z44Ensure(db);await z45Ensure(db);await z46Ensure(db);await z49Ensure(db);await z62Ensure(db);await z63Ensure(db);await z64Ensure(db);
 })().catch(e=>{z68SchemaReadyPromise=null;throw e});
 return z68SchemaReadyPromise;
}


