// Update 27 business earnings: minted game currency, independent of state treasury.
// The existing push cron visits this every minute; fallback is account page visits.
// U29: company owner quizzes were removed at the president's request.
async function zBusinessPayDue(db,now=Date.now(),ownerId=''){
 const query=ownerId?'SELECT business_key,owner_id,next_at FROM z_business_income WHERE owner_id=? AND next_at<=? ORDER BY next_at LIMIT 6':'SELECT business_key,owner_id,next_at FROM z_business_income WHERE next_at<=? ORDER BY next_at LIMIT 6';
 const rows=ownerId?await db.prepare(query).bind(ownerId,now).all():await db.prepare(query).bind(now).all();
 let paid=0;
 for(const r of rows.results){
  const claimed=await db.prepare('UPDATE z_business_income SET next_at=?,cycles_paid=cycles_paid+1 WHERE business_key=? AND next_at=? AND next_at<=? RETURNING owner_id').bind(now+10800000,r.business_key,r.next_at,now).first();
  if(!claimed)continue;
  // SQLite/D1 trigger credits user + transaction atomically with the guarded income update.
  const amount=r.business_key.startsWith('company:')?4000:r.business_key.startsWith('asset:')?(await db.prepare('SELECT kind FROM econ_assets WHERE id=?').bind(r.business_key.slice(6)).first())?.kind==='construction'?180:90:90;
  await zNotify(db,claimed.owner_id,'🏢 عائد مشروعك','وصلك '+amount+' زنجر دخل مشروعك كل 3 ساعات، دون خصم من خزينة الدولة','money');
  paid++;
 }
 return paid;
}
async function zWorld(req,db){
 const u=await getMe(req,db);if(u){await z43GrantSweep(db,Date.now(),u.id);await z72ReminderSweep(db);}if(u)await zBusinessPayDue(db,Date.now(),u.id);const [all,furniturePublic,companies]=await Promise.all([
 z32PublicRead('world-homes',60000,()=>db.prepare(`SELECT u.id,u.name,u.joined,COALESCE(h.level,1) AS level,COALESCE(h.style,'gold') AS style FROM users u LEFT JOIN z_homes h ON h.user_id=u.id WHERE NOT EXISTS (SELECT 1 FROM z64_archived_users a WHERE a.user_id=u.id AND a.restored_at=0) ORDER BY u.joined ASC LIMIT 300`).all()),
 z32PublicRead('world-furniture',60000,()=>db.prepare('SELECT f.user_id,f.item,f.qty FROM z_furniture f JOIN users u ON u.id=f.user_id WHERE f.qty>0 AND NOT EXISTS(SELECT 1 FROM z64_archived_users a WHERE a.user_id=u.id AND a.restored_at=0) LIMIT 5000').all()),
 z32PublicRead('world-companies',30000,()=>db.prepare(`SELECT c.id,c.owner_id,u.name AS owner_name,c.name,c.balance,c.wage,c.next_pay_at,(SELECT COUNT(*) FROM z_company_members m WHERE m.company_id=c.id AND m.status='active') AS employees FROM z_companies c JOIN users u ON u.id=c.owner_id WHERE NOT EXISTS(SELECT 1 FROM z64_archived_users a WHERE a.user_id=u.id AND a.restored_at=0) ORDER BY c.created_at DESC LIMIT 70`).all())
 ]);
 const out={homes:all.results,companies:companies.results,savings:0,company_requests:[],my_company:null,furniture:furniturePublic.results,notifications:[],unread:0,reports:[],appeals:[],my_membership:null,hr:null,hr_requests:[],manage_staff:[],my_company_income_next:0,my_owner_bonus:0};
 if(!u)return json(out);
 const [saving,company,notices,membership]=await Promise.all([
 db.prepare('SELECT balance,interest_at FROM z_savings WHERE user_id=?').bind(u.id).first(),
 db.prepare('SELECT * FROM z_companies WHERE owner_id=?').bind(u.id).first(),
 db.prepare('SELECT * FROM z_notifications WHERE user_id=? ORDER BY created_at DESC LIMIT 35').bind(u.id).all(),
 db.prepare("SELECT m.company_id,m.status,c.name FROM z_company_members m JOIN z_companies c ON c.id=m.company_id WHERE m.user_id=? AND m.status IN ('active','pending') ORDER BY CASE m.status WHEN 'active' THEN 0 ELSE 1 END,m.created_at DESC LIMIT 1").bind(u.id).first()
 ]);
 if(company){const income=await db.prepare('SELECT next_at FROM z_business_income WHERE business_key=?').bind('company:'+company.id).first();const hires=await db.prepare("SELECT COUNT(*) AS n FROM z_company_members WHERE company_id=? AND status='active'").bind(company.id).first();out.my_company_income_next=Number(income?.next_at||0);out.my_owner_bonus=Number(hires?.n||0)*250;}
 out.savings=Number(saving?.balance||0);out.interest_at=Number(saving?.interest_at||0);await z37AccessEnsure(db);const specialOwner=await db.prepare('SELECT user_id FROM z37_sovereign_owner WHERE id=1').first();out.sovereign_owner=specialOwner?.user_id===u.id;out.sovereign_interest=false;out.my_company=company;out.my_membership=membership;out.notifications=notices.results;out.unread=out.notifications.filter(n=>!n.read_at).length;
 if(membership&&membership.status==='active')out.hr=await db.prepare('SELECT * FROM z_employee_hr WHERE company_id=? AND user_id=?').bind(membership.company_id,u.id).first();
 if(company||isAdmin(u)){
   const staff=await db.prepare(`SELECT m.company_id,m.user_id,u.name,m.status,c.name AS company_name,c.owner_id,c.wage AS base_wage,m.created_at,h.wage AS custom_wage,h.last_work_day,h.last_absence_day,h.paid_leave_until,h.unpaid_leave_until,h.fine_due,h.advance_due FROM z_company_members m JOIN users u ON u.id=m.user_id JOIN z_companies c ON c.id=m.company_id LEFT JOIN z_employee_hr h ON h.company_id=m.company_id AND h.user_id=m.user_id WHERE (?=1 OR m.company_id=?) ORDER BY m.created_at DESC LIMIT 150`).bind(isAdmin(u)?1:0,company?.id||'').all();
   out.manage_staff=staff.results;
   if(company)out.company_requests=staff.results.filter(a=>a.company_id===company.id);
   const requests=await db.prepare("SELECT r.*,u.name AS employee_name,c.name AS company_name FROM z_hr_requests r JOIN users u ON u.id=r.user_id JOIN z_companies c ON c.id=r.company_id WHERE (?=1 OR r.company_id=?) ORDER BY r.created_at DESC LIMIT 70").bind(isAdmin(u)?1:0,company?.id||'').all();
   out.hr_requests=requests.results;
 }else if(membership){const r=await db.prepare('SELECT * FROM z_hr_requests WHERE user_id=? ORDER BY created_at DESC LIMIT 25').bind(u.id).all();out.hr_requests=r.results;}

 const police=await policeGranted(db,u);
 if(police){const reports=await db.prepare(`SELECT r.*,a.name AS author_name,t.name AS target_name FROM z_reports r JOIN users a ON a.id=r.author_id JOIN users t ON t.id=r.target_id ORDER BY r.created_at DESC LIMIT 90`).all();out.reports=reports.results;}
 else {const reports=await db.prepare('SELECT id,target_id,reason,status,created_at FROM z_reports WHERE author_id=? ORDER BY created_at DESC LIMIT 30').bind(u.id).all();out.reports=reports.results;}
 const appeals=await (isAdmin(u)?db.prepare(`SELECT z.*,u.name AS user_name FROM z_appeals z JOIN users u ON u.id=z.user_id ORDER BY z.created_at DESC LIMIT 90`).all():db.prepare('SELECT * FROM z_appeals WHERE user_id=? ORDER BY created_at DESC LIMIT 30').bind(u.id).all());out.appeals=appeals.results;
 return json(out);
}

// Update 26 — controlled Finance Ministry. No existing citizen or state balances are reset.
// Permission code is checked on server as a one-way digest; NEVER exposed in HTML/JS.
const Z_FINANCE_CODE_HASH='e790ea75b8baec73bab281a5f8995468f61dc89a2d91b3f421ad4d1c903a5ae2';
function zGovRank(u){if(!u)return -1;return isAdmin(u)?5:z78IsPresidential(u)?4:u.role==='minister'?3:u.role==='judge'?2:z78IsGov(u)?2:u.role==='citizen'?1:0;}
async function zFinanceAllowed(db,u){if(!u)return false;if(isAdmin(u))return true;
 if(u.job==='وزير المالية')return true;
 return false;}
async function zFinanceState(req,db){
 const u=await getMe(req,db);if(!u)return err(401,'سجّل الدخول إلى حسابك أولًا');
 const finance=await zFinanceAllowed(db,u),judge=u.role==='judge',president=isAdmin(u),canReview=finance||judge||president;
 const others=await db.prepare("SELECT id,name,role,job FROM users WHERE id<>? AND role IN ('president','admin','minister','judge','citizen','resident') AND NOT EXISTS(SELECT 1 FROM z64_archived_users a WHERE a.user_id=users.id AND a.restored_at=0) ORDER BY joined ASC LIMIT 400").bind(u.id).all();
 const higher=others.results.filter(x=>zGovRank(x)>zGovRank(u));
 const my=await db.prepare('SELECT r.*,s.name AS sender_name,t.name AS target_name,v.name AS recipient_name FROM z_finance_requests r JOIN users s ON s.id=r.sender_id LEFT JOIN users t ON t.id=r.target_id LEFT JOIN users v ON v.id=r.recipient_id WHERE r.sender_id=? OR r.recipient_id=? OR r.target_id=? ORDER BY r.created_at DESC LIMIT 100').bind(u.id,u.id,u.id).all();
 const pending=canReview?await db.prepare("SELECT r.*,s.name AS sender_name,t.name AS target_name,v.name AS recipient_name FROM z_finance_requests r JOIN users s ON s.id=r.sender_id LEFT JOIN users t ON t.id=r.target_id LEFT JOIN users v ON v.id=r.recipient_id WHERE r.status='pending' AND (r.kind IN ('tax','fine') OR r.recipient_id=?) ORDER BY r.created_at DESC LIMIT 100").bind(u.id).all():{results:[]};
 let ledger=[],assets=[],taxPaidCount=0;
 if(finance){ledger=(await db.prepare('SELECT id,delta,reason,actor,created_at FROM z_state_ledger ORDER BY created_at DESC LIMIT 180').all()).results;
  const owned=await db.prepare("SELECT a.id,a.user_id,a.kind,a.created_at,u.name AS owner_name, CASE WHEN p.asset_id IS NOT NULL THEN 1 ELSE 0 END AS paid FROM econ_assets a JOIN users u ON u.id=a.user_id LEFT JOIN z_asset_tax_paid p ON p.asset_id=a.id AND p.owner_id=a.user_id WHERE a.kind IN ('land','shop','restaurant','transport','mine','fish','residence','factory') ORDER BY a.created_at DESC LIMIT 150").all();
  const prices={land:95000,shop:8500,restaurant:13500,transport:4200,mine:10500,fish:5500};
  assets=owned.results.map(a=>({...a,price:prices[a.kind]||0,tax:Math.ceil((prices[a.kind]||0)*.10)}));
  taxPaidCount=assets.filter(a=>a.paid).length;
 }
 const all=await db.prepare('SELECT id,name,role,job FROM users ORDER BY joined ASC LIMIT 400').all();
 const myFines=await db.prepare("SELECT r.id,r.amount,r.message,r.reviewed_at,a.status AS appeal_status FROM z_finance_requests r LEFT JOIN z_fine_appeals a ON a.request_id=r.id WHERE r.kind='fine' AND r.status='approved' AND r.target_id=? ORDER BY r.reviewed_at DESC LIMIT 40").bind(u.id).all();
 const appeals=judge||president?await db.prepare("SELECT a.*,r.amount,r.message AS fine_reason,t.name AS target_name FROM z_fine_appeals a JOIN z_finance_requests r ON r.id=a.request_id JOIN users t ON t.id=a.user_id ORDER BY a.created_at DESC LIMIT 90").all():await db.prepare("SELECT a.*,r.amount,r.message AS fine_reason FROM z_fine_appeals a JOIN z_finance_requests r ON r.id=a.request_id WHERE a.user_id=? ORDER BY a.created_at DESC LIMIT 50").bind(u.id).all();
 return json({ok:true,me:u.id,treasury:await zTreasuryBalance(db),finance,judge,president,higher,people:all.results,requests:my.results,queue:pending.results,ledger,assets,taxPaidCount,myFines:myFines.results,appeals:appeals.results});
}
async function zFinanceAction(req,db,p){
 const u=await getMe(req,db);if(!u)return err(401,'سجّل الدخول أولًا');
 const now=Date.now(),type=crop(p.type,30),finance=await zFinanceAllowed(db,u);
 if(type==='fineAppeal'){
  const fid=crop(p.request_id,80),reason=crop(p.reason,500);
  if(reason.length<12)throw Error('اكتب سبب اعتراض واضح على الغرامة');
  const fine=await db.prepare("SELECT id FROM z_finance_requests WHERE id=? AND target_id=? AND kind='fine' AND status='approved'").bind(fid,u.id).first();
  if(!fine)throw Error('هذه الغرامة غير موجودة أو لم تُخصم من حسابك');
  const inserted=await db.prepare("INSERT OR IGNORE INTO z_fine_appeals(id,request_id,user_id,reason,created_at) VALUES(?,?,?,?,?) RETURNING id").bind(id(),fine.id,u.id,reason,now).first();
  if(!inserted)throw Error('تم تقديم اعتراض سابق لهذه الغرامة');
  const judges=await db.prepare("SELECT id FROM users WHERE role IN ('judge','president','admin') LIMIT 80").all();for(const j of judges.results)if(j.id!==u.id)await zNotify(db,j.id,'⚖️ تظلم مالي جديد','مواطن قدم اعتراضًا على غرامة معتمدة','government');
  return json({ok:true,id:inserted.id});
 }
 if(type==='fineAppealReview'){
  if(!(u.role==='judge'||isAdmin(u)))throw Error('تظلّم الغرامة يراجعه قاضٍ أو رئيس فقط');
  const a=await db.prepare("SELECT a.*,r.amount,r.status AS fine_status FROM z_fine_appeals a JOIN z_finance_requests r ON r.id=a.request_id WHERE a.id=? AND a.status='pending'").bind(crop(p.id,80)).first();
  if(!a)throw Error('هذا التظلّم تمت مراجعته بالفعل');
  if(a.user_id===u.id)throw Error('لا يمكنك الحكم على اعتراضك بنفسك');
  const accept=p.approve===true,reply=crop(p.reply,500);
  if(accept&&await zTreasuryBalance(db)<Number(a.amount))throw Error('الخزينة لا تكفي لرد الغرامة حاليًا');
  const claim=await db.prepare("UPDATE z_fine_appeals SET status='processing',reviewer_id=?,reply=?,reviewed_at=? WHERE id=? AND status='pending' RETURNING id").bind(u.id,reply,now,a.id).first();
  if(!claim)throw Error('تمت مراجعة التظلّم بالفعل');
  if(accept){await zTreasuryPay(db,a.user_id,Number(a.amount),'رد غرامة بعد قبول التظلم المالي',u.name,now);await zNotify(db,a.user_id,'✅ قُبل تظلمك المالي','تم رد '+a.amount+' زنجر إلى رصيدك بعد قرار قضائي','money');}
  else await zNotify(db,a.user_id,'⚖️ قرار التظلّم','رُفض اعتراضك على الغرامة'+(reply?' — '+reply:''),'government');
  await db.prepare("UPDATE z_fine_appeals SET status=? WHERE id=? AND status='processing'").bind(accept?'approved':'rejected',a.id).run();
  await activity(db,u.name,(accept?'وافق على':'رفض')+' تظلم مالي',now);return json({ok:true,refunded:accept?Number(a.amount):0});
 }
 if(type==='unlock'){
  return err(403,'وزير المالية يتعيّن من لوحة الرئاسة؛ لا حاجة لكود الوزارة القديم');
  if(finance)return json({ok:true});
  const attempts=await db.prepare('SELECT failures,blocked_until FROM z_finance_unlock_attempts WHERE user_id=?').bind(u.id).first();
  if(Number(attempts?.blocked_until||0)>now)return err(429,'محاولات متكررة؛ حاول بعد 15 دقيقة');
  const submitted=crop(p.code,130),valid=submitted&&eqSecure(await digest(submitted),Z_FINANCE_CODE_HASH);
  if(!valid){const n=Number(attempts?.failures||0)+1;
   await db.prepare('INSERT INTO z_finance_unlock_attempts(user_id,failures,blocked_until) VALUES(?,?,?) ON CONFLICT(user_id) DO UPDATE SET failures=excluded.failures,blocked_until=excluded.blocked_until').bind(u.id,n,n>=5?now+900000:0).run();
   return err(403,'كود وزارة المالية غير صحيح');}
  await db.prepare('INSERT OR IGNORE INTO z_finance_grants(user_id,created_at) VALUES(?,?)').bind(u.id,now).run();
  await db.prepare('DELETE FROM z_finance_unlock_attempts WHERE user_id=?').bind(u.id).run();
  await activity(db,u.name,'فتح صلاحية وزارة المالية دون تغيير رتبته الرسمية',now);
  return json({ok:true});
 }
 if(type==='submit'){
  const kind=crop(p.kind,20),valid=['message','bonus','report','tax','fine'].includes(kind);
  if(!valid)return err(400,'نوع الطلب غير متاح');
  const msg=crop(p.message,450);if(msg.length<10)throw Error('اكتب تفاصيل الطلب أو الدليل (10 أحرف على الأقل)');
  const recipient=crop(p.recipient_id,80),target=crop(p.target_id,80),asset=crop(p.asset_id,80);let amount=0,destination=recipient;
  if(kind==='tax'||kind==='fine'){
   if(!finance)throw Error('طلبات التحصيل والغرامة لوزارة المالية فقط');
   if(!target||target===u.id)throw Error('اختار مواطنًا غير نفسك');
   if(!await db.prepare('SELECT id FROM users WHERE id=?').bind(target).first())throw Error('الحساب غير موجود');
   if(kind==='tax'){
    const a=await db.prepare('SELECT id,kind,user_id FROM econ_assets WHERE id=? AND user_id=?').bind(asset,target).first();
    if(!a)throw Error('لم يتم العثور على ممتلكات المواطن');
    if(await db.prepare('SELECT asset_id FROM z_asset_tax_paid WHERE asset_id=? AND owner_id=?').bind(asset,target).first())throw Error('ضريبة الملكية مسدّدة بالفعل ولا يجوز تحصيلها ثانية');
    const prices={land:95000,shop:8500,restaurant:13500,transport:4200,mine:10500,fish:5500};
    if(!prices[a.kind])throw Error('هذه الملكية ليس لها سعر ضريبي معتمد؛ لا يمكن فرض قيمة تقديرية');
    amount=Math.ceil(prices[a.kind]*.1);
    if(await db.prepare("SELECT id FROM z_finance_requests WHERE kind='tax' AND asset_id=? AND target_id=? AND status IN ('pending','processing','approved') LIMIT 1").bind(asset,target).first())throw Error('سبق إرسال طلب ضريبة لهذه الملكية');
   }else{
    amount=Number(p.amount);if(!Number.isSafeInteger(amount)||amount<1||amount>10000)throw Error('الغرامة المقترحة يجب أن تكون من 1 إلى 10,000 زنجر');
   }
   destination='';
  }else{
   const r=await db.prepare('SELECT id,name,role FROM users WHERE id=?').bind(recipient).first();
   if(!r||zGovRank(r)<=zGovRank(u))throw Error('اختار مسؤولًا أعلى منك منصبًا لإرسال الطلب');
   if(kind==='report'&&target && !await db.prepare('SELECT id FROM users WHERE id=?').bind(target).first())throw Error('الشخص المبلغ عنه غير موجود');
   if(kind==='bonus')amount=Math.min(100000,Math.max(0,Math.trunc(Number(p.amount)||0)));
  }
  const requestId=id();await db.prepare('INSERT INTO z_finance_requests(id,kind,sender_id,recipient_id,target_id,asset_id,amount,message,created_at) VALUES(?,?,?,?,?,?,?,?,?)').bind(requestId,kind,u.id,destination,target,asset,amount,msg,now).run();
  const label={message:'رسالة رسمية',bonus:'طلب مكافأة أو أجر',report:'بلاغ عن مخالفة',tax:'طلب تحصيل ضريبة',fine:'اقتراح غرامة'}[kind];
  if(kind==='tax'||kind==='fine'){
   const officials=await db.prepare("SELECT id FROM users WHERE role IN ('judge','president','admin') LIMIT 120").all();
   for(const x of officials.results)if(x.id!==u.id)await zNotify(db,x.id,'⚖️ '+label,'طلب من '+u.name+' ينتظر قرارًا رسميًا',kind);
   await zNotify(db,target,'إشعار بشأن '+label,'تم رفع طلب للمراجعة فقط؛ لن يُخصم أي رصيد قبل صدور القرار',kind);
  }else await zNotify(db,destination,'📩 '+label,'من '+u.name+': '+msg.slice(0,60),kind==='report'?'report':'request');
  await activity(db,u.name,'قدّم '+label+' للمراجعة',now);
  return json({ok:true,id:requestId});
 }
 if(type==='review'){
  const row=await db.prepare("SELECT * FROM z_finance_requests WHERE id=? AND status='pending'").bind(crop(p.id,80)).first();
  if(!row)return err(404,'الطلب غير متاح أو تمت مراجعته بالفعل');
  const judge=u.role==='judge',president=isAdmin(u);
  if(row.sender_id===u.id)throw Error('يجب أن يراجع الطلب شخص آخر غير مقدمه');
  if(row.kind==='tax'||row.kind==='fine'){
   if(!(judge||president))throw Error('الموافقة على الخصم للرئاسة أو القاضي فقط');
  }else if(row.recipient_id!==u.id&&!president)throw Error('الرد للمسؤول المرسَل إليه أو الرئاسة');
  const accept=p.approve===true,reply=crop(p.reply,400);
  // Claim once before financial effects. No deduction for submission, rejection or pending state.
  if(accept&&(row.kind==='tax'||row.kind==='fine')){
   if(row.kind==='tax'){
    const asset=await db.prepare('SELECT id FROM econ_assets WHERE id=? AND user_id=?').bind(row.asset_id,row.target_id).first();
    if(!asset)throw Error('تغيّرت ملكية الأصل، يلزم إعادة التقييم');
    if(await db.prepare('SELECT asset_id FROM z_asset_tax_paid WHERE asset_id=? AND owner_id=?').bind(row.asset_id,row.target_id).first())throw Error('هذه الضريبة دُفعت بالفعل؛ ارفض الطلب المكرر');
   }
   const funds=await db.prepare('SELECT points FROM users WHERE id=?').bind(row.target_id).first();
   if(!funds||Number(funds.points)<Number(row.amount))throw Error('رصيد المواطن لا يغطي المبلغ؛ لم يحدث أي خصم');
  }
  const claimed=await db.prepare("UPDATE z_finance_requests SET status='processing',reviewer_id=?,reviewed_at=?,reply=? WHERE id=? AND status='pending' RETURNING id").bind(u.id,now,reply,row.id).first();
  if(!claimed)return err(409,'تمت معالجة الطلب بالفعل');
  if(accept&&(row.kind==='tax'||row.kind==='fine')){
   const charged=await db.prepare('UPDATE users SET points=points-? WHERE id=? AND points>=? RETURNING points').bind(row.amount,row.target_id,row.amount).first();
   if(!charged){await db.prepare("UPDATE z_finance_requests SET status='pending',reviewer_id='',reviewed_at=0 WHERE id=? AND status='processing'").bind(row.id).run();throw Error('لا يوجد رصيد كافٍ؛ لم يُخصم شيء');}
   if(row.kind==='tax')await db.prepare('INSERT OR IGNORE INTO z_asset_tax_paid(asset_id,owner_id,paid_at) VALUES(?,?,?)').bind(row.asset_id,row.target_id,now).run();
   const reason=row.kind==='tax'?'ضريبة ملكية 10% بعد موافقة رسمية':'غرامة بعد قرار قضائي/رئاسي';
   await addTx(db,row.target_id,-row.amount,reason,now);
   await stateEconomyAdd(db,row.amount,reason,u.name,now);
   await zNotify(db,row.target_id,'قرار مالي معتمد','تم خصم '+row.amount+' زنجر بسبب '+reason,'money');
  }
  await db.prepare('UPDATE z_finance_requests SET status=? WHERE id=? AND status=\'processing\'').bind(accept?'approved':'rejected',row.id).run();
  await zNotify(db,row.sender_id,'قرار بشأن طلبك',accept?'تم قبول الطلب رسميًا':'تم رفض الطلب'+(reply?' — '+reply:''),'request');
  if(row.recipient_id&&row.recipient_id!==row.sender_id)await zNotify(db,row.recipient_id,'تحديث الطلب الحكومي',accept?'تم اعتماد طلب وصل إليك':'تم رفض الطلب','government');
  await activity(db,u.name,(accept?'وافق على':'رفض')+' طلب وزارة المالية',now);
  return json({ok:true});
 }
 return err(400,'عملية غير معروفة لوزارة المالية');
}
async function zWorldAction(req,db,p){
 const u=await getMe(req,db);if(!u)return err(401,'سجل الدخول أولًا');
 const now=Date.now(),type=crop(p.type,45),n=Number(p.amount),companyId=crop(p.company_id,80);
 if(type==='noticeRead'){
  if(p.all===true)await db.prepare('UPDATE z_notifications SET read_at=? WHERE user_id=? AND read_at=0').bind(now,u.id).run();
  else await db.prepare('UPDATE z_notifications SET read_at=? WHERE user_id=? AND id=?').bind(now,u.id,crop(p.id,80)).run();
  return json({ok:true});
 }
 if(type==='homeUpgrade'){
  let home=await db.prepare('SELECT level FROM z_homes WHERE user_id=?').bind(u.id).first(),level=Number(home?.level||1);if(level>=4)throw Error('بيتك وصل لأعلى مستوى');
  const price=Z_HOME_COST[level+1];await zPointDebit(db,u,price,'توسعة البيت للمستوى '+(level+1),true);await db.prepare(`INSERT INTO z_homes(user_id,level,updated_at) VALUES(?,?,?) ON CONFLICT(user_id) DO UPDATE SET level=excluded.level,updated_at=excluded.updated_at`).bind(u.id,level+1,now).run();return json({ok:true});
 }
 if(type==='homeFurniture'){
  const key=crop(p.item,30),item=Z_FURNITURE[key];if(!item)throw Error('العفش غير موجود');
  const house=await db.prepare('SELECT level FROM z_homes WHERE user_id=?').bind(u.id).first();if(key==='garden'&&Number(house?.level||1)<2)throw Error('الحديقة تحتاج بيت مستوى 2');if(key==='pool'&&Number(house?.level||1)<3)throw Error('حمام السباحة يحتاج فيلا مستوى 3');const owned=await db.prepare('SELECT qty FROM z_furniture WHERE user_id=? AND item=?').bind(u.id,key).first();if(Number(owned?.qty||0)>=5)throw Error('عندك الحد الأقصى من القطعة دي');
  await zPointDebit(db,u,item.cost,'شراء '+item.title+' للبيت',true);await db.prepare(`INSERT INTO z_furniture(user_id,item,qty) VALUES(?,?,1) ON CONFLICT(user_id,item) DO UPDATE SET qty=qty+1`).bind(u.id,key).run();return json({ok:true});
 }
 if(['savingDeposit','savingWithdraw','savingInterest'].includes(type))return await z80BankGate(req,db,{},p);
 if(type==='companyCreate'){
  const name=crop(p.name,45);if(name.length<3)throw Error('اسم الشركة قصير');
  if(await db.prepare('SELECT id FROM z_companies WHERE owner_id=?').bind(u.id).first())throw Error('عندك شركة بالفعل');
  await zPointDebit(db,u,18000,'تأسيس شركة '+name,true);
  const newId=id();await db.prepare('INSERT INTO z_companies(id,owner_id,name,balance,wage,next_pay_at,created_at) VALUES(?,?,?,?,?,?,?)').bind(newId,u.id,name,0,250,now+21600000,now).run();
  return json({ok:true});
 }
 if(type==='companyApply'){
  const c=await db.prepare('SELECT id,owner_id,name FROM z_companies WHERE id=?').bind(companyId).first();if(!c||c.owner_id===u.id)throw Error('الشركة غير متاحة لك');
  const current=await db.prepare("SELECT company_id,status FROM z_company_members WHERE user_id=? AND status IN ('pending','active') LIMIT 1").bind(u.id).first();
  if(current)throw Error(current.status==='active'?'أنت موظف بالفعل. استقل من شركتك أولًا قبل التقديم لشركة جديدة.':'لديك طلب انضمام معلّق؛ اسحبه أولًا إذا أردت تغيير الشركة.');
  const requested=await db.prepare(`INSERT INTO z_company_members(company_id,user_id,status,created_at) VALUES(?,?,'pending',?) ON CONFLICT(company_id,user_id) DO UPDATE SET status='pending',created_at=excluded.created_at WHERE z_company_members.status IN ('resigned','rejected','withdrawn') RETURNING user_id`).bind(companyId,u.id,now).first();
  if(!requested)throw Error('طلب التوظيف موجود بالفعل');
  await zNotify(db,c.owner_id,'طلب توظيف جديد','المواطن '+u.name+' طلب الانضمام إلى '+c.name+' — يمكنك القبول أو الرفض من الإشعارات أو صفحة الشركات','job');return json({ok:true});
 }
 if(type==='companyApprove'||type==='companyReject'){
  const c=await db.prepare('SELECT * FROM z_companies WHERE id=? AND owner_id=?').bind(companyId,u.id).first();if(!c)throw Error('قرار قبول أو رفض الموظف لصاحب الشركة فقط');
  const candidate=crop(p.user_id,80),accept=type==='companyApprove';
  if(accept){const conflict=await db.prepare("SELECT company_id FROM z_company_members WHERE user_id=? AND company_id<>? AND status='active' LIMIT 1").bind(candidate,companyId).first();if(conflict)throw Error('المواطن يعمل بالفعل في شركة أخرى');}
  const res=await db.prepare("UPDATE z_company_members SET status=? WHERE company_id=? AND user_id=? AND status='pending' RETURNING user_id").bind(accept?'active':'rejected',companyId,candidate).first();if(!res)throw Error('الطلب انتهى أو تمت مراجعته من قبل');
  await zNotify(db,candidate,accept?'✅ قبول التوظيف':'❌ رفض التوظيف',(accept?'تم قبول طلبك في ':'تم رفض طلبك في ')+c.name,'job');return json({ok:true});
 }
 if(type==='companyWithdraw'){
  const pending=await db.prepare("UPDATE z_company_members SET status='withdrawn' WHERE company_id=? AND user_id=? AND status='pending' RETURNING company_id").bind(companyId,u.id).first();
  if(!pending)throw Error('لا يوجد طلب توظيف معلّق لسحبه');
  const c=await db.prepare('SELECT owner_id,name FROM z_companies WHERE id=?').bind(companyId).first();
  if(c)await zNotify(db,c.owner_id,'سحب طلب توظيف',u.name+' سحب طلبه من '+c.name,'job');return json({ok:true});
 }
 if(type==='companyFund'){
  const c=await db.prepare('SELECT id FROM z_companies WHERE id=? AND owner_id=?').bind(companyId,u.id).first();if(!c)throw Error('ليست شركتك');
  if(!Number.isSafeInteger(n)||n<100||n>100000)throw Error('حدد مبلغ تمويل صحيح');await zPointDebit(db,u,n,'تمويل الشركة');await db.prepare('UPDATE z_companies SET balance=balance+? WHERE id=?').bind(n,companyId).run();return json({ok:true});
 }
 if(['companyWork','companyResign','companyAdvanceRequest','companyLeaveRequest'].includes(type)){
   const membership=await db.prepare("SELECT m.company_id,m.status,c.name,c.wage FROM z_company_members m JOIN z_companies c ON c.id=m.company_id WHERE m.user_id=? AND m.status='active' ORDER BY m.created_at DESC LIMIT 1").bind(u.id).first();
   if(!membership)throw Error('لا توجد وظيفة نشطة في شركة');const cid=membership.company_id,day=Math.floor(now/86400000);
   if(type==='companyResign'){
     const done=await db.prepare("UPDATE z_company_members SET status='resigned' WHERE company_id=? AND user_id=? AND status='active' RETURNING user_id").bind(cid,u.id).first();
     if(!done)throw Error('انتهت الوظيفة');await db.prepare("UPDATE z_hr_requests SET status='cancelled' WHERE company_id=? AND user_id=? AND status='pending'").bind(cid,u.id).run();const owner=await db.prepare('SELECT owner_id FROM z_companies WHERE id=?').bind(cid).first();if(owner)await zNotify(db,owner.owner_id,'استقالة موظف',u.name+' خرج من شركة '+membership.name,'job');return json({ok:true});
   }
   await db.prepare('INSERT OR IGNORE INTO z_employee_hr(company_id,user_id) VALUES(?,?)').bind(cid,u.id).run();
   if(type==='companyWork'){
     const h=await db.prepare('SELECT paid_leave_until,unpaid_leave_until,last_work_day FROM z_employee_hr WHERE company_id=? AND user_id=?').bind(cid,u.id).first();
     if(Math.max(h.paid_leave_until,h.unpaid_leave_until)>now)throw Error('لديك إجازة معتمدة حاليًا');
     const checked=await db.prepare('INSERT OR IGNORE INTO z_company_attendance(company_id,user_id,work_day,created_at) VALUES(?,?,?,?) RETURNING user_id').bind(cid,u.id,day,now).first();
     if(!checked)throw Error('سجّلت حضورك اليوم بالفعل');
     await db.prepare('UPDATE z_employee_hr SET last_work_day=? WHERE company_id=? AND user_id=?').bind(day,cid,u.id).run();
     await zNotify(db,u.id,'حضور العمل','تم إثبات حضورك اليوم في '+membership.name,'jobs');return json({ok:true});
   }
   const pending=await db.prepare("SELECT id FROM z_hr_requests WHERE company_id=? AND user_id=? AND status='pending'").bind(cid,u.id).first();if(pending)throw Error('عندك طلب ينتظر قرار المدير');
   const kind=type==='companyAdvanceRequest'?'advance':p.kind==='paid'?'paid_leave':'unpaid_leave';
   let amount=0,days=0;
   if(kind==='advance'){amount=Number(p.amount);if(!Number.isSafeInteger(amount)||amount<50||amount>membership.wage*3)throw Error('السلفة من 50 إلى ثلاثة أضعاف الراتب الأساسي');}
   else{days=Number(p.days);if(!Number.isInteger(days)||days<1||days>7)throw Error('مدة الإجازة من يوم إلى 7 أيام');}
   await db.prepare("INSERT INTO z_hr_requests(id,company_id,user_id,kind,amount,days,status,created_at) VALUES(?,?,?,?,?,?,'pending',?)").bind(id(),cid,u.id,kind,amount,days,now).run();
   const boss=await db.prepare('SELECT owner_id FROM z_companies WHERE id=?').bind(cid).first();await zNotify(db,boss.owner_id,'طلب موظف','طلب '+(kind==='advance'?'سلفة':kind==='paid_leave'?'إجازة براتب':'إجازة بدون راتب')+' ينتظر الموافقة','jobs');return json({ok:true});
 }
 if(['companyWage','companyFine','companyReviewRequest'].includes(type)){
   const cid=crop(p.company_id,80),c=await db.prepare('SELECT * FROM z_companies WHERE id=?').bind(cid).first();
   if(!c||(c.owner_id!==u.id&&!isAdmin(u)))throw Error('التعديل لمدير الشركة أو الرئاسة فقط');
   if(type==='companyReviewRequest'){
     const req=await db.prepare("SELECT * FROM z_hr_requests WHERE id=? AND company_id=? AND status='pending'").bind(crop(p.id,80),cid).first();if(!req)throw Error('الطلب لم يعد متاحًا');
     const active=await db.prepare("SELECT user_id FROM z_company_members WHERE company_id=? AND user_id=? AND status='active'").bind(cid,req.user_id).first();if(!active)throw Error('الموظف غير نشط');
     const yes=p.accept===true;if(yes&&req.kind==='advance'){
       const drawn=await db.prepare('UPDATE z_companies SET balance=balance-? WHERE id=? AND balance>=? RETURNING balance').bind(req.amount,cid,req.amount).first();if(!drawn)throw Error('خزينة الشركة لا تكفي السلفة');
     }
     const claimed=await db.prepare("UPDATE z_hr_requests SET status=?,reviewed_at=? WHERE id=? AND status='pending' RETURNING id").bind(yes?'approved':'rejected',now,req.id).first();if(!claimed)throw Error('تمت معالجة الطلب');
     if(yes){await db.prepare('INSERT OR IGNORE INTO z_employee_hr(company_id,user_id) VALUES(?,?)').bind(cid,req.user_id).run();
       if(req.kind==='advance'){await db.prepare('UPDATE users SET points=points+? WHERE id=?').bind(req.amount,req.user_id).run();await db.prepare('UPDATE z_employee_hr SET advance_due=advance_due+? WHERE company_id=? AND user_id=?').bind(req.amount,cid,req.user_id).run();await addTx(db,req.user_id,req.amount,'سلفة شركة '+c.name,now);}
       else {const col=req.kind==='paid_leave'?'paid_leave_until':'unpaid_leave_until',until=now+req.days*86400000;await db.prepare(`UPDATE z_employee_hr SET ${col}=MAX(${col},?) WHERE company_id=? AND user_id=?`).bind(until,cid,req.user_id).run();await db.prepare('INSERT OR IGNORE INTO z_company_leaves(request_id,company_id,user_id,kind,starts_at,ends_at) VALUES(?,?,?,?,?,?)').bind(req.id,cid,req.user_id,req.kind,now,until).run();}
     }
     await zNotify(db,req.user_id,'قرار طلب الشركة',yes?'تم قبول الطلب في '+c.name:'تم رفض الطلب في '+c.name,'jobs');return json({ok:true});
   }
   const userId=crop(p.user_id,80),exists=await db.prepare("SELECT user_id FROM z_company_members WHERE company_id=? AND user_id=? AND status='active'").bind(cid,userId).first();if(!exists)throw Error('هذا المواطن ليس موظفًا نشطًا في الشركة');
   await db.prepare('INSERT OR IGNORE INTO z_employee_hr(company_id,user_id) VALUES(?,?)').bind(cid,userId).run();
   if(type==='companyWage'){
     const wage=Number(p.wage);if(!Number.isSafeInteger(wage)||wage<250||wage>1000000000)throw Error('أقل راتب 250 زنجر وأعلى مبلغ تقني مليار زنجر؛ ويشترط توفر رصيد في خزينة الشركة');
     await db.prepare('UPDATE z_employee_hr SET wage=? WHERE company_id=? AND user_id=?').bind(wage,cid,userId).run();await zNotify(db,userId,'تعديل راتبك','راتبك أصبح '+wage+' زنجر لكل دورة صرف في '+c.name,'jobs');
   }else{
     const fine=Number(p.amount);if(!Number.isSafeInteger(fine)||fine<1||fine>Math.floor(c.wage*.5))throw Error('الغرامة لا تتجاوز 50% من الراتب الأساسي');
     await db.prepare('UPDATE z_employee_hr SET fine_due=fine_due+? WHERE company_id=? AND user_id=?').bind(fine,cid,userId).run();await zNotify(db,userId,'غرامة عمل','تم جدولة غرامة '+fine+' زنجر للخصم من مرتبك القادم، وليس من رصيدك الحالي','jobs');
   }
   return json({ok:true});
 }

 if(type==='companyPayroll'){
   const c=await db.prepare('SELECT * FROM z_companies WHERE id=?').bind(companyId).first();if(!c||(c.owner_id!==u.id&&!isAdmin(u)))throw Error('أنت لست مدير الشركة');
   if(now<c.next_pay_at)throw Error('الرواتب تُصرف كل 6 ساعات مثل النظام السابق');
   const day=Math.floor(now/86400000),previousDay=day-1,previousStart=previousDay*86400000;
   const tracking=await db.prepare("SELECT value FROM site_settings WHERE key='u25_attendance_tracking'").first();
   const trackedSince=Number(tracking?.value||now);
   const people=await db.prepare(`SELECT m.user_id,m.created_at,h.wage,h.last_work_day,h.last_absence_day,h.paid_leave_until,h.unpaid_leave_until,h.fine_due,h.advance_due,
     EXISTS(SELECT 1 FROM z_company_attendance a WHERE a.company_id=m.company_id AND a.user_id=m.user_id AND a.work_day=?) AS attended_yesterday,
     EXISTS(SELECT 1 FROM z_company_leaves l WHERE l.company_id=m.company_id AND l.user_id=m.user_id AND l.starts_at<? AND l.ends_at>?) AS leave_yesterday
     FROM z_company_members m LEFT JOIN z_employee_hr h ON h.company_id=m.company_id AND h.user_id=m.user_id WHERE m.company_id=? AND m.status='active' LIMIT 50`).bind(previousDay,previousStart+86400000,previousStart,companyId).all();
   if(!people.results.length)throw Error('عيّن موظفًا أولًا');
   // No owner mini-games: normal management payroll once per six hours, from company treasury.
   const bossBonus=people.results.length*250;
   const lines=people.results.map(m=>{
     const wage=Number(m.wage||c.wage),unpaid=Number(m.unpaid_leave_until||0)>now,paid=Number(m.paid_leave_until||0)>now;
     // Charge one absence only after that ENTIRE previous day has passed; never
     // penalize before the Update 25 attendance system existed or a hire began.
     const autoFine=previousStart>=trackedSince&&Number(m.created_at)<previousStart&&!m.attended_yesterday&&!m.leave_yesterday&&Number(m.last_absence_day)!==previousDay?Math.ceil(wage*.10):0;
     const fine=Math.min(wage,Number(m.fine_due||0)+autoFine),gross=unpaid?0:wage,fineApplied=Math.min(gross,fine),advance=Math.min(gross-fineApplied,Number(m.advance_due||0));
     return {user_id:m.user_id,wage,gross,net:gross-fineApplied-advance,fineApplied,advance,autoFine,day:previousDay,oldFine:Number(m.fine_due||0),absence:!!autoFine};
   });
   const total=lines.reduce((a,l)=>a+l.gross-l.advance,0),fees=lines.reduce((a,l)=>a+l.fineApplied,0);
   const paydayTotal=total+bossBonus;
   const paid=await db.prepare('UPDATE z_companies SET balance=balance-?,next_pay_at=? WHERE id=? AND balance>=? AND next_pay_at<=? RETURNING balance').bind(paydayTotal,now+21600000,companyId,paydayTotal,now).first();
   if(!paid)throw Error('رصيد الشركة غير كافٍ أو الرواتب لم يحن موعدها');
   for(const l of lines){
     await db.prepare('INSERT OR IGNORE INTO z_employee_hr(company_id,user_id) VALUES(?,?)').bind(companyId,l.user_id).run();
     await db.prepare('UPDATE z_employee_hr SET fine_due=MAX(0,fine_due-?),advance_due=MAX(0,advance_due-?),last_absence_day=CASE WHEN ?=1 THEN ? ELSE last_absence_day END WHERE company_id=? AND user_id=?').bind(Math.max(0,l.fineApplied-l.autoFine),l.advance,l.absence?1:0,day,companyId,l.user_id).run();
     if(l.net>0){await db.prepare('UPDATE users SET points=points+? WHERE id=?').bind(l.net,l.user_id).run();await addTx(db,l.user_id,l.net,'راتب '+c.name+' بعد التسويات',now);}
     await zNotify(db,l.user_id,'كشف راتب الشركة',l.net+' زنجر مستلمة'+(l.autoFine?' · خصم غياب 10% عن يوم الأمس':'')+(l.advance?' · تسوية سلفة '+l.advance:''),'money');
   }
   if(bossBonus){await db.prepare('UPDATE users SET points=points+? WHERE id=?').bind(bossBonus,c.owner_id).run();await addTx(db,c.owner_id,bossBonus,'مرتب صاحب الشركة: 250 زنجر × '+people.results.length+' موظف نشط — دورة 6 ساعات',now);await zNotify(db,c.owner_id,'👑 راتب صاحب الشركة','وصلك '+bossBonus+' زنجر، 250 عن كل موظف نشط','money');}
   if(fees)await stateEconomyAdd(db,fees,'غرامات الغياب والعمل',c.name,now);
   return json({ok:true,total:paydayTotal,owner_salary:bossBonus,paid:lines.reduce((a,l)=>a+l.net,0),fees});
 }
 if(type==='reportCreate'){
  const target=crop(p.target_id,80),reason=crop(p.reason,400);if(reason.length<12||target===u.id)throw Error('اختار مواطنًا آخر واكتب تفاصيل بلاغ واضحة');
  if(!await db.prepare('SELECT id FROM users WHERE id=?').bind(target).first())throw Error('المواطن غير موجود');
  await db.prepare('INSERT INTO z_reports(id,author_id,target_id,reason,status,created_at) VALUES(?,?,?,?,?,?)').bind(id(),u.id,target,reason,'pending',now).run();return json({ok:true});
 }
 if(type==='reportReview'){
  if(!await policeGranted(db,u))throw Error('صلاحية الشرطة مطلوبة');
  const status=p.status==='reviewed'?'reviewed':p.status==='rejected'?'rejected':'';if(!status)throw Error('حالة غير صالحة');
  const row=await db.prepare(`UPDATE z_reports SET status=?,reviewer_id=? WHERE id=? AND status='pending' RETURNING author_id`).bind(status,u.id,crop(p.id,80)).first();if(!row)throw Error('البلاغ تمت مراجعته');
  await zNotify(db,row.author_id,'تحديث بلاغ','تمت مراجعة البلاغ وحالته الآن: '+status,'report');return json({ok:true});
 }
 if(type==='appealCreate'){
  const row=await prisonActive(db,u.id,now),reason=crop(p.reason,400);if(!row)throw Error('لا يوجد سجن فعال');if(reason.length<12)throw Error('اكتب سبب الاعتراض');
  if(await db.prepare(`SELECT id FROM z_appeals WHERE prison_id=? AND user_id=? AND status='pending'`).bind(row.id,u.id).first())throw Error('لديك اعتراض ينتظر الرد');
  await db.prepare('INSERT INTO z_appeals(id,user_id,prison_id,reason,status,created_at) VALUES(?,?,?,?,?,?)').bind(id(),u.id,row.id,reason,'pending',now).run();return json({ok:true});
 }
 if(type==='appealReview'){
  if(!isAdmin(u))throw Error('قرار الاعتراض للرئاسة فقط');
  const row=await db.prepare(`SELECT * FROM z_appeals WHERE id=? AND status='pending'`).bind(crop(p.id,80)).first();if(!row)throw Error('الاعتراض غير متاح');
  const status=p.accept===true?'accepted':'rejected';await db.prepare('UPDATE z_appeals SET status=? WHERE id=? AND status=?').bind(status,row.id,'pending').run();
  if(status==='accepted')await db.prepare('UPDATE prison_requests SET ends_at=? WHERE id=? AND status=?').bind(now,row.prison_id,'approved').run();
  await zNotify(db,row.user_id,'قرار الاعتراض',status==='accepted'?'تم قبول اعتراضك وإنهاء السجن':'لم يتم قبول الاعتراض','report');return json({ok:true});
 }
 return err(400,'عملية غير مدعومة');
}
async function zVoice(req,db,msgId){
 const u=await getMe(req,db);if(!u)return err(401,'سجل الدخول أولًا');
 const msg=await db.prepare('SELECT room_id FROM chat_messages WHERE id=?').bind(msgId).first();if(!msg)return err(404,'الرسالة غير موجودة');
 if(!await chatAllowed(db,u,msg.room_id))return err(403,'التسجيل الصوتي خاص بأعضاء المحادثة');
 const audio=await db.prepare('SELECT mime,data FROM z_chat_voice WHERE message_id=?').bind(msgId).first();if(!audio)return err(404,'التسجيل غير موجود');
 const binary=atob(audio.data),bytes=new Uint8Array(binary.length);for(let i=0;i<binary.length;i++)bytes[i]=binary.charCodeAt(i);
 return new Response(bytes,{headers:{'Content-Type':audio.mime,'Cache-Control':'private, no-store','Content-Length':String(bytes.length),'Accept-Ranges':'none','X-Content-Type-Options':'nosniff'}});
}
async function zImage(req,db,msgId){
 const u=await getMe(req,db);if(!u)return err(401,'سجل الدخول أولًا');
 const msg=await db.prepare('SELECT room_id FROM chat_messages WHERE id=?').bind(msgId).first();if(!msg)return err(404,'الرسالة غير موجودة');
 if(!await chatAllowed(db,u,msg.room_id))return err(403,'الصورة خاصة بأعضاء المحادثة');
 const image=await db.prepare('SELECT mime,data FROM z_chat_images WHERE message_id=?').bind(msgId).first();if(!image)return err(404,'الصورة غير موجودة');
 const binary=atob(image.data),bytes=new Uint8Array(binary.length);for(let i=0;i<binary.length;i++)bytes[i]=binary.charCodeAt(i);
 return new Response(bytes,{headers:{'Content-Type':image.mime,'Cache-Control':'private, no-store','Content-Length':String(bytes.length),'Accept-Ranges':'none','X-Content-Type-Options':'nosniff'}});
}


// U42: role codes are validated in the Worker (only SHA-256 digests are stored here).
const Z42_ROLE_CODES = [
{key:'president',job:'رئيس الدولة',hash:'67e06c26b29ea394625821185d923a584e31e48ad4579d4df3c552bcc94bcd46'},
{key:'vice',job:'نائب الرئيس',hash:'e2429d971bb126bb20ceb13db62fdf5da6a46966b87d5d10e2413f5640257f9b'},
{key:'director',job:'مدير الدولة',hash:'821dfb6d2e31ea3dac9448027821965839c91bfeaeeaee5b4f59ca7f21c0d72d'},
{key:'foreign',job:'وزير الخارجية',hash:'4166998deed057af93d5545bd79844263e330d2e60e55728c65519a36eeef154'},
{key:'education',job:'وزير التعليم',hash:'fb1cbf1c1721029a9ba8be80f4a54c114fd4114fa104c62aa185d838b596cac7'},
{key:'health',job:'وزير الصحة',hash:'9fd42c0d80e9332371e309983e44aaf68617edd22196939a5c1f8104c8d456a6'},
{key:'telecom',job:'وزير الاتصالات',hash:'4810b4f20c75f01765cc3ba8d77e3069f370c6e32f07ec0892f8d25396aa8163'},
{key:'defense',job:'وزير الدفاع وشؤون الدولة',hash:'91845db6ece50a976f792d9bfaf7159b22157f6fa066bde3b7a930b04ba9422f'}
];
const Z42_BUILD='1.43.0';
const Z42_RELEASE=[
 'ميزانية بداية الدولة 50,000 زنجر مع صرف مقيد للصلاحيات وسجل مالي',
 'إصلاح تنبيه التحديث المتكرر وشرح مرئي للتغييرات',
 'حالة اتصال المواطن: أخضر متصل / أحمر غير متصل',
 'تأكيد صرف مكافآت الوظائف على السيرفر قبل إظهار الفوز',
 'رسائل رئاسية جماعية أو لمواطن معين',
 'خانة أكواد موحدة في آخر الصفحة الرئيسية وثمانية مناصب جديدة'
];
let z42Ready=null;
async function z42Ensure(db){
 if(z42Ready)return z42Ready;
 z42Ready=(async()=>{
  for(const sql of [
   'CREATE TABLE IF NOT EXISTS z42_presence (user_id TEXT PRIMARY KEY,last_seen INTEGER NOT NULL,active INTEGER NOT NULL DEFAULT 1)',
   'CREATE INDEX IF NOT EXISTS idx_z42_presence_seen ON z42_presence(last_seen)',
   'CREATE TABLE IF NOT EXISTS z42_role_claims (user_id TEXT PRIMARY KEY,role_key TEXT NOT NULL UNIQUE,created_at INTEGER NOT NULL)',
   'CREATE TABLE IF NOT EXISTS z42_code_attempts (user_id TEXT PRIMARY KEY,failures INTEGER NOT NULL DEFAULT 0,blocked_until INTEGER NOT NULL DEFAULT 0)',
   'CREATE TABLE IF NOT EXISTS z42_budget_payouts (id TEXT PRIMARY KEY,user_id TEXT NOT NULL,amount INTEGER NOT NULL,reason TEXT NOT NULL,actor TEXT NOT NULL,created_at INTEGER NOT NULL)',
   "CREATE TRIGGER IF NOT EXISTS z42_budget_check BEFORE INSERT ON z42_budget_payouts BEGIN SELECT CASE WHEN NEW.amount<1 OR NEW.amount>50000 OR NOT EXISTS(SELECT 1 FROM z_state_treasury WHERE id=1 AND balance>=NEW.amount) THEN RAISE(ABORT,'خزينة الدولة غير كافية أو المبلغ غير صالح') END; END",
   "CREATE TRIGGER IF NOT EXISTS z42_budget_pay AFTER INSERT ON z42_budget_payouts BEGIN UPDATE z_state_treasury SET balance=balance-NEW.amount WHERE id=1; UPDATE users SET points=points+NEW.amount WHERE id=NEW.user_id; INSERT INTO transactions(id,user_id,amount,note,created_at) VALUES(lower(hex(randomblob(16))),NEW.user_id,NEW.amount,'صرف ميزانية الدولة: '||NEW.reason,NEW.created_at); INSERT INTO z_state_ledger(id,delta,reason,actor,created_at) VALUES(lower(hex(randomblob(16))),-NEW.amount,'صرف ميزانية الدولة: '||NEW.reason,NEW.actor,NEW.created_at); END",
   "CREATE TRIGGER IF NOT EXISTS z42_courier_win_pay AFTER INSERT ON z_courier_wins BEGIN UPDATE users SET points=points+400 WHERE id=NEW.user_id; INSERT INTO transactions(id,user_id,amount,note,created_at) VALUES(lower(hex(randomblob(16))),NEW.user_id,400,'الفوز في لعبة توصيل الزنجر',NEW.won_at); END",
  ])await db.prepare(sql).run();
  // One-time opening balance; never reapplied on future visits or deployments.
  await db.batch([
   db.prepare("UPDATE z_state_treasury SET balance=50000 WHERE id=1 AND NOT EXISTS (SELECT 1 FROM site_settings WHERE key='z42_budget_initialized')"),
   db.prepare("INSERT OR IGNORE INTO site_settings(key,value,updated_at) VALUES('z42_budget_initialized','1',?)").bind(Date.now())
  ]);
 })().catch(e=>{z42Ready=null;throw e});return z42Ready;
}
async function z42Presence(req,db,active){const u=await getMe(req,db);if(!u)return err(401,'سجل دخولك لتظهر حالة الاتصال');await db.prepare('INSERT INTO z42_presence(user_id,last_seen,active) VALUES(?,?,?) ON CONFLICT(user_id) DO UPDATE SET last_seen=excluded.last_seen,active=excluded.active').bind(u.id,Date.now(),active?1:0).run();return json({ok:true});}
async function z42CodeRedeem(req,db,p){
 const u=await getMe(req,db);if(!u)return err(401,'سجل الدخول أولًا');
 const code=String(p.code||'').trim();if(code.length<4||code.length>150)return err(400,'اكتب كودًا صالحًا');if(eqSecure(await digest(code),Z39_PRESIDENT_HASH))return err(410,'كود الرئاسة القديم ملغى؛ استخدم تحقق الرئاسة الجديد بخطوتين');
 const attempt=await db.prepare('SELECT failures,blocked_until FROM z42_code_attempts WHERE user_id=?').bind(u.id).first(),now=Date.now();
 if(Number(attempt?.blocked_until||0)>now)return err(429,'انتظر 15 دقيقة قبل المحاولة التالية');
 if(eqSecure(await digest(code),Z39_PRESIDENT_HASH)){
  const r=await unlockAdmin(req,db,{},p);if(r.status===200)await db.prepare('DELETE FROM z42_code_attempts WHERE user_id=?').bind(u.id).run();return r;
 }
 const hash=await digest(code);
 const found=Z42_ROLE_CODES.find(r=>eqSecure(hash,r.hash));
 if(found?.key==='president')return err(410,'كود الرئاسة القديم مقفول للجميع؛ افتح لوحة الرئاسة الجديدة');
 if(!found){const failed=Number(attempt?.failures||0)+1;await db.prepare('INSERT INTO z42_code_attempts(user_id,failures,blocked_until) VALUES(?,?,?) ON CONFLICT(user_id) DO UPDATE SET failures=excluded.failures,blocked_until=excluded.blocked_until').bind(u.id,failed,failed>=5?now+900000:0).run();return err(403,failed>=5?'كود غير صحيح؛ انتظر 15 دقيقة':'الكود غير صحيح');}
 const owner=await db.prepare('SELECT c.user_id,u.job FROM z42_role_claims c JOIN users u ON u.id=c.user_id WHERE c.role_key=?').bind(found.key).first();
 if(owner&&owner.user_id!==u.id&&owner.job===found.job)return err(409,'المنصب مخصص لمواطن آخر بالفعل. الرئاسة تقدر تغيّر التعيين من لوحة الإدارة.');
 if(owner&&owner.user_id!==u.id&&owner.job!==found.job)await db.prepare('DELETE FROM z42_role_claims WHERE role_key=? AND user_id=?').bind(found.key,owner.user_id).run();
 const role=found.key==='president'?'president':/^(education|foreign|health|telecom|defense)$/.test(found.key)?'minister':'citizen';
 const commands=[
  db.prepare('DELETE FROM z42_role_claims WHERE user_id=?').bind(u.id),
  db.prepare('INSERT INTO z42_role_claims(user_id,role_key,created_at) VALUES(?,?,?)').bind(u.id,found.key,now),
  db.prepare('UPDATE users SET role=?,job=? WHERE id=?').bind(role,found.job,u.id),
  db.prepare('DELETE FROM z42_code_attempts WHERE user_id=?').bind(u.id)
 ];
 if(found.key==='president'){commands.push(db.prepare('INSERT OR IGNORE INTO admin_grants(user_id,created_at) VALUES(?,?)').bind(u.id,now));commands.push(db.prepare('INSERT OR IGNORE INTO z39_president_grants(user_id,created_at) VALUES(?,?)').bind(u.id,now));}
 await db.batch(commands);z32PublicCache.clear();await activity(db,u.name,'تولى منصب '+found.job,now);
 return json({ok:true,job:found.job,role_key:found.key,notice:'✅ مبروك! منصبك الآن '+found.job});
}
async function z42BudgetAllowed(db,u,req){return !!(u&&(isAdmin(u)||String(u.job||'')==='رئيس الدولة'||String(u.job||'')==='وزير المالية'||String(u.job||'').includes('وزير الدفاع')||await zWarAuthorized(db,u,req)));}
async function z42Budget(req,db,p=null){const u=await getMe(req,db),allowed=await z42BudgetAllowed(db,u,req);if(!u)return err(401,'سجل الدخول أولًا');
 if(p===null){const treasury=await zTreasuryBalance(db),history=allowed?(await db.prepare('SELECT delta,reason,actor,created_at FROM z_state_ledger ORDER BY created_at DESC LIMIT 25').all()).results:[];return json({treasury,allowed,job:u.job,history});}
 if(!allowed)return err(403,'صرف ميزانية الدولة للرئاسة ووزير المالية والدفاع المصرح فقط');
 if(p.type!=='spend')return err(400,'طلب غير صحيح');const amount=Number(p.amount),reason=crop(p.reason,100),recipient=crop(p.user_id,80);
 if(!Number.isSafeInteger(amount)||amount<1||amount>50000)return err(400,'المبلغ يجب أن يكون بين 1 و50,000 زنجر');
 if(reason.length<5)return err(400,'اكتب سبب الصرف (5 أحرف على الأقل)');
 const target=await db.prepare('SELECT id,name FROM users WHERE id=?').bind(recipient).first();if(!target)return err(404,'المواطن غير موجود');
 const operationId=/^[a-f0-9-]{36}$/.test(String(p.operation_id||''))?String(p.operation_id):id();
 const previous=await db.prepare('SELECT user_id,amount,reason,actor FROM z42_budget_payouts WHERE id=?').bind(operationId).first();
 if(previous){if(previous.user_id!==target.id||Number(previous.amount)!==amount||previous.reason!==reason||previous.actor!==u.name)return err(409,'رقم العملية مستخدم لمعاملة أخرى');return json({ok:true,already_paid:true,treasury:await zTreasuryBalance(db),notice:'هذه المعاملة صُرفت بالفعل ولم يتم تكرارها'});}
 await db.prepare('INSERT OR IGNORE INTO z42_budget_payouts(id,user_id,amount,reason,actor,created_at) VALUES(?,?,?,?,?,?)').bind(operationId,target.id,amount,reason,u.name,Date.now()).run();
 await activity(db,u.name,'صرف '+amount+' زنجر إلى '+target.name,Date.now());z32PublicCache.clear();
 await zNotify(db,target.id,'💰 تحويل من ميزانية الدولة','وصل إلى رصيدك '+amount+' زنجر — '+reason,'money');
 return json({ok:true,treasury:await zTreasuryBalance(db),notice:'تم صرف '+amount+' زنجر إلى '+target.name});
}
async function z42Message(req,db,p){const u=await getMe(req,db);if(!u||!isAdmin(u))return err(403,'إرسال الرسائل الرئاسية يحتاج فتح صلاحية الرئاسة');
 const message=crop(p.body,400),to=String(p.to||'all'),batch=crop(p.batch,80),cursor=crop(p.cursor,80);
 if(message.length<5||message.length>400)return err(400,'الرسالة يجب أن تكون بين 5 و400 حرف');
 if(!/^[a-zA-Z0-9-]{12,80}$/.test(batch))return err(400,'معرّف الإرسال غير صالح');
 const query=to==='all'?db.prepare('SELECT id,name FROM users WHERE id>? ORDER BY id ASC LIMIT 25').bind(cursor):db.prepare('SELECT id,name FROM users WHERE id=? LIMIT 1').bind(to);
 const targets=(await query.all()).results;const now=Date.now();
 for(const target of targets){const notifId='z42-'+batch+'-'+target.id;
  await db.prepare('INSERT OR IGNORE INTO z_notifications(id,user_id,title,body,kind,created_at) VALUES(?,?,?,?,?,?)').bind(notifId,target.id,'📨 رسالة من رئاسة الدولة',message,'government',now).run();
  await zPushEnqueue(db,target.id,'رسالة من رئاسة الدولة',message,'government','',notifId);
 }
 const next=to==='all'&&targets.length===25?targets[targets.length-1].id:null;
 return json({ok:true,sent:targets.length,next_cursor:next,notice:next?'تم إرسال دفعة رسائل، جارٍ استكمال باقي المواطنين':'تم إرسال رسائل الرئاسة'});
}

