// V78 — التأمين وبطاقة المواطن.
// Site calendar: one "month" = 10 real days, one "year" = 120 real days.
// Everything here is additive: new tables, new /api/v78/* routes, and three small hooks
// (bank interest rate, state-fee rate, daily card reward). All money moves are atomic and idempotent.
const Z78_DAY=86400000,Z78_MONTH=10*Z78_DAY,Z78_YEAR=120*Z78_DAY,Z78_CARD_TERM=Z78_MONTH,Z78_ID_TERM=600*Z78_DAY,Z78_SOON=3*Z78_DAY;
const Z78_RIYADH=3*3600000;
const Z78_INSURANCE={
 basic:{rank:1,name:'العادي',monthly:7000,annual:70000,tax:9,interest:12,gov:false},
 plus:{rank:2,name:'التأمين +',monthly:8500,annual:85000,tax:8,interest:14,gov:false},
 premium:{rank:3,name:'التأمين ++',monthly:10000,annual:100000,tax:6,interest:17,gov:true}
};
const Z78_CARDS={
 citizen:{rank:1,name:'بطاقة مواطن',price:1300,discount:5,reward:0,badge:'',gov:false,pres:false},
 plus:{rank:2,name:'بطاقة مواطن +',price:1800,discount:10,reward:50,badge:'🥈',gov:false,pres:false},
 premium:{rank:3,name:'بطاقة مواطن ++',price:2300,discount:15,reward:100,badge:'🥇',gov:false,pres:false},
 gov:{rank:4,name:'بطاقة المناصب الحكومية',price:2600,discount:15,reward:0,badge:'🏛️',gov:true,pres:false},
 president:{rank:5,name:'بطاقة المناصب الرئاسية',price:3100,discount:20,reward:150,badge:'👑',gov:true,pres:true}
};
// V79: Position *benefits* are derived from the server-side assigned users.job
// AND/OR an official role. Admin-only powers remain protected by isAdmin() and
// their existing code/grant checks; a position card NEVER grants admin access.
// users.job defaults to 'مواطن'; changing it requires an approved presidency action
// or a validated ministry code, unlike free-form citizen profile fields.
const Z79_GOV_ROLES=new Set(['president','admin','minister','judge']);
const Z79_NO_OFFICE=['','مواطن','مقيم','زائر','بدون منصب','بلا منصب','لا يوجد','لا يوجد منصب','عاطل','غير موظف'];
const Z79_PRES_JOBS=['رئيس الدولة','نائب الرئيس','وزير الدفاع وشؤون الدولة','وزير الدفاع وشئون الدولة','وزير الدفاع','الشرطي','شرطي','وزير الخارجية','رئيس مجلس عضو الدولة','رئيس مجلس اعضاء الدولة','رئيس مجلس الدولة','رئيس مجلس أعضاء الدولة'];
function z79JobKey(job){return String(job||'').normalize('NFKC').replace(/[\u064b-\u065f\u0670\u0640]/g,'').replace(/[أإآٱ]/g,'ا').replace(/ى/g,'ي').replace(/ة/g,'ه').replace(/\s+/g,'').trim().toLowerCase();}
const Z79_NO_OFFICE_KEYS=new Set(Z79_NO_OFFICE.map(z79JobKey));
const Z79_PRES_JOB_KEYS=new Set(Z79_PRES_JOBS.map(z79JobKey));
function z78IsGov(u){return !!u&&(Z79_GOV_ROLES.has(String(u.role||'').toLowerCase())||!Z79_NO_OFFICE_KEYS.has(z79JobKey(u.job)));}
function z78IsPresidential(u){return !!u&&((typeof isAdmin==='function'&&isAdmin(u))||String(u.role||'').toLowerCase()==='president'||Z79_PRES_JOB_KEYS.has(z79JobKey(u.job)));}
// Equivalent official-role test in SQLite, for the atomic banking trigger.
// Use the same job defaults so the trigger and purchase/benefits API agree.
function z79GovSql(userAlias){
 const role=`${userAlias}.role IN ('president','admin','minister','judge')`;
 const job=`TRIM(COALESCE(${userAlias}.job,''))`;
 // Only non-default *server-assigned* positions qualify. The mixed Arabic
 // spellings below cover the same normal labels as z79JobKey().
 const blank=Z79_NO_OFFICE.map(v=>`'${v}'`).join(',');
 return `(${role} OR (${job} NOT IN (${blank}) AND ${job}<>''))`;
}

// Bank interest percent for a user, evaluated INSIDE the trigger so it can never disagree with the Worker.
function z78RateSql(userExpr,timeExpr){
 return `COALESCE((SELECT CASE s78.tier WHEN 'basic' THEN 12 WHEN 'plus' THEN 14 WHEN 'premium' THEN 17 END FROM z78_subs s78 WHERE s78.user_id=${userExpr} AND s78.kind='insurance' AND s78.status='active' AND s78.started_at<=${timeExpr} AND s78.expires_at>${timeExpr} AND (s78.tier<>'premium' OR EXISTS(SELECT 1 FROM users x78 WHERE x78.id=${userExpr} AND ${z79GovSql('x78')})) ORDER BY s78.started_at DESC LIMIT 1),10)`;
}
const Z78_BANK_CHECK_TRIGGER=`CREATE TRIGGER z68_bank_check BEFORE INSERT ON z68_bank_moves BEGIN
     SELECT CASE WHEN NEW.kind IN ('deposit','withdraw') AND (NEW.amount<100 OR NEW.amount>100000) THEN RAISE(ABORT,'مبلغ البنك لازم يكون بين 100 و100000') END;
     SELECT CASE WHEN NOT EXISTS(SELECT 1 FROM users WHERE id=NEW.user_id) THEN RAISE(ABORT,'الحساب غير متاح') END;
     SELECT CASE WHEN NEW.kind='deposit' AND NOT EXISTS(SELECT 1 FROM users WHERE id=NEW.user_id AND points>=NEW.amount) THEN RAISE(ABORT,'رصيد المحفظة غير كاف') END;
     SELECT CASE WHEN NEW.kind='withdraw' AND NOT EXISTS(SELECT 1 FROM z_savings s WHERE s.user_id=NEW.user_id AND s.balance-NEW.amount >= 2*COALESCE((SELECT SUM(c.credit_used) FROM z_card_profiles c WHERE c.user_id=NEW.user_id AND c.collateral_type='savings'),0)) THEN RAISE(ABORT,'رصيد التوفير غير كاف أو مرهون') END;
     SELECT CASE WHEN NEW.kind='interest' AND NOT EXISTS(SELECT 1 FROM z_savings s WHERE s.user_id=NEW.user_id AND CAST(s.balance*${z78RateSql('NEW.user_id','NEW.created_at')}/100 AS INTEGER)>=1 AND NEW.amount=CAST(s.balance*${z78RateSql('NEW.user_id','NEW.created_at')}/100 AS INTEGER) AND s.interest_at<=NEW.created_at-10800000) THEN RAISE(ABORT,'مكافأة التوفير غير جاهزة أو تغير الرصيد') END;
   END`;
const Z78_BANK_APPLY_TRIGGER=`CREATE TRIGGER z68_bank_apply AFTER INSERT ON z68_bank_moves BEGIN
     UPDATE users SET points=points-NEW.amount WHERE id=NEW.user_id AND NEW.kind='deposit';
     INSERT INTO z_savings(user_id,balance,interest_at) SELECT NEW.user_id,NEW.amount,0 WHERE NEW.kind='deposit' ON CONFLICT(user_id) DO UPDATE SET balance=balance+excluded.balance;
     UPDATE z_savings SET balance=balance-NEW.amount WHERE user_id=NEW.user_id AND NEW.kind='withdraw';
     UPDATE users SET points=points+NEW.amount WHERE id=NEW.user_id AND NEW.kind='withdraw';
     UPDATE z_savings SET balance=balance+NEW.amount,interest_at=NEW.created_at WHERE user_id=NEW.user_id AND NEW.kind='interest';
     INSERT INTO transactions(id,user_id,amount,note,created_at) VALUES(NEW.id||'-tx',NEW.user_id,CASE WHEN NEW.kind='deposit' THEN -NEW.amount WHEN NEW.kind='withdraw' THEN NEW.amount ELSE 0 END,CASE NEW.kind WHEN 'deposit' THEN 'إيداع في بنك الزنجر' WHEN 'withdraw' THEN 'سحب من بنك الزنجر' ELSE 'أرباح التوفير كل 3 ساعات: '||NEW.amount||' زنجر' END,NEW.created_at);
   END`;

let z78Ready=null;
async function z78Ensure(db){
 if(z78Ready)return z78Ready;
 z78Ready=(async()=>{
  await db.batch([
   db.prepare('CREATE TABLE IF NOT EXISTS z78_identity_expiry(user_id TEXT PRIMARY KEY,expires_at INTEGER NOT NULL)'),
   db.prepare(`CREATE TABLE IF NOT EXISTS z78_subs(id TEXT PRIMARY KEY,user_id TEXT NOT NULL,kind TEXT NOT NULL CHECK(kind IN ('insurance','card')),period TEXT NOT NULL DEFAULT '',tier TEXT NOT NULL,price INTEGER NOT NULL,credit INTEGER NOT NULL DEFAULT 0,started_at INTEGER NOT NULL,expires_at INTEGER NOT NULL,status TEXT NOT NULL DEFAULT 'active',request_id TEXT NOT NULL,notified_soon INTEGER NOT NULL DEFAULT 0,notified_end INTEGER NOT NULL DEFAULT 0,UNIQUE(user_id,request_id))`),
   db.prepare('CREATE INDEX IF NOT EXISTS z78_subs_user ON z78_subs(user_id,kind,status,expires_at)'),
   db.prepare('CREATE INDEX IF NOT EXISTS z78_subs_due ON z78_subs(status,expires_at)'),
   db.prepare('CREATE TABLE IF NOT EXISTS z78_rewards(user_id TEXT NOT NULL,day INTEGER NOT NULL,amount INTEGER NOT NULL,PRIMARY KEY(user_id,day))'),
   db.prepare('CREATE TABLE IF NOT EXISTS z78_attempts(user_id TEXT NOT NULL,at INTEGER NOT NULL)'),
   db.prepare('CREATE INDEX IF NOT EXISTS z78_attempts_user ON z78_attempts(user_id,at)')
  ]);
  // One-time: switch the existing savings triggers to the insurance-aware versions.
  const done=await db.prepare("SELECT value FROM site_settings WHERE key='z78_bank_rates'").first();
  if(done?.value!=='v79_roles_1'){
   const hasBank=await db.prepare("SELECT name FROM sqlite_master WHERE type='table' AND name='z68_bank_moves'").first();
   if(hasBank){
    await db.batch([db.prepare('DROP TRIGGER IF EXISTS z68_bank_check'),db.prepare(Z78_BANK_CHECK_TRIGGER),db.prepare('DROP TRIGGER IF EXISTS z68_bank_apply'),db.prepare(Z78_BANK_APPLY_TRIGGER),
     db.prepare("INSERT INTO site_settings(key,value,updated_at) VALUES('z78_bank_rates','v79_roles_1',?) ON CONFLICT(key) DO UPDATE SET value='v79_roles_1',updated_at=excluded.updated_at").bind(Date.now())]);
   }
  }
 })().catch(e=>{z78Ready=null;throw e;});
 return z78Ready;
}

const z78Digits=s=>String(s??'').replace(/[٠-٩]/g,d=>String('٠١٢٣٤٥٦٧٨٩'.indexOf(d))).replace(/[۰-۹]/g,d=>String('۰۱۲۳۴۵۶۷۸۹'.indexOf(d)));
const z78NameKey=s=>z78Digits(s).normalize('NFKC').replace(/[ً-ٰٟـ]/g,'').replace(/[أإآ]/g,'ا').replace(/ى/g,'ي').replace(/\s+/g,' ').trim().toLowerCase();
function z78DateKey(s){
 const t=z78Digits(s).trim().replace(/[\/.\s]+/g,'-');const m=t.match(/^(\d{1,4})-(\d{1,2})-(\d{1,4})$/);if(!m)return '';
 let [,a,b,c]=m;let y,mo=b,d;if(a.length===4){y=a;d=c;}else if(c.length===4){y=c;d=a;}else return '';
 return `${y}-${String(mo).padStart(2,'0')}-${String(d).padStart(2,'0')}`;
}
const z78DateStr=ms=>new Date(Number(ms)+Z78_RIYADH).toISOString().slice(0,10);

async function z78IdentityExpiry(db,u,now=Date.now()){
 let row=await db.prepare('SELECT expires_at FROM z78_identity_expiry WHERE user_id=?').bind(u.id).first();
 if(!row){await db.prepare('INSERT OR IGNORE INTO z78_identity_expiry(user_id,expires_at) VALUES(?,?)').bind(u.id,now+Z78_ID_TERM).run();row=await db.prepare('SELECT expires_at FROM z78_identity_expiry WHERE user_id=?').bind(u.id).first();}
 return Number(row.expires_at);
}
async function z78Verify(db,u,p,now=Date.now()){
 await z78Ensure(db);
 const tries=await db.prepare('SELECT COUNT(*) AS n FROM z78_attempts WHERE user_id=? AND at>?').bind(u.id,now-600000).first();
 if(Number(tries?.n||0)>=6)return {error:err(429,'محاولات كثيرة. جرّب بعد 10 دقائق')};
 let card=await db.prepare('SELECT card_no,card_code FROM z76_identity_cards WHERE user_id=?').bind(u.id).first();
 if(!card){await z76EnsureIdentityCards(db);card=await db.prepare('SELECT card_no,card_code FROM z76_identity_cards WHERE user_id=?').bind(u.id).first();}
 const expiry=await z78IdentityExpiry(db,u,now);
 const okName=z78NameKey(p.name)===z78NameKey(u.name)&&z78NameKey(p.name)!=='';
 const okNo=!!card&&z78Digits(p.card_no).replace(/\s+/g,'')===String(card.card_no);
 const okCode=!!card&&String(p.card_code||'').replace(/\s+/g,'').toUpperCase()===String(card.card_code).toUpperCase();
 const okDate=z78DateKey(p.expiry)===z78DateStr(expiry);
 if(!(okName&&okNo&&okCode&&okDate)){
  await db.prepare('INSERT INTO z78_attempts(user_id,at) VALUES(?,?)').bind(u.id,now).run();
  if(Math.random()<0.05)await db.prepare('DELETE FROM z78_attempts WHERE at<?').bind(now-86400000).run();
  return {error:err(400,'هناك خطأ في البيانات')};
 }
 if(expiry<=now)return {error:err(400,'هذه الهوية منتهية الصلاحية')};
 return {ok:true};
}

async function z78Active(db,userId,kind,now=Date.now()){
 return db.prepare("SELECT id,tier,period,price,credit,started_at,expires_at FROM z78_subs WHERE user_id=? AND kind=? AND status='active' AND started_at<=? AND expires_at>? ORDER BY started_at DESC LIMIT 1").bind(userId,kind,now,now).first();
}
// Insurance/card that are really in force now (position-bound plans stop when the position is lost).
async function z78InsuranceFor(db,u,now=Date.now()){
 const row=await z78Active(db,u.id,'insurance',now);if(!row)return null;const plan=Z78_INSURANCE[row.tier];if(!plan)return null;
 if(plan.gov&&!z78IsGov(u))return null;return {...row,plan};
}
async function z78CardFor(db,u,now=Date.now()){
 const row=await z78Active(db,u.id,'card',now);if(!row)return null;const plan=Z78_CARDS[row.tier];if(!plan)return null;
 if(plan.pres&&!z78IsPresidential(u))return null;if(plan.gov&&!z78IsGov(u))return null;return {...row,plan};
}
// Effective state-support fee rate (was a flat 10%): insurance sets the base, the card gives a discount on it.
async function z78TaxRate(db,u,now=Date.now()){
 try{await z78Ensure(db);const [ins,card]=await Promise.all([z78InsuranceFor(db,u,now),z78CardFor(db,u,now)]);
  return ((ins?ins.plan.tax:10)/100)*(1-(card?card.plan.discount:0)/100);}
 catch(e){console.warn('z78 tax rate',String(e));return 0.10;}
}
async function z78InterestPct(db,u,now=Date.now()){
 try{await z78Ensure(db);const ins=await z78InsuranceFor(db,u,now);return ins?ins.plan.interest:10;}
 catch(e){console.warn('z78 interest',String(e));return 10;}
}
async function z78DailyReward(db,u,now=Date.now()){
 try{
  await z78Ensure(db);const card=await z78CardFor(db,u,now);const reward=card?.plan.reward||0;if(!reward)return 0;
  const day=Math.floor((now+Z78_RIYADH)/Z78_DAY);
  await db.batch([
   db.prepare('INSERT INTO z78_rewards(user_id,day,amount) VALUES(?,?,?)').bind(u.id,day,reward),
   db.prepare('UPDATE users SET points=points+? WHERE id=?').bind(reward,u.id),
   db.prepare('INSERT INTO transactions(id,user_id,amount,note,created_at) VALUES(?,?,?,?,?)').bind(id(),u.id,reward,'مكافأة البطاقة اليومية — '+card.plan.name,now)
  ]);
  return reward;
 }catch(e){if(/UNIQUE|constraint/i.test(String(e?.message||e)))return 0;console.warn('z78 reward',String(e));return 0;}
}
async function z78Sweep(db,now=Date.now()){
 await z78Ensure(db);
 const label=r=>(r.kind==='insurance'?'التأمين ':'')+((r.kind==='insurance'?Z78_INSURANCE:Z78_CARDS)[r.tier]?.name||'');
 const soon=await db.prepare("SELECT id,user_id,kind,tier,expires_at FROM z78_subs WHERE status='active' AND notified_soon=0 AND expires_at>? AND expires_at<=? LIMIT 40").bind(now,now+Z78_SOON).all();
 for(const r of soon.results){
  const hit=await db.prepare('UPDATE z78_subs SET notified_soon=1 WHERE id=? AND notified_soon=0 RETURNING id').bind(r.id).first();
  if(hit)await zNotify(db,r.user_id,'⏳ اشتراكك قرب ينتهي',label(r)+' ينتهي يوم '+z78DateStr(r.expires_at)+'. جدّده من صفحة التأمين وبطاقة المواطن.','money');
 }
 const ended=await db.prepare("SELECT id,user_id,kind,tier FROM z78_subs WHERE status='active' AND expires_at<=? LIMIT 40").bind(now).all();
 for(const r of ended.results){
  const hit=await db.prepare("UPDATE z78_subs SET status='expired',notified_end=1 WHERE id=? AND status='active' RETURNING id").bind(r.id).first();
  if(hit)await zNotify(db,r.user_id,'انتهى اشتراكك',label(r)+' انتهى، وامتيازاته توقفت. تقدر تجدده في أي وقت.','money');
 }
}

function z78Public(row){return row?{id:row.id,kind:row.kind,tier:row.tier,period:row.period,price:Number(row.price),credit:Number(row.credit||0),started_at:Number(row.started_at),expires_at:Number(row.expires_at),status:row.status}:null}
async function z78State(db,u,now=Date.now()){
 await z78Ensure(db);
 const [ins,card,hist,expiry]=await Promise.all([z78InsuranceFor(db,u,now),z78CardFor(db,u,now),db.prepare('SELECT id,kind,tier,period,price,credit,started_at,expires_at,status FROM z78_subs WHERE user_id=? ORDER BY started_at DESC LIMIT 30').bind(u.id).all(),z78IdentityExpiry(db,u,now)]);
 const gov=z78IsGov(u),pres=z78IsPresidential(u);
 return {ok:true,now,gov,pres,month_days:10,year_days:120,card_days:10,
  identity:{expires_at:expiry,expires_date:z78DateStr(expiry),expired:expiry<=now},
  insurance:ins?z78Public({...ins,kind:'insurance',status:'active'}):null,card:card?z78Public({...card,kind:'card',status:'active'}):null,
  badge:card?.plan.badge||'',card_name:card?.plan.name||'',
  rates:{tax_pct:Math.round((await z78TaxRate(db,u,now))*10000)/100,interest_pct:ins?ins.plan.interest:10,discount_pct:card?card.plan.discount:0},
  catalog:{
   insurance:Object.entries(Z78_INSURANCE).map(([tier,p])=>({tier,name:p.name,monthly:p.monthly,annual:p.annual,tax:p.tax,interest:p.interest,eligible:!p.gov||gov,restricted:!!p.gov})),
   cards:Object.entries(Z78_CARDS).map(([tier,p])=>({tier,name:p.name,price:p.price,discount:p.discount,reward:p.reward,badge:p.badge,eligible:(!p.gov||gov)&&(!p.pres||pres),restricted:!!(p.gov||p.pres)}))},
  history:hist.results.map(z78Public)};
}

async function z78Buy(request,db,env,u,p){
 const now=Date.now();await z78Ensure(db);
 if(await isMaintenance(db)&&!(await maintenanceAllowed(request,db,env)))return err(503,'الدولة تحت الصيانة');
 if(await prisonActive(db,u.id))return err(403,'حسابك في السجن؛ المعاملات متوقفة');
 const suspended=await db.prepare('SELECT until_at FROM suspensions WHERE user_id=?').bind(u.id).first();
 if(suspended&&Number(suspended.until_at)>now)return err(403,'الحساب موقوف مؤقتًا');
 try{if(await z40ResetIsActive(db))return err(423,'تصفير الموسم جارٍ، المعاملات متوقفة');}catch(e){if(!/no such table/i.test(String(e.message)))throw e;}
 const kind=String(p.kind||''),tier=String(p.tier||''),rid=String(p.request_id||'');
 if(!/^[a-zA-Z0-9-]{8,85}$/.test(rid))return err(400,'رقم عملية غير صالح');
 let plan,price,term,period='',label;
 if(kind==='insurance'){
  plan=Z78_INSURANCE[tier];if(!plan)return err(400,'باقة غير معروفة');
  period=String(p.period||'');if(!['monthly','annual'].includes(period))return err(400,'اختر تأمينًا شهريًا أو سنويًا');
  if(plan.gov&&!z78IsGov(u))return err(403,'هذه الباقة للمناصب الحكومية والرئاسية فقط');
  price=period==='annual'?plan.annual:plan.monthly;term=period==='annual'?Z78_YEAR:Z78_MONTH;label='التأمين '+(period==='annual'?'السنوي':'الشهري')+' — '+plan.name;
 }else if(kind==='card'){
  plan=Z78_CARDS[tier];if(!plan)return err(400,'بطاقة غير معروفة');
  if(plan.pres&&!z78IsPresidential(u))return err(403,'البطاقة الرئاسية متاحة للمناصب الرئاسية المحددة فقط');
  if(plan.gov&&!z78IsGov(u))return err(403,'هذه البطاقة لأصحاب المناصب الحكومية فقط');
  price=plan.price;term=Z78_CARD_TERM;label=plan.name;
 }else return err(400,'نوع الاشتراك غير صحيح');
 const old=await db.prepare('SELECT id,kind,tier,period FROM z78_subs WHERE user_id=? AND request_id=?').bind(u.id,rid).first();
 if(old){if(old.kind!==kind||old.tier!==tier)return err(409,'رقم عملية مستخدم لاشتراك مختلف');return json(await z78State(db,u,now));}
 if(kind==='insurance'){const v=await z78Verify(db,u,p,now);if(v.error)return v.error;}
 // One active plan per kind. Only upgrades (or an early renewal in the last 3 days) are allowed; the unused part is credited.
 const active=await z78Active(db,u.id,kind,now);let credit=0,replace=null;
 if(active){
  const oldPlan=(kind==='insurance'?Z78_INSURANCE:Z78_CARDS)[active.tier]||{rank:0};
  const oldDur=Number(active.expires_at)-Number(active.started_at),remaining=Number(active.expires_at)-now;
  const oldScore=oldPlan.rank*1e6+oldDur/Z78_DAY,newScore=plan.rank*1e6+term/Z78_DAY;
  if(!(newScore>oldScore||(newScore===oldScore&&remaining<=Z78_SOON)))return err(409,'عندك اشتراك فعّال أعلى أو مساوٍ. اختر باقة أعلى، أو جدّد قبل الانتهاء بـ 3 أيام.');
  credit=Math.max(0,Math.floor(Number(active.price)*remaining/Math.max(1,oldDur)));replace=active.id;
 }
 const charge=Math.max(1,price-credit);
 const bal=await db.prepare('SELECT points FROM users WHERE id=?').bind(u.id).first();
 if(Number(bal?.points||0)<charge)return err(409,'رصيدك لا يكفي. المطلوب '+charge+' زنجر');
 const sid=id();
 const statements=[
  db.prepare('INSERT INTO z78_subs(id,user_id,kind,period,tier,price,credit,started_at,expires_at,status,request_id) VALUES(?,?,?,?,?,?,?,?,?,?,?)').bind(sid,u.id,kind,period,tier,price,credit,now,now+term,'active',rid)];
 if(replace)statements.push(db.prepare("UPDATE z78_subs SET status='replaced' WHERE id=? AND status='active'").bind(replace));
 // Unguarded debit on purpose: users.points has CHECK(points>=0), so an overdraft aborts the whole batch.
 statements.push(db.prepare('UPDATE users SET points=points-? WHERE id=?').bind(charge,u.id));
 statements.push(db.prepare('INSERT INTO transactions(id,user_id,amount,note,created_at) VALUES(?,?,?,?,?)').bind(id(),u.id,-charge,crop('اشتراك '+label+(credit?' (بعد خصم '+credit+' من اشتراكك السابق)':''),200),now));
 try{await db.batch(statements);}
 catch(e){
  const again=await db.prepare('SELECT id FROM z78_subs WHERE user_id=? AND request_id=?').bind(u.id,rid).first();
  if(again)return json(await z78State(db,u,now));
  if(/CHECK|constraint/i.test(String(e?.message||e)))return err(409,'رصيدك لا يكفي أو تغيّر اشتراكك. جرّب مرة ثانية.');
  throw e;
 }
 try{await zNotify(db,u.id,'✅ تم تفعيل اشتراكك',label+' — ساري حتى '+z78DateStr(now+term),'money');}catch(e){}
 return json({...(await z78State(db,u,now)),purchased:{id:sid,kind,tier,period,charge,credit}});
}

async function z78Route(request,db,env,method,path){
 const u=await getMe(request,db);if(!u)return err(401,'سجّل دخولك الأول');
 if(method==='GET'&&path==='/api/v78/state')return json(await z78State(db,u));
 if(method!=='POST')return err(405,'طريقة غير مسموحة');
 let p={};try{p=await request.json()}catch(e){}
 if(path==='/api/v78/verify'){const v=await z78Verify(db,u,p);return v.error||json({ok:true});}
 if(path==='/api/v78/buy')return await z78Buy(request,db,env,u,p);
 return err(404,'غير موجود');
}
