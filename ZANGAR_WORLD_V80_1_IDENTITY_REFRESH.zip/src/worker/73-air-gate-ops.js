// ===== V66 AIR DEFENSE GATE AND OPERATIONS =====
async function z660GateEnsure(db){
 if(!z660GateSchema)z660GateSchema=(async()=>{
  await db.prepare('CREATE TABLE IF NOT EXISTS z660_air_gate_sessions(token_hash TEXT PRIMARY KEY,expires_at INTEGER NOT NULL)').run();
  await db.prepare('CREATE TABLE IF NOT EXISTS z660_air_gate_attempts(key TEXT PRIMARY KEY,failures INTEGER NOT NULL DEFAULT 0,blocked_until INTEGER NOT NULL DEFAULT 0)').run();
 })().catch(e=>{z660GateSchema=null;throw e});
 return z660GateSchema;
}
let z70CommandSchema=null;
async function z70CommandEnsure(db){
 if(!z70CommandSchema)z70CommandSchema=db.prepare('CREATE TABLE IF NOT EXISTS z70_air_command_sessions(token_hash TEXT PRIMARY KEY,user_id TEXT NOT NULL,expires_at INTEGER NOT NULL)').run().catch(e=>{z70CommandSchema=null;throw e;});
 return z70CommandSchema;
}
async function z70CommandAllowed(request,db,u){
 if(!u)return false;
 await z711Ensure(db);
 const current=await db.prepare('SELECT granted_at,revoked_at FROM z711_code_entitlements WHERE user_id=? AND scope=?').bind(u.id,'air_command').first();
 if(current)return Number(current.granted_at)>0&&Number(current.revoked_at)===0;
 // Keep the owner's existing valid 8-hour code session on first upgrade to V71.1.
 const token=cookieValue(request,'z70_air_command');if(!/^[a-f0-9]{64}$/.test(token))return false;
 await z70CommandEnsure(db);
 const old=await db.prepare('SELECT 1 FROM z70_air_command_sessions WHERE token_hash=? AND user_id=? AND expires_at>?').bind(await digest(token),u.id,Date.now()).first();
 if(!old)return false;
 await db.prepare("INSERT OR IGNORE INTO z711_code_entitlements(user_id,scope,granted_at,revoked_at) VALUES(?,'air_command',?,0)").bind(u.id,Date.now()).run();
 return z711Active(db,u.id,'air_command');
}
async function z70CommandLock(request,db){
 const origin=request.headers.get('Origin');if(origin&&origin!==new URL(request.url).origin)return err(403,'مصدر غير موثوق');
 const token=cookieValue(request,'z70_air_command');if(/^[a-f0-9]{64}$/.test(token)){
  await z70CommandEnsure(db);
  await db.prepare('DELETE FROM z70_air_command_sessions WHERE token_hash=?').bind(await digest(token)).run();
 }
 return json({ok:true,minister:false},200,{'Set-Cookie':'z70_air_command=; HttpOnly; Secure; SameSite=Strict; Path=/; Max-Age=0','Cache-Control':'no-store'});
}
async function z711RevokeOther(request,db){
 const origin=request.headers.get('Origin');if(origin&&origin!==new URL(request.url).origin)return err(403,'مصدر غير موثوق');
 const u=await getMe(request,db);if(!u)return err(401,'سجّل الدخول أولًا');
 const p=await request.json().catch(()=>({}));
 if(p.confirm!==true||!['head_control','sovereign_control'].includes(p.scope))return err(400,'حدد الصلاحية وأكد الإلغاء');
 await z711Revoke(db,u.id,p.scope);
 return json({ok:true,revoked:p.scope});
}
async function z711RevokeAir(request,db){
 const origin=request.headers.get('Origin');if(origin&&origin!==new URL(request.url).origin)return err(403,'مصدر غير موثوق');
 const u=await getMe(request,db);if(!u)return err(401,'سجل الدخول أولًا');
 const p=await request.json().catch(()=>({}));if(p.confirm!==true)return err(400,'يلزم التأكيد قبل إلغاء رمز القيادة');
 await z711Revoke(db,u.id,'air_command');
 await db.prepare('DELETE FROM z70_air_command_sessions WHERE user_id=?').bind(u.id).run();
 return json({ok:true,revoked:true},200,{'Set-Cookie':'z70_air_command=; HttpOnly; Secure; SameSite=Strict; Path=/; Max-Age=0','Cache-Control':'no-store'});
}
async function z660AirGateAllowed(request,db){
 await z660GateEnsure(db);
 const token=cookieValue(request,'z660_air_gate');if(!/^[a-f0-9]{64}$/.test(token))return false;
 return !!await db.prepare('SELECT 1 FROM z660_air_gate_sessions WHERE token_hash=? AND expires_at>?').bind(await digest(token),Date.now()).first();
}
async function z660AirUnlock(request,db){
 const u=await getMe(request,db);if(!u)return err(401,'سجّل الدخول إلى حسابك أولًا، ثم أدخل الرمز السري لتشغيل الدبابة');
 const origin=request.headers.get('Origin');if(origin&&origin!==new URL(request.url).origin)return err(403,'مصدر غير موثوق');
 await z660GateEnsure(db);
 const key=await digest('z660-gate:'+String(request.headers.get('CF-Connecting-IP')||'unknown').slice(0,75));
 const now=Date.now();const attempts=await db.prepare('SELECT failures,blocked_until FROM z660_air_gate_attempts WHERE key=?').bind(key).first();
 if(Number(attempts?.blocked_until||0)>now)return err(429,'محاولات كثيرة؛ أعد المحاولة بعد 15 دقيقة');
 const raw=await request.text();if(raw.length>500)return err(413,'طلب كبير');
 let p;try{p=JSON.parse(raw||'{}')}catch{return err(400,'طلب غير صحيح')}
 const pin=String(p.pin||'');const valid=/^[0-9]{9}$/.test(pin)&&eqSecure(await digest(pin),Z660_GATE_HASH);
 if(!valid){const n=Number(attempts?.failures||0)+1;await db.prepare(`INSERT INTO z660_air_gate_attempts(key,failures,blocked_until) VALUES(?,?,?) ON CONFLICT(key) DO UPDATE SET failures=excluded.failures,blocked_until=excluded.blocked_until`).bind(key,n>=6?0:n,n>=6?now+15*60000:0).run();return err(401,'رمز الدخول غير صحيح');}
 await db.prepare('DELETE FROM z660_air_gate_attempts WHERE key=?').bind(key).run();
 const token=hex(crypto.getRandomValues(new Uint8Array(32)));
 await z70CommandEnsure(db);
 await z711Grant(db,u.id,'air_command');
 await db.prepare('INSERT INTO z70_air_command_sessions(token_hash,user_id,expires_at) VALUES(?,?,?)').bind(await digest(token),u.id,now+8*3600000).run();
 return json({ok:true,unlocked:true,persistent:true},200,{'Set-Cookie':`z70_air_command=${token}; HttpOnly; Secure; SameSite=Strict; Path=/; Max-Age=28800`,'Cache-Control':'no-store'});
}
async function z660Emergency(request,db){
 const u=await getMe(request,db);if(!u||!(await z70CommandAllowed(request,db,u)))return err(403,'افتح مركز التحكم بالرمز السري أولًا');
 if(await isMaintenance(db)||await z40ResetIsActive(db))return err(503,'العمليات غير متاحة أثناء الصيانة');
 const origin=request.headers.get('Origin');if(origin&&origin!==new URL(request.url).origin)return err(403,'مصدر غير موثوق');
 const p=await request.json().catch(()=>({}));const requestId=String(p.request_id||'');
 if(!/^[a-zA-Z0-9-]{12,90}$/.test(requestId))return err(400,'معرّف الإرسال غير صحيح');
 await z68EnsureGameSchema(db);await z42Ensure(db);await z659AirEnsure(db);
 const existing=await db.prepare('SELECT actor_id FROM z660_air_emergencies WHERE id=?').bind(requestId).first();
 if(existing)return existing.actor_id===u.id?json({ok:true,already_sent:true,recipients:0}):err(409,'معرّف العملية مستخدم');
 const now=Date.now();try{await db.prepare('INSERT INTO z660_air_emergencies(id,actor_id,created_at) VALUES(?,?,?)').bind(requestId,u.id,now).run();}
 catch(e){const m=String(e.message||e);if(/30 دقيقة|الإنذار|منصب وزير الدفاع/.test(m))return err(429,m);throw e;}
 await z68AlertCreate(db,requestId,now);
 const count=await db.prepare('SELECT COUNT(*) AS n FROM users u WHERE NOT EXISTS(SELECT 1 FROM z64_archived_users a WHERE a.user_id=u.id AND a.restored_at=0)').first();
 return json({ok:true,recipients:Number(count?.n||0),alert:await z68AlertSnapshot(db,now),notice:'تم تسجيل إنذار داخل لعبة ZANGAR WORLD وإرسال روابط الإنذار للمشتركين'});
}
