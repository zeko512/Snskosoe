// Update 49: fresh, session-scoped presidential two-stage gate. Previous grants never authorize it.
const Z49_CODE_HASH='7dd50fcb1d342d3c66594c099cdc284cdbb35e106f5a2ad3ef16d136d5a368b6', Z49_PIN_HASH='7c2b166fdc25b6c4648974acd0b495fe09dde7d2aba4a3e878a849e6956d3911';
const Z49_STEP_TTL=5*60*1000, Z49_ACCESS_TTL=12*3600000;
let z49Ready=null;
async function z49Ensure(db){
 if(z49Ready)return z49Ready;
 z49Ready=(async()=>{
  await db.batch([
   db.prepare('CREATE TABLE IF NOT EXISTS z49_gate_pending (session_hash TEXT PRIMARY KEY,user_id TEXT NOT NULL,expires_at INTEGER NOT NULL)'),
   db.prepare('CREATE TABLE IF NOT EXISTS z49_gate_access (session_hash TEXT PRIMARY KEY,user_id TEXT NOT NULL,created_at INTEGER NOT NULL,expires_at INTEGER NOT NULL)'),
   db.prepare('CREATE TABLE IF NOT EXISTS z49_gate_attempts (user_id TEXT PRIMARY KEY,failures INTEGER NOT NULL DEFAULT 0,blocked_until INTEGER NOT NULL DEFAULT 0)'),
   db.prepare('CREATE TABLE IF NOT EXISTS z49_unit_gifts (id TEXT PRIMARY KEY,actor_id TEXT NOT NULL,province_id TEXT NOT NULL,unit TEXT NOT NULL,qty INTEGER NOT NULL CHECK(qty BETWEEN 1 AND 100000),created_at INTEGER NOT NULL)'),
   db.prepare('CREATE TABLE IF NOT EXISTS z49_fund_gifts (id TEXT PRIMARY KEY,actor_id TEXT NOT NULL,province_id TEXT NOT NULL,amount INTEGER NOT NULL CHECK(amount BETWEEN 1 AND 10000000),created_at INTEGER NOT NULL)'),
   db.prepare('CREATE TABLE IF NOT EXISTS z49_wallet_gifts (id TEXT PRIMARY KEY,actor_id TEXT NOT NULL,target_id TEXT NOT NULL,amount INTEGER NOT NULL CHECK(amount BETWEEN 1 AND 10000000),created_at INTEGER NOT NULL)'),
   db.prepare("CREATE TABLE IF NOT EXISTS z49_rebuilds(id TEXT PRIMARY KEY,province_id TEXT NOT NULL,war_id TEXT NOT NULL,soldiers INTEGER NOT NULL,missiles INTEGER NOT NULL,planes INTEGER NOT NULL,ships INTEGER NOT NULL,cost INTEGER NOT NULL,actor_id TEXT NOT NULL,created_at INTEGER NOT NULL,UNIQUE(province_id,war_id))"),
   db.prepare("CREATE TRIGGER IF NOT EXISTS z49_rebuild_check BEFORE INSERT ON z49_rebuilds BEGIN SELECT CASE WHEN NOT EXISTS(SELECT 1 FROM z46_provinces WHERE id=NEW.province_id AND treasury>=NEW.cost) THEN RAISE(ABORT,'خزينة الدولة لا تكفي لإعادة الإعمار') END; END"),
   db.prepare("CREATE TRIGGER IF NOT EXISTS z49_rebuild_apply AFTER INSERT ON z49_rebuilds BEGIN UPDATE z46_provinces SET treasury=treasury-NEW.cost,soldiers=soldiers+NEW.soldiers,missiles=missiles+NEW.missiles,planes=planes+NEW.planes,ships=ships+NEW.ships WHERE id=NEW.province_id; INSERT INTO z46_ledger(id,province_id,actor_id,kind,delta,note,created_at) VALUES(NEW.id,NEW.province_id,NEW.actor_id,'rebuild',-NEW.cost,'إعادة إعمار الجيش بعد المعركة',NEW.created_at); END"),
   db.prepare("CREATE TABLE IF NOT EXISTS z49_unit_transfers(id TEXT PRIMARY KEY,from_id TEXT NOT NULL,to_id TEXT NOT NULL,actor_id TEXT NOT NULL,unit TEXT NOT NULL,qty INTEGER NOT NULL CHECK(qty BETWEEN 1 AND 10000),status TEXT NOT NULL DEFAULT 'pending' CHECK(status IN ('pending','accepted','rejected')),created_at INTEGER NOT NULL,decided_at INTEGER NOT NULL DEFAULT 0)"),
   db.prepare("CREATE TRIGGER IF NOT EXISTS z49_unit_transfer_check BEFORE INSERT ON z49_unit_transfers BEGIN SELECT CASE WHEN NEW.from_id=NEW.to_id OR NEW.unit NOT IN ('soldiers','missiles','planes','ships') OR NOT EXISTS(SELECT 1 FROM z46_provinces WHERE id=NEW.to_id) THEN RAISE(ABORT,'بيانات نقل الجيش غير صالحة') END; SELECT CASE WHEN NOT EXISTS(SELECT 1 FROM z46_provinces WHERE id=NEW.from_id AND CASE NEW.unit WHEN 'soldiers' THEN soldiers WHEN 'missiles' THEN missiles WHEN 'planes' THEN planes WHEN 'ships' THEN ships ELSE 0 END>=NEW.qty) THEN RAISE(ABORT,'قوات الدولة المرسلة غير كافية') END; END"),
   db.prepare("CREATE TRIGGER IF NOT EXISTS z49_unit_transfer_hold AFTER INSERT ON z49_unit_transfers BEGIN UPDATE z46_provinces SET soldiers=soldiers-CASE WHEN NEW.unit='soldiers' THEN NEW.qty ELSE 0 END,missiles=missiles-CASE WHEN NEW.unit='missiles' THEN NEW.qty ELSE 0 END,planes=planes-CASE WHEN NEW.unit='planes' THEN NEW.qty ELSE 0 END,ships=ships-CASE WHEN NEW.unit='ships' THEN NEW.qty ELSE 0 END WHERE id=NEW.from_id; INSERT INTO z46_ledger(id,province_id,actor_id,kind,delta,note,created_at) VALUES(NEW.id,NEW.from_id,NEW.actor_id,'unit_transfer',0,'قوات في انتظار موافقة الدولة المستلمة',NEW.created_at); END"),
   db.prepare("CREATE TRIGGER IF NOT EXISTS z49_unit_transfer_close AFTER UPDATE OF status ON z49_unit_transfers WHEN OLD.status='pending' AND NEW.status IN ('accepted','rejected') BEGIN UPDATE z46_provinces SET soldiers=soldiers+CASE WHEN NEW.unit='soldiers' THEN NEW.qty ELSE 0 END,missiles=missiles+CASE WHEN NEW.unit='missiles' THEN NEW.qty ELSE 0 END,planes=planes+CASE WHEN NEW.unit='planes' THEN NEW.qty ELSE 0 END,ships=ships+CASE WHEN NEW.unit='ships' THEN NEW.qty ELSE 0 END WHERE id=CASE WHEN NEW.status='accepted' THEN NEW.to_id ELSE NEW.from_id END; INSERT INTO z46_ledger(id,province_id,actor_id,kind,delta,note,created_at) VALUES(NEW.id||'-done',CASE WHEN NEW.status='accepted' THEN NEW.to_id ELSE NEW.from_id END,NEW.actor_id,'unit_transfer',0,CASE WHEN NEW.status='accepted' THEN 'تم استلام دعم عسكري من دولة أخرى' ELSE 'تم إرجاع القوات بعد رفض العرض' END,NEW.decided_at); END"),
   db.prepare("CREATE TRIGGER IF NOT EXISTS z49_unit_gift_apply AFTER INSERT ON z49_unit_gifts BEGIN UPDATE z46_provinces SET soldiers=soldiers+CASE WHEN NEW.unit='soldiers' THEN NEW.qty ELSE 0 END,missiles=missiles+CASE WHEN NEW.unit='missiles' THEN NEW.qty ELSE 0 END,planes=planes+CASE WHEN NEW.unit='planes' THEN NEW.qty ELSE 0 END,ships=ships+CASE WHEN NEW.unit='ships' THEN NEW.qty ELSE 0 END WHERE id=NEW.province_id; INSERT INTO z46_ledger(id,province_id,actor_id,kind,delta,note,created_at) VALUES(NEW.id,NEW.province_id,NEW.actor_id,'central_gift',0,'دعم عسكري من الرئاسة',NEW.created_at); END"),
   db.prepare("CREATE TRIGGER IF NOT EXISTS z49_fund_gift_apply AFTER INSERT ON z49_fund_gifts BEGIN UPDATE z46_provinces SET treasury=treasury+NEW.amount,economy=economy+NEW.amount WHERE id=NEW.province_id; INSERT INTO z46_ledger(id,province_id,actor_id,kind,delta,note,created_at) VALUES(NEW.id,NEW.province_id,NEW.actor_id,'central_gift',NEW.amount,'قرار رئاسي خاص: إضافة لمحفظة المواطن',NEW.created_at); END"),
   db.prepare("CREATE TRIGGER IF NOT EXISTS z49_wallet_gift_apply AFTER INSERT ON z49_wallet_gifts BEGIN UPDATE users SET points=points+NEW.amount WHERE id=NEW.target_id; INSERT INTO transactions(id,user_id,amount,note,created_at) VALUES(NEW.id,NEW.target_id,NEW.amount,'قرار رئاسي خاص: إضافة لمحفظة المواطن',NEW.created_at); END")
  ]);
 })().catch(e=>{z49Ready=null;throw e});return z49Ready;
}
function z49SessionHash(req){const token=cookieValue(req,'zangar_session');return /^[a-f0-9]{64}$/.test(token)?digest(token):Promise.resolve('');}
async function z49Gate(req,db,p,env={}){
 const u=await getMe(req,db);if(!u)return err(401,'سجّل دخولك كمواطن أولًا');
 const stage=String(p.stage||''),now=Date.now(),hash=await z49SessionHash(req);
 const attempt=await db.prepare('SELECT failures,blocked_until FROM z49_gate_attempts WHERE user_id=?').bind(u.id).first();
 if(stage==='close'){
  // Explicit account-wide revoke; refresh/logout/deploy never call this endpoint.
  await z711Revoke(db,u.id,'presidency');
  await db.batch([db.prepare('DELETE FROM z49_gate_access WHERE user_id=?').bind(u.id),db.prepare('DELETE FROM z49_gate_pending WHERE user_id=?').bind(u.id)]);
  return json({ok:true,active:false,notice:'تم إلغاء صلاحية الرئاسة من حسابك بناءً على طلبك'});
 }
 if(stage==='status')return json({ok:true,active:isAdmin(u),persistent:isAdmin(u)});
 if(Number(attempt?.blocked_until||0)>now)return err(429,'التحقق مؤقتًا مقفول بسبب محاولات كثيرة؛ انتظر 15 دقيقة.');
 const pending=stage==='pin'?await db.prepare('SELECT expires_at FROM z49_gate_pending WHERE session_hash=? AND user_id=?').bind(hash,u.id).first():null;
 if(stage==='pin'&&(!pending||Number(pending.expires_at)<now))return err(403,'انتهت مهلة الخطوة الأولى؛ ابدأ بكتابة كود الرئاسة من جديد.');
 if(stage!=='code'&&stage!=='pin')return err(400,'مرحلة تحقق غير معروفة');
 const submitted=String(stage==='code'?p.code:p.pin||'').trim();
 const secret=stage==='code'?env.Z49_PRESIDENT_CODE:env.Z49_PRESIDENT_PIN;
 const expected=stage==='code'?Z49_CODE_HASH:Z49_PIN_HASH; // V64: use precisely the owner's confirmed new code and PIN; stale environment bindings must not override them.
 const ok=submitted.length>=4&&submitted.length<=100&&eqSecure(await digest(submitted),expected);
 if(!ok){
  const failures=Number(attempt?.failures||0)+1;
  await db.prepare('INSERT INTO z49_gate_attempts(user_id,failures,blocked_until) VALUES(?,?,?) ON CONFLICT(user_id) DO UPDATE SET failures=excluded.failures,blocked_until=excluded.blocked_until').bind(u.id,failures,failures>=5?now+900000:0).run();
  return err(403,failures>=5?'تم قفل المحاولات لمدة 15 دقيقة':'الرمز غير صحيح');
 }
 if(stage==='code'){
  await db.prepare('INSERT INTO z49_gate_pending(session_hash,user_id,expires_at) VALUES(?,?,?) ON CONFLICT(session_hash) DO UPDATE SET user_id=excluded.user_id,expires_at=excluded.expires_at').bind(hash,u.id,now+Z49_STEP_TTL).run();
  return json({ok:true,next:'/president49-pin.html',notice:'تم التأكد من الخطوة الأولى؛ أدخل الرمز السري'});
 }
 await z711Grant(db,u.id,'presidency');
 await db.batch([
  db.prepare('DELETE FROM z49_gate_pending WHERE session_hash=?').bind(hash),
  db.prepare('DELETE FROM z49_gate_attempts WHERE user_id=?').bind(u.id)
 ]);
 return json({ok:true,persistent:true,notice:'تم حفظ صلاحيات الرئاسة على حسابك؛ ستعود تلقائيًا بعد تحديث الصفحة أو تسجيل الدخول',next:'/v64.html#accounts'});
}
