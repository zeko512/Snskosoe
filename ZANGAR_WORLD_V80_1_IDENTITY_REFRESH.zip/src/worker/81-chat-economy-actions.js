// Update 33: free chat for ALL citizens; old paid access records are preserved, never charged again.
async function zChatCharge(db,u,now){return;}
async function zModernAction(req,db,p){
 const u=await getMe(req,db);if(!u)return err(401,'سجّل دخولك أولًا');
 const type=crop(p.type,40),now=Date.now();if(await prisonActive(db,u.id,now))return err(403,'أنت في السجن حاليًا');
 if(type==='educationDecision'){
  if(!await hasDepartment(db,u,'education'))return err(403,'إصدار قرارات التعليم يحتاج صلاحية وزارة التعليم');
  const kind=crop(p.kind,30),title=crop(p.title,90),detail=crop(p.detail,600);
  if(!['المنهج','الامتحانات','الجدول','قرار عام'].includes(kind)||title.length<5||detail.length<12)return err(400,'اكتب نوع القرار وعنوانًا ووصفًا واضحًا');
  await db.prepare('INSERT INTO z_edu_decisions(id,author_id,kind,title,detail,created_at) VALUES(?,?,?,?,?,?)').bind(id(),u.id,kind,title,detail,now).run();
  await activity(db,u.name,'أصدر قرارًا تعليميًا: '+title,now);return json({ok:true});
 }
 if(type==='cardIssue'){
  const kind=crop(p.kind,30),tier=crop(p.tier,15),mode=crop(p.mode,10),t=ZCARD_TIERS[tier];
  if(!['فيزا','ماستركارد'].includes(kind)||!t||!['debit','credit'].includes(mode))return err(400,'اختيار البطاقة غير صحيح');
  const number='4000 '+Array.from({length:3},()=>String(Math.floor(1000+Math.random()*9000))).join(' '),cardId=id();
  if(t.price)await zPointDebit(db,u,t.price,'إصدار بطاقة '+t.title+' '+kind,true);
  await db.batch([db.prepare('INSERT INTO cards(id,user_id,kind,number,created_at) VALUES(?,?,?,?,?)').bind(cardId,u.id,kind,number,now),db.prepare('INSERT INTO z_card_profiles(card_id,user_id,tier,mode,created_at) VALUES(?,?,?,?,?)').bind(cardId,u.id,tier,mode,now)]);
  return json({ok:true});
 }
 if(type==='cardMode'){
  const mode=crop(p.mode,10),card=crop(p.card_id,80);
  if(!['debit','credit'].includes(mode))return err(400,'نوع البطاقة غير صحيح');
  const result=await db.prepare('UPDATE z_card_profiles SET mode=? WHERE card_id=? AND user_id=? AND credit_used=0 RETURNING card_id').bind(mode,card,u.id).first();
  if(!result)return err(409,'لا يمكن تغيير النوع قبل سداد الكريدت أو البطاقة قديمة');return json({ok:true});
 }
 if(type==='cardCashback'){
  const cardId=crop(p.card_id,80),amount=Number(p.amount);
  if(!Number.isSafeInteger(amount)||amount<1)return err(400,'المبلغ غير صحيح');if(await zTreasuryBalance(db)<amount)return err(409,'الخزينة لا تكفي لاسترداد الكاش باك حاليًا');
  const changed=await db.prepare('UPDATE z_card_profiles SET cashback=cashback-? WHERE card_id=? AND user_id=? AND cashback>=? RETURNING cashback').bind(amount,cardId,u.id,amount).first();
  if(!changed)return err(400,'رصيد الكاش باك لا يكفي');
  await zTreasuryPay(db,u.id,amount,'استرداد كاش باك البطاقة',u.name);return json({ok:true});
 }
 if(type==='creditDraw'){
  const cfg=await z45LoanConfig(db);if(!cfg.open) return err(403,'التمويلات والقروض متوقفة مؤقتًا بقرار الرئاسة');
  const card=crop(p.card_id,80),amount=Number(p.amount),assetId=crop(p.asset_id,80),guarantee=crop(p.guarantee,10);
  if(!Number.isSafeInteger(amount)||amount<100||amount>Math.min(25000,cfg.max))return err(400,'المبلغ أكبر من حد التمويل المسموح');
  const profile=await db.prepare("SELECT * FROM z_card_profiles WHERE card_id=? AND user_id=? AND mode='credit'").bind(card,u.id).first();
  if(!profile)return err(403,'اختار بطاقة كريدت تملكها');
  let limit=0;if(guarantee==='savings'){const s=await db.prepare('SELECT balance FROM z_savings WHERE user_id=?').bind(u.id).first();limit=Math.min(25000,Math.floor(Number(s?.balance||0)*0.5));}
  else if(guarantee==='land'){const land=await db.prepare("SELECT id FROM econ_assets WHERE id=? AND user_id=? AND kind='land'").bind(assetId,u.id).first();if(!land)return err(403,'الأرض ليست ملكك');const other=await db.prepare("SELECT card_id FROM z_card_profiles WHERE user_id=? AND credit_used>0 AND collateral_type='land' AND collateral_asset_id=? AND card_id<>?").bind(u.id,assetId,card).first();if(other)return err(409,'الأرض مرهونة لكريدت آخر');limit=20000;}
  else return err(400,'اختار ضمانًا من التوفير أو أرضًا تملكها');
  if(profile.credit_used>0&&(profile.collateral_type!==guarantee||profile.collateral_asset_id!==(guarantee==='land'?assetId:'')))return err(409,'سدّد المبلغ السابق لتغيير نوع الضمان');
  if(await zTreasuryBalance(db)<amount)return err(409,'الخزينة لا تكفي للتمويل حاليًا');
  const updated=await db.prepare('UPDATE z_card_profiles SET credit_used=credit_used+?,collateral_type=?,collateral_asset_id=? WHERE card_id=? AND user_id=? AND credit_used+?<=? RETURNING credit_used').bind(amount,guarantee,guarantee==='land'?assetId:'',card,u.id,amount,limit).first();
  if(!updated)return err(400,'قيمة التمويل أكبر من ضمانك المتاح');
  await zTreasuryPay(db,u.id,amount,'تمويل بطاقة كريدت بضمان '+(guarantee==='land'?'أرض':'التوفير'),u.name);return json({ok:true,limit,used:updated.credit_used});
 }
 if(type==='creditRepay'){
  const card=crop(p.card_id,80),amount=Number(p.amount);if(!Number.isSafeInteger(amount)||amount<1)return err(400,'مبلغ السداد غير صحيح');
  const profile=await db.prepare('SELECT credit_used FROM z_card_profiles WHERE card_id=? AND user_id=?').bind(card,u.id).first();if(!profile||amount>profile.credit_used)return err(400,'المبلغ أكبر من مديونية البطاقة');
  await zPointDebit(db,u,amount,'سداد بطاقة كريدت');await zTreasuryReceive(db,amount,'سداد تمويل كريدت',u.name);await db.prepare(`UPDATE z_card_profiles SET credit_used=credit_used-?,collateral_type=CASE WHEN credit_used=? THEN '' ELSE collateral_type END,collateral_asset_id=CASE WHEN credit_used=? THEN '' ELSE collateral_asset_id END WHERE card_id=? AND user_id=?`).bind(amount,amount,amount,card,u.id).run();return json({ok:true});
 }
 if(type==='residenceBuy'){
  const already=await db.prepare("SELECT id FROM econ_assets WHERE user_id=? AND kind='residence'").bind(u.id).first();if(already)return err(409,'تمتلك وحدة سكنية بالفعل');
  await zPointDebit(db,u,95000,'شراء وحدة سكنية مع المعاينة',true);
  const residenceId=id();await db.prepare('INSERT INTO econ_assets(id,user_id,kind,created_at) VALUES(?,?,?,?)').bind(residenceId,u.id,'residence',now).run();await db.prepare('INSERT OR IGNORE INTO z_asset_tax_paid(asset_id,owner_id,paid_at) VALUES(?,?,?)').bind(residenceId,u.id,now).run();
  return json({ok:true});
 }
 if(type==='propertyOffer'){
  const asset=crop(p.asset_id,80),kind=crop(p.kind,10),price=Number(p.price);
  if(!['rent','sale'].includes(kind)||!Number.isSafeInteger(price)||price<100||price>500000)return err(400,'سعر أو نوع العرض غير صحيح');
  const owned=await db.prepare("SELECT id FROM econ_assets WHERE id=? AND user_id=? AND kind IN ('land','shop','restaurant','residence','factory')").bind(asset,u.id).first();if(!owned)return err(403,'لا تملك هذا العقار');
  const pledged=await db.prepare("SELECT card_id FROM z_card_profiles WHERE user_id=? AND credit_used>0 AND collateral_type='land' AND collateral_asset_id=?").bind(u.id,asset).first();if(pledged)return err(409,'الأرض مستخدمة كضمان كريدت');
  const exists=await db.prepare("SELECT id FROM z_property_listings WHERE asset_id=? AND status='open'").bind(asset).first();if(exists)return err(409,'العقار معروض بالفعل');
  await db.prepare('INSERT INTO z_property_listings(id,asset_id,owner_id,kind,price,status,created_at) VALUES(?,?,?,?,?,?,?)').bind(id(),asset,u.id,kind,price,'open',now).run();return json({ok:true});
 }
 if(type==='propertyCancel'){
  const done=await db.prepare("UPDATE z_property_listings SET status='cancelled' WHERE id=? AND owner_id=? AND status='open' RETURNING id").bind(crop(p.id,80),u.id).first();if(!done)return err(404,'العرض غير متاح');return json({ok:true});
 }
 if(type==='propertyAccept'){
  const listing=await db.prepare("SELECT * FROM z_property_listings WHERE id=? AND status='open'").bind(crop(p.id,80)).first();if(!listing||listing.owner_id===u.id)return err(404,'العرض غير متاح لك');
  const property=await db.prepare('SELECT * FROM econ_assets WHERE id=? AND user_id=?').bind(listing.asset_id,listing.owner_id).first();if(!property)return err(409,'العقار لم يعد متاحًا');
  if(listing.kind==='sale'){
    const same=await db.prepare('SELECT id FROM econ_assets WHERE user_id=? AND kind=? AND id<>?').bind(u.id,property.kind,property.id).first();
    if(same&&property.kind!=='land')return err(409,'قواعد الدولة تسمح بوحدة واحدة من نفس النوع');
  }
  const pledged=await db.prepare("SELECT card_id FROM z_card_profiles WHERE user_id=? AND credit_used>0 AND collateral_type='land' AND collateral_asset_id=?").bind(listing.owner_id,listing.asset_id).first();
  if(pledged)return err(409,'العقار مستخدم كضمان كريدت ولا يمكن نقله');
  const tax=Math.max(1,Math.ceil(listing.price*.10)),total=listing.price+tax;
  const debit=await db.prepare('UPDATE users SET points=points-? WHERE id=? AND points>=? RETURNING points').bind(total,u.id,total).first();if(!debit)return err(400,'رصيدك لا يكفي السعر وضريبة 10%');
  const claimed=await db.prepare("UPDATE z_property_listings SET status='closed',buyer_id=? WHERE id=? AND status='open' RETURNING asset_id").bind(u.id,listing.id).first();if(!claimed){await db.prepare('UPDATE users SET points=points+? WHERE id=?').bind(total,u.id).run();return err(409,'سبقك مواطن آخر للعرض');}
  await db.prepare('UPDATE users SET points=points+? WHERE id=?').bind(listing.price,listing.owner_id).run();
  await addTx(db,u.id,-total,'شراء أو استئجار عقار من مواطن');await addTx(db,listing.owner_id,listing.price,'بيع أو إيجار عقار');await stateEconomyAdd(db,tax,'رسوم صفقة عقارية',u.name);
  if(listing.kind==='sale'){
   await db.prepare('UPDATE econ_assets SET user_id=? WHERE id=? AND user_id=?').bind(u.id,property.id,listing.owner_id).run();await db.prepare('UPDATE z_business_income SET owner_id=? WHERE business_key=?').bind(u.id,'asset:'+property.id).run();await db.prepare('INSERT OR IGNORE INTO z_asset_tax_paid(asset_id,owner_id,paid_at) VALUES(?,?,?)').bind(property.id,u.id,now).run();
  }else{await db.prepare('INSERT INTO z_property_rentals(id,asset_id,owner_id,tenant_id,rent_until,created_at) VALUES(?,?,?,?,?,?)').bind(id(),property.id,listing.owner_id,u.id,now+24*3600000,now).run();}
  await zNotify(db,listing.owner_id,'عقار مباع أو مؤجر','تمت صفقة على عقارك بنجاح','property');await zNotify(db,u.id,'عملية عقارية ناجحة','تم إتمام شراء أو استئجار العقار','property');return json({ok:true});
 }
 if(type==='stockTrade'){
  const sym=crop(p.symbol,10),qty=Number(p.quantity),side=crop(p.side,5);
  if(!Object.prototype.hasOwnProperty.call(ECON_STOCKS,sym)||!['buy','sell'].includes(side)||!Number.isSafeInteger(qty)||qty<1||qty>25)return err(400,'صفقة الأسهم غير صحيحة');
  await zStockTick(db);const row=await db.prepare('SELECT price FROM z_stock_state WHERE symbol=?').bind(sym).first();let price=Number(row?.price||(ECON_STOCKS[sym].base)),tradeAmount=price*qty;
  if(side==='buy'){
   const brokerFee=Math.ceil(tradeAmount*.03),tax=Math.ceil(tradeAmount*.10),total=tradeAmount+brokerFee+tax;await zPointDebit(db,u,total,'شراء '+qty+' سهم '+sym+' شامل رسوم 3% وضريبة 10%');await stateEconomyAdd(db,brokerFee+tax,'رسوم وضريبة بورصة',u.name);
   await db.prepare('INSERT INTO econ_shares(user_id,symbol,quantity) VALUES(?,?,?) ON CONFLICT(user_id,symbol) DO UPDATE SET quantity=quantity+excluded.quantity').bind(u.id,sym,qty).run();
  }else{
   if(await zTreasuryBalance(db)<Math.floor(tradeAmount*.97))return err(409,'خزينة الدولة لا تكفي شراء الأسهم المعروضة حاليًا');
   const mine=await db.prepare('UPDATE econ_shares SET quantity=quantity-? WHERE user_id=? AND symbol=? AND quantity>=? RETURNING quantity').bind(qty,u.id,sym,qty).first();if(!mine)return err(400,'لا تملك عدد الأسهم المطلوب');
   const payout=Math.floor(tradeAmount*.97);await zTreasuryPay(db,u.id,payout,'بيع '+qty+' سهم '+sym,u.name);
  }
  // Virtual market: each actual player trade moves price; history persists in D1.
  const delta=Math.max(1,Math.round(price*Math.min(.16,qty*.012)))*(side==='buy'?1:-1),newPrice=Math.max(100,Math.min(2000000,price+delta));
  await db.prepare('INSERT INTO z_stock_state(symbol,price,updated_at) VALUES(?,?,?) ON CONFLICT(symbol) DO UPDATE SET price=excluded.price,updated_at=excluded.updated_at').bind(sym,newPrice,now).run();
  await db.prepare('INSERT INTO z_stock_history(id,symbol,price,created_at) VALUES(?,?,?,?)').bind(id(),sym,newPrice,now).run();
  await activity(db,u.name,(side==='buy'?'اشترى ':'باع ')+qty+' سهم '+sym,now);return json({ok:true,price,new_price:newPrice});
 }
 return err(400,'عملية غير معروفة');
}
async function zChangePassword(req,db,p){
 const u=await getMe(req,db);if(!u)return err(401,'سجّل الدخول أولًا');
 const old=crop(p.old_proof,200),newSalt=crop(p.new_salt,100),newProof=crop(p.new_proof,200);
 if(!/^[0-9a-f]{64}$/.test(old)||!/^[0-9a-f]{64}$/.test(newProof)||!/^[0-9a-f]{32}$/.test(newSalt))return err(400,'بيانات تغيير كلمة المرور غير صحيحة');
 const expected=u.passhash.startsWith('v2:')?'v2:'+await digest('zangar-v2|'+u.salt+'|'+old):old;
 if(!eqSecure(expected,u.passhash))return err(403,'كلمة المرور الحالية غير صحيحة');
 if(eqSecure(old,newProof))return err(400,'اختار كلمة مرور جديدة');
 await db.prepare('UPDATE users SET salt=?,passhash=? WHERE id=? AND passhash=?').bind(newSalt,'v2:'+await digest('zangar-v2|'+newSalt+'|'+newProof),u.id,u.passhash).run();
 const cookie=cookieValue(req,'zangar_session');await db.prepare('DELETE FROM sessions WHERE user_id=? AND token_hash<>?').bind(u.id,await digest(cookie)).run();
 return json({ok:true});
}
async function zCourierAction(req,db,p){
 const u=await getMe(req,db);if(!u)return err(401,'سجّل دخولك للعب وكسب الزنجر');if(await prisonActive(db,u.id))return err(403,'اللعب ممنوع أثناء السجن');
 const now=Date.now(),type=crop(p.type,25);
 if(type==='start'){
  const last=await db.prepare('SELECT MAX(won_at) AS at FROM z_courier_wins WHERE user_id=?').bind(u.id).first();if(Number(last?.at||0)>now-2*3600000)return err(429,'مكافأة 400 زنجر متاحة كل ساعتين. تقدر تلعب للتدريب لاحقًا.');
  await db.prepare("UPDATE z_courier_runs SET status='abandoned' WHERE user_id=? AND status='active'").bind(u.id).run();
  const run=id(),seed=Math.floor(Math.random()*900000)+100000;
  await db.prepare('INSERT INTO z_courier_runs(id,user_id,seed,stage,items,started_at,updated_at,status) VALUES(?,?,?,?,?,?,?,?)').bind(run,u.id,seed,1,0,now,now,'active').run();
  return json({ok:true,run,seed,stage:1,required:3,award:400});
 }
 if(type==='item'||type==='stage'){
  const run=await db.prepare("SELECT * FROM z_courier_runs WHERE id=? AND user_id=? AND status='active'").bind(crop(p.run,80),u.id).first();
  if(!run){
   const prior=await db.prepare('SELECT id FROM z_courier_wins WHERE id=? AND user_id=?').bind(crop(p.run,80),u.id).first();
   if(prior){const balance=await db.prepare('SELECT points FROM users WHERE id=?').bind(u.id).first();return json({ok:true,won:true,already_paid:true,award:400,balance:balance?.points});}
   return err(404,'الجولة غير نشطة. ابدأ من جديد');
  }
  if(now-run.started_at>15*60000)return err(408,'انتهت مهلة الجولة');
  const stage=Number(p.stage);if(stage!==run.stage)return err(409,'مرحلة غير متطابقة');
  if(type==='item'){
   const count=Number(p.count);if(count!==run.items+1||count>3)return err(409,'ترتيب الطرود غير صحيح');
   if(now-run.updated_at<900)return err(429,'سرعة غير طبيعية في جمع الطرود');
   const updated=await db.prepare("UPDATE z_courier_runs SET items=?,updated_at=? WHERE id=? AND stage=? AND items=? AND status='active' RETURNING id").bind(count,now,run.id,stage,run.items).first();if(!updated)return err(409,'تم تسجيل الطرد من قبل');return json({ok:true,items:count});
  }
  if(run.items!==3||now-run.updated_at<1200)return err(409,'اجمع الطرود الثلاثة وأكمل الطريق أولًا');
  if(stage<3){const next=await db.prepare("UPDATE z_courier_runs SET stage=stage+1,items=0,updated_at=? WHERE id=? AND stage=? AND status='active' RETURNING stage").bind(now,run.id,stage).first();if(!next)return err(409,'المرحلة انتهت');return json({ok:true,stage:next.stage});}
  if(now-run.started_at<18000)return err(429,'الوقت قصير جدًا؛ الجولة لم تُستكمل بشكل طبيعي');
  if(await zTreasuryBalance(db)<400)return err(409,'خزينة الدولة لا تكفي دفع مكافأة الجولة الآن');
  const prev=await db.prepare('SELECT id FROM z_courier_wins WHERE id=? AND user_id=?').bind(run.id,u.id).first();
  if(prev){const credits=await db.prepare('SELECT points FROM users WHERE id=?').bind(u.id).first();return json({ok:true,won:true,already_paid:true,award:400,balance:credits?.points});}
  await db.batch([
   db.prepare("UPDATE z_courier_runs SET status='won',updated_at=? WHERE id=? AND stage=3 AND items=3 AND status='active'").bind(now,run.id),
   db.prepare('INSERT INTO z_courier_wins(id,user_id,won_at) VALUES(?,?,?)').bind(run.id,u.id,now)
  ]);
  const credits=await db.prepare('SELECT points FROM users WHERE id=?').bind(u.id).first();
  return json({ok:true,won:true,award:400,balance:credits?.points});
 }
 return err(400,'طلب لعبة غير معروف');
}

// Publicly visible simulated market prices, sampled from actual game state every 15m.
async function zStockTick(db){
 const base=Object.fromEntries(Object.entries(ECON_STOCKS).map(([sym,item])=>[sym,item.base])),now=Date.now(),block=Math.floor(now/900000);
 const oldest=await db.prepare('SELECT MIN(updated_at) AS t FROM z_stock_state').first();
 if(oldest?.t && now-Number(oldest.t)<900000)return;
 const rows=await db.prepare('SELECT symbol,price,updated_at FROM z_stock_state').all();
 const z74moves=[];
 const bySymbol=new Map(rows.results.map(x=>[x.symbol,x]));
 for(const symbol of Object.keys(base)){
  let r=bySymbol.get(symbol);
  if(!r){let price=base[symbol];await db.prepare('INSERT OR IGNORE INTO z_stock_state(symbol,price,updated_at) VALUES(?,?,?)').bind(symbol,price,now).run();await db.prepare('INSERT INTO z_stock_history(id,symbol,price,created_at) VALUES(?,?,?,?)').bind(id(),symbol,price,now).run();continue;}
  if(now-r.updated_at<900000)continue;
  // Driven by time and symbol (stable), plus real user buys/sells kept in price.
  const key=Object.keys(base).indexOf(symbol)*4+3;
  const previousUpdate=Number(r.updated_at),step=Math.floor(previousUpdate/900000)+1,last=Math.min(block,step+12);
  let price=Number(r.price);
  for(let tick=step;tick<=last;tick++){
   const noise=Math.sin((tick+1)*78.233+(key+7)*12.9898)*43758.5453;
   const uniform=noise-Math.floor(noise); // deterministic pseudo-random, independent of trading
   const up=uniform<0.50; // Update 45: equal 50% odds up/down; persisted actual price, not a decorative chart
   const magnitude=0.05+((Math.sin(tick*4.737+key*3.13)+1)/2)*0.20;
   const drift=up?magnitude:-magnitude;
   const movement=Math.round(price*drift); // maximum +200% or 4,000 per tick; a 2,000 share cannot jump above 6,000
   price=Math.max(100,Math.min(Math.round(base[symbol]*10),price+Math.max(-Math.floor(price*.5),Math.min(Math.min(4000,price*2),movement))));
  }
  // Store only the final tick per visit to avoid hundreds of D1 queries after downtime.
  // Optimistic timestamp guard prevents another visitor overwriting a newer price.
  const at=last*900000;
  const moved=await db.prepare('UPDATE z_stock_state SET price=?,updated_at=? WHERE symbol=? AND updated_at=? RETURNING symbol').bind(price,at,symbol,previousUpdate).first();
  if(moved){await db.prepare('INSERT INTO z_stock_history(id,symbol,price,created_at) VALUES(?,?,?,?)').bind(id(),symbol,price,at).run();z74moves.push({symbol,from:Number(r.price),to:price,at});}
 }
 // V74: stock-market push (never allowed to break the price tick).
 if(z74moves.length){try{await z74StockPush(db,z74moves);}catch(e){console.warn('z74 stock push',String(e));}}
}
async function zStockPrice(db,symbol){await zStockTick(db);const r=await db.prepare('SELECT price FROM z_stock_state WHERE symbol=?').bind(symbol).first();return Number(r?.price||1200);}


