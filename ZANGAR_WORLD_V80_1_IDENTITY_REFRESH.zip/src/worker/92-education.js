// Update 35.1 / Education examination module. Only new tables; preserves legacy economy.
const Z36_EDU_PERIOD=48*3600000, Z36_EDU_DURATION=20*60000;
let z36EduReady=null,z36LastSettle=0;
async function z36EducationEnsure(db){
 if(z36EduReady)return z36EduReady;
 z36EduReady=(async()=>{
  const statements=[
   `CREATE TABLE IF NOT EXISTS z36_edu_config(id INTEGER PRIMARY KEY CHECK(id=1),anchor_at INTEGER NOT NULL)`,
   `CREATE TABLE IF NOT EXISTS z36_edu_exams(cycle INTEGER PRIMARY KEY,author_id TEXT NOT NULL,created_at INTEGER NOT NULL,closes_at INTEGER NOT NULL,questions_json TEXT NOT NULL)`,
   `CREATE TABLE IF NOT EXISTS z36_edu_attempts(cycle INTEGER NOT NULL,user_id TEXT NOT NULL,started_at INTEGER NOT NULL,submitted_at INTEGER NOT NULL DEFAULT 0,answers_json TEXT NOT NULL DEFAULT '[]',score INTEGER NOT NULL DEFAULT 0,correct_count INTEGER NOT NULL DEFAULT 0,wrong_count INTEGER NOT NULL DEFAULT 0,PRIMARY KEY(cycle,user_id))`,
   `CREATE TABLE IF NOT EXISTS z36_edu_appeals(id TEXT PRIMARY KEY,cycle INTEGER NOT NULL,user_id TEXT NOT NULL,question_no INTEGER NOT NULL,reason TEXT NOT NULL,status TEXT NOT NULL DEFAULT 'pending',reply TEXT NOT NULL DEFAULT '',reviewer_id TEXT NOT NULL DEFAULT '',fine_amount INTEGER NOT NULL DEFAULT 0,created_at INTEGER NOT NULL,reviewed_at INTEGER NOT NULL DEFAULT 0,UNIQUE(cycle,user_id,question_no))`,
   `CREATE TABLE IF NOT EXISTS z36_edu_rewards(id TEXT PRIMARY KEY,cycle INTEGER NOT NULL,user_id TEXT NOT NULL,kind TEXT NOT NULL,amount INTEGER NOT NULL,created_at INTEGER NOT NULL,UNIQUE(cycle,user_id,kind))`,
   `CREATE TABLE IF NOT EXISTS z36_edu_fines(id TEXT PRIMARY KEY,cycle INTEGER NOT NULL,user_id TEXT NOT NULL,kind TEXT NOT NULL,amount INTEGER NOT NULL,created_at INTEGER NOT NULL,UNIQUE(cycle,user_id,kind))`,
   `CREATE TABLE IF NOT EXISTS z36_edu_settled(cycle INTEGER PRIMARY KEY,settled_at INTEGER NOT NULL)`,
   `CREATE INDEX IF NOT EXISTS idx_z36_edu_appeals_status ON z36_edu_appeals(status,created_at DESC)`,
   `CREATE TRIGGER IF NOT EXISTS z36_edu_reward_apply AFTER INSERT ON z36_edu_rewards BEGIN
      UPDATE users SET points=points+NEW.amount WHERE id=NEW.user_id;
      INSERT INTO transactions(id,user_id,amount,note,created_at) VALUES(NEW.id,NEW.user_id,NEW.amount,CASE WHEN NEW.kind='minister' THEN 'مكافأة إعداد امتحان وزارة التعليم' ELSE 'نتيجة امتحان وزارة التعليم' END,NEW.created_at);
    END`,
   `CREATE TRIGGER IF NOT EXISTS z36_edu_minister_publish AFTER INSERT ON z36_edu_exams BEGIN
      INSERT OR IGNORE INTO z36_edu_rewards(id,cycle,user_id,kind,amount,created_at) VALUES(lower(hex(randomblob(16))),NEW.cycle,NEW.author_id,'minister',5000,NEW.created_at);
    END`,
   `CREATE TRIGGER IF NOT EXISTS z36_edu_exam_award AFTER UPDATE OF submitted_at ON z36_edu_attempts WHEN OLD.submitted_at=0 AND NEW.submitted_at>0 AND NEW.score>0 BEGIN
      INSERT OR IGNORE INTO z36_edu_rewards(id,cycle,user_id,kind,amount,created_at) VALUES(lower(hex(randomblob(16))),NEW.cycle,NEW.user_id,'exam',NEW.score,NEW.submitted_at);
    END`,
   `CREATE TRIGGER IF NOT EXISTS z36_edu_exam_deduction AFTER UPDATE OF submitted_at ON z36_edu_attempts WHEN OLD.submitted_at=0 AND NEW.submitted_at>0 AND NEW.score<0 BEGIN
      INSERT OR IGNORE INTO z36_edu_fines(id,cycle,user_id,kind,amount,created_at) VALUES(lower(hex(randomblob(16))),NEW.cycle,NEW.user_id,'نتيجة امتحان التعليم',-NEW.score,NEW.submitted_at);
    END`,
   `CREATE TRIGGER IF NOT EXISTS z36_edu_fine_apply AFTER INSERT ON z36_edu_fines BEGIN
      INSERT INTO transactions(id,user_id,amount,note,created_at)
        SELECT NEW.id,NEW.user_id,-MIN(NEW.amount,points),'غرامة التعليم: '||NEW.kind,NEW.created_at FROM users WHERE id=NEW.user_id AND points>0;
      UPDATE z_state_treasury SET balance=balance+COALESCE((SELECT MIN(NEW.amount,points) FROM users WHERE id=NEW.user_id),0) WHERE id=1;
      INSERT INTO z_state_ledger(id,delta,reason,actor,created_at)
        SELECT lower(hex(randomblob(16))),MIN(NEW.amount,points),'غرامة وزارة التعليم: '||NEW.kind,name,NEW.created_at FROM users WHERE id=NEW.user_id AND points>0;
      UPDATE users SET points=MAX(0,points-NEW.amount) WHERE id=NEW.user_id;
    END`,
   `CREATE TRIGGER IF NOT EXISTS z36_edu_appeal_apply AFTER UPDATE OF status ON z36_edu_appeals WHEN OLD.status='pending' AND NEW.status='accepted' BEGIN
      UPDATE z36_edu_attempts SET score=score+600,correct_count=correct_count+1,wrong_count=MAX(0,wrong_count-1) WHERE cycle=NEW.cycle AND user_id=NEW.user_id;
      UPDATE users SET points=points+600 WHERE id=NEW.user_id;
      INSERT INTO transactions(id,user_id,amount,note,created_at) VALUES(NEW.id,NEW.user_id,600,'تصحيح نتيجة سؤال في امتحان التعليم بعد قبول التظلم',NEW.reviewed_at);
      INSERT OR IGNORE INTO z36_edu_fines(id,cycle,user_id,kind,amount,created_at)
        SELECT lower(hex(randomblob(16))),NEW.cycle,e.author_id,'خطأ في نموذج إجابة السؤال '||NEW.question_no,NEW.fine_amount,NEW.reviewed_at
        FROM z36_edu_exams e WHERE e.cycle=NEW.cycle AND NEW.fine_amount>0;
    END`
  ];
  for(const query of statements)await db.prepare(query).run();
  await db.prepare('INSERT OR IGNORE INTO z36_edu_config(id,anchor_at) VALUES(1,?)').bind(Date.now()).run();
 })().catch(e=>{z36EduReady=null;throw e});
 return z36EduReady;
}
async function z36EducationCycle(db,now=Date.now()){
 await z36EducationEnsure(db);
 const cfg=await db.prepare('SELECT anchor_at FROM z36_edu_config WHERE id=1').first();
 const anchor=Number(cfg.anchor_at),cycle=Math.max(0,Math.floor((now-anchor)/Z36_EDU_PERIOD));
 return {cycle,anchor,closes_at:anchor+(cycle+1)*Z36_EDU_PERIOD,opens_at:anchor+cycle*Z36_EDU_PERIOD};
}
function z36EduMinister(u){return !!(u&&(isAdmin(u)||String(u.job||'').includes('وزير التعليم')))}
function z36Normalize(s){return String(s??'').normalize('NFKC').trim().toLocaleLowerCase().replace(/[\u064b-\u065f\u0670]/g,'').replace(/\s+/g,' ')}
function z36EduGrade(questions,answers){
 let score=0,correct=0,wrong=0,details=[];
 for(let i=0;i<questions.length;i++){
  const q=questions[i],a=answers[i];
  const ok=q.type==='choice'?Number.isInteger(a)&&a===q.answer:(z36Normalize(a)!==''&&z36Normalize(a)===z36Normalize(q.answer));
  score+=ok?(questions.length===5?1000:500):-100; correct+=ok?1:0;wrong+=ok?0:1;
  details.push({question_no:i+1,correct:ok,answer:q.type==='choice'?q.options[q.answer]:q.answer});
 }
 return {score,correct,wrong,details};
}
// Called only from the existing scheduled endpoint or education pages; idempotent, no global re-count on every homepage read.
async function z36EducationSettle(db,now=Date.now()){
 if(now-z36LastSettle<3600000)return;
 await z36EducationEnsure(db);
 const {cycle}=await z36EducationCycle(db,now);
 if(!cycle){z36LastSettle=now;return;}
 const last=await db.prepare('SELECT MAX(cycle) AS cycle FROM z36_edu_settled').first();
 for(let c=Math.max(Number(last?.cycle??-1)+1,cycle-8,0);c<cycle;c++){

  const exam=await db.prepare('SELECT created_at,closes_at,author_id FROM z36_edu_exams WHERE cycle=?').bind(c).first();
  if(exam){
   await db.prepare(`INSERT OR IGNORE INTO z36_edu_fines(id,cycle,user_id,kind,amount,created_at)
      SELECT lower(hex(randomblob(16))),?,u.id,'غياب عن امتحان التعليم',1000,?
      FROM users u LEFT JOIN z36_edu_attempts a ON a.cycle=? AND a.user_id=u.id AND a.submitted_at>0
      WHERE u.joined<=? AND a.user_id IS NULL`).bind(c,now,c,exam.created_at).run();
  }else{
   // No exam in the full 48h period: fine the currently appointed education minister once, not the citizens.
   await db.prepare(`INSERT OR IGNORE INTO z36_edu_fines(id,cycle,user_id,kind,amount,created_at)
      SELECT lower(hex(randomblob(16))),?,u.id,'عدم وضع امتحان التعليم',3000,?
      FROM users u WHERE u.job LIKE '%وزير التعليم%'`).bind(c,now).run();
  }
  await db.prepare('INSERT OR IGNORE INTO z36_edu_settled(cycle,settled_at) VALUES(?,?)').bind(c,now).run();
 }
 z36LastSettle=now;
}
async function z36EducationState(req,db){
 const u=await getMe(req,db);if(!u)return err(401,'سجّل دخولك أولًا');
 const now=Date.now();await z36EducationSettle(db,now);
 const period=await z36EducationCycle(db,now);
 const exam=await db.prepare('SELECT cycle,author_id,created_at,closes_at,questions_json FROM z36_edu_exams WHERE cycle=?').bind(period.cycle).first();
 const attempt=await db.prepare('SELECT cycle,started_at,submitted_at,score,correct_count,wrong_count,answers_json FROM z36_edu_attempts WHERE cycle=? AND user_id=?').bind(period.cycle,u.id).first();
 const questions=exam?JSON.parse(exam.questions_json):[];
 const visible=questions.map(q=>({text:q.text,type:q.type,options:q.type==='choice'?q.options:[]}));
 const completed=!!attempt?.submitted_at,results=completed?z36EduGrade(questions,JSON.parse(attempt.answers_json||'[]')).details:[];
 if(completed){const corrections=await db.prepare("SELECT question_no FROM z36_edu_appeals WHERE cycle=? AND user_id=? AND status='accepted'").bind(period.cycle,u.id).all();for(const c of corrections.results){if(results[c.question_no-1])results[c.question_no-1].correct=true;}}
 const canReview=isAdmin(u),canPublish=z36EduMinister(u);
 const appeals=await (canReview?
   db.prepare("SELECT a.id,a.cycle,a.question_no,a.reason,a.status,a.created_at,u.name AS citizen_name FROM z36_edu_appeals a JOIN users u ON u.id=a.user_id ORDER BY a.created_at DESC LIMIT 70").all():
   db.prepare('SELECT id,cycle,question_no,reason,status,created_at,reply FROM z36_edu_appeals WHERE user_id=? ORDER BY created_at DESC LIMIT 30').bind(u.id).all());
 return json({ok:true,now,period,canPublish,canReview,exam:exam?{cycle:exam.cycle,created_at:exam.created_at,closes_at:exam.closes_at,questions:visible}:null,attempt:attempt?{started_at:attempt.started_at,submitted_at:attempt.submitted_at,score:attempt.score,correct:attempt.correct_count,wrong:attempt.wrong_count,answers:JSON.parse(attempt.answers_json||'[]'),deadline:Math.min(attempt.started_at+Z36_EDU_DURATION,exam?.closes_at||now),results}:null,appeals:appeals.results});
}
async function z36EducationAppealDetail(db,appealId){
 const a=await db.prepare('SELECT * FROM z36_edu_appeals WHERE id=?').bind(appealId).first();
 if(!a)return err(404,'الشكوى غير موجودة');
 const exam=await db.prepare('SELECT questions_json FROM z36_edu_exams WHERE cycle=?').bind(a.cycle).first();
 const attempt=await db.prepare('SELECT answers_json FROM z36_edu_attempts WHERE cycle=? AND user_id=?').bind(a.cycle,a.user_id).first();
 if(!exam||!attempt)return err(404,'بيانات السؤال غير موجودة');
 const q=JSON.parse(exam.questions_json)[a.question_no-1],answer=JSON.parse(attempt.answers_json)[a.question_no-1];
 return json({ok:true,appeal:a,question:q.text,answer:q.type==='choice'?q.options[answer]||'لم يجب':answer,model_answer:q.type==='choice'?q.options[q.answer]:q.answer});
}
async function z36EducationReview(db,u,p){
 const appealId=crop(p.appeal_id,80),approve=p.approve===true,reply=crop(p.reply,500),fine=Number(p.fine_amount||0);
 if(reply.length<8||!Number.isInteger(fine)||fine<0||fine>3000||approve&&fine<1)return err(400,'اذكر سبب القرار، وحدد غرامة الوزير عند قبول الشكوى (1–3,000 زنجر)');
 const a=await db.prepare("SELECT cycle,user_id,question_no FROM z36_edu_appeals WHERE id=? AND status='pending'").bind(appealId).first();
 if(!a)return err(404,'الشكوى غير موجودة أو تمت مراجعتها');
 const updated=await db.prepare("UPDATE z36_edu_appeals SET status=?,reply=?,reviewer_id=?,fine_amount=?,reviewed_at=? WHERE id=? AND status='pending' RETURNING id").bind(approve?'accepted':'rejected',reply,u.id,approve?fine:0,Date.now(),appealId).first();
 if(!updated)return err(409,'تمت المراجعة بالفعل');
 await zNotify(db,a.user_id,'نتيجة شكوى امتحان التعليم',(approve?'تم قبول اعتراضك وتصحيح درجتك. ':'تم رفض الاعتراض. ')+reply,'government');
 return json({ok:true,notice:approve?'تم تصحيح الدرجة وإجراء الغرامة المسجلة':'تم رفض الشكوى مع تسجيل الرد'});
}
async function z36EducationAction(req,db,p){
 const u=await getMe(req,db);if(!u)return err(401,'سجّل دخولك أولًا');
 if(await prisonActive(db,u.id))return err(403,'لا يمكن إجراء الامتحان أثناء السجن');
 const now=Date.now();await z36EducationSettle(db,now);const period=await z36EducationCycle(db,now);
 const type=crop(p.type,24);
 if(type==='publish'){
  if(!z36EduMinister(u))return err(403,'إعداد الامتحانات لوزير التعليم أو الرئاسة فقط');
  const source=Array.isArray(p.questions)?p.questions:[];
  if(source.length!==5)return err(400,'يجب إنشاء 5 أسئلة بالضبط');
  const questions=[];
  for(const raw of source){
   const q={text:crop(raw.text,340),type:raw.type};
   if(q.text.length<5||!['choice','essay'].includes(q.type))return err(400,'السؤال غير صالح');
   if(q.type==='choice'){
    q.options=Array.isArray(raw.options)?raw.options.map(x=>crop(x,180)):[];
    q.answer=Number(raw.answer);
    if(q.options.length!==4||q.options.some(x=>!x)||!Number.isInteger(q.answer)||q.answer<0||q.answer>3)return err(400,'كل سؤال اختياري يحتاج 4 اختيارات وإجابة صحيحة');
   }else{q.answer=crop(raw.answer,180);if(!q.answer)return err(400,'أدخل الإجابة النموذجية للسؤال المقالي');}
   questions.push(q);
  }
  if(period.closes_at-now<Z36_EDU_DURATION)return err(409,'موعد الدورة قرب ينتهي؛ انتظر بداية دورة اليومين التالية');
  const added=await db.prepare('INSERT OR IGNORE INTO z36_edu_exams(cycle,author_id,created_at,closes_at,questions_json) VALUES(?,?,?,?,?) RETURNING cycle').bind(period.cycle,u.id,now,period.closes_at,JSON.stringify(questions)).first();
  if(!added)return err(409,'تم نشر امتحان هذه الدورة بالفعل');
  await z33NotifyAll(db,'📚 امتحان جديد في الدولة','تم نشر امتحان وزارة التعليم؛ 5 أسئلة، و20 دقيقة لكل مواطن.','government','/education-exams.html','edu-'+period.cycle);
  return json({ok:true,notice:'تم نشر الامتحان ومكافأة الإعداد 5,000 زنجر'});
 }
 if(type==='appealDetail'){
  if(!isAdmin(u))return err(403,'الإطلاع على الإجابات الإدارية للرئاسة فقط');
  return z36EducationAppealDetail(db,crop(p.appeal_id,80));
 }
 const exam=await db.prepare('SELECT * FROM z36_edu_exams WHERE cycle=?').bind(period.cycle).first();
 if(type==='review'){
  if(!isAdmin(u))return err(403,'مراجعة شكاوى التعليم من صلاحية الرئاسة أو اللوحة الخاصة');
  return z36EducationReview(db,u,p);
 }
 if(!exam)return err(404,'لم يُنشر امتحان هذه الدورة بعد');
 if(type==='start'){
  if(now>=exam.closes_at)return err(409,'انتهت دورة الامتحان');
  await db.prepare('INSERT OR IGNORE INTO z36_edu_attempts(cycle,user_id,started_at) VALUES(?,?,?)').bind(period.cycle,u.id,now).run();
  return json({ok:true,notice:'بدأ وقت الامتحان، أمامك 20 دقيقة'});
 }
 const a=await db.prepare('SELECT * FROM z36_edu_attempts WHERE cycle=? AND user_id=?').bind(period.cycle,u.id).first();
 if(type==='submit'){
  if(!a)return err(409,'اضغط بدء الامتحان أولًا');
  if(a.submitted_at)return err(409,'تم تسليم الامتحان بالفعل');
  if(now>Math.min(Number(a.started_at)+Z36_EDU_DURATION,exam.closes_at)+10000)return err(409,'انتهى وقت الامتحان. لم يتم التسليم في الموعد');
  const qs=JSON.parse(exam.questions_json);
  const answers=Array.isArray(p.answers)?p.answers.slice(0,qs.length):[];
  if(answers.length!==qs.length)return err(400,'يجب إرسال إجابة لكل سؤال (يمكن ترك السؤال فارغًا)');
  const clean=qs.map((q,i)=>q.type==='choice'?(answers[i]===''?null:Number(answers[i])):crop(answers[i],350));
  if(clean.some((x,i)=>qs[i].type==='choice'&&x!==null&&(!Number.isInteger(x)||x<0||x>3)))return err(400,'اختيار غير صالح');
  const score=z36EduGrade(qs,clean);
  const saved=await db.prepare('UPDATE z36_edu_attempts SET submitted_at=?,answers_json=?,score=?,correct_count=?,wrong_count=? WHERE cycle=? AND user_id=? AND submitted_at=0 RETURNING cycle').bind(now,JSON.stringify(clean),score.score,score.correct,score.wrong,period.cycle,u.id).first();
  if(!saved)return err(409,'تم تسليم الامتحان سابقًا');
  return json({ok:true,notice:'تم تسليم الامتحان واحتساب '+score.score+' زنجر',result:score});
 }
 if(type==='appeal'){
  if(!a?.submitted_at)return err(409,'أكمل الامتحان أولًا');
  const n=Number(p.question_no),reason=crop(p.reason,500);
  if(!Number.isInteger(n)||n<1||n>JSON.parse(exam.questions_json).length||reason.length<12)return err(400,'اختر السؤال واكتب شكوى واضحة');
  const grade=z36EduGrade(JSON.parse(exam.questions_json),JSON.parse(a.answers_json));
  if(grade.details[n-1].correct)return err(409,'السؤال مصحح على أنه صحيح بالفعل');
  const inserted=await db.prepare('INSERT OR IGNORE INTO z36_edu_appeals(id,cycle,user_id,question_no,reason,created_at) VALUES(?,?,?,?,?,?) RETURNING id').bind(id(),period.cycle,u.id,n,reason,now).first();
  if(!inserted)return err(409,'قدمت اعتراضًا على السؤال سابقًا');
  const admins=await db.prepare('SELECT user_id FROM admin_grants LIMIT 30').all();
  for(const x of admins.results)await zNotify(db,x.user_id,'📚 شكوى على تصحيح الامتحان','وصل اعتراض على السؤال '+n+' يحتاج مراجعة رئاسية','government');
  return json({ok:true,notice:'تم تقديم الشكوى للرئاسة وسيتم مراجعتها'});
 }
 return err(400,'إجراء تعليم غير معروف');
}

