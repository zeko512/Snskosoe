// V64 — Economy expansion and reversible presidential account administration.
// Existing companies, households, trade, public projects and Guest credentials are untouched.
const Z64_TYPES={construction:['شركة مقاولات',4000],factory:['مصنع',6500],shop:['متجر',3000],farm:['مزرعة',2500],restaurant:['مطعم',3500],transport:['شركة نقل',4500],services:['شركة خدمات',2800]};
const Z64_VEHICLES={city:['سيارة مدينة',7200],family:['سيارة عائلية',12800],luxury:['سيارة فاخرة',29000],truck:['شاحنة نقل',21000]};
const Z64_PRODUCTION={farm:['قمح',5],factory:['منتج مصنع',4],shop:['بضاعة',3],restaurant:['وجبة زنجر',3],construction:['مواد بناء',3],transport:['مواد بناء',2],services:['بضاعة',2]};
const Z64_FURNITURE={chair:['كرسي',250],table:['طاولة',500],bed:['سرير',950],sofa:['كنبة',1500],kitchen:['مطبخ',4900]};
let z64Ready=null;
async function z64Ensure(db){
 if(z64Ready)return z64Ready;
 z64Ready=(async()=>{
  await db.batch([
   db.prepare("CREATE TABLE IF NOT EXISTS z64_archived_users(user_id TEXT PRIMARY KEY,guest_slot INTEGER,original_name TEXT NOT NULL,original_name_key TEXT NOT NULL,deleted_by TEXT NOT NULL,deleted_at INTEGER NOT NULL,restored_at INTEGER NOT NULL DEFAULT 0,reason TEXT NOT NULL DEFAULT '')"),
   db.prepare("CREATE INDEX IF NOT EXISTS z64_archive_active ON z64_archived_users(restored_at,deleted_at)"),
   db.prepare("CREATE TABLE IF NOT EXISTS z64_businesses(id TEXT PRIMARY KEY,company_id TEXT NOT NULL,owner_id TEXT NOT NULL,kind TEXT NOT NULL,name TEXT NOT NULL,level INTEGER NOT NULL DEFAULT 1,last_produced_at INTEGER NOT NULL DEFAULT 0,created_at INTEGER NOT NULL)"),
   db.prepare("CREATE INDEX IF NOT EXISTS z64_business_owner ON z64_businesses(owner_id,created_at)"),
   db.prepare("CREATE TABLE IF NOT EXISTS z64_production(id TEXT PRIMARY KEY,branch_id TEXT NOT NULL,user_id TEXT NOT NULL,cycle INTEGER NOT NULL,item TEXT NOT NULL,quantity INTEGER NOT NULL CHECK(quantity BETWEEN 1 AND 30),created_at INTEGER NOT NULL,UNIQUE(branch_id,cycle))"),
   db.prepare(`CREATE TRIGGER IF NOT EXISTS z64_production_check BEFORE INSERT ON z64_production BEGIN
    SELECT CASE WHEN NOT EXISTS(SELECT 1 FROM z64_businesses b WHERE b.id=NEW.branch_id AND b.owner_id=NEW.user_id AND b.last_produced_at<=NEW.created_at-7200000) THEN RAISE(ABORT,'الإنتاج كل ساعتين فقط أو النشاط لا يخصك') END;
    SELECT CASE WHEN EXISTS(SELECT 1 FROM z64_businesses b WHERE b.id=NEW.branch_id AND b.kind IN ('factory','construction') AND NOT EXISTS (SELECT 1 FROM z_company_members m WHERE m.company_id=b.company_id AND m.status='active')) THEN RAISE(ABORT,'يحتاج المصنع أو شركة المقاولات إلى عامل نشط') END;
   END`),
   db.prepare(`CREATE TRIGGER IF NOT EXISTS z64_production_apply AFTER INSERT ON z64_production BEGIN
    UPDATE z64_businesses SET last_produced_at=NEW.created_at WHERE id=NEW.branch_id;
    INSERT INTO econ_inventory(user_id,item,quantity) VALUES(NEW.user_id,NEW.item,NEW.quantity) ON CONFLICT(user_id,item) DO UPDATE SET quantity=quantity+excluded.quantity;
    INSERT INTO z64_xp_events(id,user_id,amount,kind,created_at) VALUES(NEW.id,NEW.user_id,10,'production',NEW.created_at);
   END`),
   db.prepare("CREATE TABLE IF NOT EXISTS z64_vehicles(id TEXT PRIMARY KEY,user_id TEXT NOT NULL,model TEXT NOT NULL,created_at INTEGER NOT NULL)"),
   db.prepare("CREATE TABLE IF NOT EXISTS z64_furniture_inventory(user_id TEXT NOT NULL,item TEXT NOT NULL,qty INTEGER NOT NULL DEFAULT 0,PRIMARY KEY(user_id,item))"),
   db.prepare("CREATE TABLE IF NOT EXISTS z64_wallet_ops(id TEXT PRIMARY KEY,user_id TEXT NOT NULL,kind TEXT NOT NULL,cost INTEGER NOT NULL CHECK(cost BETWEEN 1 AND 1000000),note TEXT NOT NULL,created_at INTEGER NOT NULL)"),
   db.prepare("CREATE TRIGGER IF NOT EXISTS z64_wallet_check BEFORE INSERT ON z64_wallet_ops BEGIN SELECT CASE WHEN NOT EXISTS(SELECT 1 FROM users WHERE id=NEW.user_id AND points>=NEW.cost) THEN RAISE(ABORT,'رصيد المواطن لا يكفي') END; END"),
   db.prepare("CREATE TRIGGER IF NOT EXISTS z64_wallet_apply AFTER INSERT ON z64_wallet_ops BEGIN UPDATE users SET points=points-NEW.cost WHERE id=NEW.user_id; INSERT INTO transactions(id,user_id,amount,note,created_at) VALUES(NEW.id,NEW.user_id,-NEW.cost,NEW.note,NEW.created_at); UPDATE z_state_treasury SET balance=balance+NEW.cost WHERE id=1; INSERT INTO z_state_ledger(id,delta,reason,actor,created_at) VALUES(NEW.id,NEW.cost,NEW.note,'V64 اقتصاد المواطن',NEW.created_at); END"),
   db.prepare("CREATE TABLE IF NOT EXISTS z64_xp(user_id TEXT PRIMARY KEY,experience INTEGER NOT NULL DEFAULT 0 CHECK(experience>=0))"),
   db.prepare("CREATE TABLE IF NOT EXISTS z64_xp_events(id TEXT PRIMARY KEY,user_id TEXT NOT NULL,amount INTEGER NOT NULL CHECK(amount BETWEEN 1 AND 1000),kind TEXT NOT NULL,created_at INTEGER NOT NULL)"),
   db.prepare("CREATE TRIGGER IF NOT EXISTS z64_xp_apply AFTER INSERT ON z64_xp_events BEGIN INSERT INTO z64_xp(user_id,experience) VALUES(NEW.user_id,NEW.amount) ON CONFLICT(user_id) DO UPDATE SET experience=experience+excluded.experience; END"),
   db.prepare("CREATE TABLE IF NOT EXISTS z64_projects(id TEXT PRIMARY KEY,title TEXT NOT NULL,kind TEXT NOT NULL,budget INTEGER NOT NULL CHECK(budget BETWEEN 100 AND 500000),status TEXT NOT NULL DEFAULT 'open' CHECK(status IN ('open','awarded','completed','paid','cancelled')),owner_id TEXT NOT NULL,winning_company_id TEXT NOT NULL DEFAULT '',winning_bid_id TEXT NOT NULL DEFAULT '',created_at INTEGER NOT NULL,completed_at INTEGER NOT NULL DEFAULT 0)"),
   db.prepare("CREATE TABLE IF NOT EXISTS z64_project_bids(id TEXT PRIMARY KEY,project_id TEXT NOT NULL,company_id TEXT NOT NULL,owner_id TEXT NOT NULL,price INTEGER NOT NULL CHECK(price BETWEEN 100 AND 500000),created_at INTEGER NOT NULL,UNIQUE(project_id,company_id))"),
   db.prepare("CREATE TABLE IF NOT EXISTS z64_project_payments(id TEXT PRIMARY KEY,project_id TEXT NOT NULL UNIQUE,company_id TEXT NOT NULL,amount INTEGER NOT NULL CHECK(amount BETWEEN 1 AND 500000),actor_id TEXT NOT NULL,created_at INTEGER NOT NULL)"),
   db.prepare("CREATE TRIGGER IF NOT EXISTS z64_project_payment_check BEFORE INSERT ON z64_project_payments BEGIN SELECT CASE WHEN NOT EXISTS (SELECT 1 FROM z64_projects p JOIN z64_project_bids b ON b.id=p.winning_bid_id WHERE p.id=NEW.project_id AND p.status='completed' AND p.winning_company_id=NEW.company_id AND b.price=NEW.amount) THEN RAISE(ABORT,'المشروع غير مؤهل للصرف') END; SELECT CASE WHEN NOT EXISTS (SELECT 1 FROM z_state_treasury WHERE id=1 AND balance>=NEW.amount) THEN RAISE(ABORT,'الخزينة لا تكفي') END; END"),
   db.prepare("CREATE TRIGGER IF NOT EXISTS z64_project_payment_apply AFTER INSERT ON z64_project_payments BEGIN UPDATE z_state_treasury SET balance=balance-NEW.amount WHERE id=1; UPDATE z_companies SET balance=balance+NEW.amount WHERE id=NEW.company_id; UPDATE z64_projects SET status='paid' WHERE id=NEW.project_id; INSERT INTO z_state_ledger(id,delta,reason,actor,created_at) VALUES(NEW.id,-NEW.amount,'صرف مستخلص مشروع اقتصادي','الرئاسة',NEW.created_at); END"),
  ]);
 })().catch(e=>{z64Ready=null;throw e});return z64Ready;
}
function z64AllowPresident(u){return !!u&&isAdmin(u)}
function z64Int(v,min,max){const n=Number(v);return Number.isSafeInteger(n)&&n>=min&&n<=max?n:null}
async function z64State(req,db){
 const u=await getMe(req,db);if(!u)return err(401,'ادخل بحساب Guest أولًا');await z64Ensure(db);
 const [companies,branches,vehicles,furniture,projects,bids,exps,people,member,txs]=await Promise.all([
  db.prepare("SELECT c.*,u.name owner_name,(SELECT COUNT(*) FROM z_company_members m WHERE m.company_id=c.id AND m.status='active') AS employees FROM z_companies c JOIN users u ON u.id=c.owner_id WHERE NOT EXISTS (SELECT 1 FROM z64_archived_users d WHERE d.user_id=u.id AND d.restored_at=0) ORDER BY c.created_at DESC LIMIT 100").all(),
  db.prepare('SELECT * FROM z64_businesses ORDER BY created_at DESC LIMIT 150').all(),
  db.prepare('SELECT * FROM z64_vehicles WHERE user_id=? ORDER BY created_at DESC LIMIT 30').bind(u.id).all(),
  db.prepare('SELECT item,qty FROM z64_furniture_inventory WHERE user_id=?').bind(u.id).all(),
  db.prepare('SELECT * FROM z64_projects ORDER BY created_at DESC LIMIT 120').all(),
  db.prepare('SELECT * FROM z64_project_bids ORDER BY created_at DESC LIMIT 160').all(),
  db.prepare('SELECT experience FROM z64_xp WHERE user_id=?').bind(u.id).first(),
  z64AllowPresident(u)?db.prepare("SELECT u.id,u.name,u.points,gs.slot guest_slot, CASE WHEN a.user_id IS NOT NULL AND a.restored_at=0 THEN 1 ELSE 0 END archived FROM users u LEFT JOIN z639_guest_slots gs ON gs.user_id=u.id LEFT JOIN z64_archived_users a ON a.user_id=u.id ORDER BY u.joined DESC LIMIT 350").all():Promise.resolve({results:[]}),
  db.prepare('SELECT m.*,c.name company_name FROM z_company_members m JOIN z_companies c ON c.id=m.company_id WHERE m.user_id=? ORDER BY m.created_at DESC LIMIT 2').bind(u.id).all(),
  db.prepare('SELECT id,amount,note,created_at FROM transactions WHERE user_id=? ORDER BY created_at DESC LIMIT 35').bind(u.id).all()
 ]);
 const ownCompany=companies.results.find(c=>c.owner_id===u.id)||null;
 const admins=z64AllowPresident(u)?(await db.prepare('SELECT * FROM z64_archived_users WHERE restored_at=0 ORDER BY deleted_at DESC LIMIT 80').all()).results:[];
 const exp=Number(exps?.experience||0);
 const staff=ownCompany?(await db.prepare("SELECT m.company_id,m.user_id,m.status,u.name FROM z_company_members m JOIN users u ON u.id=m.user_id WHERE m.company_id=? AND NOT EXISTS(SELECT 1 FROM z64_archived_users a WHERE a.user_id=u.id AND a.restored_at=0) ORDER BY m.created_at DESC LIMIT 90").bind(ownCompany.id).all()).results:[];
 return json({ok:true,version:'64',me:{id:u.id,name:u.name,points:u.points,level:Math.floor(exp/100)+1,experience:exp,guest_slot:u.guest_slot||null},is_president:z64AllowPresident(u),companies:companies.results,my_company:ownCompany,branches:branches.results,inventory:(await db.prepare('SELECT item,quantity FROM econ_inventory WHERE user_id=? AND quantity>0 ORDER BY item').bind(u.id).all()).results,vehicles:vehicles.results,furniture:furniture.results,projects:projects.results,bids:bids.results,people:people.results,archive:admins,employment:member.results,staff,transactions:txs.results,catalogs:{types:Z64_TYPES,vehicles:Z64_VEHICLES,furniture:Z64_FURNITURE}});
}
async function z64Action(req,db,p){
 const u=await getMe(req,db);if(!u)return err(401,'ادخل بحساب Guest أولًا');await z64Ensure(db);
 const type=crop(p.type,35),now=Date.now(),pres=z64AllowPresident(u);
 const opId=String(p.request_id||'');const buyTypes=new Set(['company_create','business_branch','vehicle_buy','furniture_buy','skill_training']);
 if(buyTypes.has(type)){if(!/^[0-9a-f-]{36}$/i.test(opId))return err(400,'معرف العملية المالية غير صالح');const prior=await db.prepare('SELECT user_id,kind FROM z64_wallet_ops WHERE id=?').bind(opId).first();if(prior){if(prior.user_id===u.id&&prior.kind===({company_create:'company_create',business_branch:'business_branch',vehicle_buy:'car',furniture_buy:'furniture',skill_training:'training'}[type]))return json({ok:true,message:'العملية مسجلة بالفعل، ولم يحدث خصم جديد',replayed:true});return err(409,'معرف العملية مستخدم سابقًا');}}
 const deny=()=>err(403,'هذه العملية متاحة لمن أكمل كود الرئاسة والرمز السري فقط');
 const notice=(message)=>json({ok:true,message});
 if(type==='account_archive'){
  if(!pres)return deny();
  const target=crop(p.user_id,90),reason=crop(p.reason,180);
  if(target===u.id)return err(403,'لا يمكن حذف حساب الرئاسة الذي تنفذ منه العملية');
  if(reason.length<5||p.confirm!=='ARCHIVE')return err(400,'اكتب سببًا واضحًا وكلمة التأكيد ARCHIVE');
  const record=await db.prepare('SELECT id,name,name_key FROM users WHERE id=?').bind(target).first();if(!record)return err(404,'الحساب غير موجود');
  const gone=await db.prepare('SELECT user_id FROM z64_archived_users WHERE user_id=? AND restored_at=0').bind(target).first();if(gone)return err(409,'هذا الحساب مؤرشف بالفعل');
  const slot=await db.prepare('SELECT slot FROM z639_guest_slots WHERE user_id=?').bind(target).first();
  await db.batch([
   db.prepare('INSERT INTO z64_archived_users(user_id,guest_slot,original_name,original_name_key,deleted_by,deleted_at,reason) VALUES(?,?,?,?,?,?,?) ON CONFLICT(user_id) DO UPDATE SET guest_slot=excluded.guest_slot,original_name=excluded.original_name,original_name_key=excluded.original_name_key,deleted_by=excluded.deleted_by,deleted_at=excluded.deleted_at,reason=excluded.reason,restored_at=0').bind(record.id,slot?.slot||null,record.name,record.name_key,u.id,now,reason),
   db.prepare('UPDATE users SET name=?,name_key=?,candidate=0 WHERE id=?').bind('مؤرشف '+record.id.slice(0,8),'archive-'+record.id,record.id),
   db.prepare('DELETE FROM sessions WHERE user_id=?').bind(record.id),
   db.prepare('DELETE FROM z49_gate_access WHERE user_id=?').bind(record.id),
   db.prepare('DELETE FROM z49_gate_pending WHERE user_id=?').bind(record.id),
   db.prepare('UPDATE z639_guest_slots SET user_id=NULL,claimed_at=0 WHERE user_id=?').bind(record.id)
  ]);
  z32PublicCache.delete('bootstrap-users');z32PublicCache.delete('world-homes');z32PublicCache.delete('world-furniture');z32PublicCache.delete('world-companies');
  await z72CleanOneArchived(db,record.id);
  return notice('تم إخفاء الحساب وبيته ومحتوياته وتحرير Guest؛ محفوظ سجل الأرشفة والمراجعة');
 }
 if(type==='account_restore'){
  if(!pres)return deny();const target=crop(p.user_id,90);
  const a=await db.prepare('SELECT * FROM z64_archived_users WHERE user_id=? AND restored_at=0').bind(target).first();if(!a)return err(404,'الحساب غير مؤرشف');
  const duplicate=await db.prepare('SELECT id FROM users WHERE name_key=? AND id<>?').bind(a.original_name_key,target).first();if(duplicate)return err(409,'اسم اللاعب مستخدم حاليًا؛ تعذر الاسترجاع دون تغيير الاسم');
  if(a.guest_slot){const taken=await db.prepare('SELECT user_id FROM z639_guest_slots WHERE slot=?').bind(a.guest_slot).first();if(taken?.user_id)return err(409,'رقم Guest تم حجزه من لاعب جديد؛ لا يمكن استرجاع الحساب حتى يتوفر الرقم');}
  const st=[db.prepare('UPDATE users SET name=?,name_key=? WHERE id=?').bind(a.original_name,a.original_name_key,target),db.prepare('UPDATE z64_archived_users SET restored_at=? WHERE user_id=? AND restored_at=0').bind(now,target)];
  if(a.guest_slot)st.push(db.prepare('UPDATE z639_guest_slots SET user_id=?,claimed_at=? WHERE slot=? AND user_id IS NULL').bind(target,now,a.guest_slot));
  await db.batch(st);z32PublicCache.delete('bootstrap-users');return notice('تم استرجاع الحساب، ويمكن تسجيل الدخول بكلمة مرور Guest الحالية');
 }
 if(type==='company_create'){
  const name=crop(p.name,45);if(name.length<3)return err(400,'اسم الشركة قصير');
  const exists=await db.prepare('SELECT id FROM z_companies WHERE owner_id=?').bind(u.id).first();if(exists)return err(409,'عندك شركة بالفعل؛ أضف لها مصنعًا أو متجرًا');
  try{await db.batch([
   db.prepare('INSERT INTO z64_wallet_ops(id,user_id,kind,cost,note,created_at) VALUES(?,?,?,?,?,?)').bind(opId,u.id,'company_create',18000,'تأسيس شركة '+name,now),
   db.prepare('INSERT INTO z_companies(id,owner_id,name,balance,wage,next_pay_at,created_at) VALUES(?,?,?,?,?,?,?)').bind(opId,u.id,name,0,250,now+21600000,now),
   db.prepare('INSERT INTO z64_xp_events(id,user_id,amount,kind,created_at) VALUES(?,?,?,?,?)').bind(opId,u.id,50,'company',now)
  ]);}catch{return err(409,'رصيدك لا يكفي أو تأسست شركتك بالفعل')}
  return notice('تم تأسيس شركتك واكتساب 50 خبرة');
 }
 if(type==='business_branch'){
  const kind=crop(p.kind,30),label=Z64_TYPES[kind],name=crop(p.name,45);if(!label||name.length<3)return err(400,'اختار نوع النشاط واسمًا من 3 أحرف على الأقل');
  const c=await db.prepare('SELECT id FROM z_companies WHERE owner_id=?').bind(u.id).first();if(!c)return err(400,'أسس شركتك أولًا من قسم الشركات، ثم أضف المصنع أو المتجر أو المزرعة');
  const n=await db.prepare('SELECT COUNT(*) n FROM z64_businesses WHERE owner_id=?').bind(u.id).first();if(n.n>=8)return err(409,'الحد الأقصى 8 أنشطة للشركة');
  const op=opId;await db.batch([db.prepare('INSERT INTO z64_wallet_ops(id,user_id,kind,cost,note,created_at) VALUES(?,?,?,?,?,?)').bind(op,u.id,'business_branch',label[1],'تأسيس '+label[0]+': '+name,now),db.prepare('INSERT INTO z64_businesses(id,company_id,owner_id,kind,name,created_at) VALUES(?,?,?,?,?,?)').bind(op,c.id,u.id,kind,name,now),db.prepare('INSERT INTO z64_xp_events(id,user_id,amount,kind,created_at) VALUES(?,?,?,?,?)').bind(op,u.id,35,'business',now)]);
  return notice('تم افتتاح النشاط التجاري واكتساب 35 خبرة');
 }
 if(type==='business_produce'){
  const branchId=crop(p.branch_id,90),branch=await db.prepare('SELECT * FROM z64_businesses WHERE id=? AND owner_id=?').bind(branchId,u.id).first();if(!branch)return err(404,'النشاط ليس ملكك');
  const prod=Z64_PRODUCTION[branch.kind];if(!prod)return err(400,'هذا النشاط ليس إنتاجيًا');
  const cycle=Math.floor(now/7200000);
  try{await db.prepare('INSERT INTO z64_production(id,branch_id,user_id,cycle,item,quantity,created_at) VALUES(?,?,?,?,?,?,?)').bind(id(),branchId,u.id,cycle,prod[0],prod[1],now).run();}
  catch{return err(409,'الإنتاج غير جاهز بعد؛ انتظر ساعتين أو وظف عاملًا للمصنع')}
  return notice('تم إنتاج '+prod[1]+' × '+prod[0]+' وإضافتها إلى المخزون (+10 خبرة)');
 }
 if(type==='vehicle_buy'){
  const model=crop(p.model,25),car=Z64_VEHICLES[model];if(!car)return err(400,'اختار سيارة من القائمة');const op=opId;
  await db.batch([db.prepare('INSERT INTO z64_wallet_ops(id,user_id,kind,cost,note,created_at) VALUES(?,?,?,?,?,?)').bind(op,u.id,'car',car[1],'شراء '+car[0],now),db.prepare('INSERT INTO z64_vehicles(id,user_id,model,created_at) VALUES(?,?,?,?)').bind(op,u.id,model,now),db.prepare('INSERT INTO z64_xp_events(id,user_id,amount,kind,created_at) VALUES(?,?,?,?,?)').bind(op,u.id,20,'car',now)]);
  return notice('تم شراء '+car[0]+' وإضافتها لممتلكاتك');
 }
 if(type==='furniture_buy'){
  const item=crop(p.item,20),f=Z64_FURNITURE[item];if(!f)return err(400,'اختار قطعة أثاث صحيحة');const op=opId;
  await db.batch([db.prepare('INSERT INTO z64_wallet_ops(id,user_id,kind,cost,note,created_at) VALUES(?,?,?,?,?,?)').bind(op,u.id,'furniture',f[1],'شراء '+f[0],now),db.prepare('INSERT INTO z64_furniture_inventory(user_id,item,qty) VALUES(?,?,1) ON CONFLICT(user_id,item) DO UPDATE SET qty=qty+1').bind(u.id,item),db.prepare('INSERT INTO z64_xp_events(id,user_id,amount,kind,created_at) VALUES(?,?,?,?,?)').bind(op,u.id,8,'furniture',now)]);
  return notice('تم شراء '+f[0]);
 }
 if(type==='skill_training'){
  const op=opId;await db.batch([db.prepare('INSERT INTO z64_wallet_ops(id,user_id,kind,cost,note,created_at) VALUES(?,?,?,?,?,?)').bind(op,u.id,'training',500,'دورة تدريبية لرفع خبرة المواطن',now),db.prepare('INSERT INTO z64_xp_events(id,user_id,amount,kind,created_at) VALUES(?,?,?,?,?)').bind(op,u.id,50,'training',now)]);
  return notice('اكتسبت 50 نقطة خبرة');
 }
 if(type==='project_create'){
  if(!pres)return deny();const title=crop(p.title,100),kind=crop(p.kind,30),budget=z64Int(p.budget,100,500000);if(title.length<5||!['school','health','road','housing','factory','park','transport'].includes(kind)||!budget)return err(400,'عنوان المشروع أو نوعه أو الميزانية غير صحيح');
  await db.prepare('INSERT INTO z64_projects(id,title,kind,budget,owner_id,created_at) VALUES(?,?,?,?,?,?)').bind(id(),title,kind,budget,u.id,now).run();return notice('تم طرح المشروع للمناقصات');
 }
 if(type==='project_bid'){
  const projectId=crop(p.project_id,90),amount=z64Int(p.price,100,500000),project=await db.prepare("SELECT * FROM z64_projects WHERE id=? AND status='open'").bind(projectId).first();
  if(!project||!amount||amount>project.budget)return err(400,'المشروع أو قيمة العرض غير صحيحة');
  const c=await db.prepare('SELECT id FROM z_companies WHERE owner_id=?').bind(u.id).first();if(!c)return err(403,'يجب أن تكون مالك شركة لتقديم عرض');
  const staff=await db.prepare("SELECT COUNT(*) n FROM z_company_members WHERE company_id=? AND status='active'").bind(c.id).first();if(!staff?.n)return err(403,'يجب توظيف عامل واحد على الأقل قبل تقديم عرض المشروع');
  try{await db.prepare('INSERT INTO z64_project_bids(id,project_id,company_id,owner_id,price,created_at) VALUES(?,?,?,?,?,?)').bind(id(),projectId,c.id,u.id,amount,now).run();}catch{return err(409,'قدمت شركتك عرضًا سابقًا لنفس المشروع')}
  return notice('تم تقديم عرض شركتك');
 }
 if(type==='project_award'){
  if(!pres)return deny();const bid=await db.prepare('SELECT * FROM z64_project_bids WHERE id=?').bind(crop(p.bid_id,90)).first();if(!bid)return err(404,'العرض غير موجود');
  const done=await db.prepare("UPDATE z64_projects SET status='awarded',winning_company_id=?,winning_bid_id=? WHERE id=? AND status='open' AND budget>=? RETURNING id").bind(bid.company_id,bid.id,bid.project_id,bid.price).first();if(!done)return err(409,'المشروع رُسي بالفعل أو تغيرت حالته');
  return notice('تم إسناد المشروع إلى الشركة الفائزة');
 }
 if(type==='project_complete'){
  const c=await db.prepare('SELECT id FROM z_companies WHERE owner_id=?').bind(u.id).first(),project=await db.prepare('SELECT * FROM z64_projects WHERE id=?').bind(crop(p.project_id,90)).first();
  if(!project||project.status!=='awarded'||project.winning_company_id!==c?.id)return err(403,'المشروع غير مسند إلى شركتك');
  const updated=await db.prepare("UPDATE z64_projects SET status='completed',completed_at=? WHERE id=? AND status='awarded' RETURNING id").bind(now,project.id).first();if(!updated)return err(409,'تم تسليم هذا المشروع بالفعل');return notice('تم تسليم المشروع وينتظر اعتماد الرئاسة للصرف');
 }
 if(type==='project_pay'){
  if(!pres)return deny();const project=await db.prepare("SELECT p.*,b.price FROM z64_projects p JOIN z64_project_bids b ON b.id=p.winning_bid_id WHERE p.id=? AND p.status='completed'").bind(crop(p.project_id,90)).first();if(!project)return err(409,'المشروع غير مستحق للصرف');
  try{await db.prepare('INSERT INTO z64_project_payments(id,project_id,company_id,amount,actor_id,created_at) VALUES(?,?,?,?,?,?)').bind(id(),project.id,project.winning_company_id,project.price,u.id,now).run();}catch(e){return err(409,'لا يمكن صرف مستخلص هذا المشروع مرتين أو رصيد الخزينة غير كافٍ')}
  return notice('تم تحويل المستخلص إلى خزينة الشركة؛ تستطيع الشركة دفع أجور العمال منه');
 }
 return err(400,'هذا الإجراء غير موجود في V64');
}


// ZANGAR WORLD V65 — social connections, verified repeatable tasks, positive province rankings,
// peaceful co-operation and auditable provincial trade. No V64 schema or player data is reset.
let z65Ready=null;
async function z65Ensure(db){
 if(z65Ready)return z65Ready;
 z65Ready=(async()=>{
  await db.batch([
   db.prepare("CREATE TABLE IF NOT EXISTS z65_friend_requests (id TEXT PRIMARY KEY,sender_id TEXT NOT NULL,recipient_id TEXT NOT NULL,status TEXT NOT NULL DEFAULT 'pending' CHECK(status IN ('pending','accepted','rejected')),created_at INTEGER NOT NULL,decided_at INTEGER NOT NULL DEFAULT 0,UNIQUE(sender_id,recipient_id))"),
   db.prepare("CREATE INDEX IF NOT EXISTS z65_friends_received ON z65_friend_requests(recipient_id,status,created_at)"),
   db.prepare("CREATE TABLE IF NOT EXISTS z65_friends(a TEXT NOT NULL,b TEXT NOT NULL,created_at INTEGER NOT NULL,PRIMARY KEY(a,b),CHECK(a<b))"),
   db.prepare("CREATE INDEX IF NOT EXISTS z65_friends_b ON z65_friends(b)"),
   db.prepare("CREATE TABLE IF NOT EXISTS z65_reports (id TEXT PRIMARY KEY,reporter_id TEXT NOT NULL,target_id TEXT NOT NULL,reason TEXT NOT NULL,message_id TEXT NOT NULL DEFAULT '',status TEXT NOT NULL DEFAULT 'pending' CHECK(status IN ('pending','reviewed','dismissed')),reviewer_id TEXT NOT NULL DEFAULT '',decision TEXT NOT NULL DEFAULT '',created_at INTEGER NOT NULL,reviewed_at INTEGER NOT NULL DEFAULT 0)"),
   db.prepare("CREATE INDEX IF NOT EXISTS z65_reports_reporter ON z65_reports(reporter_id,created_at)"),
   db.prepare("CREATE TABLE IF NOT EXISTS z65_task_claims (user_id TEXT NOT NULL,task_id TEXT NOT NULL,period_key TEXT NOT NULL,reward INTEGER NOT NULL CHECK(reward BETWEEN 1 AND 5000),claimed_at INTEGER NOT NULL,PRIMARY KEY(user_id,task_id,period_key))"),
   db.prepare(`CREATE TRIGGER IF NOT EXISTS z65_task_pay AFTER INSERT ON z65_task_claims BEGIN
     UPDATE users SET points=points+NEW.reward WHERE id=NEW.user_id;
     INSERT INTO transactions(id,user_id,amount,note,created_at) VALUES('z65-'||NEW.user_id||'-'||NEW.task_id||'-'||NEW.period_key,NEW.user_id,NEW.reward,'مكافأة مهمة V65: '||NEW.task_id,NEW.claimed_at);
   END`),
   db.prepare("CREATE TABLE IF NOT EXISTS z65_province_votes (user_id TEXT NOT NULL,week_key TEXT NOT NULL,province_id TEXT NOT NULL,created_at INTEGER NOT NULL,PRIMARY KEY(user_id,week_key))"),
   db.prepare("CREATE TABLE IF NOT EXISTS z65_partners (id TEXT PRIMARY KEY,name TEXT NOT NULL,field TEXT NOT NULL)"),
   db.prepare("CREATE TABLE IF NOT EXISTS z65_treaties (id TEXT PRIMARY KEY,partner_id TEXT NOT NULL,province_id TEXT NOT NULL,field TEXT NOT NULL,description TEXT NOT NULL,proposer_id TEXT NOT NULL,status TEXT NOT NULL DEFAULT 'pending' CHECK(status IN ('pending','approved','rejected')),reviewer_id TEXT NOT NULL DEFAULT '',created_at INTEGER NOT NULL,decided_at INTEGER NOT NULL DEFAULT 0)"),
   db.prepare("CREATE TABLE IF NOT EXISTS z65_trades (id TEXT PRIMARY KEY,from_id TEXT NOT NULL,to_id TEXT NOT NULL,resource TEXT NOT NULL,quantity INTEGER NOT NULL CHECK(quantity BETWEEN 1 AND 100),price INTEGER NOT NULL CHECK(price BETWEEN 100 AND 50000),proposer_id TEXT NOT NULL,status TEXT NOT NULL DEFAULT 'pending' CHECK(status IN ('pending','settled','cancelled')),created_at INTEGER NOT NULL,settled_at INTEGER NOT NULL DEFAULT 0)"),
   db.prepare("CREATE TABLE IF NOT EXISTS z65_resources (province_id TEXT NOT NULL,resource TEXT NOT NULL,quantity INTEGER NOT NULL DEFAULT 100 CHECK(quantity>=0),PRIMARY KEY(province_id,resource))"),
   db.prepare("CREATE TABLE IF NOT EXISTS z65_trade_settlements(trade_id TEXT PRIMARY KEY,actor_id TEXT NOT NULL,created_at INTEGER NOT NULL)"),
   db.prepare(`CREATE TRIGGER IF NOT EXISTS z65_trade_check BEFORE INSERT ON z65_trade_settlements BEGIN
     SELECT CASE WHEN NOT EXISTS (SELECT 1 FROM z65_trades t JOIN z46_provinces p ON p.id=t.to_id WHERE t.id=NEW.trade_id AND t.status='pending' AND p.treasury>=t.price AND EXISTS(SELECT 1 FROM z65_resources r WHERE r.province_id=t.from_id AND r.resource=t.resource AND r.quantity>=t.quantity)) THEN RAISE(ABORT,'المبادلة غير متاحة أو رصيد المحافظة المستلمة غير كاف') END;
   END`),
   db.prepare(`CREATE TRIGGER IF NOT EXISTS z65_trade_apply AFTER INSERT ON z65_trade_settlements BEGIN
     UPDATE z46_provinces SET treasury=treasury-(SELECT price FROM z65_trades WHERE id=NEW.trade_id) WHERE id=(SELECT to_id FROM z65_trades WHERE id=NEW.trade_id);
     UPDATE z46_provinces SET treasury=treasury+(SELECT price FROM z65_trades WHERE id=NEW.trade_id) WHERE id=(SELECT from_id FROM z65_trades WHERE id=NEW.trade_id);
     INSERT INTO z46_ledger(id,province_id,actor_id,kind,delta,note,created_at)
       SELECT NEW.trade_id||'-buyer',to_id,NEW.actor_id,'peace65',-price,'شراء موارد بالتعاون السلمي: '||resource,NEW.created_at FROM z65_trades WHERE id=NEW.trade_id;
     INSERT INTO z46_ledger(id,province_id,actor_id,kind,delta,note,created_at)
       SELECT NEW.trade_id||'-seller',from_id,NEW.actor_id,'peace65',price,'بيع موارد بالتعاون السلمي: '||resource,NEW.created_at FROM z65_trades WHERE id=NEW.trade_id;
     UPDATE z65_resources SET quantity=quantity-(SELECT quantity FROM z65_trades WHERE id=NEW.trade_id) WHERE province_id=(SELECT from_id FROM z65_trades WHERE id=NEW.trade_id) AND resource=(SELECT resource FROM z65_trades WHERE id=NEW.trade_id);
     UPDATE z65_resources SET quantity=quantity+(SELECT quantity FROM z65_trades WHERE id=NEW.trade_id) WHERE province_id=(SELECT to_id FROM z65_trades WHERE id=NEW.trade_id) AND resource=(SELECT resource FROM z65_trades WHERE id=NEW.trade_id);
     UPDATE z65_trades SET status='settled',settled_at=NEW.created_at WHERE id=NEW.trade_id;
   END`),
  ]);
  await db.prepare("INSERT OR IGNORE INTO z65_resources(province_id,resource,quantity) SELECT p.id,r.name,100 FROM z46_provinces p CROSS JOIN (SELECT 'قمح' name UNION ALL SELECT 'حديد' UNION ALL SELECT 'خشب' UNION ALL SELECT 'أدوية') r WHERE p.id<>'home'").run();
  await db.batch([
    db.prepare("INSERT OR IGNORE INTO z65_partners(id,name,field) VALUES('coast','اتحاد الساحل الافتراضي','تجارة')"),
    db.prepare("INSERT OR IGNORE INTO z65_partners(id,name,field) VALUES('oasis','دولة الواحات الافتراضية','تعليم')"),
    db.prepare("INSERT OR IGNORE INTO z65_partners(id,name,field) VALUES('valley','جمهورية الوادي الافتراضية','صحة')")
  ]);
 })().catch(e=>{z65Ready=null;throw e});return z65Ready;
}
const Z65_TASKS=[
 {id:'daily_login',title:'سجّل دخولك اليوم',period:'daily',reward:200,target:1},
 {id:'daily_chat',title:'شارك برسالة محترمة اليوم',period:'daily',reward:250,target:1},
 {id:'daily_friend',title:'تواصل مع صديق',period:'daily',reward:150,target:1},
 {id:'weekly_chat',title:'اكتب 5 رسائل هذا الأسبوع',period:'weekly',reward:700,target:5},
 {id:'weekly_trade',title:'أتم عملية شراء أو تجارة',period:'weekly',reward:900,target:1},
 {id:'weekly_group',title:'شارك في مجموعة هذا الأسبوع',period:'weekly',reward:650,target:1}
];
function z65Periods(now=Date.now()){
 const day=new Date(now).toISOString().slice(0,10);
 const d=new Date(now),dow=(d.getUTCDay()+6)%7;
 const monday=new Date(Date.UTC(d.getUTCFullYear(),d.getUTCMonth(),d.getUTCDate()-dow));
 return {day,week:monday.toISOString().slice(0,10),dayStart:Date.parse(day+'T00:00:00Z'),weekStart:monday.getTime()};
}
async function z65ActiveUser(db,userid){
 return db.prepare('SELECT id,name FROM users WHERE id=? AND NOT EXISTS(SELECT 1 FROM z64_archived_users a WHERE a.user_id=users.id AND a.restored_at=0)').bind(userid).first();
}
function z65Pair(a,b){return a<b?[a,b]:[b,a]}
async function z65TaskProgress(db,u,now){
 const period=z65Periods(now);
 const [msgs,friends,spent,group,claims]=await Promise.all([
  db.prepare('SELECT created_at,room_id FROM chat_messages WHERE sender_id=? AND created_at>=? ORDER BY created_at DESC LIMIT 80').bind(u.id,period.weekStart).all(),
  db.prepare('SELECT COUNT(*) n FROM z65_friends WHERE a=? OR b=?').bind(u.id,u.id).first(),
  db.prepare('SELECT COUNT(*) n FROM transactions WHERE user_id=? AND amount<0 AND created_at>=?').bind(u.id,period.weekStart).first(),
  db.prepare("SELECT COUNT(*) n FROM chat_messages m JOIN chat_rooms r ON r.id=m.room_id AND r.kind='group' WHERE m.sender_id=? AND m.created_at>=?").bind(u.id,period.weekStart).first(),
  db.prepare('SELECT task_id,period_key FROM z65_task_claims WHERE user_id=? AND period_key IN (?,?)').bind(u.id,period.day,period.week).all()
 ]);
 const w=msgs.results.length,d=msgs.results.filter(m=>m.created_at>=period.dayStart).length;
 const progress={daily_login:1,daily_chat:d,daily_friend:Number(friends?.n||0),weekly_chat:w,weekly_trade:Number(spent?.n||0),weekly_group:Number(group?.n||0)};
 return Z65_TASKS.map(t=>({...t,progress:Math.min(t.target,progress[t.id]),done:claims.results.some(x=>x.task_id===t.id&&x.period_key===(t.period==='daily'?period.day:period.week)),period_key:t.period==='daily'?period.day:period.week}));
}
async function z65Ranking(db,now=Date.now()){
 const week=z65Periods(now).week;
 const [places,projects,members,votes]=await Promise.all([
  db.prepare('SELECT id,name,treasury,economy,governor_id FROM z46_provinces ORDER BY id').all(),
  db.prepare("SELECT province_id,COUNT(*) n,SUM(CASE WHEN kind='school' THEN 1 ELSE 0 END) schools,SUM(CASE WHEN kind='hospital' THEN 1 ELSE 0 END) hospitals FROM z62_civic_projects WHERE status='completed' GROUP BY province_id").all(),
  db.prepare('SELECT province_id,COUNT(*) n FROM z46_members m WHERE NOT EXISTS(SELECT 1 FROM z64_archived_users x WHERE x.user_id=m.user_id AND x.restored_at=0) GROUP BY province_id').all(),
  db.prepare('SELECT province_id,COUNT(*) n FROM z65_province_votes WHERE week_key=? GROUP BY province_id').bind(week).all()
 ]);
 const count=(rows,pid,k)=>Number(rows.results.find(x=>x.province_id===pid)?.[k]||0);
 return places.results.map(p=>{
  const finished=count(projects,p.id,'n'),citizens=count(members,p.id,'n'),votesCount=count(votes,p.id,'n');
  const schools=count(projects,p.id,'schools'),hospitals=count(projects,p.id,'hospitals');
  const score=finished*25+citizens*2+votesCount*5+schools*15+hospitals*15+Math.min(100,Math.floor(Number(p.economy||0)/10000));
  return {id:p.id,name:p.name,governor_id:p.governor_id,projects:finished,members:citizens,votes:votesCount,education:schools,health:hospitals,score};
 }).sort((x,y)=>y.score-x.score||x.name.localeCompare(y.name,'ar')).map((x,i)=>({...x,rank:i+1}));
}
async function z65State(req,db){
 const u=await getMe(req,db);if(!u)return err(401,'ادخل بحساب Guest أولًا');await z65Ensure(db);await z62Ensure(db);
 const now=Date.now(),week=z65Periods(now).week;
 const [people,requests,friends,reported,reports,partners,treaties,trades,myVote,rooms,ranking,tasks,resources]=await Promise.all([
  db.prepare('SELECT id,name,job FROM users WHERE id<>? AND NOT EXISTS(SELECT 1 FROM z64_archived_users a WHERE a.user_id=users.id AND a.restored_at=0) ORDER BY name LIMIT 80').bind(u.id).all(),
  db.prepare("SELECT r.id,r.sender_id,r.recipient_id,r.status,r.created_at,u.name sender_name FROM z65_friend_requests r JOIN users u ON u.id=r.sender_id WHERE (r.sender_id=? OR r.recipient_id=?) AND NOT EXISTS(SELECT 1 FROM z64_archived_users a WHERE a.user_id=u.id AND a.restored_at=0) ORDER BY r.created_at DESC LIMIT 100").bind(u.id,u.id).all(),
  db.prepare("SELECT x.id,x.name FROM z65_friends f JOIN users x ON x.id=CASE WHEN f.a=? THEN f.b ELSE f.a END WHERE (f.a=? OR f.b=?) AND NOT EXISTS(SELECT 1 FROM z64_archived_users a WHERE a.user_id=x.id AND a.restored_at=0) ORDER BY x.name LIMIT 100").bind(u.id,u.id,u.id).all(),
  db.prepare('SELECT id,target_id,reason,status,created_at FROM z65_reports WHERE reporter_id=? ORDER BY created_at DESC LIMIT 25').bind(u.id).all(),
  isAdmin(u)?db.prepare("SELECT r.id,r.reason,r.status,r.created_at,r.reporter_id,r.target_id,reporter.name reporter_name,target.name target_name FROM z65_reports r JOIN users reporter ON reporter.id=r.reporter_id JOIN users target ON target.id=r.target_id WHERE r.status='pending' ORDER BY r.created_at DESC LIMIT 80").all():Promise.resolve({results:[]}),
  db.prepare('SELECT id,name,field FROM z65_partners ORDER BY id').all(),
  db.prepare('SELECT t.*,p.name partner_name,pr.name province_name FROM z65_treaties t JOIN z65_partners p ON p.id=t.partner_id JOIN z46_provinces pr ON pr.id=t.province_id ORDER BY t.created_at DESC LIMIT 80').all(),
  db.prepare('SELECT t.*,a.name from_name,b.name to_name FROM z65_trades t JOIN z46_provinces a ON a.id=t.from_id JOIN z46_provinces b ON b.id=t.to_id ORDER BY t.created_at DESC LIMIT 80').all(),
  db.prepare('SELECT province_id FROM z65_province_votes WHERE user_id=? AND week_key=?').bind(u.id,week).first(),
  db.prepare("SELECT r.id,r.title,r.kind, (SELECT COUNT(*) FROM chat_members cm WHERE cm.room_id=r.id) members FROM chat_rooms r JOIN chat_members me ON me.room_id=r.id AND me.user_id=? WHERE r.kind='group' ORDER BY r.created_at DESC LIMIT 35").bind(u.id).all(),
  z65Ranking(db,now),z65TaskProgress(db,u,now),
  db.prepare("SELECT province_id,resource,quantity FROM z65_resources ORDER BY province_id,resource").all()
 ]);
 return json({ok:true,version:'65',me:{id:u.id,name:u.name,points:u.points},is_president:isAdmin(u),friends:friends.results,requests:requests.results,people:people.results,groups:rooms.results,reported:reported.results,reports:reports.results,partners:partners.results,treaties:treaties.results,trades:trades.results,resources:resources.results,rankings:ranking,my_vote:myVote?.province_id||'',week,tasks});
}
async function z65Action(req,db,p){
 const u=await getMe(req,db);if(!u)return err(401,'ادخل بحساب Guest أولًا');await z65Ensure(db);
 const type=crop(p.type,50),now=Date.now(),target=crop(p.user_id,90),president=isAdmin(u);
 const msg=s=>json({ok:true,message:s});
 if(type==='friend_request'){
  if(target===u.id||!await z65ActiveUser(db,target))return err(400,'لا يمكن إضافة هذا المواطن');
  const [a,b]=z65Pair(u.id,target);
  if(await db.prepare('SELECT 1 FROM z65_friends WHERE a=? AND b=?').bind(a,b).first())return err(409,'أنتما صديقان بالفعل');
  const existing=await db.prepare("SELECT id,sender_id FROM z65_friend_requests WHERE ((sender_id=? AND recipient_id=?) OR (sender_id=? AND recipient_id=?)) AND status='pending' LIMIT 1").bind(u.id,target,target,u.id).first();
  if(existing)return err(409,'يوجد طلب صداقة بانتظار الرد');
  const recent=await db.prepare('SELECT COUNT(*) n FROM z65_friend_requests WHERE sender_id=? AND created_at>?').bind(u.id,now-86400000).first();if(Number(recent?.n||0)>=15)return err(429,'الحد اليومي لطلبات الصداقة 15');
  await db.prepare("INSERT INTO z65_friend_requests(id,sender_id,recipient_id,status,created_at) VALUES(?,?,?,'pending',?) ON CONFLICT(sender_id,recipient_id) DO UPDATE SET status='pending',created_at=excluded.created_at,decided_at=0").bind(id(),u.id,target,now).run();
  return msg('تم إرسال طلب الصداقة');
 }
 if(type==='friend_decide'){
  const reqId=crop(p.request_id,90),decision=p.accept===true?'accepted':'rejected';
  const row=await db.prepare("SELECT * FROM z65_friend_requests WHERE id=? AND recipient_id=? AND status='pending'").bind(reqId,u.id).first();if(!row||!await z65ActiveUser(db,row.sender_id))return err(409,'الطلب غير متاح');
  const statements=[db.prepare("UPDATE z65_friend_requests SET status=?,decided_at=? WHERE id=? AND status='pending'").bind(decision,now,reqId)];
  if(decision==='accepted'){const [a,b]=z65Pair(u.id,row.sender_id);statements.push(db.prepare('INSERT OR IGNORE INTO z65_friends(a,b,created_at) VALUES(?,?,?)').bind(a,b,now));}
  await db.batch(statements);return msg(decision==='accepted'?'أصبحتما صديقين':'تم رفض الطلب');
 }
 if(type==='friend_remove'){
  const [a,b]=z65Pair(u.id,target);
  const r=await db.prepare('DELETE FROM z65_friends WHERE a=? AND b=? RETURNING a').bind(a,b).first();return r?msg('تمت إزالة الصديق'):err(404,'الصداقة غير موجودة');
 }
 if(type==='report'){
  const reason=crop(p.reason,600),msgId=crop(p.message_id||'',90);if(target===u.id||!await z65ActiveUser(db,target)||reason.length<12)return err(400,'اختر مواطنًا آخر واكتب سببًا واضحًا لا يقل عن 12 حرفًا');
  if(msgId&&!await db.prepare('SELECT 1 FROM chat_messages WHERE id=? AND sender_id=?').bind(msgId,target).first())return err(400,'الرسالة المشار إليها لا تخص هذا المواطن');
  const n=await db.prepare('SELECT COUNT(*) n FROM z65_reports WHERE reporter_id=? AND created_at>?').bind(u.id,now-86400000).first();if(n.n>=3)return err(429,'الحد اليومي 3 بلاغات');
  await db.prepare('INSERT INTO z65_reports(id,reporter_id,target_id,reason,message_id,created_at) VALUES(?,?,?,?,?,?)').bind(id(),u.id,target,reason,msgId,now).run();return msg('تم إرسال البلاغ للمراجعة، دون توقيع عقوبة تلقائية');
 }
 if(type==='report_decide'){
  if(!president)return err(403,'المراجعة متاحة للرئاسة فقط');
  const status=p.status==='reviewed'?'reviewed':p.status==='dismissed'?'dismissed':'';
  const decision=crop(p.decision,400),rid=crop(p.report_id,90);if(!status||decision.length<8)return err(400,'حدد القرار والسبب');
  const item=await db.prepare("SELECT reporter_id,target_id FROM z65_reports WHERE id=? AND status='pending'").bind(rid).first();if(!item||item.reporter_id===u.id||item.target_id===u.id)return err(403,'لا يجوز مراجعة بلاغ أنت طرف فيه');
  const result=await db.prepare("UPDATE z65_reports SET status=?,reviewer_id=?,decision=?,reviewed_at=? WHERE id=? AND status='pending' RETURNING id").bind(status,u.id,decision,now,rid).first();return result?msg('تم تسجيل قرار المراجعة'):err(409,'سبقت مراجعة البلاغ');
 }
 if(type==='task_claim'){
  const taskId=crop(p.task_id,40),tasks=await z65TaskProgress(db,u,now),task=tasks.find(t=>t.id===taskId);
  if(!task)return err(404,'المهمة غير موجودة');if(task.done)return err(409,'حصلت على هذه المكافأة بالفعل');if(task.progress<task.target)return err(403,'شروط المهمة لم تكتمل بعد');
  try{const res=await db.prepare('INSERT OR IGNORE INTO z65_task_claims(user_id,task_id,period_key,reward,claimed_at) VALUES(?,?,?,?,?) RETURNING task_id').bind(u.id,task.id,task.period_key,task.reward,now).first();return res?msg('تمت إضافة '+task.reward+' زنجر لرصيدك'):err(409,'تم صرف المكافأة مسبقًا');}catch(e){return err(409,'تعذّر صرف المكافأة الآن، لم يُكرر الدفع');}
 }
 if(type==='province_vote'){
  await z62Ensure(db);const pid=crop(p.province_id,90),week=z65Periods(now).week;
  if(!await db.prepare('SELECT 1 FROM z46_provinces WHERE id=?').bind(pid).first())return err(400,'المحافظة غير موجودة');
  const row=await db.prepare('INSERT OR IGNORE INTO z65_province_votes(user_id,week_key,province_id,created_at) VALUES(?,?,?,?) RETURNING user_id').bind(u.id,week,pid,now).first();
  return row?msg('تم تسجيل صوتك للمحافظة، صوت واحد فقط أسبوعيًا'):err(409,'سبق التصويت هذا الأسبوع');
 }
 if(type==='treaty_propose'){
  await z62Ensure(db);const province=crop(p.province_id,60),partner=crop(p.partner_id,40),field=crop(p.field,30),description=crop(p.description,350);
  if(!['تجارة','تعليم','صحة','نقل','ثقافة'].includes(field)||description.length<10)return err(400,'اكتب تعاونًا سلميًا واضحًا');
  if(!await db.prepare('SELECT 1 FROM z65_partners WHERE id=?').bind(partner).first())return err(400,'الشريك غير موجود');
  if(!await db.prepare('SELECT 1 FROM z46_provinces WHERE id=? AND (governor_id=? OR ?=1)').bind(province,u.id,president?1:0).first())return err(403,'يقدم الاتفاق المحافظ أو الرئاسة فقط');
  await db.prepare('INSERT INTO z65_treaties(id,partner_id,province_id,field,description,proposer_id,created_at) VALUES(?,?,?,?,?,?,?)').bind(id(),partner,province,field,description,u.id,now).run();return msg('قُدم مقترح الاتفاق السلمي للرئاسة');
 }
 if(type==='treaty_decide'){
  if(!president)return err(403,'اعتماد الاتفاقيات للرئاسة فقط');const status=p.approve===true?'approved':'rejected';
  const row=await db.prepare("UPDATE z65_treaties SET status=?,reviewer_id=?,decided_at=? WHERE id=? AND status='pending' RETURNING id").bind(status,u.id,now,crop(p.treaty_id,90)).first();return row?msg('تم توثيق قرار الاتفاقية'):err(409,'الاقتراح غير متاح');
 }
 if(type==='trade_propose'){
  await z62Ensure(db);const from=crop(p.from_id,50),to=crop(p.to_id,50),resource=crop(p.resource,50),qty=Number(p.quantity),price=Number(p.price);
  if(from===to||!['قمح','حديد','خشب','أدوية'].includes(resource)||!Number.isSafeInteger(qty)||qty<1||qty>100||!Number.isSafeInteger(price)||price<100||price>50000)return err(400,'بيانات المبادلة غير صالحة');
  if(!await db.prepare('SELECT 1 FROM z46_provinces WHERE id=? AND (governor_id=? OR ?=1)').bind(from,u.id,president?1:0).first())return err(403,'يقدم البيع محافظ المنطقة أو الرئاسة');
  if(!await db.prepare('SELECT 1 FROM z46_provinces WHERE id=?').bind(to).first())return err(400,'المحافظة الأخرى غير موجودة');
  await db.prepare('INSERT INTO z65_trades(id,from_id,to_id,resource,quantity,price,proposer_id,created_at) VALUES(?,?,?,?,?,?,?,?)').bind(id(),from,to,resource,qty,price,u.id,now).run();return msg('تم عرض مبادلة سلمية، وتنتظر موافقة المحافظة الأخرى');
 }
 if(type==='trade_accept'){
  await z62Ensure(db);const trade=await db.prepare("SELECT * FROM z65_trades WHERE id=? AND status='pending'").bind(crop(p.trade_id,90)).first();if(!trade)return err(409,'المبادلة منتهية أو غير موجودة');
  if(!await db.prepare('SELECT 1 FROM z46_provinces WHERE id=? AND (governor_id=? OR ?=1)').bind(trade.to_id,u.id,president?1:0).first())return err(403,'القبول لمحافظ المنطقة المستلمة أو الرئاسة فقط');
  try{const row=await db.prepare('INSERT OR IGNORE INTO z65_trade_settlements(trade_id,actor_id,created_at) VALUES(?,?,?) RETURNING trade_id').bind(trade.id,u.id,now).first();return row?msg('تمت المبادلة وتحويل القيمة بين خزائن المحافظات مرة واحدة'):err(409,'تم الصرف مسبقًا');}catch(e){return err(409,'لا يوجد رصيد كافٍ أو المبادلة صُرفت بالفعل');}
 }
 if(type==='trade_cancel'){
  await z62Ensure(db);const trade=await db.prepare("SELECT * FROM z65_trades WHERE id=? AND status='pending'").bind(crop(p.trade_id,90)).first();if(!trade)return err(409,'المبادلة غير متاحة');
  if(!president&&trade.proposer_id!==u.id)return err(403,'إلغاء الطلب لمقدمه أو الرئاسة فقط');
  await db.prepare("UPDATE z65_trades SET status='cancelled' WHERE id=? AND status='pending'").bind(trade.id).run();return msg('تم إلغاء المبادلة قبل أي دفع');
 }
 return err(400,'إجراء V65 غير معروف');
}

