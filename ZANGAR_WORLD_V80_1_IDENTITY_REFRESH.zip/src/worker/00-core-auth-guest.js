/* Cloudflare Pages Function: Auth, members, government, economy | D1 backend */
const DEPARTMENT_CODES={"requests": "bd7fc06058996204bba0ca0a4863743639383ddb5c0d238433e64d198094be04", "court": "fa40a44812fa32121a9915a2627cd2b55d675fa11255bc13d8d37d81afae4f59", "violations": "db022cf9ebcdc7fdf17537e2c37e77308b0b461069f92706c5ffd049e7fb642b", "ads": "fa6074c473211b23b215865fb97cef161529c5a1bc40b7f48f60fe4545b09977", "education": "7dfd172cd5182d63b8424a290380051847623e0ce75dfd1f59ad2ea404c2ab5a", "telecom": "c7a054ad7a73096411792836ac9f4ce984047672bdf22286c8866c29a652951c"};
const DEPARTMENT_KEYS=Object.keys(DEPARTMENT_CODES);
const POLICE_CODE_HASH="66ed896f1187af5f57b117cb460567c11e80ee285a3e1b4c4b9eb8a8ffaaad30";
const PRISON_DURATIONS=[1,5,10,24,48,72,120,168];
const MAX_BODY=180_000,SESSION_LIFETIME=30*86400*1000;
const json=(obj,status=200,headers={})=>new Response(JSON.stringify(obj),{status,headers:{'Content-Type':'application/json; charset=utf-8','Cache-Control':'no-store',...headers}});
const err=(s,msg)=>json({error:msg},s);
const id=()=>crypto.randomUUID();
const norm=s=>String(s||'').trim().replace(/\s+/g,' ').toLocaleLowerCase('ar');
const crop=(v,n)=>String(v??'').trim().slice(0,n);
const num=(n)=>Number(n);
const enc=new TextEncoder();
const salt=()=>Array.from(crypto.getRandomValues(new Uint8Array(16))).map(x=>x.toString(16).padStart(2,'0')).join('');
const hex=b=>Array.from(new Uint8Array(b)).map(x=>x.toString(16).padStart(2,'0')).join('');
async function digest(s){return hex(await crypto.subtle.digest('SHA-256',enc.encode(s)))}
// Cloudflare workerd limits any single PBKDF2 operation to 100,000 iterations.
// The format marker makes newly approved accounts distinguishable from legacy 160k hashes.
const Z66_PW_SCHEME='pbkdf2-sha256-100k:';
async function pwHash(p,s){let key=await crypto.subtle.importKey('raw',enc.encode(p),'PBKDF2',false,['deriveBits']);return hex(await crypto.subtle.deriveBits({name:'PBKDF2',salt:enc.encode(s),iterations:100000,hash:'SHA-256'},key,256));}

function uuid(){return id()}
function cookieValue(request,name){let cookie=request.headers.get('Cookie')||'';return (cookie.split(';').map(x=>x.trim()).find(x=>x.startsWith(name+'='))||'').slice(name.length+1)}
function sessionCookie(token,maxAge=30*86400){return `zangar_session=${token}; HttpOnly; Secure; SameSite=Lax; Path=/; Max-Age=${maxAge}`}
// V71.1 — server-owned account entitlements: code once, restore after login/refresh/deploy.
// Never store the actual secret code, PIN or temporary authorization token in localStorage.
let z711GrantReady=null;
async function z711Ensure(db){
 if(!z711GrantReady)z711GrantReady=db.prepare(`CREATE TABLE IF NOT EXISTS z711_code_entitlements (
  user_id TEXT NOT NULL, scope TEXT NOT NULL CHECK(scope IN ('presidency','air_command','head_control','sovereign_control')),
  granted_at INTEGER NOT NULL, revoked_at INTEGER NOT NULL DEFAULT 0,
  PRIMARY KEY(user_id,scope))`).run().catch(e=>{z711GrantReady=null;throw e;});
 return z711GrantReady;
}
async function z711Grant(db,userId,scope){
 await z711Ensure(db);const now=Date.now();
 await db.prepare(`INSERT INTO z711_code_entitlements(user_id,scope,granted_at,revoked_at) VALUES(?,?,?,0)
 ON CONFLICT(user_id,scope) DO UPDATE SET granted_at=excluded.granted_at,revoked_at=0`).bind(userId,scope,now).run();
}
async function z711Revoke(db,userId,scope){
 await z711Ensure(db);
 await db.prepare(`INSERT INTO z711_code_entitlements(user_id,scope,granted_at,revoked_at) VALUES(?,?,?,?)
 ON CONFLICT(user_id,scope) DO UPDATE SET revoked_at=excluded.revoked_at`).bind(userId,scope,0,Date.now()).run();
}
async function z711Active(db,userId,scope){
 await z711Ensure(db);
 return !!await db.prepare('SELECT 1 FROM z711_code_entitlements WHERE user_id=? AND scope=? AND granted_at>0 AND revoked_at=0').bind(userId,scope).first();
}
async function getMe(request,db){
 const token=cookieValue(request,'zangar_session');if(!/^[a-f0-9]{64}$/.test(token))return null;
 await z711Ensure(db);
 const h=await digest(token),now=Date.now();
 const u=await db.prepare(`SELECT u.*, gs.slot AS guest_slot,
  CASE WHEN ent.user_id IS NOT NULL AND ent.revoked_at>0 THEN 0
   WHEN ent.granted_at>0 AND ent.revoked_at=0 THEN 1
   WHEN ent.user_id IS NULL AND ag.user_id IS NOT NULL THEN 1 ELSE 0 END AS admin_granted,
  CASE WHEN ent.user_id IS NULL AND ag.user_id IS NOT NULL THEN 1 ELSE 0 END AS z711_legacy_admin
 FROM sessions s JOIN users u ON u.id=s.user_id
 JOIN z639_guest_slots gs ON gs.user_id=u.id
 LEFT JOIN z49_gate_access ag ON ag.user_id=u.id AND ag.session_hash=s.token_hash AND ag.expires_at>?
 LEFT JOIN z711_code_entitlements ent ON ent.user_id=u.id AND ent.scope='presidency'
 WHERE s.token_hash=? AND s.expires_at>?
 AND NOT EXISTS (SELECT 1 FROM z64_archived_users da WHERE da.user_id=u.id AND da.restored_at=0)`).bind(now,h,now).first();
 // One-time migration of a STILL-VALID V71 two-step presidential session.
 // Intentionally do NOT trust old admin_grants: those predate the newer two-factor gate.
 // INSERT OR IGNORE prevents a deliberately revoked entitlement from being resurrected.
 if(u?.z711_legacy_admin){
  await db.prepare(`INSERT OR IGNORE INTO z711_code_entitlements(user_id,scope,granted_at,revoked_at)
   VALUES(?,'presidency',?,0)`).bind(u.id,now).run();
 }
 if(u)delete u.z711_legacy_admin;
 return u;
}
// V76 — ID numbers and decorative codes, separate from authentication and existing identity_no.
// A UNIQUE constraint makes each card number AND each card code different across accounts.
// Never send card_code in public user records or public verification endpoints.
let z76IdentitySchemaReady=null;
async function z76EnsureIdentityCards(db){
 if(!z76IdentitySchemaReady){
  z76IdentitySchemaReady=db.prepare(`CREATE TABLE IF NOT EXISTS z76_identity_cards (
   user_id TEXT PRIMARY KEY,
   card_no TEXT NOT NULL UNIQUE,
   card_code TEXT NOT NULL UNIQUE,
   created_at INTEGER NOT NULL
  )`).run().catch(e=>{z76IdentitySchemaReady=null;throw e});
 }
 await z76IdentitySchemaReady;
 // One set-based D1 statement also assigns existing accounts without resetting their history.
 // 10-digit decimal card numbers and 10-character alphanumeric display codes.
 await db.prepare(`INSERT OR IGNORE INTO z76_identity_cards(user_id,card_no,card_code,created_at)
  SELECT u.id,
   printf('%010d',1000000000+abs(random()%9000000000)),
   upper(substr(hex(randomblob(5)),1,4)||'K'||substr(hex(randomblob(5)),1,5)),
   ?
  FROM users u
  WHERE NOT EXISTS(SELECT 1 FROM z76_identity_cards c WHERE c.user_id=u.id)`).bind(Date.now()).run();
}
// Update 60 — Return to a previously authenticated account on the SAME browser.
// Never infer account identity from a name, device, query string or localStorage.
// The original HttpOnly session cookie is the only proof of login.
async function z60SessionStatus(req,db){
 const token=cookieValue(req,'zangar_session');
 if(!/^[0-9a-f]{64}$/.test(token))return json({logged_in:false});
 const hash=await digest(token),now=Date.now();
 const row=await db.prepare('SELECT s.expires_at,u.id FROM sessions s JOIN users u ON u.id=s.user_id JOIN z639_guest_slots gs ON gs.user_id=u.id WHERE s.token_hash=? AND s.expires_at>? AND NOT EXISTS(SELECT 1 FROM z64_archived_users da WHERE da.user_id=u.id AND da.restored_at=0) LIMIT 1').bind(hash,now).first();
 if(!row)return json({logged_in:false});
 let governor=false;
 try{const gov=await db.prepare('SELECT id FROM z46_provinces WHERE governor_id=? LIMIT 1').bind(row.id).first();governor=!!gov}catch{}
 // Sliding 30-day session. Refresh at most once per 23 days, not on every page load.
 const expires=Number(row.expires_at||0),headers={};
 if(expires-now<7*86400000){
   const next=now+SESSION_LIFETIME;
   await db.prepare('UPDATE sessions SET expires_at=? WHERE token_hash=? AND expires_at>?').bind(next,hash,now).run();
   headers['Set-Cookie']=sessionCookie(token);
 }
 return json({logged_in:true,governor},200,headers);
}
async function addTx(db,userId,amount,note,now=Date.now()){await db.prepare('INSERT INTO transactions(id,user_id,amount,note,created_at) VALUES (?,?,?,?,?)').bind(uuid(),userId,amount,crop(note,200),now).run()}
async function activity(db,name,text,now=Date.now()){await db.prepare('INSERT INTO activity(id,name,text,created_at) VALUES (?,?,?,?)').bind(uuid(),crop(name,50),crop(text,250),now).run()}
function safePublic(u){return {id:u.id,name:u.name,role:u.role,rank:u.rank,job:u.job,points:u.points,avatar:u.avatar,joined:u.joined,identity_no:u.identity_no,guest_slot:u.guest_slot||null,candidate:!!u.candidate,claim_at:u.claim_at,game_at:u.game_at,dob:u.dob,bio:u.bio};}
function isAdmin(u){return !!(u&&u.admin_granted)}
// Short-lived public read coalescing; no citizen session or private balances are cached.
const z32PublicCache=new Map();
async function z32PublicRead(key,ttl,loader){
 const now=Date.now(),hit=z32PublicCache.get(key);
 if(hit&&hit.until>now)return hit.promise;
 const promise=Promise.resolve().then(loader);
 z32PublicCache.set(key,{until:now+ttl,promise});
 try{return await promise}catch(e){if(z32PublicCache.get(key)?.promise===promise)z32PublicCache.delete(key);throw e}
}

async function prisonActive(db,userId,now=Date.now()){if(!userId)return null;return db.prepare("SELECT id,reason,hours,starts_at,ends_at FROM prison_requests WHERE target_id=? AND status='approved' AND ends_at>? ORDER BY ends_at DESC LIMIT 1").bind(userId,now).first()}
async function policeGranted(db,u){return !!(u&&(isAdmin(u)||/شرطة|الداخلية|ضابط|شرطي/.test(String(u.job||''))))}
async function visaPayment(db,u,method){if(method==='visa'){const card=await db.prepare("SELECT id FROM cards WHERE user_id=? AND kind='فيزا' LIMIT 1").bind(u.id).first();if(!card)throw Error('فشلت العملية: لا تمتلك فيزا زنجر افتراضية. إصدارها من بطاقاتي البنكية.');}else if(method!==undefined&&method!==null&&method!==''&&method!=='points')throw Error('طريقة الدفع غير متاحة');}
// Season 2: ministries are activated by presidential appointment, not permanent unlock codes.
const Z39_DEPARTMENT_JOB={court:/قاض|قاضي|وزير العدل/,violations:/شرطة|الداخلية|قاض|قاضي/,education:/وزير التعليم/,telecom:/وزير الاتصالات/,ads:/رئيس الوزراء/,requests:/رئيس الوزراء/};
function z39RoleDepartments(u){if(!u)return [];if(isAdmin(u))return DEPARTMENT_KEYS;const job=String(u.job||'');return Object.entries(Z39_DEPARTMENT_JOB).filter(([k,regex])=>regex.test(job)).map(([k])=>k);}
function telecomMinister(u){return !!(u&&(isAdmin(u)||(u.role==='minister'&&u.job==='وزير الاتصالات')))}
function identityRequest(kind){return ['وثيقة رسمية','طلب إصدار هوية','طلب مراجعة بطاقة'].includes(String(kind||''))}
async function deptAccess(db,u){return z39RoleDepartments(u)}
async function hasDepartment(db,u,name){return !!u&&z39RoleDepartments(u).includes(name)}
function isStaff(u){return !!(isAdmin(u)||(u&&['minister','judge'].includes(u.role)))}
async function bootstrap(request,db){
 // Guests who have not logged in do not need a large public dump of all old avatars.
 // This also keeps new devices fast and removes the misleading 'database offline' screen.
 let u=await getMe(request,db);
 if(!u)return json({me:null,auth_required:true,users:[],version:'65.7'});
 await z76EnsureIdentityCards(db);
 let departments=await deptAccess(db,u);let [memberRows,activityRows,announcementRows,counts]=await Promise.all([
 z32PublicRead('bootstrap-users',45000,()=>db.prepare('SELECT users.id,users.name,users.role,users.rank,users.job,users.points,users.avatar,users.joined,users.identity_no,users.candidate,c.card_no FROM users LEFT JOIN z76_identity_cards c ON c.user_id=users.id WHERE NOT EXISTS(SELECT 1 FROM z64_archived_users d WHERE d.user_id=users.id AND d.restored_at=0) ORDER BY users.joined DESC LIMIT 400').all()),
 z32PublicRead('bootstrap-activity',45000,()=>db.prepare('SELECT id,name,text,created_at FROM activity ORDER BY created_at DESC LIMIT 40').all()),
 z32PublicRead('bootstrap-announcements',60000,()=>db.prepare('SELECT id,text,created_at FROM announcements ORDER BY created_at DESC LIMIT 12').all()),
 z32PublicRead('bootstrap-votes',60000,()=>db.prepare('SELECT candidate_id,COUNT(*) AS votes FROM votes GROUP BY candidate_id').all())
]);
let users=memberRows.results.map(x=>({...x,candidate:!!x.candidate}));const presenceSet=new Set((await db.prepare('SELECT user_id FROM z42_presence WHERE active=1 AND last_seen>=?').bind(Date.now()-90000).all()).results.map(x=>x.user_id));users.forEach(x=>x.online=presenceSet.has(x.id));if(u){
 let mine=await db.prepare('SELECT card_no,card_code FROM z76_identity_cards WHERE user_id=?').bind(u.id).first();
 // On a rare random collision, retry the missing user's card on this request.
 if(!mine){await z76EnsureIdentityCards(db);mine=await db.prepare('SELECT card_no,card_code FROM z76_identity_cards WHERE user_id=?').bind(u.id).first();}
 const self=users.find(x=>x.id===u.id),own={...safePublic(u),card_no:mine?.card_no||null,card_code:mine?.card_code||null};
 if(self)Object.assign(self,own);else users.unshift(own);
}
// Expose the net wallet amount (including an unpaid air-defense penalty)
// in the main citizen list and own profile without violating old CHECK(points>=0).
try{const rows=await db.prepare('SELECT user_id,amount FROM z660_air_debts WHERE amount>0').all();
 const debtById=new Map(rows.results.map(r=>[r.user_id,Number(r.amount||0)]));
 for(const member of users)member.points=Number(member.points||0)-(debtById.get(member.id)||0);
}catch(e){if(!/no such table/i.test(String(e.message||e)))throw e;}

// Images are loaded only when visible; returning 21 old base64 pictures in JSON
// overwhelmed phones and could exceed the frontend's 20-second fetch limit.
for(const member of users){
 if(/^data:image\/(?:jpeg|png|webp);base64,/i.test(String(member.avatar||''))){
   // Cache key changes when the stored picture changes, so phones don't keep an old avatar.
   const source=String(member.avatar),n=source.length;let fp=2166136261;
   for(let i=0;i<n;i+=17)fp=Math.imul(fp^source.charCodeAt(i),16777619);
   fp=Math.imul(fp^n,16777619);
   member.avatar='/api/z639/avatar?user='+encodeURIComponent(member.id)+'&v='+(fp>>>0).toString(36);
 }
}
let transactions=[],applications=[],cases=[],cards=[],myVote=null,admin_summary=null,suspensions=[],inbox_unread=0,telecom_queue=[];
const police_access=await policeGranted(db,u),prison=await prisonActive(db,u?.id);
let prison_requests=[];if(u&&(isAdmin(u)||police_access)){let q=isAdmin(u)?await db.prepare("SELECT p.*,t.name AS target_name,r.name AS requester_name,v.name AS reviewer_name FROM prison_requests p JOIN users t ON t.id=p.target_id JOIN users r ON r.id=p.requester_id LEFT JOIN users v ON v.id=p.reviewer_id ORDER BY p.created_at DESC LIMIT 120").all():await db.prepare("SELECT p.*,t.name AS target_name,r.name AS requester_name,v.name AS reviewer_name FROM prison_requests p JOIN users t ON t.id=p.target_id JOIN users r ON r.id=p.requester_id LEFT JOIN users v ON v.id=p.reviewer_id WHERE p.requester_id=? ORDER BY p.created_at DESC LIMIT 120").bind(u.id).all();prison_requests=q.results;}
if(isAdmin(u)){let [a,b,c,d,e]=await Promise.all([db.prepare('SELECT COUNT(*) AS n FROM users WHERE NOT EXISTS (SELECT 1 FROM z64_archived_users ax WHERE ax.user_id=users.id AND ax.restored_at=0)').first(),db.prepare("SELECT COUNT(*) AS n FROM users WHERE role IN ('president','admin','minister','judge') AND NOT EXISTS(SELECT 1 FROM z64_archived_users ax WHERE ax.user_id=users.id AND ax.restored_at=0)").first(),db.prepare("SELECT COUNT(*) AS n FROM cases WHERE status='confirmed'").first(),db.prepare('SELECT SUM(points) AS n FROM users WHERE NOT EXISTS(SELECT 1 FROM z64_archived_users ax WHERE ax.user_id=users.id AND ax.restored_at=0)').first(),db.prepare("SELECT COUNT(*) AS n, SUM(CASE WHEN status='pending' THEN 1 ELSE 0 END) AS pending FROM applications").first()]);admin_summary={users:a?.n||0,jobs:b?.n||0,violations:c?.n||0,points:d?.n||0,requests:e?.n||0,pending:e?.pending||0};let seen=await db.prepare('SELECT last_seen_at FROM admin_inbox_seen WHERE user_id=?').bind(u.id).first(),since=Number(seen?.last_seen_at||0), unread=await db.prepare('SELECT (SELECT COUNT(*) FROM econ_requests WHERE created_at>?) + (SELECT COUNT(*) FROM applications WHERE created_at>?) + (SELECT COUNT(*) FROM cases WHERE created_at>?) + (SELECT COUNT(*) FROM prison_requests WHERE created_at>?) AS n').bind(since,since,since,since).first();inbox_unread=Number(unread?.n||0);let sus=await db.prepare('SELECT * FROM suspensions WHERE until_at>?').bind(Date.now()).all();suspensions=sus.results;}
if(u){let cond=isAdmin(u)?'1=1':'user_id=?';let bind=isAdmin(u)?[]:[u.id];let [t,a,c,b,v]=await Promise.all([
 db.prepare('SELECT * FROM transactions WHERE user_id=? ORDER BY created_at DESC LIMIT 100').bind(u.id).all(),
 (isAdmin(u)||departments.includes('requests')?db.prepare('SELECT * FROM applications ORDER BY created_at DESC LIMIT 150').all():db.prepare('SELECT * FROM applications WHERE user_id=? ORDER BY created_at DESC LIMIT 150').bind(u.id).all()),
 (isAdmin(u)||departments.includes('court')||departments.includes('violations')?db.prepare('SELECT * FROM cases ORDER BY created_at DESC LIMIT 100').all():db.prepare('SELECT * FROM cases WHERE user_id=? OR target_id=? ORDER BY created_at DESC LIMIT 100').bind(u.id,u.id).all()),
 db.prepare('SELECT * FROM cards WHERE user_id=? ORDER BY created_at DESC').bind(u.id).all(),
 db.prepare('SELECT candidate_id FROM votes WHERE voter_id=?').bind(u.id).first()
]);transactions=t.results;applications=a.results;cases=c.results;cards=b.results;myVote=v?.candidate_id;}
 if(telecomMinister(u)){let q=await db.prepare("SELECT a.id,a.kind,a.detail,a.status,a.created_at,u.name AS user_name FROM applications a JOIN users u ON u.id=a.user_id WHERE a.kind IN ('وثيقة رسمية','طلب إصدار هوية','طلب مراجعة بطاقة') ORDER BY a.created_at DESC LIMIT 90").all();telecom_queue=q.results;}
 let votes=[];for(const row of counts.results){for(let i=0;i<Math.min(Number(row.votes),3000);i++)votes.push({voter_id:`anonymous-vote-${row.candidate_id}-${i}`,candidate_id:row.candidate_id})}if(u&&myVote){let existing=votes.find(x=>x.candidate_id===myVote);if(existing)existing.voter_id=u.id;else votes.push({voter_id:u.id,candidate_id:myVote})}
const [pubApplications,pubCases,pubEconomy,pubNumbers]=await z32PublicRead('bootstrap-public-dashboard',90000,()=>Promise.all([
 db.prepare('SELECT status,COUNT(*) AS n FROM applications GROUP BY status').all(),
 db.prepare('SELECT status,COUNT(*) AS n FROM cases GROUP BY status').all(),
 db.prepare("SELECT status,COUNT(*) AS n FROM econ_requests WHERE kind IN ('land','loan') GROUP BY status").all(),
 db.prepare("SELECT (SELECT COUNT(*) FROM users WHERE NOT EXISTS(SELECT 1 FROM z64_archived_users ax WHERE ax.user_id=users.id AND ax.restored_at=0)) AS users,(SELECT COUNT(*) FROM users WHERE role IN ('president','admin','minister','judge') AND NOT EXISTS(SELECT 1 FROM z64_archived_users ax WHERE ax.user_id=users.id AND ax.restored_at=0)) AS jobs,(SELECT COUNT(*) FROM cases WHERE status='confirmed') AS violations,(SELECT COALESCE(SUM(points),0) FROM users WHERE NOT EXISTS(SELECT 1 FROM z64_archived_users ax WHERE ax.user_id=users.id AND ax.restored_at=0)) AS points,(SELECT COUNT(*) FROM applications) AS requests,(SELECT COUNT(*) FROM applications WHERE status='pending') AS pending").first()
]));
const aggregate=r=>Object.fromEntries(r.results.map(row=>[row.status,Number(row.n)]));
const public_dashboard={applications:aggregate(pubApplications),cases:aggregate(pubCases),economy:aggregate(pubEconomy)};
const public_summary={users:pubNumbers.users,jobs:pubNumbers.jobs,violations:pubNumbers.violations,points:pubNumbers.points,requests:pubNumbers.requests,pending:pubNumbers.pending};
const federation_governor=u?await db.prepare('SELECT id,name FROM z46_provinces WHERE governor_id=? LIMIT 1').bind(u.id).first():null;
const economy=await economyBootstrap(db,u),state_economy=await stateEconomySummary(db),war_announce=await db.prepare('SELECT emergency_until FROM z_war_state WHERE id=1').first();const war_emergency_until=Number(war_announce?.emergency_until||0);const site_maintenance=isAdmin(u)?await isMaintenance(db):false;return json({site_maintenance,federation_governor,me:u?.id||null,admin_access:isAdmin(u),department_access:departments,inbox_unread,admin_summary,public_summary,public_dashboard,suspensions,telecom_manage:telecomMinister(u),telecom_queue,police_access,prison,prison_requests,users,activity:activityRows.results,announcements:announcementRows.results,transactions,applications,cases,cards,votes,economy,state_economy,war_emergency_until,version:Z41_BUILD});
}
async function auth(req,db,p){const intent=p.intent;if(intent!=='logout')return err(410,'تسجيل الحسابات متاح الآن بنظام Guest من 1 إلى 30 فقط.');if(intent==='logout'){let token=cookieValue(req,'zangar_session');if(token){await db.prepare('DELETE FROM sessions WHERE token_hash=?').bind(await digest(token)).run()}return json({ok:true},200,{'Set-Cookie':sessionCookie('',0)})}
let name=crop(p.name,35),name_key=norm(name),password=String(p.password??''),proof=String(p.proof??''),proofSalt=String(p.salt??'');
 if(!name_key)return err(400,'اكتب اسم المواطن.');
 const validProof=/^[a-f0-9]{64}$/.test(proof);
 if(intent==='register'&&(!validProof||!/^[a-f0-9]{32}$/.test(proofSalt)))return err(400,'نسخة التسجيل عندك قديمة؛ حدّث صفحة الموقع وجرب تاني.');

let user;if(intent==='register'){if(name.length!==String(p.name??'').trim().length)return err(400,'الاسم طويل جدًا');let existing=await db.prepare('SELECT id FROM users WHERE name_key=?').bind(name_key).first();if(existing)return err(409,'اسم المواطن مستخدم بالفعل');let now=Date.now(),uid=id(),s=proofSalt,h='v2:'+await digest('zangar-v2|'+s+'|'+proof);let identity='ZN-'+String(Math.floor(100000000+Math.random()*900000000));try{await db.prepare('INSERT INTO users(id,name,name_key,passhash,salt,role,rank,job,points,identity_no,joined) VALUES (?,?,?,?,?,?,?,?,?,?,?)').bind(uid,name,name_key,h,s,'citizen','مواطن','مواطن',0,identity,now).run()}catch{return err(409,'تعذر إنشاء الحساب، جرّب اسمًا آخر')}
/* Season 2: registration starts at zero; citizen earns first allowance through hourly claim. */await activity(db,name,'انضم إلى دولة الزنجر الجديدة',now);user={id:uid,name};}
else if(intent==='login'){
 let row=await db.prepare('SELECT id,name,salt,passhash FROM users WHERE name_key=?').bind(name_key).first();
 if(!row)return err(401,'اسم المواطن أو كلمة المرور غير صحيحة');
 let valid=false;
 if(row.passhash.startsWith('v2:')){
  if(!validProof)return err(400,'الرجاء تحديث صفحة الدخول والمحاولة مرة أخرى.');
  valid=row.passhash==='v2:'+await digest('zangar-v2|'+row.salt+'|'+proof);
 }else{
  // One-time migration for pre-Update-5 accounts. No expensive hash work on Workers Free.
  if(!validProof)return err(400,'حدّث صفحة الدخول وحاول مرة أخرى.');
  valid=row.passhash===proof;
  if(valid){
   const upgraded='v2:'+await digest('zangar-v2|'+row.salt+'|'+proof);
   await db.prepare('UPDATE users SET passhash=? WHERE id=? AND passhash=?').bind(upgraded,row.id,row.passhash).run();
  }
 }
 if(!valid)return err(401,'اسم المواطن أو كلمة المرور غير صحيحة');user=row;
 }else return err(400,'طلب غير صالح');
let token=hex(crypto.getRandomValues(new Uint8Array(32))),h=await digest(token),now=Date.now();await db.prepare('INSERT INTO sessions(token_hash,user_id,expires_at) VALUES(?,?,?)').bind(h,user.id,now+SESSION_LIFETIME).run();return json({ok:true},200,{'Set-Cookie':sessionCookie(token)})}

// V63.9 — Thirty server-owned guest slots. Only randomized password verifiers ship to the Worker.
// NEVER include plaintext passwords in public static files, assets or the deploy archive.
const Z639_SLOT_SEEDS = [[1,"95cceec4eabf5cd7610cb860cc570309","v2:92175bbb2a6a36bba524187f75c2ab6961849026970f39f22fafd635e8b53d71"],[2,"7de4be78dad4967575401fcc77fc2bfd","v2:e8852f6f8f37a8b514e9d731cd614398cc1285085746b0b0b32e7a610480dbd6"],[3,"2d7965b1ed970bb2ee65a7930cd00afc","v2:8f4c30607a8ee78ddf3c101493e1efbcb4a863c750e75528b5ac2d5f80462f42"],[4,"06b681a956f05c05cb6321b307036c85","v2:e4a2d51c3f8f7569176a4f333a7bfcbccbc230aabee1258b0544fbb269742f8c"],[5,"0bfa85af656e4d687522344ae393a9ef","v2:ea8fe9bd6237556db582166efcd1870a8890455a262e5a433c779c351ab75b94"],[6,"71f8086589a8c7395179590d3b7934d9","v2:06851af4592a5a26edc522a484760392a0b6044f68e79cd9ee075ab37aaad3e5"],[7,"500470de8d7685d0746c15d901d7f26c","v2:428a901e0af97926f5c9753c020292cfe9e0c819db8b56cbc172add6ae1c7754"],[8,"b26ed7f477e2eb1b86474f573e90a0a4","v2:332630db0be8342ba677221c965abbad27ba9ea6a23a0d2ed170ffc98d22a50c"],[9,"6b03f258b7bcd9787bc008130ce25e4b","v2:f63b7d81300e83afa3326a35df8bfdcabcc70a8dc4843f3d3edebff1c6344faa"],[10,"c6325acb8ee5a3bae854c40ed79da179","v2:617aa72a4002dab9994ba63e3aa73141cefdaf267196f8405bcc809351011769"],[11,"68f313c7516007d14f5d200f31cf5aea","v2:f7905b146bdb073cc55f094a297d4aa2826b60b09d74da4e752526aff237fe1c"],[12,"159af88e73c819b6ef51699c25b190c9","v2:cb4bf09b6b149c8bac07efe53d0f15bcada013ae12882defd8901b99cf50058f"],[13,"daac20af3f5934e2a273237a2dcd06a2","v2:052f7c8c5b6db76b79f54eff8f0992b0a7ecee13bf151ff4d21acfc1d2f42e26"],[14,"55d36db00cfdb5333f1ce157f0c4128a","v2:ca7af2c2e7a8cb0e052eaea8f56a17546b613d052e14fde49fa8b1a8b5fae394"],[15,"431dc20662e6c73186af62d4ee19f436","v2:4670cc10289e5021d6e2782fbfe868de858cad1932d3aa037680e2922ff01fbc"],[16,"ef1992d1ef74dda586d922a6610cee6c","v2:383535efa68129adfff857eb3a3440cc750322d91df415aebb4ad084cb87c90c"],[17,"c1fad2a4396847225c02630f1b280c8b","v2:a667e70d2777702d29648eb98f7e4c895fc1f6b8a71a7b66ea87e75d472449e9"],[18,"53d139948cc34e4a6a8075393c2f5cb0","v2:9c8b944341f956fb97d4b74529014cd40b0c3513da76e4157c178cfb4d9ae15b"],[19,"a39b302bca8e822cbaac7da8395e38c2","v2:2316209c27876bcd5e8f5eaff0004c71780eed32d7eca09291324d8e05065e7a"],[20,"20ffce12871fc8d123c47943edd349fb","v2:87b997c177fc9a41186fbc9c817949e77e863504d2cc08ad103fd0d94c572a35"],[21,"5ad99e16c67ffefab3fa3a683b18a1bb","v2:ce124768ff86f88ec5e6bb01df37c8b1b8efafc1223007fda5ed5344d315a8be"],[22,"43295287fa585ca4fd989c3de271d508","v2:e08a9ba811c21124a51f9a4e7f8c42dbda23a30011257fbf7e0618e1bfe29488"],[23,"bbb844310374e94382c491a5b4e44427","v2:c95e0a349b1dd75f03d5e54e5f658a54616ddc8a9dcac49bc65aff33a6b13016"],[24,"295b91c0433b2a50f2050286d74322be","v2:04ee358742b0cfbd2b75b6ae810e827bd7bcd3e5c59b358930c69429a8fdaf50"],[25,"117e6b07fc0a2287d609625113975498","v2:5de70c4ebd505014a6f998c5c06708d0a3d52e4187585a17a2d42f1e9fc65233"],[26,"f69739ff7c63fa5ea9bb27079f5998de","v2:9fd8f034542bb03a594d6eabedd8b5a3a27ae4f1f990eea048fcc831e5802a7c"],[27,"db4f330fdbbb4d9d018fd353a584e48a","v2:8eb17de4a72f11497a281926072708e988307a6c56b1aab238544d9a3af36444"],[28,"82046a19e9d3d240339528219bcb14fd","v2:816c26ed578cfe4cf869f5cc8ac0a14b99e04eb6be3ea9f406f3e80b72f7ac37"],[29,"f7e05dbfce24f92461fc3a533cd97205","v2:3b4c6cf43a012366cf953c8ccf9a1cc0761d6f77f3efe5c8b09eaae702c57b08"],[30,"4e9427e2d174a04202e1405c46ec1d60","v2:f905bd5942404fa7fafdec357578c75f886cc3a70aa245f36a518e2023fe5d0f"]];
// Backup verifiers for old Guest credentials. Only salted PBKDF2 hashes are embedded,
// never plaintext passwords. This supports browsers that cannot generate the old 160k proof.
const Z639_PASSWORD_FALLBACK_100K={"1":"242fcd9aae9e8132e679e9c7343bfa5526683d7ad1f980d7661c5c4ab7fb8539","2":"bb2191012af55c6757be3592edbc2184c74960b285dd977c45a6f0d82730d2ca","3":"ad5a89eb5bfeb49cf522a0fac4a42c51312defdd0633306f322e412969cf31b8","4":"44e48a70ee1961a382070d959330a08717a49fb20d0d83a45a5c9c951cb1cbcb","5":"bccf2a3fb33bc35143c9b87136fc8cc27f2129cfefd210411a7f61030091b8f1","6":"861915d6174f442e6396331b45406280128594493b8f8f287d29090654e2248c","7":"b502b7b66a7fec90efbfd394ef2792595ab7946a49d06376384e37edbc68f350","8":"0373d02cf7394ff11fc894bc3631433031025ae3b555c5a9ab92e22040bf3dd6","9":"a88981045cc7a09a492f6f583d243a1d790b8b9b39653da0860c11ca56f84bd6","10":"4f95b8ab1e52085cc7f05770c40e1a4da7e4fbfeed58b3cac05975ae223554c0","11":"da0a57bad9fd8e6be1146f91ab7bf8f446492401232c97a9da8b3b2fc16152cf","12":"b1c52a7deea91a3c1751fe80a8e522cc7215c2a8fbc2f9f20d11273e621017b5","13":"7e87445ba8b190f181ff5a4f3b90f04e8c612e3dd7265ae3a95ceab2b08d12c5","14":"4b5bcb65ce53d13121fce5ca0187f4ec00bd3fa91907ec749ddd61edb170dd03","15":"83765770d532d5a34d127158129a6b3b90ed51b6fbecf91af868a63446970f45","16":"476dfe7cdf697ca5c55f9080f3953936a79f07ae906924bda7dd652251b1614f","17":"488491fdd81ab197cd3b849d033a6507dea1cc33eea62580e450fe187c4af8b6","18":"0959c2a57f713b1456df299a597e9e89eee0368ce3a37f929a49ca01fbb2d14b","19":"bfe6cb01e14faa84662e6d3cc461c1cc5780c56d1d95dfc49c1f1172b3d47db8","20":"dfc47dc90ca2601fc422170016f0f8292cdf354103d51e315712327867d3a2d8","21":"6a19910173f903d001277cbb9d726d820614a764684ab34b59c2a4eb49499b79","22":"f58e62379ea8a6cc2d5b218a419e97ead46f0c891f9e8b136f3af24a3a4c3674","23":"fb3db7fa1434b299c5086ab796bf758d44908846869e31ac49f942eb48dde807","24":"8f254acba3d606e1c5f509f41c692c625d0dab63bee2f11a526458a26c6014fa","25":"afaf5a258456c0457d3ab477669bce75562e17b44b76f1311d892225029730fc","26":"fef698877d638776c88d18a7e286e9b0d142407b2c5c35dd7147578932a80aa7","27":"d227bb22535a064711861d53917d3c3efdc7206a6a81d0c8963c54a4aee9029a","28":"a1513ece9a2bb0a4b5fa0bff67edac6197e9349a9476c10b0cd10e360dcd847e","29":"a83ca5be1d2373a74d55a283e878704f8f3164778e3374ca9f67b6c13bf372e8","30":"452566be9355087177abe9dd4f6b9992481d3dfa9c50ecfa05ad6977ee7d2a23"};
let z639TablesReady=false;
async function z639Ensure(db){
 await db.batch([
  db.prepare('CREATE TABLE IF NOT EXISTS z639_guest_slots(slot INTEGER PRIMARY KEY CHECK(slot BETWEEN 1 AND 30),salt TEXT NOT NULL,proof_hash TEXT NOT NULL,user_id TEXT UNIQUE,claimed_at INTEGER NOT NULL DEFAULT 0)'),
  db.prepare('CREATE TABLE IF NOT EXISTS z639_attempts(key TEXT PRIMARY KEY,failures INTEGER NOT NULL DEFAULT 0,blocked_until INTEGER NOT NULL DEFAULT 0,updated_at INTEGER NOT NULL DEFAULT 0)')
 ]);
 // V63.9.3: Rotate ALL 30 Guest passwords to the owner's newly chosen credentials.
 // Keep the original user_id and claimed_at; never delete citizens, wallets or assets.
 // Revoke only sessions belonging to Guest accounts, so old passwords/sessions expire.
 // site_settings marker + D1 db.batch makes this an idempotent, atomic migration.
 const check=await db.prepare("SELECT value FROM site_settings WHERE key='z639_credentials_v6393'").first();
 if(check?.value==='1')return;
 const statements=Z639_SLOT_SEEDS.map(([slot,s,hash])=>db.prepare(`
  INSERT INTO z639_guest_slots(slot,salt,proof_hash) VALUES(?,?,?)
  ON CONFLICT(slot) DO UPDATE SET salt=excluded.salt,proof_hash=excluded.proof_hash
 `).bind(slot,s,hash));
 const now=Date.now();
 statements.push(db.prepare('DELETE FROM sessions WHERE user_id IN (SELECT user_id FROM z639_guest_slots WHERE user_id IS NOT NULL)'));
 statements.push(db.prepare("INSERT INTO site_settings(key,value,updated_at) VALUES('z639_credentials_v6393','1',?) ON CONFLICT(key) DO UPDATE SET value='1',updated_at=excluded.updated_at").bind(now));
 await db.batch(statements);
}
async function z639PublicSlots(db){
 await z639Ensure(db);
 const counts=await db.prepare('SELECT MIN(CASE WHEN user_id IS NULL THEN slot END) AS next_slot, COUNT(CASE WHEN user_id IS NOT NULL THEN 1 END) AS claimed, COUNT(*) AS total FROM z639_guest_slots').first();
 return json({version:'64',next_slot:counts?.next_slot||null,claimed:Number(counts?.claimed||0),total:Number(counts?.total||30),max:30});
}
async function z639Challenge(db,req){
 await z639Ensure(db);
 const slot=Number(new URL(req.url).searchParams.get('slot'));
 if(!Number.isInteger(slot)||slot<1||slot>30)return err(400,'اختار رقم Guest من 1 إلى 30');
 const row=await db.prepare('SELECT slot,salt,proof_hash,user_id FROM z639_guest_slots WHERE slot=?').bind(slot).first();
 if(!row)return err(404,'رقم Guest غير موجود');
 const canonical=Z639_SLOT_SEEDS.find(item=>item[0]===slot);
 return json({slot,salt:row.salt,claimed:!!row.user_id,credential_ready:!!canonical&&row.salt===canonical[1]&&row.proof_hash===canonical[2]});
}
async function z639Avatar(req,db){
 const user=await getMe(req,db);
 if(!user)return err(401,'سجل دخولك لعرض صورة المواطن');
 const id=String(new URL(req.url).searchParams.get('user')||'');
 if(!/^[0-9a-f-]{36}$/i.test(id))return err(400,'معرف الصورة غير صالح');
 const row=await db.prepare('SELECT avatar FROM users WHERE id=? LIMIT 1').bind(id).first();
 const match=/^data:image\/(jpeg|png|webp);base64,([a-zA-Z0-9+/=]+)$/.exec(row?.avatar||'');
 if(!match)return new Response(null,{status:404});
 const bytes=Uint8Array.from(atob(match[2]),c=>c.charCodeAt(0));
 if(bytes.length>1500000)return new Response(null,{status:413});
 return new Response(bytes,{headers:{'Content-Type':'image/'+match[1],'Cache-Control':'private, max-age=300','X-Content-Type-Options':'nosniff'}});
}
async function z639GuestEnter(req,db,p){
 await z639Ensure(db);
 // V63.9.4 compatibility repair: accept the browser PBKDF2 proof AND a TLS-only
 // password fallback. The old error mixed an invalid Guest slot with a missing
 // proof; a user could receive 'bad password' before we ever compared the hash.
 // Never log, return, or store the plaintext password.
 const slot=Number(p.slot),suppliedProof=String(p.proof||'').trim().toLowerCase(),now=Date.now();
 if(!Number.isInteger(slot)||slot<1||slot>30)return err(400,'رقم Guest الذي وصل للسيرفر غير صحيح (يجب أن يكون من 01 إلى 30)');
 const raw=typeof p.password==='string'?p.password.replace(/[\u200B-\u200D\uFEFF]/g,'').trim():'';
 const validProof=/^[a-f0-9]{64}$/.test(suppliedProof);
 const validRaw=raw.length>=4&&raw.length<=100;
 if(!validProof&&!validRaw)return err(400,'نسخة صفحة الدخول قديمة أو رمز التحقق لم يصل؛ افتح صفحة الموقع الرئيسية مجددًا');
 const ip=String(req.headers.get('CF-Connecting-IP')||'unknown').slice(0,90);
 const key=await digest('z639:attempts:'+slot+':'+ip);
 const attempts=await db.prepare('SELECT failures,blocked_until FROM z639_attempts WHERE key=?').bind(key).first();
 if(Number(attempts?.blocked_until||0)>now)return err(429,'محاولات كثيرة؛ جرّب بعد 15 دقيقة');
 const slotRow=await db.prepare('SELECT * FROM z639_guest_slots WHERE slot=?').bind(slot).first();
 if(!slotRow)return err(404,'رقم Guest غير موجود');
 if(!slotRow.user_id)return err(403,'تسجيل الحساب الجديد يتم من صفحة طلب الانضمام بعد اختيار كلمة مرورك وموافقة الرئاسة');
 const guestAccount=await db.prepare('SELECT passhash FROM users WHERE id=?').bind(slotRow.user_id).first();
 if(!guestAccount || guestAccount.passhash!=='guest-slot-managed')return err(403,'الحسابات الجديدة تدخل بالاسم وكلمة المرور الشخصية فقط');
 // Fast path retains the original client-side PBKDF2 protocol.
 // Fallback handles a stale/malformed browser proof using the password
 // submitted only over HTTPS in the POST body. No plaintext reaches D1.
 let verified=validProof&&('v2:'+await digest('zangar-v2|'+slotRow.salt+'|'+suppliedProof))===slotRow.proof_hash;
 if(!verified&&validRaw){
  const canonical=Z639_SLOT_SEEDS.find(x=>x[0]===slot);
  if(canonical&&canonical[1]===slotRow.salt&&canonical[2]===slotRow.proof_hash){
   verified=eqSecure(await pwHash(raw,slotRow.salt),Z639_PASSWORD_FALLBACK_100K[slot]||'');
  }
 }
 if(!verified){
  const failure=Number(attempts?.failures||0)+1;
  const until=failure>=6?now+15*60*1000:0;
  await db.prepare('INSERT INTO z639_attempts(key,failures,blocked_until,updated_at) VALUES(?,?,?,?) ON CONFLICT(key) DO UPDATE SET failures=excluded.failures,blocked_until=excluded.blocked_until,updated_at=excluded.updated_at').bind(key,failure>=6?0:failure,until,now).run();
  return err(401,'كلمة مرور Guest غير صحيحة');
 }
 await db.prepare('DELETE FROM z639_attempts WHERE key=?').bind(key).run();
 let userId=slotRow.user_id,created=false;
 if(!userId){
  const name=crop(p.name,35),avatar=String(p.avatar||'');
  if(name.length<2||name.length>35||name!==String(p.name||'').trim())return err(400,'اكتب اسمًا من حرفين إلى 35 حرفًا');
  if(avatar&&(!/^data:image\/jpeg;base64,[A-Za-z0-9+/]+={0,2}$/.test(avatar)||avatar.length>58000))return err(400,'الصورة غير مدعومة أو كبيرة؛ اختر صورة أصغر');
  const uid=id(),identity='ZG-GUEST-'+String(slot).padStart(2,'0')+'-'+crypto.randomUUID().slice(0,8);
  try{
   await db.prepare("INSERT INTO users(id,name,name_key,passhash,salt,role,rank,job,points,identity_no,joined,avatar) VALUES(?,?,?,?,?,'citizen','مواطن','مواطن',0,?,?,?)").bind(uid,name,norm(name),'guest-slot-managed',slotRow.salt,identity,now,avatar).run();
  }catch(e){return err(409,'الاسم مستخدم بالفعل؛ اختار اسم مختلف');}
  const claimed=await db.prepare('UPDATE z639_guest_slots SET user_id=?,claimed_at=? WHERE slot=? AND user_id IS NULL RETURNING slot').bind(uid,now,slot).first();
  if(!claimed){
   await db.prepare('DELETE FROM users WHERE id=?').bind(uid).run();
   return err(409,'هذا الحساب اتسجل في نفس اللحظة من جهاز آخر؛ افتح لديّ حساب');
  }
  userId=uid;created=true;
  await activity(db,name,'انضم للدولة عبر Guest '+slot,now);
 }else{
  const exists=await db.prepare('SELECT id FROM users WHERE id=?').bind(userId).first();
  if(!exists)return err(503,'الحساب يحتاج مراجعة المسؤول؛ لم يتم إنشاء حساب بديل');
 }
 const token=hex(crypto.getRandomValues(new Uint8Array(32)));
 await db.prepare('INSERT INTO sessions(token_hash,user_id,expires_at) VALUES(?,?,?)').bind(await digest(token),userId,now+SESSION_LIFETIME).run();
 return json({ok:true,slot,created},200,{'Set-Cookie':sessionCookie(token)});
}

async function stateSettingGet(db,key,defaultValue=''){const row=await db.prepare('SELECT value FROM site_settings WHERE key=?').bind(key).first();return row?String(row.value):defaultValue;}
async function stateSettingSet(db,key,value){await db.prepare('INSERT INTO site_settings(key,value,updated_at) VALUES(?,?,?) ON CONFLICT(key) DO UPDATE SET value=excluded.value,updated_at=excluded.updated_at').bind(key,String(value),Date.now()).run();}
async function zTreasuryBalance(db){const r=await db.prepare('SELECT balance FROM z_state_treasury WHERE id=1').first();return Number(r?.balance??10000000)}
async function zTreasuryLedger(db,delta,reason,actor,now=Date.now()){
 await db.prepare('INSERT INTO z_state_ledger(id,delta,reason,actor,created_at) VALUES(?,?,?,?,?)').bind(id(),delta,crop(reason,110),crop(actor||'الدولة',60),now).run();
}
async function zTreasurySpend(db,amount,reason,actor='الدولة',now=Date.now()){
 amount=Math.trunc(amount);if(!Number.isSafeInteger(amount)||amount<1)throw Error('مبلغ الخزينة غير صحيح');
 const done=await db.prepare('UPDATE z_state_treasury SET balance=balance-? WHERE id=1 AND balance>=? RETURNING balance').bind(amount,amount).first();
 if(!done)throw Error('خزينة الدولة لا تكفي لهذه العملية');
 await zTreasuryLedger(db,-amount,reason,actor,now);return done.balance;
}
async function zTreasuryPay(db,userId,amount,reason,actor='الدولة',now=Date.now()){
 if(/^(صافي أرباح|دخل إيجار المنزل|بيع .* في سوق الدولة|الفوز في لعبة توصيل|جائزة زنجر فلاي|أجر وظيفة)/.test(reason)){
   await db.prepare('UPDATE users SET points=points+? WHERE id=?').bind(amount,userId).run();
   await addTx(db,userId,amount,reason+' (إصدار مكافأة لعبة)',now);return;
 }
 await zTreasurySpend(db,amount,reason,actor,now);
 await db.prepare('UPDATE users SET points=points+? WHERE id=?').bind(amount,userId).run();
 await addTx(db,userId,amount,reason,now);
}
async function zTreasuryReceive(db,amount,reason,actor='الدولة',now=Date.now()){
 amount=Math.trunc(amount);if(!Number.isSafeInteger(amount)||amount<1)return;
 await db.prepare('UPDATE z_state_treasury SET balance=balance+? WHERE id=1').bind(amount).run();
 await zTreasuryLedger(db,amount,reason,actor,now);
}
async function stateEconomyAdd(db,amount,reason,actor,now=Date.now()){amount=Math.max(0,Math.ceil(Number(amount)||0));if(!amount)return;await zTreasuryReceive(db,amount,reason,actor,now);const total=Number(await stateSettingGet(db,'state_economy_total','0')||0)+amount;let changes=[];try{changes=JSON.parse(await stateSettingGet(db,'state_economy_log','[]')||'[]');if(!Array.isArray(changes))changes=[];}catch{changes=[]}
 changes.unshift({amount,reason:crop(reason,120),actor:crop(actor,50),created_at:now});changes=changes.slice(0,30);await stateSettingSet(db,'state_economy_total',String(total));await stateSettingSet(db,'state_economy_log',JSON.stringify(changes));}
async function stateEconomySummary(db){const total=Number(await stateSettingGet(db,'state_economy_total','0')||0);let changes=[];try{changes=JSON.parse(await stateSettingGet(db,'state_economy_log','[]')||'[]');if(!Array.isArray(changes))changes=[];}catch{changes=[]}
 const dayAgo=Date.now()-86400000,growth24h=changes.filter(x=>Number(x.created_at||0)>=dayAgo).reduce((s,x)=>s+Number(x.amount||0),0);return {total,growth24h,rate:10,changes,treasury:await zTreasuryBalance(db)};}

async function spend(db,u,amount,note,method){
 await visaPayment(db,u,method);
 amount=Math.ceil(amount);
 if(!Number.isInteger(amount)||amount<=0)throw Error('مبلغ شراء غير صالح');
 const stateTax=Math.max(1,Math.ceil(amount*(await z78TaxRate(db,u)))),total=amount+stateTax,now=Date.now();
 let res=await db.prepare('UPDATE users SET points=points-? WHERE id=? AND points>=? RETURNING points').bind(total,u.id,total).first();
 if(!res)throw Error('رصيد النقاط غير كافٍ');
 await addTx(db,u.id,-total,note+(stateTax?` + دعم اقتصاد الدولة ${stateTax} نقطة`:''),now);
 await stateEconomyAdd(db,stateTax,note,u.name,now);
 if(method==='visa'){const card=await db.prepare("SELECT p.card_id,p.tier FROM z_card_profiles p JOIN cards c ON c.id=p.card_id WHERE p.user_id=? AND c.kind='فيزا' ORDER BY p.created_at DESC LIMIT 1").bind(u.id).first();const rate=ZCARD_TIERS[card?.tier]?.rate||0;if(card&&rate){await db.prepare('UPDATE z_card_profiles SET cashback=cashback+? WHERE card_id=?').bind(Math.floor(amount*rate/100),card.card_id).run();}}
}
async function action(req,db,p){const u=await getMe(req,db);if(!u)return err(401,'سجل حسابك أولًا');const type=p.type,now=Date.now();const admin=isAdmin(u);let target;const suspension=await db.prepare('SELECT until_at FROM suspensions WHERE user_id=?').bind(u.id).first();if(!admin&&suspension?.until_at>now)throw Error('عضويتك متوقفة مؤقتًا حتى '+new Date(suspension.until_at).toLocaleString('ar-EG'));
if(await prisonActive(db,u.id,now))throw Error('أنت في السجن حاليًا: يمكنك مشاهدة الدولة فقط، ولا يمكنك تنفيذ أي عمليات حتى انتهاء المدة.');
switch(type){
case 'claim':{let penaltyRow=await db.prepare('SELECT penalty FROM grant_penalties WHERE user_id=?').bind(u.id).first();let amount=Math.max(50,500-Math.min(450,Number(penaltyRow?.penalty||0)));const ready=await db.prepare('SELECT claim_at FROM users WHERE id=?').bind(u.id).first();if(Number(ready?.claim_at||0)>now-3600000)throw Error('المنحة غير جاهزة بعد. انتظر مرور ساعة.');let result=await db.prepare('UPDATE users SET points=points+?,claim_at=? WHERE id=? AND claim_at<=? RETURNING points').bind(amount,now,u.id,now-3600000).first();if(!result)throw Error('المنحة غير جاهزة بعد');await db.prepare('DELETE FROM grant_penalties WHERE user_id=?').bind(u.id).run();await addTx(db,u.id,amount,'منحة الدولة كل ساعة — إصدار زنجر 500 من النظام',now);try{await activity(db,u.name,'استلم منحة '+amount+' زنجر',now);await zNotify(db,u.id,'منحة الساعة','وصلت منحتك: '+amount+' زنجر','money')}catch(noteErr){console.warn('Grant issued; notification failed',noteErr?.message)}break;}
case 'profile':{let name=crop(p.name,35),key=norm(name),dob=crop(p.dob,10),bio=crop(p.bio,100);if(!key)throw Error('اكتب اسم المواطن');if(dob&&!/^\d{4}-\d{2}-\d{2}$/.test(dob))throw Error('تاريخ الميلاد غير صحيح');try{await db.prepare('UPDATE users SET name=?,name_key=?,dob=?,bio=? WHERE id=?').bind(name,key,dob,bio,u.id).run()}catch{throw Error('هذا الاسم مستخدم بالفعل')}try{await activity(db,name,'حدّث بيانات الهوية',now)}catch(auditErr){console.warn('Profile saved; audit failed',auditErr?.message)}break;}
case 'avatar':{let avatar=String(p.avatar||'');if(avatar.length>130000||!/^data:image\/jpeg;base64,[A-Za-z0-9+/=]+$/.test(avatar))throw Error('صيغة الصورة غير مدعومة');await db.prepare('UPDATE users SET avatar=? WHERE id=?').bind(avatar,u.id).run();try{await activity(db,u.name,'حدّث الصورة الشخصية',now)}catch(auditErr){console.warn('Avatar saved; audit failed',auditErr?.message)}break;}
case 'premium':{let rank=crop(p.rank,30);if(!['مقيم متميز','مواطن ++'].includes(rank)||rank===u.rank)throw Error('الرتبة غير متاحة');let cost=rank==='مواطن ++'?50:20;await spend(db,u,Math.ceil(cost*1.1),'شراء رتبة '+rank,p.payment_method);await db.prepare('UPDATE users SET rank=? WHERE id=?').bind(rank,u.id).run();await activity(db,u.name,'حصل على صفة '+rank,now);break;}
case 'newcard':{let kind=crop(p.kind,30);if(!['فيزا','ماستركارد'].includes(kind))throw Error('نوع البطاقة غير متاح');await spend(db,u,Math.ceil((kind==='ماستركارد'?150:100)*1.1),'إصدار بطاقة افتراضية '+kind,p.payment_method);let no='4000 '+Array.from({length:3},()=>String(Math.floor(1000+Math.random()*9000))).join(' ');await db.prepare('INSERT INTO cards(id,user_id,kind,number,created_at) VALUES(?,?,?,?,?)').bind(id(),u.id,kind,no,now).run();await activity(db,u.name,'أصدر بطاقة افتراضية',now);break;}
case 'transfer':{await visaPayment(db,u,p.payment_method);let amt=num(p.amount),recipient=crop(p.to,75);if(!Number.isInteger(amt)||amt<1||amt>100000||recipient===u.id)throw Error('مبلغ التحويل غير صالح');target=await db.prepare('SELECT id,name FROM users WHERE id=?').bind(recipient).first();if(!target)throw Error('المستلم غير موجود');let balance=await db.prepare('SELECT points FROM users WHERE id=?').bind(u.id).first();if(balance.points<amt)throw Error('رصيدك لا يكفي');try{await db.batch([db.prepare('UPDATE users SET points=points-? WHERE id=?').bind(amt,u.id),db.prepare('UPDATE users SET points=points+? WHERE id=?').bind(amt,recipient),db.prepare('INSERT INTO transactions(id,user_id,amount,note,created_at) VALUES(?,?,?,?,?)').bind(id(),u.id,-amt,'تحويل إلى '+target.name,now),db.prepare('INSERT INTO transactions(id,user_id,amount,note,created_at) VALUES(?,?,?,?,?)').bind(id(),recipient,amt,'تحويل من '+u.name,now)]);}catch(e){if(/CHECK|constraint/i.test(String(e?.message||e)))throw Error('رصيدك لا يكفي');throw e;}await activity(db,u.name,'حوّل نقاطًا إلى '+target.name,now);await zNotify(db,recipient,'تحويل نقاط','وصلك تحويل بقيمة '+amt+' نقطة من '+u.name,'money');break;}
case 'buy':{if(!await hasDepartment(db,u,'telecom'))throw Error('قسم الاتصالات يحتاج تعيين وزير الاتصالات من الرئاسة');let kind=crop(p.item,40),prices={'باقة خفيفة':100,'باقة أسبوعية':350,'باقة الملوك':800};if(!Object.prototype.hasOwnProperty.call(prices,kind)||prices[kind]!==num(p.price))throw Error('الباقة غير موجودة');await spend(db,u,Math.ceil(prices[kind]*1.1),'شراء '+kind+' (مع الضريبة)',p.payment_method);await activity(db,u.name,'اشترى '+kind,now);break;}
case 'application':{let kind=crop(p.kind,60),detail=crop(p.detail,500);if(kind==='طلب تعليمي'&&!await hasDepartment(db,u,'education'))throw Error('هذا الإجراء يحتاج تعيين وزير التعليم من الرئاسة');if(!kind||detail.length<5)throw Error('تفاصيل الطلب قصيرة');await db.prepare('INSERT INTO applications(id,user_id,kind,detail,status,created_at) VALUES(?,?,?,?,?,?)').bind(id(),u.id,kind,detail,'pending',now).run();await activity(db,u.name,'قدم طلبًا حكوميًا',now);const admins=await db.prepare('SELECT user_id FROM z39_president_grants LIMIT 25').all();for(const recipient of admins.results)await zNotify(db,recipient.user_id,'طلب جديد','مواطن قدم طلبًا حكوميًا يحتاج مراجعة','request');break;}
case 'case':{let kind=crop(p.kind,60),detail=crop(p.detail,500),targetId=crop(p.target_id,75);if(!kind||detail.length<5||targetId===u.id)throw Error('محضر غير مكتمل');target=await db.prepare('SELECT id,name FROM users WHERE id=?').bind(targetId).first();if(!target)throw Error('العضو غير موجود');await db.prepare('INSERT INTO cases(id,user_id,target_id,kind,detail,status,created_at) VALUES(?,?,?,?,?,?,?)').bind(id(),u.id,targetId,kind,detail,'pending',now).run();await activity(db,u.name,'قدم محضرًا إلى الإدارة',now);break;}
case 'candidate':throw Error('الانتخابات ملغاة في تحديث الدولة الجديد');{let r=await db.prepare('UPDATE users SET candidate=1 WHERE id=? AND candidate=0 RETURNING id').bind(u.id).first();if(!r)throw Error('أنت مرشح بالفعل');await activity(db,u.name,'ترشح لمجلس الدولة',now);break;}
case 'vote':throw Error('الانتخابات ملغاة في تحديث الدولة الجديد');{let cid=crop(p.candidate_id,75),c=await db.prepare('SELECT id FROM users WHERE id=? AND candidate=1').bind(cid).first();if(!c)throw Error('المرشح غير موجود');try{await db.prepare('INSERT INTO votes(voter_id,candidate_id,created_at) VALUES(?,?,?)').bind(u.id,cid,now).run()}catch{throw Error('لقد صوتّ بالفعل')};await activity(db,u.name,'شارك في الانتخابات',now);break;}
case 'adminAward':{if(!admin)throw Error('صلاحية المدير مطلوبة');let amount=num(p.amount),userId=crop(p.user_id,75),note=crop(p.note,120);if(!Number.isInteger(amount)||amount<1||amount>100000||note.length<2)throw Error('منحة غير صالحة');target=await db.prepare('SELECT name FROM users WHERE id=?').bind(userId).first();if(!target)throw Error('عضو غير موجود');await zTreasuryPay(db,userId,amount,note,u.name,now);await activity(db,u.name,'منح نقاطًا إلى '+target.name,now);await zNotify(db,userId,'منحة رئاسية','تم إضافة '+amount+' زنجر إلى رصيدك','money');break;}
case 'adminJob':{if(!admin)throw Error('غير مصرح');let job=crop(p.job,60),userId=crop(p.user_id,75);if(job.length<2)throw Error('منصب غير صالح');target=await db.prepare("UPDATE users SET job=?, role=CASE WHEN id IN (SELECT user_id FROM z39_president_grants) THEN 'admin' WHEN ? LIKE '%وزير%' THEN 'minister' WHEN ? LIKE '%قاض%' THEN 'judge' ELSE 'citizen' END WHERE id=? RETURNING name").bind(job,job,job,userId).first();if(!target)throw Error('عضو غير موجود');await activity(db,u.name,'عدّل منصب '+target.name,now);await zNotify(db,userId,'تعيين حكومي','تم تعديل منصبك إلى '+job,'government');break;}
case 'telecomReject':{
  if(!telecomMinister(u))throw Error('رفض الطلبات المشبوهة من اختصاص وزير الاتصالات أو الرئاسة فقط');
  const reqId=crop(p.id,75),reason=crop(p.reason,180);
  if(reason.length<5)throw Error('اذكر سبب الرفض بوضوح');
  const row=await db.prepare('SELECT id,kind,user_id,status FROM applications WHERE id=?').bind(reqId).first();
  if(!row||!identityRequest(row.kind)||row.status!=='pending')throw Error('الطلب غير موجود أو انتهت مراجعته');
  const updated=await db.prepare("UPDATE applications SET status='rejected' WHERE id=? AND status='pending' RETURNING id").bind(reqId).first();
  if(!updated)throw Error('تمت معالجة الطلب بالفعل');
  await db.prepare('INSERT INTO telecom_reviews(id,request_id,reviewer_id,reason,created_at) VALUES(?,?,?,?,?)').bind(id(),reqId,u.id,reason,now).run();
  await activity(db,u.name,'رفض طلب هوية أو بطاقة مشبوه بعد المراجعة',now);break;
 }
 case 'adminRole':{if(!admin)throw Error('غير مصرح');let role=crop(p.role,30),userId=crop(p.user_id,75);if(!['citizen','resident','minister','judge'].includes(role))throw Error('الرئاسة لا تُمنح بتغيير الدور؛ يلزم كود الرئاسة الجديد');target=await db.prepare('SELECT id,name,role FROM users WHERE id=?').bind(userId).first();if(!target)throw Error('عضو غير موجود');if(!admin&&(role==='president'||role==='admin'||target.role==='president'||target.role==='admin'))throw Error('صلاحية الرئاسة مطلوبة');if(target.id===u.id&&target.role==='president'&&role!=='president')throw Error('لا يمكن للرئيس إلغاء صلاحياته من هذه اللوحة');await db.prepare('UPDATE users SET role=? WHERE id=?').bind(role,userId).run();await zNotify(db,target.id,'تغيير منصبك الحكومي','تم تحديث منصبك إلى '+role,'request');await activity(db,u.name,'عدّل صلاحيات '+target.name,now);break;}
case 'reviewCase':{if(!(await z63Rights(db,u)).judge)throw Error('القضاء يحتاج تعيينًا رسميًا من الرئاسة');let row=await db.prepare('SELECT * FROM cases WHERE id=? AND status=?').bind(crop(p.id,75),'pending').first();if(!row||[row.user_id,row.target_id].includes(u.id)||!['confirmed','rejected'].includes(p.status))throw Error('لا يجوز نظر محضر طرفك فيه أو محضر غير متاح');if(p.status==='confirmed'){let holder=await db.prepare('SELECT points FROM users WHERE id=?').bind(row.target_id).first();let penalty=Math.min(50,holder?.points||0);await db.batch([db.prepare('UPDATE cases SET status=? WHERE id=?').bind('confirmed',row.id),db.prepare('UPDATE users SET points=MAX(0,points-50) WHERE id=?').bind(row.target_id),db.prepare('INSERT INTO grant_penalties(user_id,penalty) VALUES(?,800) ON CONFLICT(user_id) DO UPDATE SET penalty=800').bind(row.target_id)]);if(penalty){await addTx(db,row.target_id,-penalty,'مخالفة: '+row.kind,now);await stateEconomyAdd(db,penalty,'تحصيل غرامة قضائية: '+row.kind,u.name,now)}}else await db.prepare('UPDATE cases SET status=? WHERE id=?').bind('rejected',row.id).run();await zNotify(db,row.user_id,'قرار المحكمة','تمت مراجعة المحضر: '+(p.status==='confirmed'?'تأكيد':'رفض'),'report');await zNotify(db,row.target_id,'تحديث المحضر','صدر قرار في محضر يخص حسابك','report');await activity(db,u.name,'أصدر قرارًا بخصوص محضر',now);break;}
case 'reviewRequest':{if(!await hasDepartment(db,u,'requests'))throw Error('القسم يحتاج تعيينًا مناسبًا من الرئاسة');if(!['accepted','rejected'].includes(p.status))throw Error('حالة غير متاحة');if(p.status==='accepted'&&!admin)throw Error('قبول الطلبات من صلاحيات الرئاسة الأعلى فقط');target=await db.prepare('UPDATE applications SET status=? WHERE id=? AND status=? RETURNING user_id').bind(p.status,crop(p.id,75),'pending').first();if(!target)throw Error('الطلب غير متاح');await zNotify(db,target.user_id,'قرار بشأن طلبك الحكومي',p.status==='accepted'?'تم قبول طلبك الحكومي':'تم رفض طلبك الحكومي','request');await activity(db,u.name,'راجع طلبًا حكوميًا',now);break;}
case 'announce':{if(!await hasDepartment(db,u,'ads'))throw Error('القسم يحتاج تعيينًا مناسبًا من الرئاسة');let text=crop(p.text,300);if(text.length<5)throw Error('الإعلان قصير جدًا');const announcementId=id();await db.prepare('INSERT INTO announcements(id,text,created_at) VALUES(?,?,?)').bind(announcementId,text,now).run();await zPushEnqueueAll(db,'📢 إعلان رسمي من الدولة',text,'government','/#/home','announcement-'+announcementId);await activity(db,u.name,'نشر إعلانًا رسميًا',now);break;}

case 'adminRank':{if(!admin)throw Error('صلاحية المدير مطلوبة');let userId=crop(p.user_id,75),rank=crop(p.rank,30);if(!['زائر','مواطن','مقيم','مقيم متميز','مواطن ++'].includes(rank))throw Error('صفة غير صالحة');target=await db.prepare('UPDATE users SET rank=? WHERE id=? RETURNING name').bind(rank,userId).first();if(!target)throw Error('العضو غير موجود');await activity(db,u.name,'غيّر صفة '+target.name+' إلى '+rank,now);break;}
case 'adminViolation':{if(!await hasDepartment(db,u,'violations'))throw Error('القسم يحتاج تعيينًا مناسبًا من الرئاسة');const uid=crop(p.user_id,75),kind=crop(p.kind,60),detail=crop(p.detail,350);if(!uid||!kind||detail.length<5||uid===u.id)throw Error('أكمل بيانات البلاغ دون استخدام صلاحياتك ضد نفسك');if(!await db.prepare('SELECT id FROM users WHERE id=?').bind(uid).first())throw Error('المواطن غير موجود');await db.prepare("INSERT INTO cases(id,user_id,target_id,kind,detail,status,created_at) VALUES(?,?,?,?,?,'pending',?)").bind(id(),u.id,uid,kind,detail,now).run();await zNotify(db,uid,'بلاغ للمراجعة','تم تسجيل بلاغ ينتظر قرار القضاء، ولا تُفرض غرامة قبل الحكم','report');await activity(db,u.name,'قدّم بلاغًا رسميًا للمراجعة القضائية',now);break;}
case 'adminPardon':{if(!await hasDepartment(db,u,'violations'))throw Error('القسم يحتاج تعيينًا مناسبًا من الرئاسة');let userId=crop(p.user_id,75);target=await db.prepare('SELECT id,name FROM users WHERE id=?').bind(userId).first();if(!target)throw Error('العضو غير موجود');await db.batch([db.prepare("UPDATE cases SET status='pardoned' WHERE target_id=? AND status='confirmed'").bind(userId),db.prepare('DELETE FROM grant_penalties WHERE user_id=?').bind(userId)]);await activity(db,u.name,'أصدر عفوًا رسميًا عن '+target.name,now);break;}
case 'adminSuspend':{if(!admin)throw Error('صلاحية المدير مطلوبة');let userId=crop(p.user_id,75),hours=Number(p.hours),reason=crop(p.reason,150);if(![1,24,72,168].includes(hours))throw Error('مدة الإيقاف غير صالحة');target=await db.prepare('SELECT id,name FROM users WHERE id=?').bind(userId).first();if(!target||target.id===u.id)throw Error('لا يمكنك إيقاف نفسك أو عضو غير موجود');await db.prepare('INSERT INTO suspensions(user_id,until_at,reason) VALUES(?,?,?) ON CONFLICT(user_id) DO UPDATE SET until_at=excluded.until_at,reason=excluded.reason').bind(userId,now+hours*3600000,reason).run();await zNotify(db,target.id,'إيقاف العضوية','تم إيقاف حسابك مؤقتًا لمدة '+hours+' ساعة','government');await activity(db,u.name,'أوقف عضوية '+target.name+' مؤقتًا',now);break;}
case 'adminUnfreeze':{if(!admin)throw Error('صلاحية المدير مطلوبة');let userId=crop(p.user_id,75);await db.prepare('DELETE FROM suspensions WHERE user_id=?').bind(userId).run();await zNotify(db,userId,'إلغاء إيقاف العضوية','تمت إعادة فتح عضويتك','government');await activity(db,u.name,'ألغى إيقاف عضوية',now);break;}
case 'adminCandidate':throw Error('الانتخابات ملغاة في تحديث الدولة الجديد');{if(!admin)throw Error('صلاحية المدير مطلوبة');let userId=crop(p.user_id,75),v=p.value===true?1:0;target=await db.prepare('SELECT name FROM users WHERE id=?').bind(userId).first();if(!target)throw Error('العضو غير موجود');await db.prepare('UPDATE users SET candidate=? WHERE id=?').bind(v,userId).run();await activity(db,u.name,(v?'اعتمد ترشح ':'ألغى ترشح ')+target.name,now);break;}
case 'gameReward':{let score=num(p.score);if(!Number.isInteger(score)||score<1||score>1000)throw Error('نتيجة لعبة غير صالحة');let amount=Math.min(score*2,20);let ready=await db.prepare('SELECT game_at FROM users WHERE id=?').bind(u.id).first();if(Number(ready?.game_at||0)>now-300000)throw Error('مكافأة اللعبة متاحة كل 5 دقائق');await zTreasurySpend(db,amount,'جائزة زنجر فلاي',u.name,now);let result=await db.prepare('UPDATE users SET points=points+?,game_at=? WHERE id=? AND game_at<=? RETURNING id').bind(amount,now,u.id,now-300000).first();if(!result)throw Error('مكافأة اللعبة متاحة كل 5 دقائق');await addTx(db,u.id,amount,'جائزة زنجر فلاي',now);await activity(db,u.name,'حصل على جائزة زنجر فلاي',now);break;}
default:return err(400,'إجراء غير معروف')};return json({ok:true});}
async function unlockAdmin(req,db,env,p){return err(410,'تم إيقاف كود الرئاسة القديم. افتح صفحة الرئاسة الجديدة للتحقق بخطوتين.');}
async function z49RetiredUnlock(req,db,env,p){
 const u=await getMe(req,db);if(!u)return err(401,'سجل دخولك أولًا لفتح لوحة التحكم');
 // New long presidential access code replaces every prior ordinary presidential code.
 const code=String(p.code||'');if(code.length>150||code.length<3)return err(400,'الكود غير صحيح');
 const state=await db.prepare('SELECT failures,blocked_until FROM admin_unlock_attempts WHERE user_id=?').bind(u.id).first(),now=Date.now();
 if(state?.blocked_until>now)return err(429,'محاولات كثيرة. انتظر 15 دقيقة ثم حاول مرة أخرى.');
 let d1=await digest(code),d2=Z39_PRESIDENT_HASH,diff=0;for(let i=0;i<d1.length;i++)diff|=d1.charCodeAt(i)^d2.charCodeAt(i);
 if(diff!==0){let n=(state?.blocked_until&&state.blocked_until<=now?0:Number(state?.failures||0))+1;await db.prepare('INSERT INTO admin_unlock_attempts(user_id,failures,blocked_until) VALUES(?,?,?) ON CONFLICT(user_id) DO UPDATE SET failures=excluded.failures,blocked_until=excluded.blocked_until').bind(u.id,n,n>=5?now+900000:0).run();return err(403,n>=5?'محاولات كثيرة. جرّب بعد 15 دقيقة.':'الكود غير صحيح');}
 await db.batch([db.prepare('INSERT OR IGNORE INTO admin_grants(user_id,created_at) VALUES(?,?)').bind(u.id,now),db.prepare('INSERT OR IGNORE INTO z39_president_grants(user_id,created_at) VALUES(?,?)').bind(u.id,now),db.prepare('UPDATE users SET role=? WHERE id=? AND role NOT IN (?,?)').bind('admin',u.id,'president','admin'),db.prepare('DELETE FROM admin_unlock_attempts WHERE user_id=?').bind(u.id)]);
 await activity(db,u.name,'تم فتح لوحة التحكم للمرة الأولى',now);return json({ok:true,unlocked:true});
}

