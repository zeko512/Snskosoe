// UPDATE 43 — deterministic, server-authoritative rewards, finance and push alerts.
const Z45_RELEASE=[
 'Update 49: متجر عسكري بالأسعار الجديدة وتحذير مقارنة قوة الجيش قبل الحرب، ومساعدات عسكرية بين الدول بعد الموافقة',
 'إدارة الرئاسة المركزية عبر تحقق جديد بخطوتين؛ الصلاحيات القديمة لم تعد تفتح وحدها',
 'Update 48: تصميم جديد منظم للدول، 20 موظفًا افتراضيًا بكل محافظة إضافية، يضيفون 1,000 زنجر في ساعة العمل كل ساعتين',
 'اتحاد المحافظات: تعيين الرؤساء مباشرة من الرئاسة، ولوحة مستقلّة للمحافظة مع تغيير اسمها',
 'رسم إدارة المحافظة 4,000 زنجر يوميًا من خزينة المحافظة فقط، مع مشروعات وجيوش وحروب وغنائم حتى 130,000',
 'المهمات اليومية ومساعد الذكاء الاصطناعي الاختياري، وتحديث امتحانات التعليم إلى 5 أسئلة',
 'إصلاح استهداف الصواريخ وصرف مكافأة 3,000 زنجر للمدافع و5,000 لخزينة الدولة بعد نجاح الاعتراض',
 'جوائز الفوز في الحروب حسب قوة الدول: من 30,000 للخزينة و2,000 لكل مواطن و5,000 للقائد، بزيادة 20% لكل مرتبة',
 'تحسين إدارة القروض والحسابات والخدمات المالية',
 'المنحة الدورية 650 زنجر كل ساعة وفائدة البنك 10% كل 3 ساعات',
 'البورصة: احتمالات صعود وهبوط متساوية 50% مع تحديث السعر الحقيقي وسقف للحركة',
 'مراجعة المكافآت في السيرفر وعدم صرفها أكثر من مرة، مع بقاء بيانات الدولة والأنظمة السابقة'
];
const Z44_RELEASE=[
 'تذكير يومي بسداد القروض وزر دفع المبلغ كاملًا أو جزء منه',
 'خصم القرض المتبقي بعد 5 أيام مع دعم الرصيد السالب، ومهلة 3 أيام قبل السجن الافتراضي ليومين',
 'التبرع لسداد دين أي مواطن، والإفراج المبكر إذا انتهى الدين',
 'تحسين تفاصيل إشعارات وزير المالية للتحويلات والقروض والعمليات المسجلة',
 'إصلاح التحقق من صرف مكافآت الحروب ومنع ظهور رسالة نجاح الدفع قبل التأكيد',
 'ألعاب جديدة لنائب الرئيس والمحقق المالي وشبكة الاتصالات',
 'استمرار جميع ميزات الدولة السابقة دون تصفير للحسابات أو الممتلكات'
];
const Z43_RELEASE=[
 'مكافأة الفوز بالحرب: 2,500 للخزينة و700 لكل مواطن و1,000 إضافية لقائد الانتصار',
 'إصلاح سجل الدفاع القديم ومنع تكرار المكافآت بالمعرّف الفريد',
 'إشعارات مالية لوزير المالية عن معاملات المواطنين وتغيرات الخزينة حسب صلاحياته',
 'تنبيه منحة الـ650 زنجر عندما تصبح جاهزة للاستلام',
 'ربط كل الإشعارات المحلية بنظام Push للموبايل حسب أذونات المواطن',
 'نتيجة انتصار جديدة توضح المكافآت بعد تأكيد السيرفر',
 'شرح متحرك لجميع تغييرات تحديث 43 دون حذف الحسابات'
];
let z43Ready=null;
async function z43Ensure(db){
 if(z43Ready)return z43Ready;
 z43Ready=(async()=>{
  // Migrate old reward triggers BEFORE any new war request or scheduled war tick.
  await z38WarEnsure(db);await z39WarUpgrade(db);
  const existing=await db.prepare("SELECT value FROM site_settings WHERE key='z43_migrated'").first();
  if(existing?.value==='1')return;
  const statements=[
   'CREATE TABLE IF NOT EXISTS z43_war_rewards (event_id TEXT PRIMARY KEY,kind TEXT NOT NULL,treasury_added INTEGER NOT NULL,president_added INTEGER NOT NULL DEFAULT 0,citizen_added INTEGER NOT NULL DEFAULT 0,leader_added INTEGER NOT NULL DEFAULT 0,created_at INTEGER NOT NULL)',
   'CREATE TABLE IF NOT EXISTS z43_grant_notified(user_id TEXT PRIMARY KEY,claim_at INTEGER NOT NULL,created_at INTEGER NOT NULL)',
   'DROP TRIGGER IF EXISTS z37_war_payout_apply',
   'DROP TRIGGER IF EXISTS z37_war_payout_apply', // remove any resurrected pre-season million-coin award
   'DROP TRIGGER IF EXISTS z43_war_reward',
   'DROP TRIGGER IF EXISTS z43_radar_reward',
   'DROP TRIGGER IF EXISTS z43_notifications_push',
   'DROP TRIGGER IF EXISTS z43_finance_transactions',
   'DROP TRIGGER IF EXISTS z43_finance_treasury',
   'DROP TRIGGER IF EXISTS z43_grant_alert',
   `CREATE TRIGGER z43_notifications_push AFTER INSERT ON z_notifications BEGIN
    INSERT OR IGNORE INTO z_push_outbox(id,dedupe,endpoint,user_id,kind,title,body,url,created_at)
    SELECT lower(hex(randomblob(16))),
    NEW.id,
    s.endpoint,s.user_id,NEW.kind,
    NEW.title,
    CASE WHEN NEW.id LIKE 'z43-fin-%' THEN 'تم تسجيل معاملات مالية جديدة؛ افتح إشعارات الدولة للمبالغ والأسماء والأسباب الكاملة.' ELSE NEW.body END,
    CASE WHEN NEW.kind='war' THEN '/war.html' WHEN NEW.kind='money' THEN '/#/bank'
         WHEN NEW.kind IN ('job','jobs') THEN '/#/companies' WHEN NEW.kind='chat' THEN '/#/chat'
         WHEN NEW.kind IN ('market','trade','property') THEN '/#/market-pro' ELSE '/#/notifications' END,NEW.created_at
    FROM z_push_subscriptions s LEFT JOIN z_push_prefs pp ON pp.user_id=s.user_id
    WHERE s.user_id=NEW.user_id AND COALESCE(CASE
      WHEN NEW.kind='war' THEN pp.war WHEN NEW.kind='money' THEN pp.money
      WHEN NEW.kind IN ('job','jobs') THEN pp.jobs WHEN NEW.kind='chat' THEN pp.chat
      WHEN NEW.kind IN ('market','trade','property') THEN pp.market
      WHEN NEW.kind='government' THEN pp.government WHEN NEW.kind='social' THEN pp.social
      ELSE pp.system END,1)=1;
   END`,
   `CREATE TRIGGER z43_finance_transactions AFTER INSERT ON transactions
   WHEN NEW.note NOT LIKE 'مكافأة انتصار Update 43%'
   BEGIN
     INSERT OR IGNORE INTO z_notifications(id,user_id,title,body,kind,created_at)
     SELECT 'z43-fin-tx-'||NEW.id||'-'||fm.id,fm.id,
       '💰 متابعة حركة أموال المواطنين',
       COALESCE(payer.name,'مواطن')||' · '||CASE WHEN NEW.amount>=0 THEN '+' ELSE '' END||NEW.amount||' زنجر · '||SUBSTR(NEW.note,1,100),
       'money',NEW.created_at
     FROM users fm LEFT JOIN users payer ON payer.id=NEW.user_id
     WHERE fm.job='وزير المالية';
   END`,
   `CREATE TRIGGER z43_finance_treasury AFTER INSERT ON z_state_ledger
   WHEN NEW.reason NOT LIKE 'صد صاروخ سري Update 43%'
   BEGIN
     INSERT OR IGNORE INTO z_notifications(id,user_id,title,body,kind,created_at)
     SELECT 'z43-fin-ledger-'||NEW.id||'-'||fm.id,fm.id,'🏦 حركة خزينة الدولة',
       CASE WHEN NEW.reason='مكافأة انتصار Update 43' THEN '+2,500 للخزينة، +700 لكل مواطن، +1,000 إضافية لقائد الحرب' ELSE CASE WHEN NEW.delta>=0 THEN '+' ELSE '' END||NEW.delta||' زنجر · '||SUBSTR(NEW.reason,1,100) END,
       'money',NEW.created_at FROM users fm WHERE fm.job='وزير المالية';
   END`,
   `CREATE TRIGGER z43_war_reward AFTER INSERT ON z37_war_payouts
   WHEN NEW.battle_id NOT LIKE 'radar-%'
   BEGIN
     INSERT OR IGNORE INTO z43_war_rewards(event_id,kind,treasury_added,citizen_added,leader_added,created_at)
       VALUES(NEW.battle_id,'battle',2500,700,CASE WHEN NEW.actor_id IS NOT NULL THEN 1000 ELSE 0 END,NEW.created_at);
     UPDATE z_state_treasury SET balance=balance+2500 WHERE id=1;
     INSERT INTO z_state_ledger(id,delta,reason,actor,created_at)
       VALUES(lower(hex(randomblob(16))),2500,'مكافأة انتصار Update 43','نظام الحروب',NEW.created_at);
     UPDATE users SET points=points+700;
     INSERT INTO transactions(id,user_id,amount,note,created_at)
       SELECT lower(hex(randomblob(16))),id,700,'مكافأة انتصار Update 43 لكل مواطن',NEW.created_at FROM users;
     UPDATE users SET points=points+1000 WHERE id=NEW.actor_id AND NEW.actor_id IS NOT NULL;
     INSERT INTO transactions(id,user_id,amount,note,created_at)
       SELECT lower(hex(randomblob(16))),id,1000,'مكافأة انتصار Update 43 لقائد المعركة',NEW.created_at FROM users WHERE id=NEW.actor_id;
     INSERT OR IGNORE INTO z_notifications(id,user_id,title,body,kind,created_at)
       SELECT 'z43-victory-'||NEW.battle_id||'-'||id,id,'🏆 انتصار دولة الزنجر',
       'وصلتك مكافأة انتصار 700 زنجر'||CASE WHEN id=NEW.actor_id THEN ' + 1,000 زنجر إضافية لقائد الحرب' ELSE '' END||' · خزينة الدولة +2,500 زنجر',
       'war',NEW.created_at FROM users;
   END`,
   `CREATE TRIGGER z43_radar_reward AFTER INSERT ON z37_war_payouts
   WHEN NEW.battle_id LIKE 'radar-%'
   BEGIN
     INSERT OR IGNORE INTO z43_war_rewards(event_id,kind,treasury_added,president_added,created_at)
       VALUES(NEW.battle_id,'radar',1500,CASE WHEN EXISTS(SELECT 1 FROM z42_role_claims r JOIN users u ON u.id=r.user_id WHERE r.role_key='president' AND u.job='رئيس الدولة') THEN 700 ELSE 0 END,NEW.created_at);
     UPDATE z_state_treasury SET balance=balance+1500 WHERE id=1;
     UPDATE users SET points=points+700 WHERE id=(SELECT r.user_id FROM z42_role_claims r JOIN users u ON u.id=r.user_id WHERE r.role_key='president' AND u.job='رئيس الدولة' LIMIT 1);
     -- Secret radar payout intentionally creates NO notification, chat message, public ledger or transaction.
     -- Protected technical record above enables exactly-once verification.
   END`,
   `CREATE TRIGGER z43_grant_alert AFTER INSERT ON z43_grant_notified BEGIN
     INSERT OR IGNORE INTO z_notifications(id,user_id,title,body,kind,created_at)
       VALUES('z43-grant-'||NEW.user_id||'-'||NEW.claim_at,NEW.user_id,'🪙 منحتك جاهزة للاستلام',
       'منحة الدولة (حتى 650 زنجر) جاهزة الآن! افتح الصفحة الرئيسية واضغط استلام. الرصيد لا يزيد قبل استلامها.','money',NEW.created_at);
   END`,
   "INSERT OR REPLACE INTO site_settings(key,value,updated_at) VALUES('z43_migrated','1',strftime('%s','now')*1000)"
  ];
  await db.batch(statements.map(sql=>db.prepare(sql)));
 })().catch(e=>{z43Ready=null;throw e});return z43Ready;
}
// UPDATE 44 — additive loan recovery, verified war rewards and confidential finance audit.
const Z44_DAY=86400000;
let z44Ready=null;
async function z44Ensure(db){
 if(z44Ready)return z44Ready;
 z44Ready=(async()=>{
  // Read-only check avoids re-creating 20+ triggers on every Cloudflare isolate cold start.
  const flag=await db.prepare("SELECT value FROM site_settings WHERE key='z44_migrated'").first();
  if(flag?.value==='1'){
   const exists=await db.prepare("SELECT COUNT(*) AS n FROM sqlite_master WHERE type='trigger' AND name IN ('z44_loan_remind','z44_loan_collect','z44_support_check','z44_support_apply','z44_loan_released','z44_jail_apply','z43_finance_transactions','z43_finance_treasury','z43_notifications_push','z37_war_payout_battle','z43_war_reward','z43_radar_reward')").first();
   const oldPayout=await db.prepare("SELECT name FROM sqlite_master WHERE type='trigger' AND name='z37_war_payout_apply' LIMIT 1").first();
   if(Number(exists?.n)===12&&!oldPayout)return;
  }
  // A missing legacy battle trigger after season rollover previously produced victories without rewards.
  const sql=[
   `CREATE TABLE IF NOT EXISTS z44_loan_meta(loan_id TEXT PRIMARY KEY,user_id TEXT NOT NULL,charged_at INTEGER NOT NULL DEFAULT 0,grace_until INTEGER NOT NULL DEFAULT 0,jail_id TEXT NOT NULL DEFAULT '',cleared_at INTEGER NOT NULL DEFAULT 0)`,
   `CREATE TABLE IF NOT EXISTS z44_loan_reminders(loan_id TEXT NOT NULL,day INTEGER NOT NULL,created_at INTEGER NOT NULL,PRIMARY KEY(loan_id,day))`,
   `CREATE TABLE IF NOT EXISTS z44_loan_collections(loan_id TEXT PRIMARY KEY,user_id TEXT NOT NULL,amount INTEGER NOT NULL CHECK(amount>0),created_at INTEGER NOT NULL)`,
   `CREATE TABLE IF NOT EXISTS z44_loan_support(id TEXT PRIMARY KEY,loan_id TEXT NOT NULL,payer_id TEXT NOT NULL,amount INTEGER NOT NULL CHECK(amount>0),created_at INTEGER NOT NULL)`,
   `CREATE TABLE IF NOT EXISTS z44_loan_jails(loan_id TEXT PRIMARY KEY,user_id TEXT NOT NULL,created_at INTEGER NOT NULL)`,
   'CREATE INDEX IF NOT EXISTS idx_z44_loan_user ON z44_loan_meta(user_id,charged_at)',
   'DROP TRIGGER IF EXISTS z44_loan_remind',
   `CREATE TRIGGER z44_loan_remind AFTER INSERT ON z44_loan_reminders BEGIN
      INSERT OR IGNORE INTO z_notifications(id,user_id,title,body,kind,created_at)
      SELECT 'z44-loan-'||NEW.loan_id||'-'||NEW.day,l.user_id,'💳 تذكير بسداد قرض الدولة',
      CASE WHEN NEW.day<5 THEN 'باقي على سداد قرضك '||MAX(0,l.principal-l.repaid)||' زنجر؛ أمامك '||(5-NEW.day)||' يوم. افتح الإشعار واختر «ادفع الآن» ثم المبلغ كاملًا أو جزءًا منه.'
       ELSE 'انتهت مهلة القرض؛ تابع رصيدك السالب وسدد أو اطلب مساهمة من المواطنين قبل انتهاء مهلة الثلاثة أيام.' END,
      'money',NEW.created_at FROM econ_loans l WHERE l.id=NEW.loan_id;
    END`,
   'DROP TRIGGER IF EXISTS z44_loan_collect',
   `CREATE TRIGGER z44_loan_collect AFTER INSERT ON z44_loan_collections BEGIN
      UPDATE users SET points=points-NEW.amount WHERE id=NEW.user_id;
      UPDATE econ_loans SET repaid=principal WHERE id=NEW.loan_id;
      UPDATE z44_loan_meta SET charged_at=NEW.created_at,grace_until=NEW.created_at+259200000,cleared_at=CASE WHEN (SELECT points FROM users WHERE id=NEW.user_id)>=0 THEN NEW.created_at ELSE 0 END WHERE loan_id=NEW.loan_id;
      UPDATE z_state_treasury SET balance=balance+NEW.amount WHERE id=1;
      INSERT INTO z_state_ledger(id,delta,reason,actor,created_at) VALUES(lower(hex(randomblob(16))),NEW.amount,'تحصيل قرض بعد خمسة أيام','نظام قروض الدولة',NEW.created_at);
      INSERT INTO transactions(id,user_id,amount,note,created_at) VALUES(lower(hex(randomblob(16))),NEW.user_id,-NEW.amount,'خصم تلقائي بعد 5 أيام لقرض الدولة',NEW.created_at);
      INSERT OR IGNORE INTO z_notifications(id,user_id,title,body,kind,created_at) VALUES('z44-collected-'||NEW.loan_id,NEW.user_id,'💳 انتهت مهلة القرض',
       'تم خصم المتبقي من محفظتك؛ لو رصيدك سالب، كل دخل جديد يقلل السالب. أمامك 3 أيام قبل السجن الافتراضي. يمكن للمواطنين المساهمة في السداد.','money',NEW.created_at);
    END`,
   'DROP TRIGGER IF EXISTS z44_support_check',
   `CREATE TRIGGER z44_support_check BEFORE INSERT ON z44_loan_support BEGIN
      SELECT CASE WHEN NOT EXISTS(SELECT 1 FROM z44_loan_meta m JOIN users u ON u.id=m.user_id WHERE m.loan_id=NEW.loan_id AND m.charged_at>0 AND u.points<0 AND NEW.amount<=-u.points AND NEW.payer_id<>m.user_id) THEN RAISE(ABORT,'لا يوجد دين سالب أو قيمة المساهمة تتجاوز المتبقي') END;
      SELECT CASE WHEN NOT EXISTS(SELECT 1 FROM users WHERE id=NEW.payer_id AND points>=NEW.amount) THEN RAISE(ABORT,'رصيد المساهم لا يكفي') END;
    END`,
   'DROP TRIGGER IF EXISTS z44_support_apply',
   `CREATE TRIGGER z44_support_apply AFTER INSERT ON z44_loan_support BEGIN
      UPDATE users SET points=points-NEW.amount WHERE id=NEW.payer_id;
      UPDATE users SET points=points+NEW.amount WHERE id=(SELECT user_id FROM z44_loan_meta WHERE loan_id=NEW.loan_id);
      INSERT INTO transactions(id,user_id,amount,note,created_at) VALUES(lower(hex(randomblob(16))),NEW.payer_id,-NEW.amount,'مساهمة في سداد قرض مواطن',NEW.created_at);
      INSERT INTO transactions(id,user_id,amount,note,created_at) SELECT lower(hex(randomblob(16))),user_id,NEW.amount,'مساهمة مواطن في تقليل رصيد القرض السالب',NEW.created_at FROM z44_loan_meta WHERE loan_id=NEW.loan_id;
      INSERT OR IGNORE INTO z_notifications(id,user_id,title,body,kind,created_at)
       SELECT 'z44-support-'||NEW.id,m.user_id,'❤️ مساعدة في سداد قرضك','ساهم مواطن بمبلغ '||NEW.amount||' زنجر في تقليل دينك.','money',NEW.created_at FROM z44_loan_meta m WHERE m.loan_id=NEW.loan_id;
    END`,
   'DROP TRIGGER IF EXISTS z44_loan_released',
   `CREATE TRIGGER z44_loan_released AFTER UPDATE OF points ON users WHEN OLD.points<0 AND NEW.points>=0 BEGIN
      UPDATE z44_loan_meta SET cleared_at=CAST(strftime('%s','now') AS INTEGER)*1000 WHERE user_id=NEW.id AND charged_at>0 AND cleared_at=0;
      UPDATE prison_requests SET ends_at=CAST(strftime('%s','now') AS INTEGER)*1000 WHERE id IN (SELECT jail_id FROM z44_loan_meta WHERE user_id=NEW.id AND jail_id<>'') AND status='approved' AND ends_at>CAST(strftime('%s','now') AS INTEGER)*1000;
      INSERT OR IGNORE INTO z_notifications(id,user_id,title,body,kind,created_at) VALUES('z44-debt-cleared-'||NEW.id||'-'||CAST(strftime('%s','now') AS INTEGER),NEW.id,'✅ تمت تسوية دينك','رصيدك لم يعد بالسالب. إذا كنت مسجونًا بسبب القرض فقد تم الإفراج المبكر عنك.','money',CAST(strftime('%s','now') AS INTEGER)*1000);
    END`,
   'DROP TRIGGER IF EXISTS z44_jail_apply',
   `CREATE TRIGGER z44_jail_apply AFTER INSERT ON z44_loan_jails BEGIN
      INSERT OR IGNORE INTO prison_requests(id,target_id,requester_id,reason,hours,status,created_at,reviewed_at,starts_at,ends_at)
      VALUES('loan44-'||NEW.loan_id,NEW.user_id,NEW.user_id,'تأخر سداد قرض افتراضي بعد مهلة 5+3 أيام',48,'approved',NEW.created_at,NEW.created_at,NEW.created_at,NEW.created_at+172800000);
      UPDATE z44_loan_meta SET jail_id='loan44-'||NEW.loan_id WHERE loan_id=NEW.loan_id;
      INSERT OR IGNORE INTO z_notifications(id,user_id,title,body,kind,created_at) VALUES('z44-jail-'||NEW.loan_id,NEW.user_id,'🔒 سجن افتراضي بسبب الدين','تم بدء مدة يومين لعدم سداد الرصيد السالب. مساهمات المواطنين التي تنهي الدين تتيح الإفراج فورًا.','government',NEW.created_at);
    END`,
   // Keep financial minister informed of ordinary transfers, but do not expose sovereign-only transfers or payouts.
   'DROP TRIGGER IF EXISTS z43_finance_transactions',
   `CREATE TRIGGER z43_finance_transactions AFTER INSERT ON transactions
    WHEN NEW.note NOT LIKE 'مكافأة انتصار Update 43%'
     AND NEW.note NOT LIKE 'قرار رئاسي خاص%'
     AND NEW.note NOT LIKE 'تحويل خاص%'
     AND NEW.note NOT LIKE 'تحويل من توفير القيادة%'
     AND NEW.note NOT LIKE 'مكافأة الرئاسة%'
     AND NEW.note NOT LIKE 'مكافأة خاصة للرئاسة%'
     AND NEW.note NOT LIKE 'مكافأة تنفيذ أو صد حرب%'
    BEGIN INSERT OR IGNORE INTO z_notifications(id,user_id,title,body,kind,created_at)
    SELECT 'z43-fin-tx-'||NEW.id||'-'||fm.id,fm.id,'💰 حركة مالية موثقة',
      CASE WHEN NEW.note LIKE 'تحويل إلى %' THEN 'المرسل: '||COALESCE(owner.name,'مواطن')||' · المستلم: '||SUBSTR(NEW.note,11)||' · المبلغ: '||ABS(NEW.amount)||' زنجر'
      WHEN NEW.note LIKE 'تحويل من %' THEN 'المرسل: '||SUBSTR(NEW.note,10)||' · المستلم: '||COALESCE(owner.name,'مواطن')||' · المبلغ: '||ABS(NEW.amount)||' زنجر'
      ELSE 'المواطن: '||COALESCE(owner.name,'مواطن')||' · المبلغ: '||CASE WHEN NEW.amount>0 THEN '+' ELSE '' END||NEW.amount||' زنجر · السبب: '||SUBSTR(NEW.note,1,100) END,
      'money',NEW.created_at FROM users fm LEFT JOIN users owner ON owner.id=NEW.user_id WHERE fm.job='وزير المالية';
    END`,
   'DROP TRIGGER IF EXISTS z43_finance_treasury',
   `CREATE TRIGGER z43_finance_treasury AFTER INSERT ON z_state_ledger
     WHEN NEW.reason NOT LIKE 'صد صاروخ سري%'
      AND NEW.reason NOT LIKE 'دعم رئاسي لخزينة الدولة%'
      AND NEW.reason NOT LIKE 'تحويل خاص%'
      AND NEW.reason NOT LIKE 'مكافأة خاصة%'
      AND NEW.reason NOT LIKE 'مكافأة الرئاسة%'
     BEGIN INSERT OR IGNORE INTO z_notifications(id,user_id,title,body,kind,created_at)
     SELECT 'z43-fin-ledger-'||NEW.id||'-'||fm.id,fm.id,'🏦 سجل ميزانية الدولة',
      CASE WHEN NEW.delta>=0 THEN '+' ELSE '' END||NEW.delta||' زنجر · السبب: '||SUBSTR(NEW.reason,1,115)||' · بواسطة '||COALESCE(NEW.actor,'النظام'),
      'money',NEW.created_at FROM users fm WHERE fm.job='وزير المالية'; END`,
   'DROP TRIGGER IF EXISTS z43_notifications_push',
   `CREATE TRIGGER z43_notifications_push AFTER INSERT ON z_notifications BEGIN
    INSERT OR IGNORE INTO z_push_outbox(id,dedupe,endpoint,user_id,kind,title,body,url,created_at)
    SELECT lower(hex(randomblob(16))),
     NEW.id,
     s.endpoint,s.user_id,NEW.kind,
     NEW.title,
     NEW.body,
     CASE WHEN NEW.id LIKE 'z44-loan-%' OR NEW.id LIKE 'z44-collected-%' OR NEW.id LIKE 'z44-support-%' OR NEW.id LIKE 'z44-jail-%' THEN '/loans44.html'
          WHEN NEW.kind='war' THEN '/war.html' WHEN NEW.kind='money' THEN '/#/bank'
          WHEN NEW.kind IN ('job','jobs') THEN '/jobs36.html' WHEN NEW.kind='chat' THEN '/#/chat'
          WHEN NEW.kind IN ('market','trade','property') THEN '/#/market-pro' ELSE '/#/notifications' END,
     NEW.created_at FROM z_push_subscriptions s LEFT JOIN z_push_prefs pp ON pp.user_id=s.user_id
     WHERE s.user_id=NEW.user_id AND COALESCE(CASE WHEN NEW.kind='war' THEN pp.war WHEN NEW.kind='money' THEN pp.money
      WHEN NEW.kind IN ('job','jobs') THEN pp.jobs WHEN NEW.kind='chat' THEN pp.chat
      WHEN NEW.kind IN ('market','trade','property') THEN pp.market
      WHEN NEW.kind='government' THEN pp.government WHEN NEW.kind='social' THEN pp.social ELSE pp.system END,1)=1;
   END`,
   // Repair lost trigger after resets without touching past winnings.
   `CREATE TRIGGER IF NOT EXISTS z37_war_payout_battle AFTER INSERT ON z33_battles
     WHEN (NEW.attacker='home' AND NEW.result='victory') OR (NEW.attacker<>'home' AND NEW.result='defended') BEGIN
     INSERT OR IGNORE INTO z37_war_payouts(battle_id,actor_id,created_at) VALUES(NEW.id,CASE WHEN NEW.actor_id='system' THEN NULL ELSE NEW.actor_id END,NEW.created_at); END`,
   'DROP TRIGGER IF EXISTS z37_war_payout_apply', // remove any resurrected pre-season million-coin award
   'DROP TRIGGER IF EXISTS z43_war_reward',
   `CREATE TRIGGER z43_war_reward AFTER INSERT ON z37_war_payouts WHEN NEW.battle_id NOT LIKE 'radar-%' BEGIN
      INSERT OR IGNORE INTO z43_war_rewards(event_id,kind,treasury_added,citizen_added,leader_added,created_at) VALUES(NEW.battle_id,'battle',2500,700,CASE WHEN NEW.actor_id IS NOT NULL THEN 1000 ELSE 0 END,NEW.created_at);
      UPDATE z_state_treasury SET balance=balance+2500 WHERE id=1;
      INSERT INTO z_state_ledger(id,delta,reason,actor,created_at) VALUES(lower(hex(randomblob(16))),2500,'مكافأة انتصار Update 43','نظام الحروب',NEW.created_at);
      UPDATE users SET points=points+700;
      INSERT INTO transactions(id,user_id,amount,note,created_at) SELECT lower(hex(randomblob(16))),id,700,'مكافأة انتصار Update 43 لكل مواطن',NEW.created_at FROM users;
      UPDATE users SET points=points+1000 WHERE id=NEW.actor_id;
      INSERT INTO transactions(id,user_id,amount,note,created_at) SELECT lower(hex(randomblob(16))),id,1000,'مكافأة انتصار Update 43 لقائد المعركة',NEW.created_at FROM users WHERE id=NEW.actor_id;
      INSERT OR IGNORE INTO z_notifications(id,user_id,title,body,kind,created_at)
       SELECT 'z43-victory-'||NEW.battle_id||'-'||id,id,'🏆 انتصار دولة الزنجر','وصلك 700 زنجر مكافأة الانتصار'||CASE WHEN id=NEW.actor_id THEN ' ومعها 1,000 زنجر لقيادة الحرب' ELSE '' END||' · خزينة الدولة +2,500 زنجر','war',NEW.created_at FROM users;
    END`,
   'DROP TRIGGER IF EXISTS z43_radar_reward',
   `CREATE TRIGGER z43_radar_reward AFTER INSERT ON z37_war_payouts WHEN NEW.battle_id LIKE 'radar-%' BEGIN
      INSERT OR IGNORE INTO z43_war_rewards(event_id,kind,treasury_added,president_added,created_at)
       VALUES(NEW.battle_id,'radar',1500,CASE WHEN EXISTS(SELECT 1 FROM z42_role_claims r JOIN users u ON u.id=r.user_id WHERE r.role_key='president' AND u.job='رئيس الدولة') THEN 700 ELSE 0 END,NEW.created_at);
      UPDATE z_state_treasury SET balance=balance+1500 WHERE id=1;
      UPDATE users SET points=points+700 WHERE id=(SELECT r.user_id FROM z42_role_claims r JOIN users u ON u.id=r.user_id WHERE r.role_key='president' AND u.job='رئيس الدولة' LIMIT 1);
      -- Do not create any public ledger, notifications or transaction for the private event.
    END`,
   "INSERT OR REPLACE INTO site_settings(key,value,updated_at) VALUES('z44_migrated','1',strftime('%s','now')*1000)",
  ];
  await db.batch(sql.map(q=>db.prepare(q)));
 })().catch(e=>{z44Ready=null;throw e});return z44Ready;
}
async function z44LoanSweep(db,now=Date.now(),userId=''){
 await z44Ensure(db);
 const suffix=userId?' AND l.user_id=?':'';
 const args=userId?[userId]:[];
 await db.prepare(`INSERT OR IGNORE INTO z44_loan_meta(loan_id,user_id)
 SELECT l.id,l.user_id FROM econ_loans l WHERE l.principal>l.repaid${suffix}`).bind(...args).run();
 // For one loan, emit at most one reminder per sweep; primary key prevents repeat spam.
 await db.prepare(`INSERT OR IGNORE INTO z44_loan_reminders(loan_id,day,created_at)
 SELECT l.id,CASE WHEN ?>=l.due_at THEN 5+MIN(2,CAST((?-l.due_at)/? AS INTEGER))
 ELSE MIN(4,MAX(0,CAST((?-l.created_at)/? AS INTEGER))) END,?
 FROM econ_loans l JOIN z44_loan_meta m ON m.loan_id=l.id
 WHERE l.repaid<l.principal AND m.charged_at=0${suffix} LIMIT 80`).bind(now,now,Z44_DAY,now,Z44_DAY,now,...args).run();
 // Deduction happens once for each overdue loan, atomically with the treasury recovery.
 await db.prepare(`INSERT OR IGNORE INTO z44_loan_collections(loan_id,user_id,amount,created_at)
 SELECT l.id,l.user_id,l.principal-l.repaid,? FROM econ_loans l JOIN z44_loan_meta m ON m.loan_id=l.id
 WHERE l.repaid<l.principal AND l.due_at<=? AND m.charged_at=0${suffix} LIMIT 40`).bind(now,now,...args).run();
 // Continue one reminder each day during the three-day grace period.
 await db.prepare(`INSERT OR IGNORE INTO z44_loan_reminders(loan_id,day,created_at)
 SELECT m.loan_id,5+MIN(2,MAX(0,CAST((?-m.charged_at)/? AS INTEGER))),?
 FROM z44_loan_meta m JOIN users u ON u.id=m.user_id
 WHERE m.charged_at>0 AND m.cleared_at=0 AND m.grace_until>? AND u.points<0
 ${userId?' AND m.user_id=?':''} LIMIT 80`).bind(now,Z44_DAY,now,now,...args).run();
 // A separate three-day grace starts at charge; two-day jail never renews automatically.
 await db.prepare(`INSERT OR IGNORE INTO z44_loan_jails(loan_id,user_id,created_at)
 SELECT m.loan_id,m.user_id,? FROM z44_loan_meta m JOIN users u ON u.id=m.user_id
 WHERE m.charged_at>0 AND m.grace_until<=? AND m.cleared_at=0 AND u.points<0 AND m.jail_id=''
 AND NOT EXISTS(SELECT 1 FROM prison_requests p WHERE p.target_id=m.user_id AND p.status='approved' AND p.ends_at>?)
 ${userId?' AND m.user_id=?':''} LIMIT 40`).bind(now,now,now,...args).run();
}
async function z44LoansState(req,db){const u=await getMe(req,db);if(!u)return err(401,'سجل دخولك أولًا');await z44LoanSweep(db,Date.now(),u.id);
 const mine=await db.prepare(`SELECT l.id,l.principal,l.repaid,l.due_at,m.charged_at,m.grace_until,m.jail_id,u.points,
 CASE WHEN m.charged_at>0 THEN MAX(0,-u.points) ELSE l.principal-l.repaid END AS remaining
 FROM econ_loans l JOIN z44_loan_meta m ON m.loan_id=l.id JOIN users u ON u.id=l.user_id WHERE l.user_id=? ORDER BY l.created_at DESC LIMIT 15`).bind(u.id).all();
 const debtors=await db.prepare(`SELECT m.loan_id,u.name AS citizen,MAX(0,-u.points) AS remaining,m.grace_until,m.jail_id
 FROM z44_loan_meta m JOIN users u ON u.id=m.user_id WHERE m.charged_at>0 AND u.points<0
 ORDER BY m.charged_at DESC LIMIT 75`).all();
 return json({ok:true,mine:mine.results,debtors:debtors.results,now:Date.now()});}
async function z44LoansAction(req,db,p){const u=await getMe(req,db);if(!u)return err(401,'سجل الدخول أولًا');
 const type=String(p.type||''),loanId=crop(p.loan_id,100),amount=Number(p.amount);
 if(!Number.isSafeInteger(amount)||amount<1||amount>25000)return err(400,'اختر مبلغًا صحيحًا من 1 إلى 25,000 زنجر');
 if(type==='repay'){
  const loan=await db.prepare('SELECT principal,repaid FROM econ_loans WHERE id=? AND user_id=?').bind(loanId,u.id).first();
  if(!loan)return err(403,'القرض ليس من حسابك');
  if(await prisonActive(db,u.id))return err(403,'خلال السجن يمكن للآخرين سداد دينك؛ لا يمكنك التحويل من محفظة محظورة');
  return economyAction(req,db,{type:'repay',id:loanId,amount});
 }
 if(type==='support'){
  if(await prisonActive(db,u.id))return err(403,'لا يمكن التحويل أثناء السجن');
  const operationId=String(p.request_id||'');if(!/^support44-[a-f0-9-]{36}$/.test(operationId))return err(400,'مُعرّف الطلب غير صالح');
  const added=await db.prepare('INSERT OR IGNORE INTO z44_loan_support(id,loan_id,payer_id,amount,created_at) VALUES(?,?,?,?,?) RETURNING id').bind(operationId,loanId,u.id,amount,Date.now()).first();
  if(!added)return json({ok:true,already_paid:true,notice:'المساهمة دي اتسجلت قبل كده وماتخصمتش تاني'});
  return json({ok:true,notice:'تمت المساهمة بمبلغ '+amount+' زنجر، وتم تحديث رصيد المواطن المتعثر'});
 }
 return err(400,'نوع عملية غير معروف');
}
async function z43GrantSweep(db,now=Date.now(),userId=''){
 // One alert for each specific claim cycle; may be called by cron or while viewing the site.
 const sql=`INSERT OR REPLACE INTO z43_grant_notified(user_id,claim_at,created_at)
 SELECT u.id,u.claim_at,? FROM users u LEFT JOIN z43_grant_notified a ON a.user_id=u.id
 WHERE u.claim_at>0 AND u.claim_at<=? AND (a.user_id IS NULL OR a.claim_at<>u.claim_at)`+(userId?' AND u.id=?':'')+' LIMIT 500';
 return userId?db.prepare(sql).bind(now,now-3600000,userId).run():db.prepare(sql).bind(now,now-3600000).run();
}

