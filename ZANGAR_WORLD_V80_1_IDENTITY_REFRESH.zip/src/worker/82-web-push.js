// Zangar Web Push: payload-free VAPID requests; notification content lives in the service worker.
// Keeping push payload empty avoids storing plaintext message content with third-party push providers.
const Z_PUSH_HOSTS=['fcm.googleapis.com','updates.push.services.mozilla.com','web.push.apple.com'];
const Z_PUSH_ENCODE = bytes=>{let s='';for(const b of bytes)s+=String.fromCharCode(b);return btoa(s).replace(/\+/g,'-').replace(/\//g,'_').replace(/=+$/,'');};
const Z_PUSH_UTF8 = s=>new TextEncoder().encode(s);
const Z_PUSH_DECODE = raw=>{
 const s=String(raw||'').replace(/-/g,'+').replace(/_/g,'/');if(!/^[A-Za-z0-9+/]*={0,2}$/.test(s))throw Error('key not base64url');
 const v=atob(s.padEnd(Math.ceil(s.length/4)*4,'='));return Uint8Array.from(v,c=>c.charCodeAt(0));
};
function zPushValidEndpoint(endpoint){
 try{const u=new URL(endpoint);if(u.protocol!=='https:'||u.username||u.password||u.port||u.hash||endpoint.length>1300)return false;
  const h=u.hostname.toLowerCase();return Z_PUSH_HOSTS.includes(h)||/^(?:[a-z0-9-]+\.)+notify\.windows\.com$/.test(h)||/^(?:[a-z0-9-]+\.)+push\.apple\.com$/.test(h);
 }catch{return false;}
}
function zPushConfigured(env){return Boolean(env?.VAPID_PUBLIC_KEY&&env?.VAPID_PRIVATE_KEY);}
async function zPushJwt(endpoint,env){
 const publicBytes=Z_PUSH_DECODE(env.VAPID_PUBLIC_KEY);const privateBytes=Z_PUSH_DECODE(env.VAPID_PRIVATE_KEY);
 if(publicBytes.length!==65||publicBytes[0]!==4||privateBytes.length!==32)throw Error('VAPID key length');
 const key=await crypto.subtle.importKey('jwk',{
   kty:'EC',crv:'P-256',x:Z_PUSH_ENCODE(publicBytes.slice(1,33)),y:Z_PUSH_ENCODE(publicBytes.slice(33,65)),d:Z_PUSH_ENCODE(privateBytes),ext:false
 },{name:'ECDSA',namedCurve:'P-256'},false,['sign']);
 const aud=new URL(endpoint).origin;
 const head=Z_PUSH_ENCODE(Z_PUSH_UTF8(JSON.stringify({typ:'JWT',alg:'ES256'})));
 const payload=Z_PUSH_ENCODE(Z_PUSH_UTF8(JSON.stringify({aud,exp:Math.floor(Date.now()/1000)+3600,sub:String(env.VAPID_SUBJECT||'https://new-zangar-state.pages.dev')})));
 const unsigned=head+'.'+payload;
 const signature=Z_PUSH_ENCODE(new Uint8Array(await crypto.subtle.sign({name:'ECDSA',hash:'SHA-256'},key,Z_PUSH_UTF8(unsigned))));
 return unsigned+'.'+signature;
}
// Encrypted RFC 8291 aes128gcm payload (supported by Chrome/Firefox/Apple Web Push).
function zPushJoin(...parts){const out=new Uint8Array(parts.reduce((n,x)=>n+x.length,0));let at=0;for(const part of parts){out.set(part,at);at+=part.length;}return out;}
async function zPushHmac(key,bytes){const k=await crypto.subtle.importKey('raw',key,{name:'HMAC',hash:'SHA-256'},false,['sign']);return new Uint8Array(await crypto.subtle.sign('HMAC',k,bytes));}
async function zPushEncrypt(row,payload){
 const ua=Z_PUSH_DECODE(row.p256dh),auth=Z_PUSH_DECODE(row.auth);
 if(ua.length!==65||auth.length!==16)throw Error('Bad browser keys');
 const ephemeral=await crypto.subtle.generateKey({name:'ECDH',namedCurve:'P-256'},true,['deriveBits']);
 const as=new Uint8Array(await crypto.subtle.exportKey('raw',ephemeral.publicKey));
 const userPub=await crypto.subtle.importKey('raw',ua,{name:'ECDH',namedCurve:'P-256'},false,[]);
 const shared=new Uint8Array(await crypto.subtle.deriveBits({name:'ECDH',public:userPub},ephemeral.privateKey,256));
 const prkKey=await zPushHmac(auth,shared);
 const ikm=(await zPushHmac(prkKey,zPushJoin(Z_PUSH_UTF8('WebPush: info\0'),ua,as,new Uint8Array([1])))).slice(0,32);
 const salt=crypto.getRandomValues(new Uint8Array(16)),prk=await zPushHmac(salt,ikm);
 const cek=(await zPushHmac(prk,zPushJoin(Z_PUSH_UTF8('Content-Encoding: aes128gcm\0'),new Uint8Array([1])))).slice(0,16);
 const nonce=(await zPushHmac(prk,zPushJoin(Z_PUSH_UTF8('Content-Encoding: nonce\0'),new Uint8Array([1])))).slice(0,12);
 const encoded=zPushJoin(Z_PUSH_UTF8(JSON.stringify(payload)),new Uint8Array([2]));
 if(encoded.length>3000)throw Error('Push payload too long');
 const key=await crypto.subtle.importKey('raw',cek,{name:'AES-GCM'},false,['encrypt']);
 const cipher=new Uint8Array(await crypto.subtle.encrypt({name:'AES-GCM',iv:nonce},key,encoded));
 const header=new Uint8Array(21);header.set(salt);new DataView(header.buffer).setUint32(16,4096,false);header[20]=65;
 return zPushJoin(header,as,cipher);
}
async function zPushSendOne(db,env,row,payload){
 if(!zPushValidEndpoint(row.endpoint))return {ok:false,error:'invalid_endpoint'};
 try{
  const [jwt,encrypted]=await Promise.all([zPushJwt(row.endpoint,env),zPushEncrypt(row,payload)]);
  const reply=await fetch(row.endpoint,{method:'POST',redirect:'manual',headers:{
    'TTL':'86400','Urgency':row.kind==='war'?'high':'normal',
    'Content-Encoding':'aes128gcm','Content-Type':'application/octet-stream',
    'Authorization':'vapid t='+jwt+', k='+String(env.VAPID_PUBLIC_KEY)
   },body:encrypted});
  if(reply.status===404||reply.status===410){await db.prepare('DELETE FROM z_push_subscriptions WHERE endpoint=?').bind(row.endpoint).run();return {ok:false,expired:true};}
  return {ok:reply.ok,status:reply.status};
 }catch(e){console.error('Push transport error:',String(e));return {ok:false,error:'transport'};}
}
async function zPushBroadcast(db,env,userId='',payload={kind:'system',title:'دولة الزنجر الجديدة',body:'تنبيه تجريبي من الدولة',url:'/#/notifications'}){
 if(!zPushConfigured(env))return {accepted:0,failed:0,disabled:true};
 const rows=userId?await db.prepare('SELECT endpoint,p256dh,auth FROM z_push_subscriptions WHERE user_id=? LIMIT 5').bind(userId).all():await db.prepare('SELECT endpoint,p256dh,auth FROM z_push_subscriptions LIMIT 400').all();
 let accepted=0,failed=0,expired=0;
 for(let start=0;start<rows.results.length;start+=8){
  const batch=await Promise.all(rows.results.slice(start,start+8).map(row=>zPushSendOne(db,env,{...row,kind:payload.kind},payload)));
  for(const result of batch)if(result.ok)accepted++;else if(result.expired)expired++;else failed++;
 }
 return {accepted,failed,expired,subscribers:rows.results.length};
}
async function zPushDeliverQueue(db,env,limit=20){
 if(!zPushConfigured(env))return {configured:false};
 const now=Date.now();let accepted=0,failed=0,expired=0,attempted=0;
 for(let i=0;i<limit;i++){
  const row=await db.prepare(`UPDATE z_push_outbox SET claimed_at=?,attempts=attempts+1
    WHERE id=(SELECT id FROM z_push_outbox WHERE sent_at=0 AND attempts<4 AND claimed_at<=?
    AND created_at>=? ORDER BY created_at ASC LIMIT 1) AND sent_at=0 AND claimed_at<=?
    RETURNING *`).bind(Date.now(),Date.now()-65000,Date.now()-86400000,Date.now()-65000).first();
  if(!row)break;
  attempted++;
  const sub=await db.prepare('SELECT endpoint,p256dh,auth FROM z_push_subscriptions WHERE endpoint=? AND user_id=?').bind(row.endpoint,row.user_id).first();
  if(!sub){await db.prepare('UPDATE z_push_outbox SET sent_at=?,last_error=? WHERE id=?').bind(Date.now(),'no_subscription',row.id).run();continue;}
  // Preference can be changed after a notification was queued.
  const topic=zPushTopic(row.kind);
  const pref=await db.prepare(`SELECT ${topic} AS enabled FROM z_push_prefs WHERE user_id=?`).bind(row.user_id).first();
  if(pref&&Number(pref.enabled)!==1){await db.prepare('UPDATE z_push_outbox SET sent_at=?,last_error=? WHERE id=?').bind(Date.now(),'category_muted',row.id).run();continue;}
  const result=await zPushSendOne(db,env,{...sub,kind:row.kind},{id:row.id,kind:row.kind,title:row.title,body:row.body,url:row.url});
  if(result.ok){accepted++;await db.prepare('UPDATE z_push_outbox SET sent_at=?,last_error=? WHERE id=?').bind(Date.now(),'ok',row.id).run();}
  else if(result.expired){expired++;await db.prepare('UPDATE z_push_outbox SET sent_at=?,last_error=? WHERE id=?').bind(Date.now(),'expired',row.id).run();}
  else {failed++;await db.prepare('UPDATE z_push_outbox SET last_error=?,claimed_at=? WHERE id=?').bind(String(result.status||result.error||'failed'),Date.now(),row.id).run();}
 }
 return {attempted,accepted,failed,expired};
}
async function zPushDrain(db,env){
 if(!zPushConfigured(env))return {configured:false};
 const now=Date.now();
 const event=await db.prepare(`UPDATE z_push_dispatch SET claimed_at=?,attempts=attempts+1
 WHERE hour_slot=(SELECT hour_slot FROM z_push_dispatch WHERE sent_at=0 AND created_at>=? AND attempts<4
 AND claimed_at<=? ORDER BY hour_slot ASC LIMIT 1)
 AND sent_at=0 AND claimed_at<=? RETURNING hour_slot`).bind(now,now-240000,now-65000,now-65000).first();
 if(event){
  await zPushEnqueueAll(db,'🚀 صاروخ معادٍ على الرادار','ظهر هدف أحمر جديد! افتح غرفة العمليات وشارك في الدفاع.','war','/war.html','rocket-17m-'+event.hour_slot);
  await db.prepare('UPDATE z_push_dispatch SET sent_at=? WHERE hour_slot=? AND sent_at=0').bind(Date.now(),event.hour_slot).run();
 }
 return {rocket_enqueued:!!event,...await zPushDeliverQueue(db,env,65)};
}
