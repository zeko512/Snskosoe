// Update 4 Quick Setup: safe, idempotent one-time schema completion on first /api request.
// Uses fixed CREATE ... IF NOT EXISTS only; never deletes or resets user data.
// Each D1 prepared statement is standalone; do not feed multiline CREATE statements to db.exec.
const ZANGAR_CREATE_STATEMENTS = [
 "CREATE TABLE IF NOT EXISTS users ( id TEXT PRIMARY KEY, name TEXT NOT NULL, name_key TEXT NOT NULL UNIQUE, passhash TEXT NOT NULL, salt TEXT NOT NULL, role TEXT NOT NULL DEFAULT 'citizen', rank TEXT NOT NULL DEFAULT 'مواطن', job TEXT NOT NULL DEFAULT 'مواطن', points INTEGER NOT NULL DEFAULT 0 CHECK(points >= 0), avatar TEXT NOT NULL DEFAULT '', dob TEXT NOT NULL DEFAULT '', bio TEXT NOT NULL DEFAULT '', identity_no TEXT NOT NULL UNIQUE, candidate INTEGER NOT NULL DEFAULT 0, joined INTEGER NOT NULL, claim_at INTEGER NOT NULL DEFAULT 0, game_at INTEGER NOT NULL DEFAULT 0 )",
 "CREATE TABLE IF NOT EXISTS sessions (token_hash TEXT PRIMARY KEY,user_id TEXT NOT NULL,expires_at INTEGER NOT NULL,FOREIGN KEY(user_id) REFERENCES users(id))",
 "CREATE INDEX IF NOT EXISTS idx_sessions_user ON sessions(user_id)",
 "CREATE TABLE IF NOT EXISTS transactions(id TEXT PRIMARY KEY,user_id TEXT NOT NULL,amount INTEGER NOT NULL,note TEXT NOT NULL,created_at INTEGER NOT NULL)",
 "CREATE INDEX IF NOT EXISTS idx_transactions_user ON transactions(user_id,created_at DESC)",
 "CREATE TABLE IF NOT EXISTS activity(id TEXT PRIMARY KEY,name TEXT NOT NULL,text TEXT NOT NULL,created_at INTEGER NOT NULL)",
 "CREATE TABLE IF NOT EXISTS applications(id TEXT PRIMARY KEY,user_id TEXT NOT NULL,kind TEXT NOT NULL,detail TEXT NOT NULL,status TEXT NOT NULL DEFAULT 'pending',created_at INTEGER NOT NULL)",
 "CREATE TABLE IF NOT EXISTS cases(id TEXT PRIMARY KEY,user_id TEXT NOT NULL,target_id TEXT NOT NULL,kind TEXT NOT NULL,detail TEXT NOT NULL,status TEXT NOT NULL DEFAULT 'pending',created_at INTEGER NOT NULL)",
 "CREATE TABLE IF NOT EXISTS cards(id TEXT PRIMARY KEY,user_id TEXT NOT NULL,kind TEXT NOT NULL,number TEXT NOT NULL,created_at INTEGER NOT NULL)",
 "CREATE TABLE IF NOT EXISTS votes(voter_id TEXT PRIMARY KEY,candidate_id TEXT NOT NULL,created_at INTEGER NOT NULL)",
 "CREATE TABLE IF NOT EXISTS announcements(id TEXT PRIMARY KEY,text TEXT NOT NULL,created_at INTEGER NOT NULL)",
 "CREATE TABLE IF NOT EXISTS telecom_reviews(id TEXT PRIMARY KEY,request_id TEXT NOT NULL,reviewer_id TEXT NOT NULL,reason TEXT NOT NULL,created_at INTEGER NOT NULL)",
 "CREATE TABLE IF NOT EXISTS site_settings(key TEXT PRIMARY KEY, value TEXT NOT NULL, updated_at INTEGER NOT NULL)",
 "CREATE TABLE IF NOT EXISTS maintenance_attempts(visitor_hash TEXT PRIMARY KEY,failures INTEGER NOT NULL DEFAULT 0,blocked_until INTEGER NOT NULL DEFAULT 0)",
  "CREATE TABLE IF NOT EXISTS admin_grants (user_id TEXT PRIMARY KEY, created_at INTEGER NOT NULL)",
 "CREATE TABLE IF NOT EXISTS department_grants (user_id TEXT NOT NULL, department TEXT NOT NULL,created_at INTEGER NOT NULL,PRIMARY KEY(user_id,department))",
 "CREATE TABLE IF NOT EXISTS department_attempts (user_id TEXT NOT NULL,department TEXT NOT NULL,failures INTEGER NOT NULL DEFAULT 0,blocked_until INTEGER NOT NULL DEFAULT 0,PRIMARY KEY(user_id,department))",
 "CREATE TABLE IF NOT EXISTS admin_inbox_seen (user_id TEXT PRIMARY KEY,last_seen_at INTEGER NOT NULL DEFAULT 0)",
 "CREATE TABLE IF NOT EXISTS admin_unlock_attempts (user_id TEXT PRIMARY KEY, failures INTEGER NOT NULL DEFAULT 0, blocked_until INTEGER NOT NULL DEFAULT 0)",
 "CREATE TABLE IF NOT EXISTS grant_penalties (user_id TEXT PRIMARY KEY, penalty INTEGER NOT NULL DEFAULT 800)",
 "CREATE TABLE IF NOT EXISTS suspensions (user_id TEXT PRIMARY KEY, until_at INTEGER NOT NULL, reason TEXT NOT NULL DEFAULT '')",
 "CREATE TABLE IF NOT EXISTS econ_assets (id TEXT PRIMARY KEY,user_id TEXT NOT NULL,kind TEXT NOT NULL,level INTEGER NOT NULL DEFAULT 1,created_at INTEGER NOT NULL,last_at INTEGER NOT NULL DEFAULT 0,meta TEXT NOT NULL DEFAULT '{}')",
 "CREATE INDEX IF NOT EXISTS idx_econ_assets_user ON econ_assets(user_id)",
 "CREATE UNIQUE INDEX IF NOT EXISTS idx_econ_asset_single ON econ_assets(user_id,kind) WHERE kind <> 'land'",
 "CREATE TABLE IF NOT EXISTS econ_inventory (user_id TEXT NOT NULL,item TEXT NOT NULL,quantity INTEGER NOT NULL DEFAULT 0 CHECK(quantity>=0),PRIMARY KEY(user_id,item))",
 "CREATE TABLE IF NOT EXISTS econ_requests (id TEXT PRIMARY KEY,user_id TEXT NOT NULL,user_name TEXT NOT NULL,kind TEXT NOT NULL,amount INTEGER NOT NULL DEFAULT 0,message TEXT NOT NULL,status TEXT NOT NULL DEFAULT 'pending',reply TEXT NOT NULL DEFAULT '',created_at INTEGER NOT NULL)",
 "CREATE INDEX IF NOT EXISTS idx_econ_requests_user ON econ_requests(user_id,created_at DESC)",
 "CREATE TABLE IF NOT EXISTS econ_loans (id TEXT PRIMARY KEY,user_id TEXT NOT NULL,principal INTEGER NOT NULL,repaid INTEGER NOT NULL DEFAULT 0,created_at INTEGER NOT NULL,due_at INTEGER NOT NULL)",
 "CREATE TABLE IF NOT EXISTS econ_market (id TEXT PRIMARY KEY,seller_id TEXT NOT NULL,seller_name TEXT NOT NULL,item TEXT NOT NULL,quantity INTEGER NOT NULL,unit_price INTEGER NOT NULL,status TEXT NOT NULL DEFAULT 'open',created_at INTEGER NOT NULL)",
 "CREATE TABLE IF NOT EXISTS econ_shares (user_id TEXT NOT NULL,symbol TEXT NOT NULL,quantity INTEGER NOT NULL DEFAULT 0,PRIMARY KEY(user_id,symbol))",
 "CREATE TABLE IF NOT EXISTS econ_job_cooldowns (user_id TEXT PRIMARY KEY,ready_at INTEGER NOT NULL DEFAULT 0)",
 "CREATE TABLE IF NOT EXISTS econ_auctions (id TEXT PRIMARY KEY,seller_id TEXT NOT NULL,seller_name TEXT NOT NULL,item TEXT NOT NULL,quantity INTEGER NOT NULL,start_price INTEGER NOT NULL,bid INTEGER NOT NULL DEFAULT 0,highest_bidder TEXT NOT NULL DEFAULT '',ends_at INTEGER NOT NULL,status TEXT NOT NULL DEFAULT 'open',created_at INTEGER NOT NULL)",
 "CREATE INDEX IF NOT EXISTS idx_econ_auctions_status ON econ_auctions(status,ends_at)",
 "CREATE TABLE IF NOT EXISTS chat_rooms (id TEXT PRIMARY KEY,kind TEXT NOT NULL CHECK(kind IN ('private','group')),title TEXT NOT NULL DEFAULT '',direct_key TEXT UNIQUE,created_by TEXT NOT NULL,created_at INTEGER NOT NULL,last_message_at INTEGER NOT NULL DEFAULT 0)",
 "CREATE INDEX IF NOT EXISTS idx_chat_rooms_recent ON chat_rooms(last_message_at,created_at)",
 "CREATE TABLE IF NOT EXISTS chat_members (room_id TEXT NOT NULL,user_id TEXT NOT NULL,joined_at INTEGER NOT NULL,PRIMARY KEY(room_id,user_id),FOREIGN KEY(room_id) REFERENCES chat_rooms(id),FOREIGN KEY(user_id) REFERENCES users(id))",
 "CREATE INDEX IF NOT EXISTS idx_chat_members_user ON chat_members(user_id,room_id)",
 "CREATE TABLE IF NOT EXISTS chat_messages (id TEXT PRIMARY KEY,room_id TEXT NOT NULL,sender_id TEXT NOT NULL,body TEXT NOT NULL,created_at INTEGER NOT NULL,FOREIGN KEY(sender_id) REFERENCES users(id))",
 "CREATE INDEX IF NOT EXISTS idx_chat_messages_room_time ON chat_messages(room_id,created_at DESC,id DESC)",
 "CREATE TABLE IF NOT EXISTS police_grants (user_id TEXT PRIMARY KEY,created_at INTEGER NOT NULL)",
 "CREATE TABLE IF NOT EXISTS police_unlock_attempts (user_id TEXT PRIMARY KEY,failures INTEGER NOT NULL DEFAULT 0,blocked_until INTEGER NOT NULL DEFAULT 0)",
 "CREATE TABLE IF NOT EXISTS prison_requests (id TEXT PRIMARY KEY,target_id TEXT NOT NULL,requester_id TEXT NOT NULL,reviewer_id TEXT,reason TEXT NOT NULL,hours INTEGER NOT NULL,status TEXT NOT NULL DEFAULT 'pending' CHECK(status IN ('pending','approved','rejected')),created_at INTEGER NOT NULL,reviewed_at INTEGER NOT NULL DEFAULT 0,starts_at INTEGER NOT NULL DEFAULT 0,ends_at INTEGER NOT NULL DEFAULT 0)",
 "CREATE INDEX IF NOT EXISTS idx_prison_target_status ON prison_requests(target_id,status,ends_at)",
 "CREATE TABLE IF NOT EXISTS z_homes (user_id TEXT PRIMARY KEY,level INTEGER NOT NULL DEFAULT 1,style TEXT NOT NULL DEFAULT 'gold',updated_at INTEGER NOT NULL DEFAULT 0)",
 'CREATE TABLE IF NOT EXISTS z_furniture (user_id TEXT NOT NULL,item TEXT NOT NULL,qty INTEGER NOT NULL DEFAULT 0,PRIMARY KEY(user_id,item))',
 'CREATE TABLE IF NOT EXISTS z_savings (user_id TEXT PRIMARY KEY,balance INTEGER NOT NULL DEFAULT 0,interest_at INTEGER NOT NULL DEFAULT 0)',
 'CREATE TABLE IF NOT EXISTS z_companies (id TEXT PRIMARY KEY,owner_id TEXT NOT NULL UNIQUE,name TEXT NOT NULL,balance INTEGER NOT NULL DEFAULT 0,wage INTEGER NOT NULL DEFAULT 250,next_pay_at INTEGER NOT NULL DEFAULT 0,created_at INTEGER NOT NULL)',
 "CREATE TABLE IF NOT EXISTS z_company_members (company_id TEXT NOT NULL,user_id TEXT NOT NULL,status TEXT NOT NULL DEFAULT 'pending',created_at INTEGER NOT NULL,PRIMARY KEY(company_id,user_id))",
 "CREATE TABLE IF NOT EXISTS z_reports (id TEXT PRIMARY KEY,author_id TEXT NOT NULL,target_id TEXT NOT NULL,reason TEXT NOT NULL,status TEXT NOT NULL DEFAULT 'pending',reviewer_id TEXT,created_at INTEGER NOT NULL)",
 "CREATE TABLE IF NOT EXISTS z_appeals (id TEXT PRIMARY KEY,user_id TEXT NOT NULL,prison_id TEXT NOT NULL,reason TEXT NOT NULL,status TEXT NOT NULL DEFAULT 'pending',created_at INTEGER NOT NULL)",
 'CREATE TABLE IF NOT EXISTS z_notifications (id TEXT PRIMARY KEY,user_id TEXT NOT NULL,title TEXT NOT NULL,body TEXT NOT NULL,kind TEXT NOT NULL,created_at INTEGER NOT NULL,read_at INTEGER NOT NULL DEFAULT 0)',
 'CREATE INDEX IF NOT EXISTS idx_z_notifications_user ON z_notifications(user_id,created_at DESC)',
 'CREATE TABLE IF NOT EXISTS z_chat_voice (message_id TEXT PRIMARY KEY,mime TEXT NOT NULL,data TEXT NOT NULL,seconds INTEGER NOT NULL)',
 'CREATE TABLE IF NOT EXISTS z_chat_images (message_id TEXT PRIMARY KEY,mime TEXT NOT NULL,data TEXT NOT NULL,name TEXT NOT NULL DEFAULT "")',
 'CREATE TABLE IF NOT EXISTS z_chat_access(user_id TEXT PRIMARY KEY,paid_until INTEGER NOT NULL DEFAULT 0)',
 'CREATE TABLE IF NOT EXISTS z_edu_decisions(id TEXT PRIMARY KEY,author_id TEXT NOT NULL,kind TEXT NOT NULL,title TEXT NOT NULL,detail TEXT NOT NULL,created_at INTEGER NOT NULL)',
 'CREATE TABLE IF NOT EXISTS z_card_profiles(card_id TEXT PRIMARY KEY,user_id TEXT NOT NULL,tier TEXT NOT NULL,mode TEXT NOT NULL, cashback INTEGER NOT NULL DEFAULT 0, credit_used INTEGER NOT NULL DEFAULT 0,collateral_type TEXT NOT NULL DEFAULT "", collateral_asset_id TEXT NOT NULL DEFAULT "",created_at INTEGER NOT NULL)',
 'CREATE TABLE IF NOT EXISTS z_property_listings(id TEXT PRIMARY KEY,asset_id TEXT NOT NULL,owner_id TEXT NOT NULL,kind TEXT NOT NULL,price INTEGER NOT NULL,status TEXT NOT NULL,buyer_id TEXT NOT NULL DEFAULT "",created_at INTEGER NOT NULL)',
 'CREATE TABLE IF NOT EXISTS z_property_rentals(id TEXT PRIMARY KEY,asset_id TEXT NOT NULL,owner_id TEXT NOT NULL,tenant_id TEXT NOT NULL,rent_until INTEGER NOT NULL,created_at INTEGER NOT NULL)',
 'CREATE TABLE IF NOT EXISTS z_stock_state(symbol TEXT PRIMARY KEY,price INTEGER NOT NULL,updated_at INTEGER NOT NULL)',
 'CREATE TABLE IF NOT EXISTS z_stock_history(id TEXT PRIMARY KEY,symbol TEXT NOT NULL,price INTEGER NOT NULL,created_at INTEGER NOT NULL)',
 'CREATE TABLE IF NOT EXISTS z_courier_runs(id TEXT PRIMARY KEY,user_id TEXT NOT NULL,seed INTEGER NOT NULL,stage INTEGER NOT NULL,items INTEGER NOT NULL,started_at INTEGER NOT NULL,updated_at INTEGER NOT NULL,status TEXT NOT NULL)',
 'CREATE TABLE IF NOT EXISTS z_courier_wins(id TEXT PRIMARY KEY,user_id TEXT NOT NULL,won_at INTEGER NOT NULL)',
 'CREATE INDEX IF NOT EXISTS idx_courier_wins_user ON z_courier_wins(user_id,won_at)',
 'CREATE TABLE IF NOT EXISTS z_state_treasury (id INTEGER PRIMARY KEY CHECK(id=1),balance INTEGER NOT NULL DEFAULT 10000000 CHECK(balance>=0),created_at INTEGER NOT NULL)',
 'CREATE TABLE IF NOT EXISTS z_state_ledger (id TEXT PRIMARY KEY,delta INTEGER NOT NULL,reason TEXT NOT NULL,actor TEXT NOT NULL,created_at INTEGER NOT NULL)',
 'CREATE INDEX IF NOT EXISTS idx_state_ledger_time ON z_state_ledger(created_at DESC)',
 'CREATE TABLE IF NOT EXISTS z_war_state (id INTEGER PRIMARY KEY CHECK(id=1),cannon INTEGER NOT NULL DEFAULT 0,missiles INTEGER NOT NULL DEFAULT 0,armed INTEGER NOT NULL DEFAULT 1,protection_until INTEGER NOT NULL DEFAULT 0,emergency_until INTEGER NOT NULL DEFAULT 0,last_alert INTEGER NOT NULL DEFAULT 0)',
 'CREATE TABLE IF NOT EXISTS z_war_threats (hour_slot INTEGER PRIMARY KEY,angle INTEGER NOT NULL,started_at INTEGER NOT NULL,ends_at INTEGER NOT NULL,status TEXT NOT NULL DEFAULT "inbound",shots INTEGER NOT NULL DEFAULT 0,resolved_at INTEGER NOT NULL DEFAULT 0)',
 'CREATE TABLE IF NOT EXISTS z_war_events (id TEXT PRIMARY KEY,kind TEXT NOT NULL,text TEXT NOT NULL,actor TEXT NOT NULL,created_at INTEGER NOT NULL)',
 'CREATE INDEX IF NOT EXISTS idx_z_war_threats_last_launch ON z_war_threats(started_at DESC)',
 'CREATE TABLE IF NOT EXISTS z_war_grants (user_id TEXT PRIMARY KEY,created_at INTEGER NOT NULL)',
 'CREATE TABLE IF NOT EXISTS z_push_subscriptions (endpoint TEXT PRIMARY KEY,user_id TEXT NOT NULL,p256dh TEXT NOT NULL,auth TEXT NOT NULL,created_at INTEGER NOT NULL,updated_at INTEGER NOT NULL)',
 'CREATE INDEX IF NOT EXISTS idx_z_push_sub_user ON z_push_subscriptions(user_id,updated_at DESC)',
 'CREATE TABLE IF NOT EXISTS z_push_dispatch (hour_slot INTEGER PRIMARY KEY,created_at INTEGER NOT NULL,claimed_at INTEGER NOT NULL DEFAULT 0,sent_at INTEGER NOT NULL DEFAULT 0,attempts INTEGER NOT NULL DEFAULT 0)',
 'CREATE TABLE IF NOT EXISTS z_push_test_limits (user_id TEXT PRIMARY KEY,last_test_at INTEGER NOT NULL)',
 'CREATE TABLE IF NOT EXISTS z_push_prefs (user_id TEXT PRIMARY KEY,chat INTEGER NOT NULL DEFAULT 1,money INTEGER NOT NULL DEFAULT 1,government INTEGER NOT NULL DEFAULT 1,market INTEGER NOT NULL DEFAULT 1,jobs INTEGER NOT NULL DEFAULT 1,war INTEGER NOT NULL DEFAULT 1,social INTEGER NOT NULL DEFAULT 1,system INTEGER NOT NULL DEFAULT 1,updated_at INTEGER NOT NULL DEFAULT 0)',
 'CREATE TABLE IF NOT EXISTS z_push_outbox (id TEXT PRIMARY KEY,dedupe TEXT NOT NULL,endpoint TEXT NOT NULL,user_id TEXT NOT NULL,kind TEXT NOT NULL,title TEXT NOT NULL,body TEXT NOT NULL,url TEXT NOT NULL,created_at INTEGER NOT NULL,claimed_at INTEGER NOT NULL DEFAULT 0,sent_at INTEGER NOT NULL DEFAULT 0,attempts INTEGER NOT NULL DEFAULT 0,last_error TEXT NOT NULL DEFAULT "",UNIQUE(dedupe,endpoint))',
 'CREATE INDEX IF NOT EXISTS idx_z_push_outbox_pending ON z_push_outbox(sent_at,claimed_at,created_at)',
 'CREATE INDEX IF NOT EXISTS idx_z_push_outbox_user ON z_push_outbox(user_id,created_at DESC)',
 'CREATE TABLE IF NOT EXISTS z_war_unlock_attempts (user_id TEXT PRIMARY KEY,failures INTEGER NOT NULL DEFAULT 0,blocked_until INTEGER NOT NULL DEFAULT 0)',
 'CREATE INDEX IF NOT EXISTS idx_war_events_time ON z_war_events(created_at DESC)',
 'CREATE TABLE IF NOT EXISTS z_employee_hr(company_id TEXT NOT NULL,user_id TEXT NOT NULL,wage INTEGER,last_work_day INTEGER NOT NULL DEFAULT -1,last_absence_day INTEGER NOT NULL DEFAULT -1,paid_leave_until INTEGER NOT NULL DEFAULT 0,unpaid_leave_until INTEGER NOT NULL DEFAULT 0,fine_due INTEGER NOT NULL DEFAULT 0,advance_due INTEGER NOT NULL DEFAULT 0,PRIMARY KEY(company_id,user_id))',
 'CREATE TABLE IF NOT EXISTS z_hr_requests(id TEXT PRIMARY KEY,company_id TEXT NOT NULL,user_id TEXT NOT NULL,kind TEXT NOT NULL,amount INTEGER NOT NULL DEFAULT 0,days INTEGER NOT NULL DEFAULT 0,status TEXT NOT NULL DEFAULT "pending",created_at INTEGER NOT NULL,reviewed_at INTEGER NOT NULL DEFAULT 0)',
 'CREATE TABLE IF NOT EXISTS z_company_attendance(company_id TEXT NOT NULL,user_id TEXT NOT NULL,work_day INTEGER NOT NULL,created_at INTEGER NOT NULL,PRIMARY KEY(company_id,user_id,work_day))',
 'CREATE TABLE IF NOT EXISTS z_company_leaves(request_id TEXT PRIMARY KEY,company_id TEXT NOT NULL,user_id TEXT NOT NULL,kind TEXT NOT NULL,starts_at INTEGER NOT NULL,ends_at INTEGER NOT NULL)',
 'CREATE INDEX IF NOT EXISTS idx_z_hr_requests_company ON z_hr_requests(company_id,status,created_at)',
 'CREATE TABLE IF NOT EXISTS z_asset_tax_paid(asset_id TEXT NOT NULL,owner_id TEXT NOT NULL,paid_at INTEGER NOT NULL,PRIMARY KEY(asset_id,owner_id))',
 'CREATE INDEX IF NOT EXISTS idx_z_asset_tax_paid_owner ON z_asset_tax_paid(owner_id)',
 'CREATE TABLE IF NOT EXISTS z_finance_grants(user_id TEXT PRIMARY KEY,created_at INTEGER NOT NULL)',
 'CREATE TABLE IF NOT EXISTS z_finance_unlock_attempts(user_id TEXT PRIMARY KEY,failures INTEGER NOT NULL DEFAULT 0,blocked_until INTEGER NOT NULL DEFAULT 0)',
 'CREATE TABLE IF NOT EXISTS z_finance_requests(id TEXT PRIMARY KEY,kind TEXT NOT NULL,sender_id TEXT NOT NULL,recipient_id TEXT NOT NULL DEFAULT "",target_id TEXT NOT NULL DEFAULT "",asset_id TEXT NOT NULL DEFAULT "",amount INTEGER NOT NULL DEFAULT 0,message TEXT NOT NULL,reply TEXT NOT NULL DEFAULT "",status TEXT NOT NULL DEFAULT "pending",reviewer_id TEXT NOT NULL DEFAULT "",created_at INTEGER NOT NULL,reviewed_at INTEGER NOT NULL DEFAULT 0)',
 'CREATE INDEX IF NOT EXISTS idx_finance_requests_created ON z_finance_requests(created_at DESC)',
 'CREATE INDEX IF NOT EXISTS idx_finance_requests_target ON z_finance_requests(target_id,status)',
  
 'CREATE INDEX IF NOT EXISTS idx_z_company_members_user ON z_company_members(user_id)',
 'CREATE TABLE IF NOT EXISTS z_business_income (business_key TEXT PRIMARY KEY,owner_id TEXT NOT NULL,next_at INTEGER NOT NULL,cycles_paid INTEGER NOT NULL DEFAULT 0)',
 'CREATE INDEX IF NOT EXISTS idx_z_business_income_due ON z_business_income(next_at)',
 
 'CREATE TABLE IF NOT EXISTS z_war_planned_alerts (id TEXT PRIMARY KEY,creator_id TEXT NOT NULL,minutes INTEGER NOT NULL,created_at INTEGER NOT NULL,arrival_at INTEGER NOT NULL)',
 'CREATE TABLE IF NOT EXISTS z_chat_room_prefs(user_id TEXT NOT NULL,room_id TEXT NOT NULL,pinned INTEGER NOT NULL DEFAULT 0,archived INTEGER NOT NULL DEFAULT 0,last_read_at INTEGER NOT NULL DEFAULT 0,PRIMARY KEY(user_id,room_id))',
 'CREATE TABLE IF NOT EXISTS z_fine_appeals(id TEXT PRIMARY KEY,request_id TEXT NOT NULL UNIQUE,user_id TEXT NOT NULL,reason TEXT NOT NULL,status TEXT NOT NULL DEFAULT "pending",reviewer_id TEXT NOT NULL DEFAULT "",reply TEXT NOT NULL DEFAULT "",created_at INTEGER NOT NULL,reviewed_at INTEGER NOT NULL DEFAULT 0)'
];
const Z_U29_BUSINESS_TRIGGER="CREATE TRIGGER z_business_income_payout AFTER UPDATE OF cycles_paid ON z_business_income WHEN NEW.cycles_paid>OLD.cycles_paid BEGIN UPDATE users SET points=points+(CASE WHEN NEW.business_key LIKE 'company:%' THEN 250 WHEN EXISTS (SELECT 1 FROM econ_assets WHERE id=substr(NEW.business_key,7) AND kind='construction') THEN 180 ELSE 90 END) WHERE id=NEW.owner_id; INSERT INTO transactions(id,user_id,amount,note,created_at) VALUES(lower(hex(randomblob(16))),NEW.owner_id,(CASE WHEN NEW.business_key LIKE 'company:%' THEN 250 WHEN EXISTS (SELECT 1 FROM econ_assets WHERE id=substr(NEW.business_key,7) AND kind='construction') THEN 180 ELSE 90 END),'دخل ملكية مشروع — عائد متوازن كل 3 ساعات خارج الخزينة',CAST(strftime('%s','now') AS INTEGER)*1000); END";
// U31: restore only company-owner passive income to 4,000/3h; asset returns stay unchanged.
const Z_U31_BUSINESS_TRIGGER=Z_U29_BUSINESS_TRIGGER.replaceAll('THEN 250','THEN 4000').replace('دخل ملكية مشروع — عائد متوازن كل 3 ساعات خارج الخزينة','دخل ملكية المشروع كل 3 ساعات خارج خزينة الدولة');
let zangarSchemaInitialization = null;
async function ensureZangarSchema(db){
 if (!zangarSchemaInitialization) zangarSchemaInitialization = (async()=>{
  // U32: existing DBs need one indexed read per cold isolate, never a full migration on each request.
  let ready=null;
  try { ready=await db.prepare("SELECT value FROM site_settings WHERE key='u32_schema_ready'").first(); }
  catch(e){ if(!/no such table: site_settings/i.test(String(e?.message||e)))throw e; }
  if(ready?.value==='1')return;

  const schemaNames=ZANGAR_CREATE_STATEMENTS.map(s=>s.match(/IF NOT EXISTS\s+([A-Za-z_][\w]*)/i)?.[1]).filter(Boolean);
  const state=await db.prepare(`SELECT COUNT(*) AS n FROM sqlite_master WHERE type IN ('table','index','trigger') AND name IN (${schemaNames.map(()=>'?').join(',')})`).bind(...schemaNames).first();
  if(Number(state?.n)!==schemaNames.length)await db.batch(ZANGAR_CREATE_STATEMENTS.map(statement=>db.prepare(statement)));
  await db.prepare('INSERT OR IGNORE INTO z_state_treasury(id,balance,created_at) VALUES(1,10000000,?)').bind(Date.now()).run();
  await db.prepare('INSERT OR IGNORE INTO z_war_state(id) VALUES(1)').run();
  const columns=(await db.prepare('PRAGMA table_info(z_war_state)').all()).results;
  if(!columns.some(c=>c.name==='shots_left'))await db.prepare('ALTER TABLE z_war_state ADD COLUMN shots_left INTEGER NOT NULL DEFAULT 10').run();
  await db.prepare("INSERT OR IGNORE INTO site_settings(key,value,updated_at) VALUES('u25_attendance_tracking',?,?)").bind(String(Date.now()),Date.now()).run();
  // U29: replace the old 4,000-zangar trigger transactionally, ONCE.
  // No wallets / company balances are updated at migration time; only FUTURE payouts change.
  const u29profit=await db.prepare("SELECT value FROM site_settings WHERE key='u29_profit_rebalanced'").first();
  if(!u29profit){await db.batch([
    db.prepare('DROP TRIGGER IF EXISTS z_business_income_payout'),
    db.prepare(Z_U29_BUSINESS_TRIGGER),
    db.prepare("INSERT OR IGNORE INTO site_settings(key,value,updated_at) VALUES('u29_profit_rebalanced','1',?)").bind(Date.now())
  ]);}
  // U31: update only FUTURE owner payouts, preserve stored wallets, business balances and next_at.
  const u31restored=await db.prepare("SELECT value FROM site_settings WHERE key='u31_company_income_restored'").first();
  if(!u31restored){await db.batch([
    db.prepare('DROP TRIGGER IF EXISTS z_business_income_payout'),
    db.prepare(Z_U31_BUSINESS_TRIGGER),
    db.prepare("INSERT OR IGNORE INTO site_settings(key,value,updated_at) VALUES('u31_company_income_restored','1',?)").bind(Date.now())
  ]);}
  // U27: begin accrual from first migration, never backdate existing ownership or alter old balances.
  const incomeStart=Date.now()+3*3600000;
  // Season 2: no unconditional passive company income.
  // Investment projects yield only the new 15%-per-day project return.
  // Once only: reprice existing listed stocks, not shares or player wallets.
  const flag=await db.prepare("SELECT value FROM site_settings WHERE key='u25_stock_20_done'").first();
  if(!flag){await db.batch([db.prepare("UPDATE z_stock_state SET price=ROUND(price*1.2) WHERE symbol IN ('ZNGR','OASIS','GOLD')"),db.prepare("INSERT OR IGNORE INTO site_settings(key,value,updated_at) VALUES('u25_stock_20_done','1',?)").bind(Date.now())]);}
  // New indexes target the hot read paths (chat, notifications, citizen listings, and activity).
  // CREATE INDEX IF NOT EXISTS is non-destructive and performed ONCE for this DB.
  const indexes=[
   'CREATE INDEX IF NOT EXISTS idx_u32_users_joined ON users(joined DESC)',
   'CREATE INDEX IF NOT EXISTS idx_u32_activity_recent ON activity(created_at DESC)',
   'CREATE INDEX IF NOT EXISTS idx_u32_announcements_recent ON announcements(created_at DESC)',
   'CREATE INDEX IF NOT EXISTS idx_u32_tx_recent ON transactions(user_id,created_at DESC)',
   'CREATE INDEX IF NOT EXISTS idx_u32_chat_members_user ON chat_members(user_id,room_id)',
   'CREATE INDEX IF NOT EXISTS idx_u32_chat_messages_room ON chat_messages(room_id,created_at DESC,id DESC)',
   'CREATE INDEX IF NOT EXISTS idx_u32_notifications_user ON z_notifications(user_id,created_at DESC)',
   'CREATE INDEX IF NOT EXISTS idx_u32_stock_history_time ON z_stock_history(created_at DESC)',
   'CREATE INDEX IF NOT EXISTS idx_u32_cases_recent ON cases(created_at DESC)',
   'CREATE INDEX IF NOT EXISTS idx_u32_apps_recent ON applications(created_at DESC)',
   'CREATE INDEX IF NOT EXISTS idx_u32_market_open ON econ_market(status,created_at DESC)',
   'CREATE INDEX IF NOT EXISTS idx_u32_auctions_open ON econ_auctions(status,created_at DESC)'
  ];
  for(const sql of indexes)await db.prepare(sql).run();
  await db.prepare("INSERT OR IGNORE INTO site_settings(key,value,updated_at) VALUES('u32_schema_ready','1',?)").bind(Date.now()).run();

 })().catch(e=>{zangarSchemaInitialization=null;throw e});
 return zangarSchemaInitialization;
}

// Codes are validated only on the server; grants follow the signed-in account.
async function unlockDepartment(req,db,p){return err(403,'صلاحيات الوزارات تُمنح بالتعيين من الرئاسة، دون أكواد.');
/*
 const u=await getMe(req,db);if(!u)return err(401,'سجل الدخول أولًا');const department=crop(p.department,30),code=String(p.code||'');
 if(!DEPARTMENT_KEYS.includes(department))return err(400,'القسم غير موجود');
 if(!code||code.length>100)return err(400,'الكود غير صحيح');
 let row=await db.prepare('SELECT failures,blocked_until FROM department_attempts WHERE user_id=? AND department=?').bind(u.id,department).first(),now=Date.now();
 if(row&&row.blocked_until>now)return err(429,'محاولات كتير. جرّب بعد 15 دقيقة.');
 let actual=await digest(code),want=DEPARTMENT_CODES[department],diff=0;for(let i=0;i<want.length;i++)diff|=actual.charCodeAt(i)^want.charCodeAt(i);
 if(diff){let failures=(row?.blocked_until&&row.blocked_until<now?0:Number(row?.failures||0))+1;await db.prepare('INSERT INTO department_attempts(user_id,department,failures,blocked_until) VALUES(?,?,?,?) ON CONFLICT(user_id,department) DO UPDATE SET failures=excluded.failures,blocked_until=excluded.blocked_until').bind(u.id,department,failures,failures>=5?now+900000:0).run();return err(403,failures>=5?'محاولات كثيرة، انتظر 15 دقيقة':'الكود غير صحيح');}
 await db.batch([db.prepare('INSERT OR IGNORE INTO department_grants(user_id,department,created_at) VALUES(?,?,?)').bind(u.id,department,now),db.prepare('DELETE FROM department_attempts WHERE user_id=? AND department=?').bind(u.id,department)]);
 return json({ok:true,department});
}
*/
}
async function markInboxSeen(req,db){let u=await getMe(req,db);if(!u||!isAdmin(u))return err(403,'البريد متاح للإدارة فقط');await db.prepare('INSERT INTO admin_inbox_seen(user_id,last_seen_at) VALUES(?,?) ON CONFLICT(user_id) DO UPDATE SET last_seen_at=excluded.last_seen_at').bind(u.id,Date.now()).run();return json({ok:true})}

// Citizen chat: global, direct and member-only groups. Messages are never included in the public bootstrap.
const CHAT_GLOBAL='global';
async function chatAllowed(db,u,room){
 if(room===CHAT_GLOBAL)return true;
 if(!/^[a-f0-9-]{36}$/.test(room))return false;
 return !!await db.prepare('SELECT 1 AS yes FROM chat_members WHERE room_id=? AND user_id=?').bind(room,u.id).first();
}
async function chatState(req,db){
 const u=await getMe(req,db);if(!u)return err(401,'سجّل الدخول لفتح الشات.');
 const url=new URL(req.url),room=crop(url.searchParams.get('room')||CHAT_GLOBAL,80);
 if(room==='state-billing'){
   const bill=await z38BillState(req,db),payload=await bill.json();
   const official=(payload.bills||[]).map(b=>({id:b.id,room_id:room,sender_id:'official-state',sender_name:'الدولة',body:(b.kind==='home'?'🏠 عليك إيجار هذا اليوم، برجاء الدفع':'🏢 عليك ضريبة ملكية الشركة لهذا اليوم، برجاء الدفع')+' — التاريخ: '+new Date(b.day*86400000).toLocaleDateString('ar-EG')+' — '+b.amount+' زنجر — '+(b.paid_at?'✅ تم الدفع':'⏳ اضغط دفع الآن أو ليس الآن'),created_at:b.created_at,bill_kind:b.kind,paid_at:b.paid_at})).reverse();
   return json({room,rooms:[{id:'state-billing',kind:'official',title:'الدولة',peer_names:'الدولة',latest_body:payload.total?'مستحقات اليوم والمتأخرات: '+payload.total+' زنجر':'تم سداد المستحقات',last_message_at:official.at(-1)?.created_at||0,unread:payload.total?1:0,pinned:1,archived:0}],messages:official,me:u.id,dues:payload.dues,global_room:{}});
 }
 if(!await chatAllowed(db,u,room))return err(403,'هذه محادثة خاصة بأعضائها فقط.');
 if(url.searchParams.get('read')==='1'){const readAt=Date.now();await db.prepare('INSERT INTO z_chat_room_prefs(user_id,room_id,last_read_at) VALUES(?,?,?) ON CONFLICT(user_id,room_id) DO UPDATE SET last_read_at=excluded.last_read_at').bind(u.id,room,readAt).run();}
 const rooms=await db.prepare(`SELECT r.id,r.kind,r.title,r.created_at,r.last_message_at,
 (SELECT GROUP_CONCAT(u2.name, '، ') FROM chat_members mx JOIN users u2 ON u2.id=mx.user_id WHERE mx.room_id=r.id AND mx.user_id<>?) AS peer_names,
 (SELECT COUNT(*) FROM chat_members my WHERE my.room_id=r.id) AS member_count,
 (SELECT body FROM chat_messages mm WHERE mm.room_id=r.id ORDER BY mm.created_at DESC,mm.id DESC LIMIT 1) AS latest_body,
 COALESCE((SELECT pinned FROM z_chat_room_prefs x WHERE x.room_id=r.id AND x.user_id=?),0) AS pinned,
 COALESCE((SELECT archived FROM z_chat_room_prefs x WHERE x.room_id=r.id AND x.user_id=?),0) AS archived,
 (SELECT COUNT(*) FROM chat_messages m WHERE m.room_id=r.id AND m.sender_id<>? AND m.created_at>COALESCE((SELECT last_read_at FROM z_chat_room_prefs x WHERE x.room_id=r.id AND x.user_id=?),0)) AS unread
 FROM chat_rooms r INNER JOIN chat_members cm ON cm.room_id=r.id AND cm.user_id=?
 ORDER BY MAX(r.last_message_at,r.created_at) DESC LIMIT 80`).bind(u.id,u.id,u.id,u.id,u.id,u.id).all();
 const messages=await db.prepare(`SELECT m.id,m.room_id,m.sender_id,u.name AS sender_name,m.body,m.created_at, CASE WHEN v.message_id IS NOT NULL THEN 1 ELSE 0 END AS voice, CASE WHEN i.message_id IS NOT NULL THEN 1 ELSE 0 END AS image
   FROM chat_messages m JOIN users u ON u.id=m.sender_id LEFT JOIN z_chat_voice v ON v.message_id=m.id LEFT JOIN z_chat_images i ON i.message_id=m.id
 WHERE m.room_id=? ORDER BY m.created_at DESC,m.id DESC LIMIT 80`).bind(room).all();
 const globalMsg=await db.prepare('SELECT body,created_at FROM chat_messages WHERE room_id=? ORDER BY created_at DESC LIMIT 1').bind(CHAT_GLOBAL).first();
 const globalPrefs=await db.prepare('SELECT pinned,archived,last_read_at FROM z_chat_room_prefs WHERE user_id=? AND room_id=?').bind(u.id,CHAT_GLOBAL).first();
 const globalUnread=await db.prepare('SELECT COUNT(*) AS n FROM chat_messages WHERE room_id=? AND sender_id<>? AND created_at>?').bind(CHAT_GLOBAL,u.id,Number(globalPrefs?.last_read_at||0)).first();
 await z38AccrueOncePerDay(db,u);
 const billSummary=await db.prepare('SELECT COUNT(*) AS total,COALESCE(SUM(CASE WHEN paid_at=0 THEN amount ELSE 0 END),0) AS due,MAX(created_at) AS latest FROM z38_bills WHERE user_id=?').bind(u.id).first();
 const officialRoom={id:'state-billing',kind:'official',title:'الدولة',peer_names:'الدولة',latest_body:billSummary?.due>0?'عليك مستحقات للدولة: '+billSummary.due+' زنجر':'إيجار البيت وضريبة الشركة',last_message_at:Number(billSummary?.latest||0),unread:billSummary?.due>0?1:0,pinned:1,archived:0};
 return json({room,rooms:[officialRoom,...rooms.results],messages:messages.results.reverse(),me:u.id,global_room:{latest_body:globalMsg?.body||"مفتوح لجميع المواطنين",last_message_at:globalMsg?.created_at||0,unread:Number(globalUnread?.n||0),pinned:globalPrefs?.pinned||0,archived:globalPrefs?.archived||0}});
}
async function chatAction(req,db,p){
 const u=await getMe(req,db);if(!u)return err(401,'سجّل الدخول قبل إرسال رسالة.');
 if(String(p.room||'')==='state-billing')return err(403,'رسائل الدولة رسمية للقراءة والدفع فقط');
 const suspended=await db.prepare('SELECT until_at FROM suspensions WHERE user_id=?').bind(u.id).first();
 if(suspended&&Number(suspended.until_at)>Date.now())return err(403,'عضويتك موقوفة مؤقتًا.');
if(await prisonActive(db,u.id))return err(403,'أنت في السجن: الشات للقراءة فقط حتى انتهاء المدة.');
 if(p.type==='roomArchive'){
  const room=crop(p.room,80);if(!await chatAllowed(db,u,room))return err(403,'المحادثة غير متاحة');
  const archived=p.archived===true?1:0;
  await db.prepare('INSERT INTO z_chat_room_prefs(user_id,room_id,archived) VALUES(?,?,?) ON CONFLICT(user_id,room_id) DO UPDATE SET archived=excluded.archived').bind(u.id,room,archived).run();
  return json({ok:true,archived});
 }
 if(p.type==='roomPin'){
  const room=crop(p.room,80);if(!await chatAllowed(db,u,room))return err(403,'المحادثة غير متاحة');
  const pin=p.pinned===true?1:0;
  await db.prepare('INSERT INTO z_chat_room_prefs(user_id,room_id,pinned) VALUES(?,?,?) ON CONFLICT(user_id,room_id) DO UPDATE SET pinned=excluded.pinned').bind(u.id,room,pin).run();
  return json({ok:true,pinned:pin});
 }
 if(p.type==='delete'){
  const room=crop(p.room,80),messageId=crop(p.message_id,80);
  if(!/^[a-f0-9-]{36}$/.test(messageId))return err(400,'رسالة غير صالحة');
  if(!await chatAllowed(db,u,room))return err(403,'غير مسموح بفتح هذه المحادثة');
  const message=await db.prepare('SELECT room_id,sender_id FROM chat_messages WHERE id=?').bind(messageId).first();
  if(!message)return err(404,'الرسالة محذوفة بالفعل');
  if(message.room_id!==room)return err(403,'الرسالة مش في المحادثة دي');
  if(message.sender_id!==u.id)return err(403,'يمكنك حذف رسائلك أنت فقط');
  const jobs=[
   db.prepare('DELETE FROM z_chat_voice WHERE message_id=?').bind(messageId),
   db.prepare('DELETE FROM z_chat_images WHERE message_id=?').bind(messageId),
   db.prepare('DELETE FROM chat_messages WHERE id=? AND room_id=? AND sender_id=?').bind(messageId,room,u.id)
  ];
  if(room!==CHAT_GLOBAL)jobs.push(db.prepare('UPDATE chat_rooms SET last_message_at=COALESCE((SELECT MAX(created_at) FROM chat_messages WHERE room_id=?),0) WHERE id=?').bind(room,room));
  await db.batch(jobs);
  return json({ok:true,deleted_id:messageId});
 }
 if(p.type==='create'){
  const raw=Array.isArray(p.members)?p.members:[];
  const other=[...new Set(raw.map(String).filter(id=>id!==u.id))];
  if(other.length<1||other.length>9||other.some(x=>!/^[a-f0-9-]{36}$/.test(x)))return err(400,'اختار من شخص واحد إلى 9 أشخاص من المواطنين.');
  const placeholders=other.map(()=>'?').join(',');
  const verified=await db.prepare(`SELECT id,name FROM users WHERE id IN (${placeholders})`).bind(...other).all();
  if(verified.results.length!==other.length)return err(400,'فيه مواطن غير موجود. حدّث سجل المواطنين.');
  const group=other.length>1,now=Date.now(),title=crop(p.title,48);
  if(group&&!title)return err(400,'اكتب اسم المجموعة.');
  if(!group){
   const key=[u.id,other[0]].sort().join(':');
   let found=await db.prepare('SELECT id FROM chat_rooms WHERE direct_key=?').bind(key).first();
   if(found)return json({ok:true,room:found.id});
   const room=id();
   await db.prepare('INSERT OR IGNORE INTO chat_rooms(id,kind,title,direct_key,created_by,created_at,last_message_at) VALUES(?,?,?,?,?,?,?)').bind(room,'private','',key,u.id,now,0).run();
   found=await db.prepare('SELECT id FROM chat_rooms WHERE direct_key=?').bind(key).first();
   if(!found)return err(503,'تعذّر إنشاء المحادثة، حاول مرة أخرى.');
   await db.batch([db.prepare('INSERT OR IGNORE INTO chat_members(room_id,user_id,joined_at) VALUES(?,?,?)').bind(found.id,u.id,now),db.prepare('INSERT OR IGNORE INTO chat_members(room_id,user_id,joined_at) VALUES(?,?,?)').bind(found.id,other[0],now)]);
   return json({ok:true,room:found.id});
  }
  const room=id();
  await db.batch([db.prepare('INSERT INTO chat_rooms(id,kind,title,direct_key,created_by,created_at,last_message_at) VALUES(?,?,?,?,?,?,?)').bind(room,'group',title,null,u.id,now,0),...[u.id,...other].map(member=>db.prepare('INSERT INTO chat_members(room_id,user_id,joined_at) VALUES(?,?,?)').bind(room,member,now))]);
  return json({ok:true,room});
 }
 if(p.type==='voice'){
  const room=crop(p.room,80),mime=crop(p.mime,80),audio=String(p.data||''),seconds=Number(p.seconds);
  if(!await chatAllowed(db,u,room))return err(403,'المحادثة خاصة بأعضائها');
  if(!['audio/webm','audio/ogg','audio/mp4','audio/mpeg','audio/aac'].includes(mime))return err(400,'صيغة التسجيل غير مدعومة');
  if(!Number.isFinite(seconds)||seconds<1||seconds>17||audio.length<40||audio.length>125000||!/^[A-Za-z0-9+/]+={0,2}$/.test(audio))return err(400,'التسجيل كبير أو غير صالح؛ جرّب تسجيلًا أقصر من 15 ثانية');
  const now=Date.now(),prev=await db.prepare('SELECT created_at FROM chat_messages WHERE sender_id=? ORDER BY created_at DESC LIMIT 1').bind(u.id).first();
  if(prev&&now-prev.created_at<1500)return err(429,'انتظر لحظة قبل التسجيل التالي');
  await zChatCharge(db,u,now);
  const mid=id(),batch=[db.prepare('INSERT INTO chat_messages(id,room_id,sender_id,body,created_at) VALUES(?,?,?,?,?)').bind(mid,room,u.id,'🎤 رسالة صوتية',now),db.prepare('INSERT INTO z_chat_voice(message_id,mime,data,seconds) VALUES(?,?,?,?)').bind(mid,mime,audio,Math.ceil(seconds))];
  if(room!=='global')batch.push(db.prepare('UPDATE chat_rooms SET last_message_at=? WHERE id=?').bind(now,room));await db.batch(batch);
  if(room!=='global'){const recipients=await db.prepare('SELECT user_id FROM chat_members WHERE room_id=? AND user_id<>?').bind(room,u.id).all();for(const r of recipients.results.slice(0,9))await zNotify(db,r.user_id,'رسالة صوتية جديدة',u.name+' أرسل رسالة صوتية','chat');}
  return json({ok:true});
 }
 if(p.type==='image'){
  const room=crop(p.room,80),mime=crop(p.mime,80),img=String(p.data||''),name=crop(p.name||'','120');
  if(!await chatAllowed(db,u,room))return err(403,'المحادثة خاصة بأعضائها');
  if(!['image/jpeg','image/png','image/webp'].includes(mime))return err(400,'صيغة الصورة غير مدعومة');
  if(img.length<100||img.length>1600000||!/^[A-Za-z0-9+/]+={0,2}$/.test(img))return err(400,'الصورة كبيرة أو غير صالحة');
  const now=Date.now(),prev=await db.prepare('SELECT created_at FROM chat_messages WHERE sender_id=? ORDER BY created_at DESC LIMIT 1').bind(u.id).first();
  if(prev&&now-Number(prev.created_at)<1200)return err(429,'انتظر لحظة قبل إرسال صورة أخرى');
  await zChatCharge(db,u,now);
  const mid=id(),batch=[db.prepare('INSERT INTO chat_messages(id,room_id,sender_id,body,created_at) VALUES(?,?,?,?,?)').bind(mid,room,u.id,'🖼️ صورة',now),db.prepare('INSERT INTO z_chat_images(message_id,mime,data,name) VALUES(?,?,?,?)').bind(mid,mime,img,name)];
  if(room!=='global')batch.push(db.prepare('UPDATE chat_rooms SET last_message_at=? WHERE id=?').bind(now,room));
  await db.batch(batch);
  if(room!=='global'){const recipients=await db.prepare('SELECT user_id FROM chat_members WHERE room_id=? AND user_id<>?').bind(room,u.id).all();for(const r of recipients.results.slice(0,9))await zNotify(db,r.user_id,'صورة جديدة في الشات',u.name+' أرسل صورة','chat');}
  return json({ok:true});
 }
 if(p.type==='send'){
  const room=crop(p.room,80),body=String(p.body??'').trim();
  if(!await chatAllowed(db,u,room))return err(403,'غير مسموح بإرسال رسائل إلى هذه المحادثة.');
  if(!body||body.length>500)return err(400,'اكتب رسالة من 1 إلى 500 حرف.');
  const now=Date.now();
  const prev=await db.prepare('SELECT created_at FROM chat_messages WHERE sender_id=? ORDER BY created_at DESC LIMIT 1').bind(u.id).first();
  if(prev&&now-Number(prev.created_at)<900)return err(429,'انتظر ثانية قبل إرسال رسالة أخرى.');
  await zChatCharge(db,u,now);
  const mid=id();await db.prepare('INSERT INTO chat_messages(id,room_id,sender_id,body,created_at) VALUES(?,?,?,?,?)').bind(mid,room,u.id,body,now).run();
  if(room!==CHAT_GLOBAL){await db.prepare('UPDATE chat_rooms SET last_message_at=? WHERE id=?').bind(now,room).run();const recipients=await db.prepare('SELECT user_id FROM chat_members WHERE room_id=? AND user_id<>?').bind(room,u.id).all();for(const r of recipients.results.slice(0,9))await zNotify(db,r.user_id,'رسالة جديدة',u.name+': '+body.slice(0,65),'chat');}
  else await zPushEnqueueAll(db,'💬 رسالة في الشات العام',u.name+': '+body.slice(0,90),'chat','/#/chat','global-chat-'+mid,u.id);
  return json({ok:true});
 }
 return err(400,'طلب شات غير معروف.');
}

// Maintenance mode. Enforced by the server, never by hiding client-side buttons.
const MAINTENANCE_COOKIE='zangar_maintenance_access';
const MAINTENANCE_TTL=12*60*60*1000;
async function isMaintenance(db){const row=await db.prepare("SELECT value FROM site_settings WHERE key='maintenance'").first();return row?.value==='1'}
function eqSecure(a,b){if(typeof a!=='string'||typeof b!=='string'||a.length!==b.length)return false;let diff=0;for(let i=0;i<a.length;i++)diff|=a.charCodeAt(i)^b.charCodeAt(i);return diff===0}
async function signMaintenance(secret,payload){const key=await crypto.subtle.importKey('raw',enc.encode(secret),{name:'HMAC',hash:'SHA-256'},false,['sign']);return hex(await crypto.subtle.sign('HMAC',key,enc.encode('zangar-m11|'+payload)))}
async function hasMaintenancePass(req,env){const secret=Z39_PRESIDENT_HASH;if(typeof secret!=='string'||!secret)return false;const raw=cookieValue(req,MAINTENANCE_COOKIE),parts=raw.split('.');if(parts.length!==3||!/^[0-9]{13}$/.test(parts[0])||!/^[a-f0-9]{32}$/.test(parts[1])||!/^[a-f0-9]{64}$/.test(parts[2]))return false;const expiry=Number(parts[0]);if(expiry<Date.now()||expiry>Date.now()+MAINTENANCE_TTL+60000)return false;const expected=await signMaintenance(secret,parts[0]+'.'+parts[1]);return eqSecure(expected,parts[2])}
async function maintenanceAllowed(req,db,env){if(await hasMaintenancePass(req,env))return true;const u=await getMe(req,db);return isAdmin(u)}
function maintenanceHtml(){return `<!doctype html><html lang="ar" dir="rtl"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width, initial-scale=1"><meta name="theme-color" content="#090f22"><title>دولة الزنجر الجديدة — تحت الصيانة</title><style>
:root{color-scheme:dark;font-family:Tahoma,Arial,sans-serif}*{box-sizing:border-box}body{margin:0;min-height:100dvh;background:radial-gradient(circle at 70% 12%,#4b3a1d48,transparent 42%),radial-gradient(circle at 0% 90%,#16405c66,transparent 40%),#090f22;color:#f7ecda;display:flex;flex-direction:column}.top{height:83px;border-bottom:1px solid #344054a0;display:flex;align-items:center;gap:12px;padding:12px 22px;color:#f1ca73;font-weight:800;font-size:20px}.top img{width:52px;height:52px;border-radius:15px}.center{flex:1;display:grid;place-items:center;padding:32px 17px}.card{border:1px solid #7f6d427a;max-width:470px;width:100%;border-radius:32px;padding:33px 24px;background:linear-gradient(150deg,#17223b,#0f1830);box-shadow:0 26px 62px #01051391;text-align:center}.seal{width:77px;height:77px;margin:auto auto 18px;border:1px solid #846c37;border-radius:25px;background:#58431f66;display:grid;place-items:center;font-size:38px}.card h1{font-size:29px;line-height:1.6;margin:0;color:#f5d384}.card p{color:#c7c8d1;line-height:2;font-size:15px;margin:13px auto 26px}.field{border:1px solid #596079;border-radius:18px;display:block;padding:15px;width:100%;background:#0c1631;color:#fff;text-align:center;font-size:18px;outline:0}.field:focus{border-color:#f0c569}.label{display:block;text-align:right;font-weight:700;margin-bottom:11px}button{border:0;border-radius:19px;padding:15px;font:800 17px Tahoma,Arial,sans-serif;cursor:pointer}.gold{background:linear-gradient(#ffe394,#d8a83e);color:#392a17;width:100%;margin-top:14px}button:disabled{opacity:.5}.refresh{background:transparent;color:#e8d3a3;border:1px solid #3e4866;min-width:150px;margin-top:13px;font-size:13px}.error{color:#ffabc0;margin:12px 0 0;min-height:24px;font-size:14px}.foot{color:#9da6bd;text-align:center;font-size:12px;padding:20px}</style></head><body><header class="top"><img src="/assets/crest.svg" alt="شعار الزنجر"><span>دولة الزنجر الجديدة</span></header><main class="center"><section class="card"><div class="seal">🔧</div><h1>الدولة تحت الصيانة</h1><p>الدولة مغلقة مؤقتًا لإجراء بعض التعديلات. يرجى العودة لاحقًا. يمكن للمصرّح لهم الدخول باستخدام كود الرئاسة.</p><form id="door"><label class="label" for="code">الدخول المصرح به فقط</label><input id="code" class="field" type="password" autocomplete="off" placeholder="أدخل كود الرئاسة" maxlength="150" required><button class="gold" id="submit">فتح الدولة</button><div class="error" id="error" role="alert" aria-live="polite"></div></form><button class="refresh" onclick="location.reload()">تحديث الحالة ↻</button></section></main><footer class="foot">سيتم فتح الخدمات تلقائيًا عند انتهاء الصيانة بعد تحديث الصفحة.</footer><script>
const f=document.getElementById('door');f.addEventListener('submit',async e=>{e.preventDefault();const btn=document.getElementById('submit'),error=document.getElementById('error');btn.disabled=true;btn.textContent='جارِ التحقق...';error.textContent='';try{const r=await fetch('/api/maintenance/unlock',{method:'POST',headers:{'Content-Type':'application/json'},credentials:'same-origin',body:JSON.stringify({code:document.getElementById('code').value})});const d=await r.json();if(!r.ok)throw Error(d.error||'تعذر التحقق من الكود');location.replace('/#/home')}catch(e){error.textContent=e.message;btn.disabled=false;btn.textContent='فتح الدولة'}});
setInterval(async()=>{try{const r=await fetch('/api/maintenance/status',{cache:'no-store'});const d=await r.json();if(!d.maintenance)location.reload()}catch(e){}},30000);
</script></body></html>`}
async function maintenanceUnlock(req,db,env,p){const secret=Z39_PRESIDENT_HASH;const code=String(p.code||'');if(!code||code.length>150)return err(400,'أدخل كود الرئاسة الصحيح');const ip=crop(req.headers.get('CF-Connecting-IP')||req.headers.get('X-Forwarded-For')?.split(',')[0]||'unknown',100),who=await digest('lock11|'+ip+'|'+secret),now=Date.now();const attempt=await db.prepare('SELECT failures,blocked_until FROM maintenance_attempts WHERE visitor_hash=?').bind(who).first();if(attempt&&attempt.blocked_until>now)return err(429,'محاولات كثيرة. انتظر 15 دقيقة ثم جرّب مرة أخرى');const ok=eqSecure(await digest(code),Z39_PRESIDENT_HASH);if(!ok){const n=Number(attempt?.failures||0)+1;await db.prepare('INSERT INTO maintenance_attempts(visitor_hash,failures,blocked_until) VALUES(?,?,?) ON CONFLICT(visitor_hash) DO UPDATE SET failures=excluded.failures,blocked_until=excluded.blocked_until').bind(who,n,n>=5?now+900000:0).run();return err(403,'الكود غير صحيح');}
await db.prepare('DELETE FROM maintenance_attempts WHERE visitor_hash=?').bind(who).run();const expiry=now+MAINTENANCE_TTL,nonce=hex(crypto.getRandomValues(new Uint8Array(16))),payload=expiry+'.'+nonce,sig=await signMaintenance(secret,payload);return json({ok:true},200,{'Set-Cookie':`${MAINTENANCE_COOKIE}=${payload}.${sig}; HttpOnly; Secure; SameSite=Lax; Path=/; Max-Age=${MAINTENANCE_TTL/1000}`});}
async function setMaintenance(req,db,p){const u=await getMe(req,db);if(!isAdmin(u))return err(403,'هذه الميزة للرئاسة فقط؛ أدخل كود الرئاسة في لوحة التحكم أولًا');if(typeof p.enabled!=='boolean')return err(400,'حالة الصيانة غير صحيحة');const now=Date.now(),val=p.enabled?'1':'0';await db.prepare("INSERT INTO site_settings(key,value,updated_at) VALUES('maintenance',?,?) ON CONFLICT(key) DO UPDATE SET value=excluded.value,updated_at=excluded.updated_at").bind(val,now).run();await activity(db,u.name,p.enabled?'أغلق الدولة للصيانة':'أعاد فتح الدولة للمواطنين',now);return json({ok:true,maintenance:p.enabled});}


async function unlockPolice(req,db,p){return err(403,'الشرطة تُفتح بالتعيين من الرئيس، بدون كود منفصل.');
/*
 const u=await getMe(req,db);if(!u)return err(401,'سجّل دخولك أولًا');
 if(await prisonActive(db,u.id))return err(403,'الحساب في السجن ولا يمكنه فتح صلاحيات');
 if(isAdmin(u))return json({ok:true});
 const now=Date.now(),state=await db.prepare('SELECT failures,blocked_until FROM police_unlock_attempts WHERE user_id=?').bind(u.id).first();
 if(state?.blocked_until>now)return err(429,'محاولات كثيرة؛ انتظر 15 دقيقة');
 const value=crop(p.code,120),ok=value&&eqSecure(await digest(value),POLICE_CODE_HASH);
 if(!ok){let count=Number(state?.failures||0)+1;await db.prepare('INSERT INTO police_unlock_attempts(user_id,failures,blocked_until) VALUES(?,?,?) ON CONFLICT(user_id) DO UPDATE SET failures=excluded.failures,blocked_until=excluded.blocked_until').bind(u.id,count,count>=5?now+900000:0).run();return err(403,'كود الشرطة غير صحيح')}
 await db.batch([db.prepare('INSERT OR IGNORE INTO police_grants(user_id,created_at) VALUES(?,?)').bind(u.id,now),db.prepare('DELETE FROM police_unlock_attempts WHERE user_id=?').bind(u.id)]);
 return json({ok:true});
}
*/
}
async function prisonAction(req,db,p){
 const u=await getMe(req,db);if(!u)return err(401,'سجّل الدخول أولًا');
 if(await prisonActive(db,u.id))return err(403,'أنت في السجن، لا يمكنك اتخاذ أي إجراء');
 const chief=isAdmin(u),police=await policeGranted(db,u),now=Date.now();
 if(!police)return err(403,'هذا القسم للرئاسة أو الشرطة المخوّلة بالكود فقط');
 if(p.type==='request'){
  const targetId=crop(p.target_id,80),reason=crop(p.reason,400),hours=Number(p.hours);
  if(!PRISON_DURATIONS.includes(hours))return err(400,'اختار مدة صحيحة: ساعة أو 5 أو 10 ساعات أو يوم أو يومين أو أكثر');
  if(reason.length<8)return err(400,'لازم تكتب سبب السجن بوضوح (8 حروف على الأقل)');
  if(targetId===u.id)return err(400,'لا يمكنك طلب سجن نفسك');
  const target=await db.prepare('SELECT id,name FROM users WHERE id=?').bind(targetId).first();if(!target)return err(404,'المواطن غير موجود');
  if(await prisonActive(db,target.id,now))return err(409,'هذا المواطن يقضي مدة سجن بالفعل');
  const pending=await db.prepare("SELECT id FROM prison_requests WHERE target_id=? AND status='pending' LIMIT 1").bind(targetId).first();if(pending)return err(409,'يوجد طلب سجن ينتظر قرار الرئاسة لهذا المواطن');
  await db.prepare('INSERT INTO prison_requests(id,target_id,requester_id,reason,hours,status,created_at) VALUES(?,?,?,?,?,?,?)').bind(id(),targetId,u.id,reason,hours,'pending',now).run();
  await activity(db,u.name,'رفع طلب سجن ينتظر موافقة رئيس آخر',now);
  return json({ok:true,notice:'تم إرسال طلب السجن للرئاسة، ولا يُنفذ حتى يوافق رئيس آخر'});
 }
 if(p.type==='release'){
  if(!chief)return err(403,'الإفراج المبكر من صلاحية الرئاسة فقط');
  const prisonId=crop(p.id,80),reason=crop(p.reason,300);
  if(reason.length<8||p.confirm_text!=='تأكيد الإفراج')return err(400,'اكتب سبب الإفراج وتأكيد الإفراج');
  const prison=await db.prepare("SELECT target_id,ends_at FROM prison_requests WHERE id=? AND status='approved' AND ends_at>?").bind(prisonId,now).first();
  if(!prison)return err(404,'لا يوجد سجن نشط بهذا الرقم');
  const released=await db.prepare("UPDATE prison_requests SET ends_at=? WHERE id=? AND status='approved' AND ends_at>? RETURNING id").bind(now,prisonId,now).first();
  if(!released)return err(409,'تم الإفراج بالفعل');
  const target=await db.prepare('SELECT name FROM users WHERE id=?').bind(prison.target_id).first();
  await activity(db,u.name,'إفراج مبكر عن '+(target?.name||'مواطن')+' — '+reason,now);
  await zNotify(db,prison.target_id,'إفراج مبكر','قررت الرئاسة الإفراج عنك. السبب: '+reason,'government');
  return json({ok:true,notice:'✅ تم الإفراج المبكر وتسجيل القرار وإشعار المواطن'});
 }
 if(p.type==='review'){
  if(!chief)return err(403,'الموافقة والرفض من صلاحيات الرئاسة فقط');
  const requestId=crop(p.id,80),approve=p.approve===true;
  const row=await db.prepare("SELECT * FROM prison_requests WHERE id=? AND status='pending'").bind(requestId).first();if(!row)return err(404,'الطلب تمت مراجعته بالفعل');
  if(row.requester_id===u.id)return err(403,'لا يمكنك الموافقة على طلب السجن الذي قدمته بنفسك؛ يجب رئيس آخر');
  if(approve && await prisonActive(db,row.target_id,now))return err(409,'المواطن في السجن بالفعل');
  // The update is conditional to prevent two reviewers from deciding the same case.
  const updated=await db.prepare("UPDATE prison_requests SET status=?,reviewer_id=?,reviewed_at=?,starts_at=?,ends_at=? WHERE id=? AND status='pending' AND requester_id<>? RETURNING id").bind(approve?'approved':'rejected',u.id,now,approve?now:0,approve?now+row.hours*3600000:0,row.id,u.id).first();
  if(!updated)return err(409,'الطلب تمت مراجعته أو لا يمكنك مراجعته');
  await activity(db,u.name,(approve?'وافق على سجن ':'رفض طلب سجن ')+(await db.prepare('SELECT name FROM users WHERE id=?').bind(row.target_id).first())?.name,now);
  return json({ok:true,notice:approve?'تمت الموافقة وبدأت مدة السجن':'تم رفض طلب السجن'});
 }
 return err(400,'عملية السجن غير معروفة');
}


// World systems — all transactions run server-side and preserve legacy citizens and balances.
const Z_FURNITURE={bed:{title:'سرير مريح',cost:1500},desk:{title:'مكتب دراسة',cost:1500},sofa:{title:'كنبة',cost:3000},tv:{title:'تلفزيون',cost:4000},garden:{title:'حديقة صغيرة',cost:6000},pool:{title:'حمام سباحة',cost:15000},kitchen:{title:'مطبخ',cost:9400}};
const Z_HOME_COST={2:8000,3:25000,4:65000};
const Z_PUSH_TOPICS=['chat','money','government','market','jobs','war','social','system'];
function zPushTopic(kind){return ({chat:'chat',tax:'government',fine:'government',money:'money',job:'jobs',report:'government',request:'government',government:'government',jobs:'jobs',war:'war',property:'market',trade:'market',market:'market',social:'social',info:'system'})[kind]||'system';}
function zPushUrl(kind){return ({tax:'/finance.html',fine:'/finance.html',chat:'/#/chat',money:'/#/bank',job:'/#/companies',report:'/#/police-reports',request:'/#/documents',war:'/war.html',property:'/#/properties',trade:'/#/market-pro',market:'/#/market-pro',social:'/#/notifications'})[kind]||'/#/notifications';}
async function zPushEnqueue(db,userId,title,body,kind='system',url='',dedupe=''){
 const topic=zPushTopic(kind),safeUrl=(url.startsWith('/')&&!url.startsWith('//'))?url:zPushUrl(kind);
 const key=dedupe||id();
 await db.prepare(`INSERT OR IGNORE INTO z_push_outbox(id,dedupe,endpoint,user_id,kind,title,body,url,created_at)
 SELECT lower(hex(randomblob(16))),?,s.endpoint,s.user_id,?,?,?,?,?
 FROM z_push_subscriptions s WHERE s.user_id=?
 AND COALESCE((SELECT ${topic} FROM z_push_prefs WHERE user_id=s.user_id),1)=1`).bind(key,topic,crop(title,90),crop(body,220),safeUrl,Date.now(),userId).run();
}
async function zPushEnqueueAll(db,title,body,kind='system',url='',dedupe='',excludeUser=''){
 const topic=zPushTopic(kind),safeUrl=(url.startsWith('/')&&!url.startsWith('//'))?url:zPushUrl(kind);
 const key=dedupe||id();
 await db.prepare(`INSERT OR IGNORE INTO z_push_outbox(id,dedupe,endpoint,user_id,kind,title,body,url,created_at)
 SELECT lower(hex(randomblob(16))),?,s.endpoint,s.user_id,?,?,?,?,?
 FROM z_push_subscriptions s WHERE s.user_id<>? AND COALESCE((SELECT ${topic} FROM z_push_prefs WHERE user_id=s.user_id),1)=1`).bind(key,topic,crop(title,90),crop(body,220),safeUrl,Date.now(),excludeUser).run();
}
async function zNotify(db,userId,title,body,kind='info'){
 const eventId=id();
 await db.prepare('INSERT INTO z_notifications(id,user_id,title,body,kind,created_at) VALUES(?,?,?,?,?,?)').bind(eventId,userId,crop(title,75),crop(body,230),crop(kind,24),Date.now()).run();
 await zPushEnqueue(db,userId,title,body,kind,'',eventId);
}

async function zPointDebit(db,u,amount,note,withStateEconomy=false){
 amount=Math.ceil(amount);
 const stateTax=withStateEconomy?Math.max(1,Math.ceil(amount*(await z78TaxRate(db,u)))):0,total=amount+stateTax;
 const result=await db.prepare('UPDATE users SET points=points-? WHERE id=? AND points>=? RETURNING points').bind(total,u.id,total).first();
 if(!result)throw Error('رصيد النقاط غير كافٍ');
 await addTx(db,u.id,-total,note+(stateTax?` + دعم اقتصاد الدولة ${stateTax} نقطة`:''));
 if(stateTax)await stateEconomyAdd(db,stateTax,note,u.name);
 return result;
}

