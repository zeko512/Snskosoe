// ===== V65.9: Air-defense arcade (no revival of archived wars) =====
// All actions require a code-unlocked, account-bound command session, server-side aim checks and
// an atomic D1 INSERT trigger. Viewer status exposes radar only, never tank control.
let z659AirSchema=null;
const Z660_GATE_HASH='9364550bfed352e629650b6ef381e1cab76bab852cee8a1273742f2c08544104';
let z660GateSchema=null;

async function z659AirEnsure(db){
 if(!z659AirSchema)z659AirSchema=(async()=>{
  const q=[
   `CREATE TABLE IF NOT EXISTS z659_air_tracks (
      id TEXT PRIMARY KEY, slot INTEGER NOT NULL UNIQUE, started_at INTEGER NOT NULL,
      expires_at INTEGER NOT NULL, az INTEGER NOT NULL, el INTEGER NOT NULL,
      status TEXT NOT NULL DEFAULT 'incoming', resolved_by TEXT, resolved_at INTEGER)`,
   `CREATE INDEX IF NOT EXISTS z659_air_tracks_expiry ON z659_air_tracks(expires_at,status)`,
   `CREATE TABLE IF NOT EXISTS z659_air_shots (
      id TEXT PRIMARY KEY,user_id TEXT NOT NULL,target_id TEXT NOT NULL,
      az INTEGER NOT NULL,el INTEGER NOT NULL,hit INTEGER NOT NULL CHECK(hit IN(0,1)),
      created_at INTEGER NOT NULL)`,
   `CREATE INDEX IF NOT EXISTS z659_air_recent_shots ON z659_air_shots(user_id,created_at)`,
   `CREATE TABLE IF NOT EXISTS z660_air_debts(user_id TEXT PRIMARY KEY,amount INTEGER NOT NULL DEFAULT 0 CHECK(amount>=0))`,
   `CREATE TABLE IF NOT EXISTS z660_air_emergencies(id TEXT PRIMARY KEY,actor_id TEXT NOT NULL,created_at INTEGER NOT NULL)`,
   `CREATE TABLE IF NOT EXISTS z70_air_command_sessions(token_hash TEXT PRIMARY KEY,user_id TEXT NOT NULL,expires_at INTEGER NOT NULL)`,
   `CREATE INDEX IF NOT EXISTS z660_air_emergency_time ON z660_air_emergencies(created_at)`,
   `CREATE TABLE IF NOT EXISTS z660_air_shots (
      id TEXT PRIMARY KEY,user_id TEXT NOT NULL,target_id TEXT NOT NULL,
      az INTEGER NOT NULL,el INTEGER NOT NULL,hit INTEGER NOT NULL CHECK(hit IN(0,1)),
      created_at INTEGER NOT NULL)`,
   `CREATE INDEX IF NOT EXISTS z660_air_recent_shots ON z660_air_shots(user_id,created_at)`,
   `CREATE TRIGGER IF NOT EXISTS z660_air_debt_settle AFTER UPDATE OF points ON users
    WHEN NEW.points>OLD.points AND EXISTS (SELECT 1 FROM z660_air_debts WHERE user_id=NEW.id AND amount>0)
    BEGIN
     UPDATE users SET points=MAX(0,NEW.points-(SELECT amount FROM z660_air_debts WHERE user_id=NEW.id)) WHERE id=NEW.id;
     UPDATE z660_air_debts SET amount=MAX(0,amount-NEW.points) WHERE user_id=NEW.id;
    END`,
   `DROP TRIGGER IF EXISTS z660_air_emergency_limit`,
   `CREATE TRIGGER IF NOT EXISTS z660_air_emergency_limit BEFORE INSERT ON z660_air_emergencies BEGIN
      SELECT CASE WHEN EXISTS(SELECT 1 FROM z660_air_emergencies WHERE created_at>NEW.created_at-1800000) THEN RAISE(ABORT,'يُسمح بإنذار طوارئ واحد كل 30 دقيقة') END;
      SELECT CASE WHEN NOT EXISTS (SELECT 1 FROM z70_air_command_sessions s
        WHERE s.user_id=NEW.actor_id AND s.expires_at>NEW.created_at)
        THEN RAISE(ABORT,'يجب فتح لوحة التحكم بالرمز الصحيح أولًا') END;
    END`,
   `CREATE TRIGGER IF NOT EXISTS z660_air_emergency_alert AFTER INSERT ON z660_air_emergencies BEGIN
      INSERT OR IGNORE INTO z_notifications(id,user_id,title,body,kind,created_at)
       SELECT 'air-alert-'||NEW.id||'-'||u.id,u.id,'🚨 تحذير داخل لعبة ZANGAR WORLD','الدوله تخوض حربا الأن يرجي الحذر','war',NEW.created_at
       FROM users u WHERE NOT EXISTS (SELECT 1 FROM z64_archived_users a WHERE a.user_id=u.id AND a.restored_at=0);
    END`,
   `DROP TRIGGER IF EXISTS z660_air_shot_check`,
   `CREATE TRIGGER IF NOT EXISTS z660_air_shot_check BEFORE INSERT ON z660_air_shots BEGIN
      SELECT CASE WHEN NOT EXISTS (
        SELECT 1 FROM z70_air_command_sessions s
        WHERE s.user_id=NEW.user_id AND s.expires_at>NEW.created_at
      ) THEN RAISE(ABORT,'يجب فتح لوحة التحكم بالرمز الصحيح أولًا') END;
      SELECT CASE WHEN NOT EXISTS (
        SELECT 1 FROM z659_air_tracks t WHERE t.id=NEW.target_id AND t.status='incoming'
           AND t.started_at<=NEW.created_at AND t.expires_at>NEW.created_at
      ) THEN RAISE(ABORT,'الهدف انتهى أو تم اعتراضه') END;
      SELECT CASE WHEN EXISTS (
        SELECT 1 FROM z660_air_shots s WHERE s.user_id=NEW.user_id
         AND s.created_at>NEW.created_at-1700
      ) THEN RAISE(ABORT,'انتظر بين الطلقات') END;
      SELECT CASE WHEN NEW.az NOT BETWEEN 0 AND 359 OR NEW.el NOT BETWEEN 5 AND 83
       THEN RAISE(ABORT,'اتجاه التصويب غير صحيح') END;
      SELECT CASE WHEN NEW.hit != (
        SELECT CASE WHEN abs(((NEW.az-t.az+540)%360)-180)<=18 AND abs(NEW.el-t.el)<=14 THEN 1 ELSE 0 END
        FROM z659_air_tracks t WHERE t.id=NEW.target_id
      ) THEN RAISE(ABORT,'لا يمكن التلاعب بنتيجة التصويب') END;
    END`,
   `CREATE TRIGGER IF NOT EXISTS z660_air_shot_apply AFTER INSERT ON z660_air_shots BEGIN
      -- A miss is net -2500 (launch 2000 + penalty 500); a hit is net -500 (launch 2000 - minister reward 1500).
      -- users.points is CHECK >= 0 in V65; overdrafts are stored durably as debt, exposing an honest negative net balance.
      INSERT INTO z660_air_debts(user_id,amount)
       SELECT NEW.user_id, MAX(0,(CASE WHEN NEW.hit=1 THEN 500 ELSE 2500 END)-u.points) FROM users u WHERE u.id=NEW.user_id
       ON CONFLICT(user_id) DO UPDATE SET amount=amount+excluded.amount;
      UPDATE users SET points=MAX(0,points-CASE WHEN NEW.hit=1 THEN 500 ELSE 2500 END) WHERE id=NEW.user_id;
      INSERT INTO transactions(id,user_id,amount,note,created_at)
       VALUES (lower(hex(randomblob(16))),NEW.user_id,-2000,'الدفاع الجوي: تكلفة إطلاق صاروخ',NEW.created_at);
      INSERT INTO transactions(id,user_id,amount,note,created_at)
       SELECT lower(hex(randomblob(16))),NEW.user_id,1500,'الدفاع الجوي: مكافأة اعتراض ناجح',NEW.created_at WHERE NEW.hit=1;
      INSERT INTO transactions(id,user_id,amount,note,created_at)
       SELECT lower(hex(randomblob(16))),NEW.user_id,-500,'الدفاع الجوي: غرامة إخفاق',NEW.created_at WHERE NEW.hit=0;
      UPDATE z659_air_tracks SET status='intercepted',resolved_by=NEW.user_id,resolved_at=NEW.created_at
       WHERE id=NEW.target_id AND NEW.hit=1;
      UPDATE z_state_treasury SET balance=balance+2000 WHERE id=1 AND NEW.hit=1;
      INSERT INTO z_state_ledger(id,delta,reason,actor,created_at)
       SELECT lower(hex(randomblob(16))),2000,'مكافأة نجاح الدفاع الجوي','نظام الدفاع الجوي',NEW.created_at WHERE NEW.hit=1;
      -- Award 500 to each active registered citizen, including a minister who is also a citizen.
      -- Debt settlement trigger applies to each new credit atomically.
      UPDATE users SET points=points+500
       WHERE NEW.hit=1 AND NOT EXISTS(SELECT 1 FROM z64_archived_users a WHERE a.user_id=users.id AND a.restored_at=0);
      INSERT INTO transactions(id,user_id,amount,note,created_at)
       SELECT lower(hex(randomblob(16))),u.id,500,'مكافأة المواطن عن نجاح الدفاع الجوي',NEW.created_at
       FROM users u WHERE NEW.hit=1 AND NOT EXISTS(SELECT 1 FROM z64_archived_users a WHERE a.user_id=u.id AND a.restored_at=0);
    END`
  ];await db.batch(q.map(sql=>db.prepare(sql)));
 })().catch(e=>{z659AirSchema=null;throw e});
 await z72Ensure(db);
 return z659AirSchema;
}
async function z659AirPermission(db,u){
 if(!u||u.role!=='minister'||u.job!=='وزير الدفاع وشؤون الدولة')return false;
 return !!(await db.prepare("SELECT user_id FROM z42_role_claims WHERE user_id=? AND role_key='defense'").bind(u.id).first());
}
async function z659AirWave(db,now){
 // An alarm is one coherent timed threat, never extra random missiles every 34 seconds.
 const alarm=await db.prepare('SELECT 1 FROM z68_air_alert_phase WHERE created_at>? LIMIT 1').bind(now-600000).first();
 if(alarm)return;
 const slot=Math.floor(now/34000);
 let a=crypto.getRandomValues(new Uint32Array(2));
 const az=18+(a[0]%324),el=24+(a[1]%47);
 const trackId=id(),kind=slot%5===0?'drone':slot%3===0?'fast':'normal',duration=kind==='fast'?21000:kind==='drone'?28000:32000;
 const inserted=await db.prepare(`INSERT OR IGNORE INTO z659_air_tracks(id,slot,started_at,expires_at,az,el,status)
 VALUES(?,?,?,?,?,?,'incoming')`).bind(trackId,slot,now,now+duration,az,el).run();
 if(inserted.meta?.changes){await db.prepare('INSERT OR IGNORE INTO z68_air_track_meta(track_id,kind,facility) VALUES(?,?,?)').bind(trackId,kind,['المستشفى','المطار','محطة الكهرباء','مركز المدينة'][slot%4]).run();try{await z74AirPush(db,now);}catch(e){console.warn('z74 air push',String(e));}}
}
async function z659AirState(request,db){
 await z68EnsureGameSchema(db);await z42Ensure(db);await z659AirEnsure(db);
 const stamp=Date.now();await z68AlertEnsure(db);const city=await z68WorldRead(db,stamp);await z659AirWave(db,stamp);const alert=await z68AlertSnapshot(db,stamp);
 const u=await getMe(request,db),minister=await z70CommandAllowed(request,db,u);
 const active=(await db.prepare("SELECT t.id,t.az,t.el,t.started_at,t.expires_at,COALESCE(m.kind,'normal') AS kind,COALESCE(m.facility,'مركز المدينة') AS facility FROM z659_air_tracks t LEFT JOIN z68_air_track_meta m ON m.track_id=t.id WHERE t.status='incoming' AND t.expires_at>? ORDER BY t.started_at DESC LIMIT 4").bind(stamp).all()).results;
 const tracks=active.map(t=>({id:t.id,az:t.az,type:t.kind,facility:t.facility,...(minister?{el:t.el}:{}),started_at:t.started_at,expires_at:t.expires_at,status:'incoming'}));
 const balanceRow=minister?await db.prepare('SELECT u.points-COALESCE(d.amount,0) AS net FROM users u LEFT JOIN z660_air_debts d ON d.user_id=u.id WHERE u.id=?').bind(u.id).first():null;
 const extra=minister?{points:Number(balanceRow?.net||0),treasury:await zTreasuryBalance(db),upgrades:await z68UpgradeLevels(db,u.id)}:{};
 return json({ok:true,minister,server_time:stamp,tracks,alert,city,role:minister?'minister':'observer',...extra},200,{'Cache-Control':'no-store, private'});
}
async function z659AirFire(request,db){
 const origin=request.headers.get('Origin');if(origin&&origin!==new URL(request.url).origin)return err(403,'مصدر غير موثوق');
 const u=await getMe(request,db);if(!u||!(await z70CommandAllowed(request,db,u)))return err(403,'سجّل الدخول وافتح مركز التحكم بالرمز السري أولًا');
 if(await isMaintenance(db))return err(503,'الدولة تحت الصيانة');
 if(await prisonActive(db,u.id))return err(403,'حساب المستخدم موقوف مؤقتًا');
 if(await z40ResetIsActive(db))return err(423,'التصفير جارٍ؛ لا يمكن إجراء عمليات مالية');
 await z659AirEnsure(db);
 {const dr=await db.prepare('SELECT amount FROM z660_air_debts WHERE user_id=?').bind(u.id).first();if(Number(dr?.amount||0)>=Z74_MAX_AIR_DEBT)return err(409,'مديونيتك وصلت للحد الأقصى ('+Z74_MAX_AIR_DEBT+'). اكسب رصيدًا أو انتظر مكافآت الاعتراض لسداد جزء منها.');}
 const raw=await request.text();if(raw.length>6000)return err(413,'طلب كبير جدًا');
 let p;try{p=JSON.parse(raw||'{}')}catch{return err(400,'بيانات غير صالحة')}
 const rid=String(p.request_id||''),tid=String(p.target_id||''),az=Number(p.az),el=Number(p.el);
 if(!/^[a-zA-Z0-9-]{12,90}$/.test(rid)||!/^[a-zA-Z0-9-]{12,90}$/.test(tid))return err(400,'معرف العملية أو الهدف غير صالح');
 if(!Number.isInteger(az)||az<0||az>359||!Number.isInteger(el)||el<5||el>83)return err(400,'حدد اتجاهًا وارتفاعًا صالحين');
 const old=await db.prepare('SELECT * FROM z660_air_shots WHERE id=?').bind(rid).first();
 if(old){if(old.user_id!==u.id||old.target_id!==tid||old.az!==az||old.el!==el)return err(409,'رقم العملية مستخدم لبيانات مختلفة');const current=await db.prepare('SELECT u.points-COALESCE(d.amount,0) net FROM users u LEFT JOIN z660_air_debts d ON d.user_id=u.id WHERE u.id=?').bind(u.id).first();return json({ok:true,already_processed:true,hit:!!old.hit,points:Number(current?.net||0),treasury:await zTreasuryBalance(db),notice:'العملية سبق تنفيذها مرة واحدة'});}
 const stamp=Date.now();const target=await db.prepare('SELECT az,el FROM z659_air_tracks WHERE id=? AND status=\'incoming\' AND started_at<=? AND expires_at>?').bind(tid,stamp,stamp).first();
 if(!target)return err(409,'الصاروخ غير موجود أو انتهت مهلة الاعتراض');
 const diff=Math.abs(((az-target.az+540)%360)-180),hit=Number(diff<=18&&Math.abs(el-target.el)<=14);
 try{await db.prepare('INSERT INTO z660_air_shots(id,user_id,target_id,az,el,hit,created_at) VALUES(?,?,?,?,?,?,?)').bind(rid,u.id,tid,az,el,hit,stamp).run();}
 catch(e){const prev=await db.prepare('SELECT * FROM z660_air_shots WHERE id=?').bind(rid).first();if(prev&&prev.user_id===u.id&&prev.target_id===tid&&prev.az===az&&prev.el===el){const current=await db.prepare('SELECT u.points-COALESCE(d.amount,0) net FROM users u LEFT JOIN z660_air_debts d ON d.user_id=u.id WHERE u.id=?').bind(u.id).first();return json({ok:true,already_processed:true,hit:!!prev.hit,points:Number(current?.net||0),treasury:await zTreasuryBalance(db),notice:'العملية سبق تنفيذها مرة واحدة'});}const m=String(e?.message||e);if(/صلاحية|الهدف|انتظر|رصيد|التصويب|اتجاه/i.test(m))return err(409,m.slice(0,180));throw e;}
 const current=await db.prepare('SELECT u.points-COALESCE(d.amount,0) net FROM users u LEFT JOIN z660_air_debts d ON d.user_id=u.id WHERE u.id=?').bind(u.id).first();
 return json({ok:true,hit:!!hit,points:Number(current?.net||0),treasury:await zTreasuryBalance(db),notice:hit?'اعتراض ناجح! +1500 للمطلق و+3000 للدولة و+500 لكل مواطن نشط':'الإطلاق أخطأ الهدف: تكلفة 500 وغرامة إضافية 600'});
}




