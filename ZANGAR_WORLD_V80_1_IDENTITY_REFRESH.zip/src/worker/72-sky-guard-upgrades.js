// V68 civilian infrastructure: persistent fictional arcade health, no effect on legacy economy.
let z68WorldSchema=null;
async function z68WorldEnsure(db){
 if(!z68WorldSchema)z68WorldSchema=(async()=>{
  await z659AirEnsure(db);
  await db.batch([
   db.prepare('CREATE TABLE IF NOT EXISTS z68_air_world(id INTEGER PRIMARY KEY CHECK(id=1),hp INTEGER NOT NULL DEFAULT 100,last_reset_at INTEGER NOT NULL DEFAULT 0)'),
   db.prepare("INSERT OR IGNORE INTO z68_air_world(id,hp,last_reset_at) VALUES(1,100,0)"),
   db.prepare("CREATE TABLE IF NOT EXISTS z68_air_facilities(name TEXT PRIMARY KEY,hp INTEGER NOT NULL DEFAULT 100)"),
   db.prepare("INSERT OR IGNORE INTO z68_air_facilities(name,hp) VALUES('المستشفى',100),('المطار',100),('محطة الكهرباء',100),('مركز المدينة',100)"),
   db.prepare("CREATE TABLE IF NOT EXISTS z68_air_track_meta(track_id TEXT PRIMARY KEY,kind TEXT NOT NULL,facility TEXT NOT NULL)"),
   db.prepare(`CREATE TRIGGER IF NOT EXISTS z68_air_city_impact AFTER UPDATE OF status ON z659_air_tracks
     WHEN NEW.status='impact' AND OLD.status='incoming'
     BEGIN
       UPDATE z68_air_world SET hp=MAX(0,hp-10) WHERE id=1;
       UPDATE z68_air_facilities SET hp=MAX(0,hp-22)
        WHERE name=COALESCE((SELECT facility FROM z68_air_track_meta WHERE track_id=NEW.id),'مركز المدينة');
     END`)
  ]);
 })().catch(e=>{z68WorldSchema=null;throw e});
 return z68WorldSchema;
}
async function z68WorldRead(db,now=Date.now()){
 await z68WorldEnsure(db);
 const row=await db.prepare('SELECT hp,last_reset_at FROM z68_air_world WHERE id=1').first();
 if(now-Number(row?.last_reset_at||0)>86400000){
  await db.prepare('UPDATE z68_air_world SET hp=100,last_reset_at=? WHERE id=1 AND last_reset_at<?').bind(now,now-86400000).run();
  await db.prepare('UPDATE z68_air_facilities SET hp=100').run();
 }
 // Idempotent impact resolution: trigger deducts exactly once per track even with concurrent visitors.
 await db.prepare("UPDATE z659_air_tracks SET status='impact',resolved_at=? WHERE status='incoming' AND expires_at<=? AND started_at<=?").bind(now,now,now).run();
 const world=await db.prepare('SELECT hp FROM z68_air_world WHERE id=1').first();
 const facility=await db.prepare('SELECT name,hp FROM z68_air_facilities ORDER BY name').all();
 return {hp:Number(world?.hp??100),facilities:facility.results||[]};
}

// ===== V68 SKY GUARD: push-click-confirmed alarm, 10-minute window -> 15-sec danger phase =====
// A push being delivered is NOT a click. A verified, logged-in subscriber must open its link.
let z68AlertSchema=null;
async function z68AlertEnsure(db){
 if(!z68AlertSchema)z68AlertSchema=(async()=>{
  await z659AirEnsure(db);
  await db.batch([
   db.prepare(`CREATE TABLE IF NOT EXISTS z68_air_alert_phase(
      event_id TEXT PRIMARY KEY, token_hash TEXT NOT NULL, created_at INTEGER NOT NULL,
      accelerated_at INTEGER NOT NULL DEFAULT 0, accelerated_by TEXT NOT NULL DEFAULT '')`),
   db.prepare('CREATE INDEX IF NOT EXISTS z68_air_alert_time ON z68_air_alert_phase(created_at DESC)'),
   db.prepare(`CREATE TRIGGER IF NOT EXISTS z68_air_alert_speed AFTER UPDATE OF accelerated_at ON z68_air_alert_phase
     WHEN NEW.accelerated_at>0 AND OLD.accelerated_at=0
     BEGIN
       UPDATE z659_air_tracks
       SET started_at=NEW.accelerated_at-MIN(90000,CAST((NEW.accelerated_at-started_at)*15000/MAX(15000,expires_at-NEW.accelerated_at) AS INTEGER)),
           expires_at=NEW.accelerated_at+15000
       WHERE id='alert-'||NEW.event_id AND status='incoming' AND expires_at>NEW.accelerated_at;
     END`)
  ]);
 })().catch(e=>{z68AlertSchema=null;throw e});
 return z68AlertSchema;
}
async function z68AlertSnapshot(db,ts=Date.now()){
 await z68AlertEnsure(db);
 const row=await db.prepare(`SELECT p.event_id,p.created_at,p.accelerated_at,
    t.expires_at,t.status FROM z68_air_alert_phase p
    LEFT JOIN z659_air_tracks t ON t.id='alert-'||p.event_id
    WHERE p.created_at>? ORDER BY p.created_at DESC LIMIT 1`).bind(ts-600000).first();
 if(!row)return {active:false,accelerated:false,speed_multiplier:1,expires_at:0,remaining_ms:0};
 const active=row.status==='incoming'&&Number(row.expires_at)>ts;
 return {active,detected:active,accelerated:!!row.accelerated_at,speed_multiplier:row.accelerated_at?5:1,
   expires_at:active?Number(row.expires_at):0,remaining_ms:active?Math.max(0,Number(row.expires_at)-ts):0,
   phase:!active?'resolved':row.accelerated_at?'critical':'watch',
   event_id:row.event_id};
}
async function z68AlertOpen(request,db){
 const origin=request.headers.get('Origin');if(origin&&origin!==new URL(request.url).origin)return err(403,'مصدر طلب غير مسموح');
 const u=await getMe(request,db);if(!u)return err(401,'يلزم تسجيل الدخول بحساب المواطن صاحب الإشعار');
 const raw=await request.text();if(raw.length>2000)return err(413,'الطلب كبير');
 let data;try{data=JSON.parse(raw||'{}')}catch{return err(400,'طلب غير صالح')}
 const event=String(data.event||''),token=String(data.key||'');
 if(!/^[a-zA-Z0-9-]{12,90}$/.test(event)||!/^[a-f0-9]{64}$/.test(token))return err(400,'رابط الإنذار غير صالح');
 await z68AlertEnsure(db);
 const phase=await db.prepare('SELECT event_id,token_hash,created_at,accelerated_at FROM z68_air_alert_phase WHERE event_id=?').bind(event).first();
 if(!phase || !eqSecure(await digest(token),phase.token_hash))return err(403,'الرابط غير موثوق');
 // Only a user who really has an active subscribed device and a dispatched push is counted.
 const activeSubscriber=await db.prepare(`SELECT 1 FROM z_push_outbox o
   JOIN z_push_subscriptions s ON s.user_id=o.user_id AND s.endpoint=o.endpoint
   WHERE o.user_id=? AND o.dedupe=? AND o.sent_at>0 AND o.kind='war'
     AND COALESCE((SELECT war FROM z_push_prefs p WHERE p.user_id=o.user_id),1)=1 LIMIT 1`).bind(u.id,'sky-guard-'+event).first();
 if(!activeSubscriber)return err(403,'الدخول السريع يحتاج إشعار حرب وصل لهاتف مشترك بالفعل');
 const ts=Date.now();
 const claimed=await db.prepare(`UPDATE z68_air_alert_phase SET accelerated_at=?,accelerated_by=?
   WHERE event_id=? AND accelerated_at=0 AND created_at<=? AND created_at+600000>?
   AND EXISTS(SELECT 1 FROM z659_air_tracks t WHERE t.id='alert-'||z68_air_alert_phase.event_id AND t.status='incoming' AND t.expires_at>?)
   RETURNING event_id`).bind(ts,u.id,event,ts,ts,ts).first();
 const state=await z68AlertSnapshot(db,ts);
 return json({ok:true,triggered:!!claimed,already_active:!claimed&&state.accelerated,alert:state},200,{'Cache-Control':'no-store, private'});
}
async function z68AlertCreate(db,eventId,ts){
 await z68AlertEnsure(db);
 const token=hex(crypto.getRandomValues(new Uint8Array(32)));
 await db.prepare('INSERT OR IGNORE INTO z68_air_alert_phase(event_id,token_hash,created_at) VALUES(?,?,?)').bind(eventId,await digest(token),ts).run();
 await z68WorldEnsure(db);
 const trackId='alert-'+eventId;
 const a=crypto.getRandomValues(new Uint32Array(2));
 const slot=-Math.floor(ts/1000);
 await db.prepare(`INSERT OR IGNORE INTO z659_air_tracks(id,slot,started_at,expires_at,az,el,status)
    VALUES(?,?,?,?,?,?,'incoming')`).bind(trackId,slot,ts,ts+600000,20+(a[0]%320),25+(a[1]%49)).run();
 await db.prepare('INSERT OR IGNORE INTO z68_air_track_meta(track_id,kind,facility) VALUES(?,?,?)').bind(trackId,'alert','مركز المدينة').run();
 // Unique link is valid only for authenticated recipients with dispatched war-push subscriptions.
 await zPushEnqueueAll(db,'🚨 إنذار الدفاع الجوي في ZANGAR WORLD',
    'الدوله تخوض حربا الأن يرجي الحذر — افتح الإنذار لمتابعة الرادار','war',
    '/air-defense.html?alert='+encodeURIComponent(eventId)+'&key='+token,'sky-guard-'+eventId);
}


// V68 optional defense upgrades: priced, account-bound, idempotent, and atomically debited.
let z68UpgradeSchema=null;
async function z68UpgradeEnsure(db){
 if(!z68UpgradeSchema)z68UpgradeSchema=(async()=>{
 await z659AirEnsure(db);
 await db.batch([
  db.prepare('CREATE TABLE IF NOT EXISTS z68_air_upgrades(user_id TEXT NOT NULL,kind TEXT NOT NULL,level INTEGER NOT NULL DEFAULT 0,PRIMARY KEY(user_id,kind))'),
  db.prepare('CREATE TABLE IF NOT EXISTS z68_air_upgrade_moves(id TEXT PRIMARY KEY,user_id TEXT NOT NULL,kind TEXT NOT NULL,level INTEGER NOT NULL,cost INTEGER NOT NULL,created_at INTEGER NOT NULL)'),
  db.prepare(`DROP TRIGGER IF EXISTS z68_air_upgrade_check`),
  db.prepare(`CREATE TRIGGER IF NOT EXISTS z68_air_upgrade_check BEFORE INSERT ON z68_air_upgrade_moves BEGIN
    SELECT CASE WHEN NEW.kind NOT IN ('turret','radar','lock') OR NEW.level NOT BETWEEN 1 AND 3 THEN RAISE(ABORT,'ترقية غير متاحة') END;
    SELECT CASE WHEN NOT EXISTS(SELECT 1 FROM z70_air_command_sessions s WHERE s.user_id=NEW.user_id AND s.expires_at>NEW.created_at) THEN RAISE(ABORT,'يجب فتح لوحة التحكم بالرمز الصحيح أولًا') END;
    SELECT CASE WHEN NEW.level!=COALESCE((SELECT level FROM z68_air_upgrades WHERE user_id=NEW.user_id AND kind=NEW.kind),0)+1 THEN RAISE(ABORT,'مستوى الترقية تغير') END;
    SELECT CASE WHEN NEW.cost!=NEW.level*(CASE NEW.kind WHEN 'turret' THEN 3000 WHEN 'radar' THEN 4500 WHEN 'lock' THEN 4000 ELSE 999999 END) THEN RAISE(ABORT,'قيمة الترقية غير صحيحة') END;
    SELECT CASE WHEN NOT EXISTS(SELECT 1 FROM users u LEFT JOIN z660_air_debts d ON d.user_id=u.id WHERE u.id=NEW.user_id AND u.points-COALESCE(d.amount,0)>=NEW.cost) THEN RAISE(ABORT,'رصيد المستخدم لا يكفي للترقية') END;
  END`),
  db.prepare(`CREATE TRIGGER IF NOT EXISTS z68_air_upgrade_apply AFTER INSERT ON z68_air_upgrade_moves BEGIN
    UPDATE users SET points=points-NEW.cost WHERE id=NEW.user_id;
    INSERT INTO z68_air_upgrades(user_id,kind,level) VALUES(NEW.user_id,NEW.kind,NEW.level)
      ON CONFLICT(user_id,kind) DO UPDATE SET level=excluded.level;
    INSERT INTO transactions(id,user_id,amount,note,created_at)
      VALUES(NEW.id||'-tx',NEW.user_id,-NEW.cost,'تطوير الدفاع الجوي: '||NEW.kind||' المستوى '||NEW.level,NEW.created_at);
  END`)
 ]);
 })().catch(e=>{z68UpgradeSchema=null;throw e});
 return z68UpgradeSchema;
}
async function z68UpgradeLevels(db,userId){
 await z68UpgradeEnsure(db);
 const r=await db.prepare('SELECT kind,level FROM z68_air_upgrades WHERE user_id=?').bind(userId).all();
 return Object.fromEntries((r.results||[]).map(x=>[x.kind,x.level]));
}
async function z68UpgradeBuy(req,db){
 const origin=req.headers.get('Origin');if(origin&&origin!==new URL(req.url).origin)return err(403,'مصدر غير موثوق');
 const u=await getMe(req,db);if(!u||!(await z70CommandAllowed(req,db,u)))return err(403,'افتح مركز التحكم بالرمز السري أولًا');
 if(await isMaintenance(db)||await z40ResetIsActive(db))return err(503,'العمليات المالية متوقفة مؤقتًا');
 const raw=await req.text();if(raw.length>1000)return err(413,'طلب كبير');
 let data;try{data=JSON.parse(raw||'{}')}catch{return err(400,'طلب غير صالح')}
 const kind=String(data.kind||''),rid=String(data.request_id||'');const base={turret:3000,radar:4500,lock:4000}[kind];
 if(!base||!/^[a-zA-Z0-9-]{12,90}$/.test(rid))return err(400,'ترقية أو رقم عملية غير صالح');
 await z68UpgradeEnsure(db);
 const old=await db.prepare('SELECT * FROM z68_air_upgrade_moves WHERE id=?').bind(rid).first();
 if(old){if(old.user_id!==u.id||old.kind!==kind)return err(409,'رقم عملية مكرر لعملية مختلفة');return json({ok:true,already_processed:true,upgrades:await z68UpgradeLevels(db,u.id)});}
 const current=await db.prepare('SELECT level FROM z68_air_upgrades WHERE user_id=? AND kind=?').bind(u.id,kind).first();
 const level=Number(current?.level||0)+1;if(level>3)return err(409,'وصلت إلى أقصى مستوى');
 try{await db.prepare('INSERT INTO z68_air_upgrade_moves(id,user_id,kind,level,cost,created_at) VALUES(?,?,?,?,?,?)').bind(rid,u.id,kind,level,base*level,Date.now()).run();}
 catch(e){const m=String(e?.message||e);if(/ترقية|مستوى|رصيد|صلاحية/.test(m))return err(409,m.slice(0,150));throw e}
 const bal=await db.prepare('SELECT u.points-COALESCE(d.amount,0) AS net FROM users u LEFT JOIN z660_air_debts d ON d.user_id=u.id WHERE u.id=?').bind(u.id).first();
 return json({ok:true,level,cost:base*level,points:Number(bal?.net||0),upgrades:await z68UpgradeLevels(db,u.id)});
}

