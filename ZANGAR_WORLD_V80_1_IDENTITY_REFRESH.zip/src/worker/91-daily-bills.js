// UPDATE 38 — daily official bills, auditable virtual money only. Starts on deployment day.
// These bills do NOT rewrite homes, companies or legacy wallets.
let z38BillingReady=null;
async function z38BillEnsure(db){
 if(z38BillingReady)return z38BillingReady;
 z38BillingReady=(async()=>{
  await db.batch([
    db.prepare('CREATE TABLE IF NOT EXISTS z38_billing_config(id INTEGER PRIMARY KEY CHECK(id=1),start_day INTEGER NOT NULL,created_at INTEGER NOT NULL)'),
    db.prepare('CREATE TABLE IF NOT EXISTS z38_bills(id TEXT PRIMARY KEY,user_id TEXT NOT NULL,kind TEXT NOT NULL CHECK(kind IN (\'home\',\'company\')),day INTEGER NOT NULL,amount INTEGER NOT NULL CHECK(amount>0),paid_at INTEGER NOT NULL DEFAULT 0,created_at INTEGER NOT NULL,UNIQUE(user_id,kind,day))'),
    db.prepare('CREATE INDEX IF NOT EXISTS z38_bills_unpaid ON z38_bills(user_id,kind,paid_at,day)'),
    db.prepare('CREATE TABLE IF NOT EXISTS z38_bill_payments(id TEXT PRIMARY KEY,user_id TEXT NOT NULL,kind TEXT NOT NULL,through_day INTEGER NOT NULL,amount INTEGER NOT NULL CHECK(amount>0),created_at INTEGER NOT NULL)')
  ]);
  await db.prepare('INSERT OR IGNORE INTO z38_billing_config(id,start_day,created_at) VALUES(1,?,?)').bind(Math.floor(Date.now()/86400000),Date.now()).run();
  const flag=await db.prepare("SELECT value FROM site_settings WHERE key='u38_billing_triggers'").first();
  if(flag?.value!=='1'){
   await db.batch([
     db.prepare(`CREATE TRIGGER IF NOT EXISTS z38_payment_check BEFORE INSERT ON z38_bill_payments BEGIN
       SELECT CASE WHEN NEW.amount!=(SELECT COALESCE(SUM(amount),0) FROM z38_bills WHERE user_id=NEW.user_id AND kind=NEW.kind AND day<=NEW.through_day AND paid_at=0) THEN RAISE(ABORT,'المبلغ غير مطابق للمستحقات') END;
       SELECT CASE WHEN NOT EXISTS(SELECT 1 FROM users WHERE id=NEW.user_id AND points>=NEW.amount) THEN RAISE(ABORT,'رصيد المحفظة لا يكفي لدفع المستحقات') END;
     END`),
     db.prepare(`CREATE TRIGGER IF NOT EXISTS z38_payment_apply AFTER INSERT ON z38_bill_payments BEGIN
       UPDATE users SET points=points-NEW.amount WHERE id=NEW.user_id;
       UPDATE z_state_treasury SET balance=balance+NEW.amount WHERE id=1;
       UPDATE z38_bills SET paid_at=NEW.created_at WHERE user_id=NEW.user_id AND kind=NEW.kind AND day<=NEW.through_day AND paid_at=0;
       INSERT INTO transactions(id,user_id,amount,note,created_at) VALUES(lower(hex(randomblob(16))),NEW.user_id,-NEW.amount,CASE NEW.kind WHEN 'home' THEN 'دفع إيجار البيت اليومي والمتأخرات' ELSE 'ضريبة ملكية الشركة اليومية والمتأخرات' END,NEW.created_at);
       INSERT INTO z_state_ledger(id,delta,reason,actor,created_at) SELECT lower(hex(randomblob(16))),NEW.amount,CASE NEW.kind WHEN 'home' THEN 'تحصيل إيجار البيت اليومي' ELSE 'تحصيل ضريبة الشركة اليومية' END,name,NEW.created_at FROM users WHERE id=NEW.user_id;
     END`),
     db.prepare("INSERT OR IGNORE INTO site_settings(key,value,updated_at) VALUES('u38_billing_triggers','1',?)").bind(Date.now())
   ]);
  }
 })().catch(e=>{z38BillingReady=null;throw e});return z38BillingReady;
}
const Z38_DAY_MS=86400000;
async function z38AccrueUser(db,u){
 await z38BillEnsure(db);
 const now=Date.now(),today=Math.floor(now/Z38_DAY_MS),config=await db.prepare('SELECT start_day FROM z38_billing_config WHERE id=1').first();
 const joined=Math.floor(Number(u.joined||now)/Z38_DAY_MS),first=Math.max(Number(config.start_day),joined);
 const company=await db.prepare('SELECT created_at FROM z_companies WHERE owner_id=?').bind(u.id).first();
 for(const [kind,amount,start] of [['home',300,first],['company',300,company?Math.max(first,Math.floor(Number(company.created_at)/Z38_DAY_MS)):Infinity]]){
   if(start>today)continue;
   const last=await db.prepare('SELECT MAX(day) AS last_day FROM z38_bills WHERE user_id=? AND kind=?').bind(u.id,kind).first();
   const next=Math.max(start,last?.last_day==null?start:Number(last.last_day)+1);
   if(next>today)continue;
   // Missing days are created once; a SQL recursive CTE avoids one network roundtrip per day.
   await db.prepare(`INSERT OR IGNORE INTO z38_bills(id,user_id,kind,day,amount,created_at)
     WITH RECURSIVE dates(day) AS(SELECT ? UNION ALL SELECT day+1 FROM dates WHERE day<?)
     SELECT lower(hex(randomblob(16))),?,?,day,?,day*86400000 FROM dates`).bind(next,today,u.id,kind,amount).run();
 }
}
const z38AccruedLocally=new Map();
async function z38AccrueOncePerDay(db,u){
 const day=Math.floor(Date.now()/86400000),key=u.id;
 if(z38AccruedLocally.get(key)===day)return;
 await z38AccrueUser(db,u);
 if(z38AccruedLocally.size>500)z38AccruedLocally.clear();
 z38AccruedLocally.set(key,day);
}
async function z38BillCron(db){
 await z38BillEnsure(db);
 const today=Math.floor(Date.now()/Z38_DAY_MS);
 // One set-based insert per type, per cron run, deduplicated by unique keys.
 await db.prepare(`INSERT OR IGNORE INTO z38_bills(id,user_id,kind,day,amount,created_at)
  SELECT lower(hex(randomblob(16))),u.id,'home',?,300,? FROM users u JOIN z38_billing_config cfg ON cfg.id=1
  WHERE cfg.start_day<=? AND u.joined<?`).bind(today,Date.now(),today,(today+1)*Z38_DAY_MS).run();
 await db.prepare(`INSERT OR IGNORE INTO z38_bills(id,user_id,kind,day,amount,created_at)
  SELECT lower(hex(randomblob(16))),c.owner_id,'company',?,300,? FROM z_companies c JOIN z38_billing_config cfg ON cfg.id=1
  WHERE cfg.start_day<=? AND c.created_at<?`).bind(today,Date.now(),today,(today+1)*Z38_DAY_MS).run();
}
async function z38BillState(req,db){
 const u=await getMe(req,db);if(!u)return err(401,'سجّل الدخول لعرض مستحقات الدولة');
 await z38AccrueUser(db,u);
 const rows=await db.prepare("SELECT id,kind,day,amount,paid_at,created_at FROM z38_bills WHERE user_id=? ORDER BY day DESC,kind LIMIT 120").bind(u.id).all();
 const unpaid=await db.prepare('SELECT kind,COALESCE(SUM(amount),0) AS due FROM z38_bills WHERE user_id=? AND paid_at=0 GROUP BY kind').bind(u.id).all();const sums={home:0,company:0};for(const row of unpaid.results)sums[row.kind]=Number(row.due);
 return json({ok:true,bills:rows.results,dues:sums,total:sums.home+sums.company,now:Date.now()});
}
async function z38BillAction(req,db,p){
 const u=await getMe(req,db);if(!u)return err(401,'سجّل الدخول أولًا');
 if(p.type!=='pay'||!['home','company'].includes(p.kind))return err(400,'عملية غير متاحة');
 if(p.confirm_text!=='تأكيد الدفع')return err(400,'يجب تأكيد الدفع بوضوح');
 await z38AccrueUser(db,u);
 const through=Math.floor(Date.now()/Z38_DAY_MS),kind=p.kind;
 const due=await db.prepare('SELECT COALESCE(SUM(amount),0) AS sum FROM z38_bills WHERE user_id=? AND kind=? AND paid_at=0 AND day<=?').bind(u.id,kind,through).first();
 const amount=Number(due?.sum||0);if(!amount)return err(409,'لا توجد مستحقات غير مدفوعة');
 const requestId=String(p.request_id||'');if(!/^bill-[0-9a-f-]{36}$/.test(requestId))return err(400,'معرّف تأكيد الدفع غير صالح');
 // Single INSERT fires atomic SQLite checks + WAL balance and ledger movements.
 const paid=await db.prepare('INSERT OR IGNORE INTO z38_bill_payments(id,user_id,kind,through_day,amount,created_at) VALUES(?,?,?,?,?,?) RETURNING id').bind(requestId,u.id,kind,through,amount,Date.now()).first();
 if(!paid)return err(409,'تم تنفيذ الطلب سابقًا');
 return json({ok:true,amount,notice:'✅ تم تحويل '+amount+' زنجر إلى خزينة الدولة وتسجيل الدفع'});
}

// UPDATE 38 — only future successful battle / radar payout events use the new private allocation.
let z38WarUpgraded=null;
async function z38WarEnsure(db){
 if(z38WarUpgraded)return z38WarUpgraded;
 const latest=await db.prepare("SELECT value FROM site_settings WHERE key='z45_migrated'").first();
 if(latest?.value==='1'){z38WarUpgraded=Promise.resolve();return z38WarUpgraded;}
 z38WarUpgraded=(async()=>{
  await z37EnsureWar(db);
  const ready=await db.prepare("SELECT value FROM site_settings WHERE key='u38_war_payout_upgraded'").first();
  if(ready?.value==='1')return;
  await db.batch([
    db.prepare('DROP TRIGGER IF EXISTS z37_war_payout_apply'),
    db.prepare(`CREATE TRIGGER z37_war_payout_apply AFTER INSERT ON z37_war_payouts BEGIN
       UPDATE z_state_treasury SET balance=balance+MAX(0,800000-1500*(SELECT COUNT(*) FROM users)) WHERE id=1;
       INSERT INTO z_state_ledger(id,delta,reason,actor,created_at) VALUES(lower(hex(randomblob(16))),MAX(0,800000-1500*(SELECT COUNT(*) FROM users)),'حصة الخزينة من مكافأة حرب 800000','نظام المحاكاة',NEW.created_at);
       UPDATE users SET points=points+1500;
       INSERT INTO transactions(id,user_id,amount,note,created_at) SELECT lower(hex(randomblob(16))),id,1500,'حصة المواطن من مكافأة الحرب',NEW.created_at FROM users;
       UPDATE users SET points=points+50000 WHERE id=NEW.actor_id;
       INSERT INTO transactions(id,user_id,amount,note,created_at) SELECT lower(hex(randomblob(16))),NEW.actor_id,50000,'مكافأة حرب لصاحب المهمة',NEW.created_at WHERE NEW.actor_id IS NOT NULL AND EXISTS(SELECT 1 FROM users WHERE id=NEW.actor_id);
       UPDATE users SET points=points+40000 WHERE id=(SELECT user_id FROM z37_sovereign_owner WHERE id=1);
       INSERT INTO transactions(id,user_id,amount,note,created_at) SELECT lower(hex(randomblob(16))),user_id,40000,'مكافأة خاصة للرئاسة الدولية',NEW.created_at FROM z37_sovereign_owner WHERE id=1;
     END`),
    db.prepare("INSERT OR IGNORE INTO site_settings(key,value,updated_at) VALUES('u38_war_payout_upgraded','1',?)").bind(Date.now())
  ]);
 })().catch(e=>{z38WarUpgraded=null;throw e});return z38WarUpgraded;
}

const Z33_COUNTRIES=[
 ['home','دولة الزنجر الجديدة',500,0,0,0,0,0],
 ['falcons','جمهورية الصقور',250,16,2,8,630000,2],
 ['mountains','مملكة الجبال',520,4,1,8,650000,4],
 ['islands','اتحاد الجزر',220,8,11,7,780000,3],
 ['sands','إمبراطورية الرمال',390,9,4,12,900000,5],
 ['oasis','مملكة الواحة',320,5,3,6,570000,2]
];
const Z33_UNITS={soldiers:{price:200,label:'جندي'},planes:{price:25000,label:'طائرة حربية'},ships:{price:60000,label:'سفينة حربية'},missiles:{price:15000,label:'صاروخ هجومي'},air_defense:{price:35000,label:'دفاع جوي'}};
let z33SchemaReady=null;
async function z33Ensure(db){
 if(!z33SchemaReady)z33SchemaReady=(async()=>{
  const v=await db.prepare("SELECT value FROM site_settings WHERE key='u33_schema_ready'").first();
  if(v?.value==='1'){await z34Ensure(db);return;}
  const ddls=[
  `CREATE TABLE IF NOT EXISTS z33_charity_requests(id TEXT PRIMARY KEY,user_id TEXT NOT NULL,title TEXT NOT NULL,reason TEXT NOT NULL,goal INTEGER NOT NULL CHECK(goal BETWEEN 100 AND 100000),collected INTEGER NOT NULL DEFAULT 0 CHECK(collected>=0 AND collected<=goal),status TEXT NOT NULL DEFAULT 'open' CHECK(status IN ('open','completed','cancelled')),created_at INTEGER NOT NULL,completed_at INTEGER NOT NULL DEFAULT 0)`,
  `CREATE INDEX IF NOT EXISTS idx_z33_charity_active ON z33_charity_requests(status,created_at DESC)`,
  `CREATE INDEX IF NOT EXISTS idx_z33_charity_user ON z33_charity_requests(user_id,status)`,
  `CREATE UNIQUE INDEX IF NOT EXISTS idx_z33_charity_one_open ON z33_charity_requests(user_id) WHERE status='open'`,
  `CREATE TABLE IF NOT EXISTS z33_charity_donations(id TEXT PRIMARY KEY,request_id TEXT NOT NULL,donor_id TEXT NOT NULL,amount INTEGER NOT NULL CHECK(amount>=1),created_at INTEGER NOT NULL)`,
  `CREATE INDEX IF NOT EXISTS idx_z33_charity_donations_req ON z33_charity_donations(request_id,created_at DESC)`,
  `CREATE TRIGGER IF NOT EXISTS z33_charity_donation_check BEFORE INSERT ON z33_charity_donations BEGIN
    SELECT CASE WHEN NOT EXISTS(SELECT 1 FROM z33_charity_requests r JOIN users u ON u.id=NEW.donor_id WHERE r.id=NEW.request_id AND r.status='open' AND r.user_id<>NEW.donor_id AND NEW.amount>=1 AND r.collected+NEW.amount<=r.goal AND u.points>=NEW.amount) THEN RAISE(ABORT,'لا يمكن التبرع: تحقق من الطلب أو الرصيد أو المبلغ المتبقي') END;
   END`,
  `CREATE TRIGGER IF NOT EXISTS z33_charity_donation_apply AFTER INSERT ON z33_charity_donations BEGIN
    UPDATE users SET points=points-NEW.amount WHERE id=NEW.donor_id;
    INSERT INTO transactions(id,user_id,amount,note,created_at) VALUES(lower(hex(randomblob(16))),NEW.donor_id,-NEW.amount,'تبرع للجمعية الخيرية (محجوز حتى اكتمال الطلب)',NEW.created_at);
    UPDATE z33_charity_requests SET collected=collected+NEW.amount,status=CASE WHEN collected+NEW.amount=goal THEN 'completed' ELSE 'open' END,completed_at=CASE WHEN collected+NEW.amount=goal THEN NEW.created_at ELSE 0 END WHERE id=NEW.request_id;
    UPDATE users SET points=points+(SELECT goal FROM z33_charity_requests WHERE id=NEW.request_id) WHERE id=(SELECT user_id FROM z33_charity_requests WHERE id=NEW.request_id AND status='completed');
    INSERT INTO transactions(id,user_id,amount,note,created_at) SELECT lower(hex(randomblob(16))),user_id,goal,'استلام طلب جمعية خيرية مكتمل',NEW.created_at FROM z33_charity_requests WHERE id=NEW.request_id AND status='completed';
   END`,
  `CREATE TRIGGER IF NOT EXISTS z33_charity_refund AFTER UPDATE OF status ON z33_charity_requests WHEN OLD.status='open' AND NEW.status='cancelled' BEGIN
    UPDATE users SET points=points+(SELECT COALESCE(SUM(amount),0) FROM z33_charity_donations WHERE donor_id=users.id AND request_id=NEW.id) WHERE id IN (SELECT donor_id FROM z33_charity_donations WHERE request_id=NEW.id);
    INSERT INTO transactions(id,user_id,amount,note,created_at) SELECT lower(hex(randomblob(16))),donor_id,amount,'رد تبرع: إلغاء طلب الجمعية الخيرية',NEW.created_at FROM z33_charity_donations WHERE request_id=NEW.id;
   END`,
  `CREATE TABLE IF NOT EXISTS z33_countries(id TEXT PRIMARY KEY,name TEXT NOT NULL,soldiers INTEGER NOT NULL,planes INTEGER NOT NULL,ships INTEGER NOT NULL,defense INTEGER NOT NULL,treasury INTEGER NOT NULL,difficulty INTEGER NOT NULL)`,
  `CREATE TABLE IF NOT EXISTS z33_military(id INTEGER PRIMARY KEY CHECK(id=1),soldiers INTEGER NOT NULL DEFAULT 500,planes INTEGER NOT NULL DEFAULT 0,ships INTEGER NOT NULL DEFAULT 0,missiles INTEGER NOT NULL DEFAULT 0,air_defense INTEGER NOT NULL DEFAULT 0,budget INTEGER NOT NULL DEFAULT 0,last_attack_at INTEGER NOT NULL DEFAULT 0,last_invasion_at INTEGER NOT NULL DEFAULT 0,invasion_id TEXT NOT NULL DEFAULT '',invasion_country TEXT NOT NULL DEFAULT '',invasion_at INTEGER NOT NULL DEFAULT 0)`,
  `CREATE TABLE IF NOT EXISTS z33_alliances(id TEXT PRIMARY KEY,country_id TEXT NOT NULL,created_at INTEGER NOT NULL,ends_at INTEGER NOT NULL,status TEXT NOT NULL DEFAULT 'active')`,
  `CREATE INDEX IF NOT EXISTS idx_z33_alliances_live ON z33_alliances(status,ends_at DESC)`,
  `CREATE UNIQUE INDEX IF NOT EXISTS idx_z33_ally_one_active ON z33_alliances(status) WHERE status='active'`,
  `CREATE TABLE IF NOT EXISTS z33_funding(id TEXT PRIMARY KEY,actor TEXT NOT NULL,amount INTEGER NOT NULL CHECK(amount>=100 AND amount<=1000000),created_at INTEGER NOT NULL)`,
  `CREATE TRIGGER IF NOT EXISTS z33_funding_check BEFORE INSERT ON z33_funding BEGIN
    SELECT CASE WHEN NOT EXISTS(SELECT 1 FROM z_state_treasury WHERE id=1 AND balance>=NEW.amount) THEN RAISE(ABORT,'خزينة الدولة لا تكفي لتمويل الجيش') END;
   END`,
  `CREATE TRIGGER IF NOT EXISTS z33_funding_apply AFTER INSERT ON z33_funding BEGIN
    UPDATE z_state_treasury SET balance=balance-NEW.amount WHERE id=1;
    UPDATE z33_military SET budget=budget+NEW.amount WHERE id=1;
    INSERT INTO z_state_ledger(id,delta,reason,actor,created_at) VALUES(lower(hex(randomblob(16))),-NEW.amount,'تحويل إلى الميزانية الحربية',NEW.actor,NEW.created_at);
   END`,
  `CREATE TABLE IF NOT EXISTS z33_battles(id TEXT PRIMARY KEY,attacker TEXT NOT NULL,target TEXT NOT NULL,actor_id TEXT NOT NULL,soldiers INTEGER NOT NULL,planes INTEGER NOT NULL,ships INTEGER NOT NULL,missiles INTEGER NOT NULL,loss_soldiers INTEGER NOT NULL,loss_planes INTEGER NOT NULL,loss_ships INTEGER NOT NULL,result TEXT NOT NULL,reward INTEGER NOT NULL,created_at INTEGER NOT NULL)`,
  `CREATE INDEX IF NOT EXISTS idx_z33_battles_time ON z33_battles(created_at DESC)`,
  `CREATE TRIGGER IF NOT EXISTS z33_battle_check BEFORE INSERT ON z33_battles WHEN NEW.attacker='home' BEGIN
    SELECT CASE WHEN NOT EXISTS(SELECT 1 FROM z33_military WHERE id=1 AND soldiers>=NEW.soldiers AND planes>=NEW.planes AND ships>=NEW.ships AND missiles>=NEW.missiles AND NEW.created_at>=last_attack_at+1800000) THEN RAISE(ABORT,'الجيش غير كافٍ أو الهجوم لم يحن موعده') END;
    SELECT CASE WHEN NOT EXISTS(SELECT 1 FROM z33_countries WHERE id=NEW.target AND id<>'home' AND treasury>=NEW.reward) THEN RAISE(ABORT,'الدولة المستهدفة غير متاحة') END;
   END`,
  `CREATE TRIGGER IF NOT EXISTS z33_battle_apply AFTER INSERT ON z33_battles WHEN NEW.attacker='home' BEGIN
    UPDATE z33_military SET soldiers=soldiers-NEW.loss_soldiers,planes=planes-NEW.loss_planes,ships=ships-NEW.loss_ships,missiles=missiles-NEW.missiles,last_attack_at=NEW.created_at WHERE id=1;
    UPDATE z33_countries SET treasury=treasury-NEW.reward,soldiers=MAX(40,soldiers-CASE WHEN NEW.result='victory' THEN 65 ELSE 20 END),planes=MAX(0,planes-CASE WHEN NEW.result='victory' THEN 2 ELSE 0 END) WHERE id=NEW.target;
    UPDATE z_state_treasury SET balance=balance+NEW.reward WHERE id=1;
    INSERT INTO z_state_ledger(id,delta,reason,actor,created_at) SELECT lower(hex(randomblob(16))),NEW.reward,'غنيمة محاكاة حرب: دولة خيالية',u.name,NEW.created_at FROM users u WHERE u.id=NEW.actor_id AND NEW.reward>0;
   END`
  ];
  for(const sql of ddls)await db.prepare(sql).run();
  await db.prepare('INSERT OR IGNORE INTO z33_military(id) VALUES(1)').run();
  // No NPC initialization ever writes into citizen wallets or the existing state treasury.
  for(const c of Z33_COUNTRIES)await db.prepare('INSERT OR IGNORE INTO z33_countries(id,name,soldiers,planes,ships,defense,treasury,difficulty) VALUES(?,?,?,?,?,?,?,?)').bind(...c).run();
  await db.prepare("INSERT OR IGNORE INTO site_settings(key,value,updated_at) VALUES('u33_schema_ready','1',?)").bind(Date.now()).run();await z34Ensure(db);
 })().catch(e=>{z33SchemaReady=null;throw e});
 return z33SchemaReady;
}
async function z33NotifyAll(db,title,body,kind='war',url='/campaign.html',key=id()){
 const now=Date.now();
 // One INSERT ... SELECT, instead of one roundtrip per citizen; preserves U32 read optimizations.
 await db.prepare(`INSERT INTO z_notifications(id,user_id,title,body,kind,created_at)
 SELECT lower(hex(randomblob(16))),u.id,?,?,?,? FROM users u`).bind(crop(title,75),crop(body,230),kind,now).run();
 await zPushEnqueueAll(db,title,body,kind,url,key);
}
async function z33CharityState(req,db){
 const u=await getMe(req,db);
 const requests=await db.prepare(`SELECT r.id,r.user_id,r.title,r.reason,r.goal,r.collected,r.status,r.created_at,r.completed_at,u.name AS applicant FROM z33_charity_requests r JOIN users u ON u.id=r.user_id WHERE r.status IN ('open','completed') ORDER BY CASE r.status WHEN 'open' THEN 0 ELSE 1 END,r.created_at DESC LIMIT 70`).all();
 const donations=u?await db.prepare('SELECT request_id,amount,created_at FROM z33_charity_donations WHERE donor_id=? ORDER BY created_at DESC LIMIT 40').bind(u.id).all():{results:[]};
 return json({ok:true,me:u?{id:u.id,name:u.name,points:u.points}:null,requests:requests.results,donations:donations.results});
}
async function z33CharityAction(req,db,p){
 const u=await getMe(req,db);if(!u)return err(401,'سجّل دخولك أولًا');
 const now=Date.now(),type=crop(p.type,20);
 if(type==='create'){
  const title=crop(p.title,75),reason=crop(p.reason,360),goal=Number(p.goal);
  if(title.length<4||reason.length<12||!Number.isSafeInteger(goal)||goal<100||goal>100000)throw Error('اكتب عنوانًا وسببًا واضحًا ومبلغًا بين 100 و100,000 زنجر');
  const active=await db.prepare("SELECT id FROM z33_charity_requests WHERE user_id=? AND status='open' LIMIT 1").bind(u.id).first();if(active)throw Error('عندك طلب مفتوح بالفعل؛ انتظر اكتماله أو ألغِه');
  const requestId=id();await db.prepare('INSERT INTO z33_charity_requests(id,user_id,title,reason,goal,created_at) VALUES(?,?,?,?,?,?)').bind(requestId,u.id,title,reason,goal,now).run();
  await z33NotifyAll(db,'❤️ طلب مساعدة جديد',u.name+' يطلب '+goal+' زنجر في الجمعية الخيرية','social','/charity.html','charity-'+requestId);
  return json({ok:true,request_id:requestId});
 }
 if(type==='donate'){
  const requestId=crop(p.request_id,75),amount=Number(p.amount);
  if(!Number.isSafeInteger(amount)||amount<1||amount>100000)throw Error('قيمة التبرع غير صحيحة');
  const donationId=id();await db.prepare('INSERT INTO z33_charity_donations(id,request_id,donor_id,amount,created_at) VALUES(?,?,?,?,?)').bind(donationId,requestId,u.id,amount,now).run();
  const r=await db.prepare('SELECT user_id,goal,collected,status FROM z33_charity_requests WHERE id=?').bind(requestId).first();
  if(r){await zNotify(db,r.user_id,r.status==='completed'?'✅ اكتمل طلب الجمعية الخيرية':'❤️ تبرع جديد لطلبك',r.status==='completed'?'اكتمل طلب '+r.goal+' زنجر وتم تحويله لمحفظتك':'تم التبرع بـ'+amount+' زنجر؛ المجموع '+r.collected+' من '+r.goal,'social');
   if(r.status==='completed')await z33NotifyAll(db,'✅ اكتمل طلب خيري','تم جمع المبلغ المطلوب كاملًا للجمعية الخيرية','social','/charity.html','charity-done-'+requestId);
  }
  return json({ok:true,collected:r?.collected,status:r?.status});
 }
 if(type==='cancel'){
  const claim=await db.prepare("UPDATE z33_charity_requests SET status='cancelled' WHERE id=? AND user_id=? AND status='open' RETURNING collected").bind(crop(p.request_id,75),u.id).first();
  if(!claim)throw Error('لا يمكن إلغاء هذا الطلب');
  // z33_charity_refund trigger restores each donated amount atomically with cancelling.
  await zNotify(db,u.id,'إلغاء الطلب','تم إلغاء طلبك ورد المساهمات لأصحابها','social');
  return json({ok:true,refunded:claim.collected});
 }
 return err(400,'أمر غير معروف');
}
function z33CombatScore(army){return (Number(army?.soldiers)||0)+(Number(army?.planes)||0)*25+(Number(army?.ships)||0)*40+(Number(army?.missiles)||0)*30+(Number(army?.air_defense)||0)*38;}
// U35: dynamic five-opponent prize ladder, ordered by their actual combined force at battle time.
// Fixed original NPC strength, never re-rank countries after they lose soldiers.
const Z45_COUNTRY_RANK=Object.fromEntries(Z33_COUNTRIES.slice(1).slice().sort((a,b)=>
 (a[2]+a[3]*25+a[4]*40+a[5]*38)-(b[2]+b[3]*25+b[4]*40+b[5]*38)
).map((c,i)=>[c[0],i]));
function z45WarPrize(country){const rank=Z45_COUNTRY_RANK[country];if(!Number.isInteger(rank))return {rank:0,treasury:0,citizen:0,leader:0};const factor=1.2**rank;return {rank:rank+1,treasury:Math.round(30000*factor),citizen:Math.round(2000*factor),leader:Math.round(5000*factor)};}
async function z35WarPrize(db,target){return z45WarPrize(target);}

async function z33WarAdvance(db,now=Date.now()){return []; // Update 62: no old campaign progression

 const m=await db.prepare('SELECT * FROM z33_military WHERE id=1').first();if(!m)return;
 if(m.invasion_id&&m.invasion_at<=now){
  const enemy=await db.prepare('SELECT * FROM z33_countries WHERE id=?').bind(m.invasion_country).first();
  const ally=await db.prepare("SELECT c.* FROM z33_alliances a JOIN z33_countries c ON c.id=a.country_id WHERE a.status='active' AND a.ends_at>? ORDER BY a.created_at DESC LIMIT 1").bind(now).first();
  const defense=z33CombatScore(m)+(ally?Math.floor(z33CombatScore(ally)*.25):0);
  const strength=enemy?z33CombatScore(enemy)*.7:300;
  const blocked=defense>=strength;
  const soldiersLost=Math.min(m.soldiers,Math.ceil((blocked?.012:.065)*Number(m.soldiers)));
  const planeLost=Math.min(m.planes,blocked?0:Math.floor(m.planes*.12));
  const damage=blocked?0:Math.min(m.budget,Math.ceil(3500+strength*.5));
  const defensePrize=blocked?await z35WarPrize(db,enemy?.id):null;
  // Exactly-once claim. One arrival cannot be applied twice, even with concurrent GET/cron.
  const claimed=await db.prepare("UPDATE z33_military SET invasion_id='',invasion_country='',invasion_at=0,last_invasion_at=?, soldiers=MAX(0,soldiers-?),planes=MAX(0,planes-?),budget=MAX(0,budget-?) WHERE id=1 AND invasion_id=? RETURNING id").bind(now,soldiersLost,planeLost,damage,m.invasion_id).first();
  if(claimed){
   await db.prepare('INSERT INTO z33_battles(id,attacker,target,actor_id,soldiers,planes,ships,missiles,loss_soldiers,loss_planes,loss_ships,result,reward,created_at) VALUES(?,?,?,?,?,?,?,?,?,?,?,?,?,?)').bind(id(),enemy?.id||'unknown','home','system',enemy?.soldiers||0,enemy?.planes||0,enemy?.ships||0,0,soldiersLost,planeLost,0,blocked?'defended':'invasion_hit',0,now).run();
   await z33NotifyAll(db,blocked?'🛡️ نجح دفاع الزنجر':'🚨 انتهى هجوم خارجي',blocked?'تم صد هجوم '+enemy?.name+' في المحاكاة؛ خزينة الدولة +'+defensePrize.treasury.toLocaleString('en-US')+' زنجر، ولكل مواطن +'+defensePrize.citizen.toLocaleString('en-US'):'وقعت خسائر في الجيش والميزانية الحربية فقط','war','/campaign.html','invasion-end-'+m.invasion_id);
  }
 }
 // Every 3h after a completed event, schedule exactly one 10 minute warning. Never touch original 17m radar.
 else if(!m.invasion_id&&(!m.last_invasion_at || now-m.last_invasion_at>=3*3600000)){
  const enemies=Z33_COUNTRIES.slice(1).filter(c=>c[0]!==m.invasion_country);
  const chosen=enemies[Math.floor(now/(3*3600000))%enemies.length],invasionId=id();
  const claimed=await db.prepare("UPDATE z33_military SET invasion_id=?,invasion_country=?,invasion_at=? WHERE id=1 AND invasion_id='' RETURNING invasion_id").bind(invasionId,chosen[0],now+600000).first();
  if(claimed)await z33NotifyAll(db,'🚨 إنذار حرب قبل 10 دقائق',chosen[1]+' تستعد للهجوم على دولة الزنجر! جهّز الدفاعات واستدعِ الحلفاء','war','/campaign.html','invasion-'+invasionId);
 }
}
async function z33WarState(req,db){
 const now=Date.now(),u=await getMe(req,db),admin=!!u&&(await zWarAuthorized(db,u,req))&&!(await prisonActive(db,u.id));
 // State endpoint does not itself create auto attacks; only existing push cron creates/resolves.
 const [army,countries,allies,logs,treasury]=await Promise.all([
 db.prepare('SELECT * FROM z33_military WHERE id=1').first(),
 db.prepare('SELECT * FROM z33_countries ORDER BY rowid').all(),
 db.prepare("SELECT a.country_id,a.created_at,a.ends_at,c.name FROM z33_alliances a JOIN z33_countries c ON c.id=a.country_id WHERE a.status='active' AND a.ends_at>? ORDER BY a.created_at DESC LIMIT 1").bind(now).first(),
 db.prepare("SELECT b.*,u.name AS actor_name,CASE WHEN EXISTS(SELECT 1 FROM z43_war_rewards r WHERE r.event_id=b.id AND r.kind='battle') THEN 1 ELSE 0 END AS reward_paid,(SELECT treasury_added FROM z43_war_rewards r WHERE r.event_id=b.id) AS treasury_reward,(SELECT citizen_added FROM z43_war_rewards r WHERE r.event_id=b.id) AS citizen_reward,(SELECT leader_added FROM z43_war_rewards r WHERE r.event_id=b.id) AS leader_reward FROM z33_battles b LEFT JOIN users u ON u.id=b.actor_id ORDER BY b.created_at DESC LIMIT 30").all(),
 zTreasuryBalance(db)]);
 return json({ok:true,now,authorized:admin,logged_in:!!u,army,treasury,countries:countries.results,alliance:allies||null,battles:logs.results,prices:Z33_UNITS});
}
async function z33WarAction(req,db,p){return err(403,Z62_PEACE_MESSAGE);

 const u=await getMe(req,db);if(!u)return err(401,'سجّل دخولك أولًا');
 if(!(await zWarAuthorized(db,u,req)))return err(403,'تحتاج صلاحية رئاسية معتمدة');
 if(await prisonActive(db,u.id))return err(403,'لا يمكن إدارة الحرب أثناء السجن');
 const type=crop(p.type,25),now=Date.now();
 if(type==='fund'){
  const amount=Number(p.amount);if(!Number.isSafeInteger(amount)||amount<100||amount>1000000)throw Error('اختار تحويلًا من 100 إلى مليون زنجر');
  // Single SQL INSERT + trigger transfers funds and writes the ledger atomically.
  await db.prepare('INSERT INTO z33_funding(id,actor,amount,created_at) VALUES(?,?,?,?)').bind(id(),u.name,amount,now).run();
  return json({ok:true});
 }
 if(type==='buy'){
  const unit=crop(p.unit,30),qty=Number(p.quantity),item=Z33_UNITS[unit];
  if(!item||!Number.isSafeInteger(qty)||qty<1||qty>1000)throw Error('نوع الوحدة أو الكمية غير صحيحة');
  const total=qty*item.price;if(total>1000000)throw Error('الصفقة أكبر من الحد المسموح');
  const sql=`UPDATE z33_military SET budget=budget-?,${unit}=${unit}+? WHERE id=1 AND budget>=? RETURNING budget`;
  const result=await db.prepare(sql).bind(total,qty,total).first();if(!result)throw Error('الميزانية الحربية لا تكفي');
  return json({ok:true,cost:total});
 }
 if(type==='alliance'){
  const target=crop(p.country_id,30),country=await db.prepare("SELECT id,name FROM z33_countries WHERE id=? AND id<>'home'").bind(target).first();if(!country)throw Error('الدولة غير موجودة');
  await db.prepare("UPDATE z33_alliances SET status='expired' WHERE status='active' AND ends_at<=?").bind(now).run();
  const already=await db.prepare("SELECT id FROM z33_alliances WHERE status='active' AND ends_at>? LIMIT 1").bind(now).first();if(already)throw Error('عندنا حليف بالفعل؛ التحالف مستمر 72 ساعة');
  await db.prepare("INSERT INTO z33_alliances(id,country_id,created_at,ends_at,status) VALUES(?,?,?,?,'active')").bind(id(),target,now,now+72*3600000).run();
  await z33NotifyAll(db,'🤝 تحالف عسكري جديد','دولة الزنجر تحالفت مع '+country.name+' لمدة 72 ساعة','war','/campaign.html','alliance-'+target+'-'+now);
  return json({ok:true});
 }
 if(type==='attack'){
  const target=crop(p.country_id,30),v={};for(const k of ['soldiers','planes','ships','missiles']){v[k]=Number(p[k]||0);if(!Number.isSafeInteger(v[k])||v[k]<0||v[k]>10000)throw Error('عدد القوات غير صحيح')}
  if(!v.soldiers&&!v.planes&&!v.ships&&!v.missiles)throw Error('حدد قوات للهجوم أولًا');
  const enemy=await db.prepare("SELECT * FROM z33_countries WHERE id=? AND id<>'home'").bind(target).first();if(!enemy)throw Error('الدولة المستهدفة غير موجودة');
  const allied=await db.prepare("SELECT id FROM z33_alliances WHERE country_id=? AND status='active' AND ends_at>? LIMIT 1").bind(target,now).first();if(allied)throw Error('لا يمكن مهاجمة دولة حليفة أثناء التحالف');
  const army=await db.prepare('SELECT * FROM z33_military WHERE id=1').first();if(now-army.last_attack_at<1800000)throw Error('انتظر 30 دقيقة بين الهجمات');
  const ally=await db.prepare("SELECT c.* FROM z33_alliances a JOIN z33_countries c ON c.id=a.country_id WHERE a.status='active' AND a.ends_at>? ORDER BY a.created_at DESC LIMIT 1").bind(now).first();
  const attacker=z33CombatScore(v)+(ally?z33CombatScore(ally)*.25:0);
  const defender=z33CombatScore(enemy)+enemy.defense*38;
  const ratio=attacker/Math.max(defender,1),result=ratio>1?'victory':ratio>=.8?'partial':'defeat';
  const lossRate=result==='victory'?.08:result==='partial'?.23:.47;
  const ls=Math.ceil(v.soldiers*lossRate),lp=Math.ceil(v.planes*lossRate*.6),lh=Math.ceil(v.ships*lossRate*.55);
  const prize=await z35WarPrize(db,target);
  const activeSeason=await db.prepare('SELECT season FROM z39_season_meta WHERE id=1').first();
  const reward=0; // Update45: only dedicated victory trigger mints rewards; no old battle treasury addition.
  const shownReward=result==='victory'?prize.treasury:reward;
  const battleId=id();await db.prepare("INSERT INTO z33_battles(id,attacker,target,actor_id,soldiers,planes,ships,missiles,loss_soldiers,loss_planes,loss_ships,result,reward,created_at) VALUES(?,?,?,?,?,?,?,?,?,?,?,?,?,?)").bind(battleId,'home',target,u.id,v.soldiers,v.planes,v.ships,v.missiles,ls,lp,lh,result,reward,now).run();
  if(result==='victory'){await db.prepare('INSERT OR IGNORE INTO z37_war_payouts(battle_id,actor_id,created_at) VALUES(?,?,?)').bind(battleId,u.id,now).run();}
  const paid=result==='victory'?await db.prepare('SELECT event_id FROM z43_war_rewards WHERE event_id=?').bind(battleId).first():null;
  await z33NotifyAll(db,'⚔️ تقرير معركة جديدة','هجوم دولة الزنجر على '+enemy.name+' — '+(result==='victory'?'انتصار؛ الخزينة +'+prize.treasury+' زنجر ولكل مواطن +'+prize.citizen+' ولقائد الحرب +'+prize.leader+' إضافية':'النتيجة '+(result==='partial'?'نجاح جزئي':'هزيمة')),'war','/campaign.html','battle-'+battleId);
  return json({ok:true,battle_id:battleId,result,reward_confirmed:result!=='victory'||!!paid,reward:shownReward,citizen_reward:result==='victory'?prize.citizen:0,leader_reward:result==='victory'?prize.leader:0,treasury_reward:result==='victory'?prize.treasury:0,losses:{soldiers:ls,planes:lp,ships:lh}});
 }
 return err(400,'أمر عسكري غير معروف');
}


let z34OwnerReady=null;
async function z34OwnerAlerts(db,ownerId){
 if(z34OwnerReady)return z34OwnerReady;
 z34OwnerReady=(async()=>{
  await db.prepare('CREATE TABLE IF NOT EXISTS z34_head_owner(id INTEGER PRIMARY KEY CHECK(id=1),user_id TEXT NOT NULL)').run();
  await db.prepare('INSERT INTO z34_head_owner(id,user_id) VALUES(1,?) ON CONFLICT(id) DO NOTHING').bind(ownerId).run();
  const statements=[
   `CREATE TRIGGER IF NOT EXISTS z34_head_treasury_alert AFTER INSERT ON z_state_ledger BEGIN
      INSERT INTO z_notifications(id,user_id,title,body,kind,created_at) SELECT lower(hex(randomblob(16))),o.user_id,'👑 حركة خزينة الدولة',NEW.actor||' — '||NEW.reason||' ('||NEW.delta||' زنجر)','money',NEW.created_at FROM z34_head_owner o;
      INSERT OR IGNORE INTO z_push_outbox(id,dedupe,endpoint,user_id,kind,title,body,url,created_at)
      SELECT lower(hex(randomblob(16))),'head-treasury-'||NEW.id,s.endpoint,s.user_id,'money','👑 حركة خزينة الدولة',NEW.actor||' — '||NEW.reason||' ('||NEW.delta||' زنجر)','/head.html',NEW.created_at FROM z_push_subscriptions s JOIN z34_head_owner o ON s.user_id=o.user_id WHERE COALESCE((SELECT money FROM z_push_prefs WHERE user_id=s.user_id),1)=1;
   END`,
   `CREATE TRIGGER IF NOT EXISTS z34_head_battle_alert AFTER INSERT ON z33_battles BEGIN
      INSERT INTO z_notifications(id,user_id,title,body,kind,created_at) SELECT lower(hex(randomblob(16))),o.user_id,'👑 نتيجة حرب','النتيجة: '||NEW.result||' — الدولة: '||NEW.target||' — العائد: '||NEW.reward,'war',NEW.created_at FROM z34_head_owner o;
      INSERT OR IGNORE INTO z_push_outbox(id,dedupe,endpoint,user_id,kind,title,body,url,created_at) SELECT lower(hex(randomblob(16))),'head-battle-'||NEW.id,s.endpoint,s.user_id,'war','👑 نتيجة حرب','النتيجة: '||NEW.result||' — الدولة: '||NEW.target,'/head.html',NEW.created_at FROM z_push_subscriptions s JOIN z34_head_owner o ON s.user_id=o.user_id WHERE COALESCE((SELECT war FROM z_push_prefs WHERE user_id=s.user_id),1)=1;
   END`,
   `CREATE TRIGGER IF NOT EXISTS z34_head_fine_alert AFTER INSERT ON cases WHEN NEW.status='confirmed' BEGIN
      INSERT INTO z_notifications(id,user_id,title,body,kind,created_at) SELECT lower(hex(randomblob(16))),o.user_id,'👑 مخالفة جديدة','النوع: '||NEW.kind||' — المواطن: '||COALESCE((SELECT name FROM users WHERE id=NEW.target_id),'غير معروف'),'government',NEW.created_at FROM z34_head_owner o;
   END`,
   `CREATE TRIGGER IF NOT EXISTS z34_head_fine_confirm_alert AFTER UPDATE OF status ON cases WHEN NEW.status='confirmed' AND OLD.status<>'confirmed' BEGIN
      INSERT INTO z_notifications(id,user_id,title,body,kind,created_at) SELECT lower(hex(randomblob(16))),o.user_id,'👑 تم اعتماد مخالفة','النوع: '||NEW.kind||' — المواطن: '||COALESCE((SELECT name FROM users WHERE id=NEW.target_id),'غير معروف'),'government',CAST(strftime('%s','now') AS INTEGER)*1000 FROM z34_head_owner o;
   END`,
   `CREATE TRIGGER IF NOT EXISTS z34_head_radar_alert AFTER UPDATE OF status ON z_war_threats WHEN OLD.status<>NEW.status AND NEW.status<>'inbound' BEGIN
      INSERT INTO z_notifications(id,user_id,title,body,kind,created_at) SELECT lower(hex(randomblob(16))),o.user_id,'👑 نتيجة اعتراض صاروخ','تغيرت حالة الصاروخ إلى '||NEW.status,'war',CAST(strftime('%s','now') AS INTEGER)*1000 FROM z34_head_owner o;
   END`
  ];
  for(const q of statements)await db.prepare(q).run();
 })().catch(e=>{z34OwnerReady=null;throw e});
 return z34OwnerReady;
}
// Owner-only control center; the second code and owner user ID must be set as Cloudflare secrets.
async function z34Head(req,db,env,p,detail=false){
 if(req.headers.get('Origin')&&req.headers.get('Origin')!==new URL(req.url).origin)return err(403,'مصدر الطلب غير مصرح به');
 const u=await getMe(req,db);if(!u)return err(401,'سجّل دخولك أولًا لتوثيق أي عملية إدارية');
 // Access is controlled by the second code alone, not by president role or HEAD_OF_STATE_USER_ID.
 // Authenticated sessions are still required so all financial changes have an accountable actor.
 const code=String(p.owner_code||'');
 const already=await z711Active(db,u.id,'head_control');
 if(!already){
  const expected=env.HEAD_OF_STATE_CODE?await digest(String(env.HEAD_OF_STATE_CODE)):'46f3103321db1fa31d90500379916cd59eb3ff698f003bf18aa5ba64ded86cc5';
  await db.prepare('CREATE TABLE IF NOT EXISTS z36_head_attempts(user_id TEXT PRIMARY KEY,failures INTEGER NOT NULL DEFAULT 0,blocked_until INTEGER NOT NULL DEFAULT 0)').run();
  const nowAttempt=Date.now(),attempt=await db.prepare('SELECT failures,blocked_until FROM z36_head_attempts WHERE user_id=?').bind(u.id).first();
  if(Number(attempt?.blocked_until||0)>nowAttempt)return err(429,'عدد محاولات كبير، جرّب بعد 15 دقيقة');
  if(code.length<12||code.length>150||!eqSecure(await digest(code),expected)){
    const failures=Number(attempt?.failures||0)+1;
    await db.prepare('INSERT INTO z36_head_attempts(user_id,failures,blocked_until) VALUES(?,?,?) ON CONFLICT(user_id) DO UPDATE SET failures=excluded.failures,blocked_until=excluded.blocked_until').bind(u.id,failures,failures>=5?nowAttempt+900000:0).run();
    return err(403,'الرمز الخاص غير صحيح');
  }
  await z711Grant(db,u.id,'head_control');
  if(attempt?.failures)await db.prepare('DELETE FROM z36_head_attempts WHERE user_id=?').bind(u.id).run();
 }
 await z33Ensure(db);
 await z36EducationEnsure(db);
 await z34OwnerAlerts(db,u.id);
 const type=crop(p.type||'overview',30),now=Date.now();
 if(type==='educationAppealDetail')return z36EducationAppealDetail(db,crop(p.appeal_id,80));
 if(type==='educationAppealReview')return z36EducationReview(db,u,{...p,type:'review'});
 if(type==='overview'){
  const [citizens,ledger,battles,cases,treasury,debts,educationAppeals,loans]=await Promise.all([
   db.prepare('SELECT id,name,identity_no,role,rank,job FROM users ORDER BY joined DESC LIMIT 150').all(),
   db.prepare('SELECT id,delta,reason,actor,created_at FROM z_state_ledger ORDER BY created_at DESC LIMIT 80').all(),
   db.prepare('SELECT id,result,target,reward,created_at FROM z33_battles ORDER BY created_at DESC LIMIT 30').all(),
   db.prepare("SELECT id,kind,detail,target_id,status,created_at FROM cases ORDER BY created_at DESC LIMIT 35").all(),
   zTreasuryBalance(db),
   db.prepare('SELECT ledger_id,actor,amount,reason,created_at,status,cleared_at,cleared_by,clear_reason FROM z35_state_debts ORDER BY created_at DESC LIMIT 120').all(),
   db.prepare("SELECT a.id,a.cycle,a.question_no,a.reason,a.status,a.created_at,u.name AS citizen_name FROM z36_edu_appeals a JOIN users u ON u.id=a.user_id ORDER BY a.created_at DESC LIMIT 30").all(),
   db.prepare("SELECT l.id,l.user_id,u.name AS citizen_name,l.principal,l.repaid,l.due_at,l.created_at,COALESCE(m.charged_at,0) AS charged_at,u.points FROM econ_loans l JOIN users u ON u.id=l.user_id LEFT JOIN z44_loan_meta m ON m.loan_id=l.id ORDER BY l.created_at DESC LIMIT 250").all()]);
  await z37AccessEnsure(db);const sole=await db.prepare('SELECT user_id FROM z37_sovereign_owner WHERE id=1').first();return json({ok:true,citizens:citizens.results,ledger:ledger.results,battles:[],cases:cases.results,treasury,debts:debts.results,educationAppeals:educationAppeals.results,loans:loans.results,loan_config:await z45LoanConfig(db),sovereign_available:isAdmin(u)&&(!sole||sole.user_id===u.id)});
 }
 if(type==='clearDebt'){
   const ledgerId=crop(p.ledger_id,80),reason=crop(p.reason,160);
   if(p.confirm_text!=='تأكيد الشطب'||reason.length<6)return err(400,'يجب تأكيد شطب السجل وكتابة سبب واضح');
   const updated=await db.prepare("UPDATE z35_state_debts SET status='cleared',cleared_at=?,cleared_by=?,clear_reason=? WHERE ledger_id=? AND status='open' RETURNING ledger_id").bind(now,u.name,reason,ledgerId).first();
   if(!updated)return err(409,'هذا السجل غير موجود أو تمت تسويته سابقًا');
   await activity(db,u.name,'تسوية سجل مديونية الخزينة '+ledgerId+' — '+reason,now);
   return json({ok:true,cleared:updated.ledger_id});
 }
 const userId=crop(p.user_id,80);
 if(type==='citizen'){
  const target=await db.prepare('SELECT id,name,identity_no,rank,job,role,points,joined FROM users WHERE id=?').bind(userId).first();if(!target)return err(404,'المواطن غير موجود');
  const [saving,company,assets,shares,inventory,transactions,cards,loans]=await Promise.all([
   db.prepare('SELECT balance,interest_at FROM z_savings WHERE user_id=?').bind(userId).first(),
   db.prepare('SELECT id,name,balance,wage FROM z_companies WHERE owner_id=?').bind(userId).first(),
   db.prepare('SELECT id,kind,level,meta FROM econ_assets WHERE user_id=? ORDER BY created_at DESC LIMIT 100').bind(userId).all(),
   db.prepare('SELECT symbol,quantity FROM econ_shares WHERE user_id=? ORDER BY symbol').bind(userId).all(),
   db.prepare('SELECT item,quantity FROM econ_inventory WHERE user_id=? ORDER BY item').bind(userId).all(),
   db.prepare('SELECT amount,note,created_at FROM transactions WHERE user_id=? ORDER BY created_at DESC LIMIT 35').bind(userId).all(),
   db.prepare('SELECT p.tier,p.mode,p.cashback,p.credit_used FROM z_card_profiles p WHERE p.user_id=? LIMIT 12').bind(userId).all(),
   db.prepare('SELECT l.id,l.principal,l.repaid,l.created_at,l.due_at,COALESCE(m.charged_at,0) AS charged_at,COALESCE(m.grace_until,0) AS grace_until FROM econ_loans l LEFT JOIN z44_loan_meta m ON m.loan_id=l.id WHERE l.user_id=? ORDER BY l.created_at DESC LIMIT 30').bind(userId).all()]);
  return json({ok:true,citizen:target,saving:saving||{balance:0},company,assets:assets.results,shares:shares.results,inventory:inventory.results,transactions:transactions.results,cards:cards.results,loans:loans.results});
 }
 if(type==='loanConfig45'){
  if(!isAdmin(u))return err(403,'التحكم بالقروض يتطلب حساب الرئاسة المعتمد');
  if(p.confirm_text!=='تأكيد التنفيذ')return err(400,'التأكيد مطلوب');
  const open=p.open===true,max=Number(p.max);
  if(!Number.isSafeInteger(max)||max<3000||max>1000000)return err(400,'الحد الأقصى بين 3,000 ومليون زنجر');
  await db.batch([
   db.prepare("INSERT INTO site_settings(key,value,updated_at) VALUES('z45_loan_open',?,?) ON CONFLICT(key) DO UPDATE SET value=excluded.value,updated_at=excluded.updated_at").bind(open?'1':'0',now),
   db.prepare("INSERT INTO site_settings(key,value,updated_at) VALUES('z45_loan_max',?,?) ON CONFLICT(key) DO UPDATE SET value=excluded.value,updated_at=excluded.updated_at").bind(String(max),now),
  ]);
  await activity(db,u.name,'غيّر إعدادات قروض الدولة (الفتح والحد الأعلى)',now);
  return json({ok:true,config:await z45LoanConfig(db)});
 }
 if(type==='treasuryTopup45'){
  if(!isAdmin(u))return err(403,'تدعيم الخزينة للرئاسة المعتمدة فقط');
  if(p.confirm_text!=='تأكيد التنفيذ')return err(400,'التأكيد مطلوب');
  const amount=Number(p.amount),reason=crop(p.reason,120),rid=crop(p.request_id,85);
  if(!Number.isSafeInteger(amount)||amount<1||amount>10000000||reason.length<6||!/^head45-[0-9a-f-]{36}$/.test(rid))return err(400,'المبلغ أو السبب أو رقم العملية غير صالح');
  const inserted=await db.prepare('INSERT OR IGNORE INTO z45_treasury_topups(id,amount,reason,actor,created_at) VALUES(?,?,?,?,?) RETURNING id').bind(rid,amount,reason,u.name,now).first();
  if(!inserted)return err(409,'تم تنفيذ الإضافة من قبل');
  return json({ok:true,treasury:await zTreasuryBalance(db)});
 }
 if(type==='removeAsset'){
  if(p.confirm_text!=='تأكيد التنفيذ')return err(400,'اكتب تأكيد التنفيذ');
  const assetId=crop(p.asset_id,80),reason=crop(p.reason,180);if(reason.length<6)return err(400,'اكتب سبب الإجراء');
  const asset=await db.prepare('SELECT id,kind,user_id FROM econ_assets WHERE id=? AND user_id=?').bind(assetId,userId).first();if(!asset)return err(404,'الملكية غير موجودة');
  const listing=await db.prepare("SELECT id FROM z_property_listings WHERE asset_id=? AND status='open' LIMIT 1").bind(assetId).first();
  const guarantee=await db.prepare("SELECT card_id FROM z_card_profiles WHERE collateral_asset_id=? AND credit_used>0 LIMIT 1").bind(assetId).first();
  if(listing||guarantee)return err(409,'لا يمكن إزالة ملكية معروضة للبيع أو مرهونة لقرض. أغلق الالتزامات أولًا.');
  const opId=id();
  await db.batch([
   db.prepare('DELETE FROM z_business_income WHERE business_key=? AND owner_id=?').bind('asset:'+assetId,userId),
   db.prepare('DELETE FROM z_business_income WHERE business_key=? AND owner_id=?').bind('asset:'+assetId.slice(0,80),userId),
   db.prepare("DELETE FROM econ_assets WHERE id=? AND user_id=? AND NOT EXISTS(SELECT 1 FROM z_property_listings WHERE asset_id=? AND status='open') AND NOT EXISTS(SELECT 1 FROM z_card_profiles WHERE collateral_asset_id=? AND credit_used>0)").bind(assetId,userId,assetId,assetId),
   db.prepare('INSERT INTO activity(id,name,text,created_at) VALUES(?,?,?,?)').bind(opId,u.name,'إزالة ملكية بالرقابة الرئاسية: '+asset.kind+' — '+assetId+' — '+reason,now)
  ]);
  await zNotify(db,userId,'قرار رئاسي بشأن ممتلكاتك','تم إزالة ملكية '+asset.kind+' بسبب: '+reason,'government');
  return json({ok:true,removed_asset:assetId});
 }
 if(type==='adjust'){
  if(p.confirm_text!=='تأكيد التنفيذ')return err(400,'اكتب عبارة تأكيد التنفيذ كما هي قبل تعديل الرصيد');
  const amount=Number(p.amount),reason=crop(p.reason,180),side=p.side;
  if(!Number.isSafeInteger(amount)||amount<1||amount>1000000||!['add','deduct'].includes(side)||reason.length<6)return err(400,'مبلغ أو سبب العملية غير صالح');
  const delta=side==='add'?amount:-amount;
  const unique=crop(p.request_id,80);if(!/^[a-zA-Z0-9-]{12,80}$/.test(unique))return err(400,'رقم تأكيد العملية مفقود');
  // One transaction guards duplicate submissions; the audit row is idempotent.
  // First execution installs idempotent, single-statement financial trigger; no mid-operation partial debits.
  await db.prepare('CREATE TABLE IF NOT EXISTS z34_head_adjust(id TEXT PRIMARY KEY,target_id TEXT NOT NULL,delta INTEGER NOT NULL,reason TEXT NOT NULL,actor TEXT NOT NULL,created_at INTEGER NOT NULL)').run();
  await db.prepare(`CREATE TRIGGER IF NOT EXISTS z34_head_adjust_check BEFORE INSERT ON z34_head_adjust BEGIN
    SELECT CASE WHEN NOT EXISTS(SELECT 1 FROM users WHERE id=NEW.target_id AND points+NEW.delta>=0) THEN RAISE(ABORT,'العضو غير موجود أو الرصيد لا يكفي') END;
   END`).run();
  await db.prepare(`CREATE TRIGGER IF NOT EXISTS z34_head_adjust_apply AFTER INSERT ON z34_head_adjust BEGIN
    UPDATE users SET points=points+NEW.delta WHERE id=NEW.target_id;
    INSERT INTO transactions(id,user_id,amount,note,created_at) VALUES(NEW.id,NEW.target_id,NEW.delta,'قرار رئاسي خاص: '||NEW.reason||' — بواسطة '||NEW.actor,NEW.created_at);
   END`).run();
  const receipt=await db.prepare('INSERT OR IGNORE INTO z34_head_adjust(id,target_id,delta,reason,actor,created_at) VALUES(?,?,?,?,?,?) RETURNING id').bind('head34-'+unique,userId,delta,reason,u.name,now).first();
  if(!receipt)return err(409,'رقم العملية سبق استخدامه');
  await activity(db,u.name,'قرار رئاسي خاص على حساب مواطن: '+(side==='add'?'إضافة ':'خصم ')+amount+' زنجر — '+reason,now);
  await zNotify(db,userId,'قرار مالي رئاسي','تم '+(side==='add'?'إضافة ':'خصم ')+amount+' زنجر. السبب: '+reason,'money');
  return json({ok:true,delta});
 }
 return err(400,'عملية غير معروفة');
}


async function z37Sovereign(req,db,env,p){
 const u=await getMe(req,db);if(!u)return err(401,'سجّل الدخول أولًا');
 await z37AccessEnsure(db);
 const expected=env.HEAD_OF_STATE_CODE?await digest(String(env.HEAD_OF_STATE_CODE)):'46f3103321db1fa31d90500379916cd59eb3ff698f003bf18aa5ba64ded86cc5';
 const code=String(p.owner_code||'');
 if(!isAdmin(u))return err(403,'الرئاسة الدولية الخاصة تتطلب صلاحية رئيس الدولة بالإضافة إلى الكود');
 const hasCode=await z711Active(db,u.id,'sovereign_control');
 if(!hasCode&&(code.length<12||code.length>150||!eqSecure(await digest(code),expected)))return err(403,'الرمز الخاص غير صحيح');
 if(env.HEAD_OF_STATE_USER_ID && String(env.HEAD_OF_STATE_USER_ID)!==u.id)return err(403,'هذا الحساب ليس الحساب الرئيسي المسجل في إعدادات الدولة');
 if(env.HEAD_OF_STATE_IDENTITY_NO && String(env.HEAD_OF_STATE_IDENTITY_NO)!==String(u.identity_no||''))return err(403,'رقم الهوية غير مطابق لحساب الرئاسة الخاصة');
 // Only the first verified account becomes the exclusive recipient of the special bank and battle rates.
 const now=Date.now();await db.prepare('INSERT OR IGNORE INTO z37_sovereign_owner(id,user_id,claimed_at) VALUES(1,?,?)').bind(u.id,now).run();
 const owner=await db.prepare('SELECT user_id FROM z37_sovereign_owner WHERE id=1').first();
 if(owner?.user_id!==u.id)return err(403,'الرئاسة الدولية الخاصة مرتبطة بحساب رئيس واحد فقط');
 if(!hasCode)await z711Grant(db,u.id,'sovereign_control');
 const type=crop(p.type||'status',24);
 if(type==='status'){
  const [treasury,saving,history,people]=await Promise.all([zTreasuryBalance(db),db.prepare('SELECT balance,interest_at FROM z_savings WHERE user_id=?').bind(u.id).first(),db.prepare('SELECT id,user_id,source,amount,reason,created_at FROM z37_sovereign_transfers ORDER BY created_at DESC LIMIT 30').all(),db.prepare('SELECT id,name FROM users ORDER BY name LIMIT 250').all()]);
  return json({ok:true,treasury,saving:saving||{balance:0,interest_at:0},bonus_percent:5,bonus_interval_minutes:240,transfers:history.results,citizens:people.results});
 }
 if(type==='transfer'){
  const amount=Number(p.amount),reason=crop(p.reason,160),source=String(p.source||'treasury'),userId=crop(p.user_id,80),unique=crop(p.request_id,90);
  if(p.confirm_text!=='تأكيد التحويل'||!Number.isSafeInteger(amount)||amount<1||amount>1000000||reason.length<6||!['treasury','bank'].includes(source)||!/^sovereign-[a-f0-9-]{36}$/.test(unique))return err(400,'أدخل مبلغًا صحيحًا وسببًا وتأكيدًا');
  const exists=await db.prepare('SELECT id FROM users WHERE id=?').bind(userId).first();if(!exists)return err(404,'المواطن غير موجود');
  // Bank source transfers from the authenticated sovereign account's own savings. Treasury source debits treasury atomically.
  const added=await db.prepare('INSERT OR IGNORE INTO z37_sovereign_transfers(id,user_id,actor_id,source,amount,reason,created_at) VALUES(?,?,?,?,?,?,?) RETURNING id').bind(unique,userId,u.id,source,amount,reason,now).first();
  if(!added)return err(409,'تم تنفيذ رقم العملية بالفعل');
  return json({ok:true,amount,notice:'اكتمل التحويل وحُفظ في السجلات من غير إرسال إشعارات عامة'});
 }
 return err(400,'عملية غير معروفة');
}

