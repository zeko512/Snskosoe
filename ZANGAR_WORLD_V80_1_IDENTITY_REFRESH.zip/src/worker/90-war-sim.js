// Zangar fictional arcade defense — shared server-side game state, no real-world guidance.
async function zWarEvent(db,kind,message,actor='مركز العمليات',now=Date.now()){
 await db.prepare('INSERT INTO z_war_events(id,kind,text,actor,created_at) VALUES(?,?,?,?,?)').bind(id(),kind,crop(message,160),crop(actor,60),now).run();
}
// Defense access is granted by an account-bound code; existing presidential grants also work.
const Z_WAR_DEFENSE_CODE_HASH='a502027a4eb989c8eaa91de9a551b9c9b32ac0a637b3a2b29f1faa64cc4e1874';
let z37AccessReady=null;
async function z37AccessEnsure(db){
 if(!z37AccessReady)z37AccessReady=(async()=>{
  await db.prepare('CREATE TABLE IF NOT EXISTS z37_defense_passes(token_hash TEXT PRIMARY KEY,user_id TEXT NOT NULL,expires_at INTEGER NOT NULL)').run();
  await db.prepare('CREATE INDEX IF NOT EXISTS z37_defense_user ON z37_defense_passes(user_id,expires_at)').run();
  await db.prepare('CREATE TABLE IF NOT EXISTS z37_sovereign_owner(id INTEGER PRIMARY KEY CHECK(id=1),user_id TEXT NOT NULL,claimed_at INTEGER NOT NULL)').run();
  await db.prepare('CREATE TABLE IF NOT EXISTS z37_sovereign_transfers(id TEXT PRIMARY KEY,user_id TEXT NOT NULL,actor_id TEXT NOT NULL,source TEXT NOT NULL,amount INTEGER NOT NULL CHECK(amount>0 AND amount<=1000000),reason TEXT NOT NULL,created_at INTEGER NOT NULL)').run();
  await db.prepare(`CREATE TRIGGER IF NOT EXISTS z37_sovereign_transfer_check BEFORE INSERT ON z37_sovereign_transfers BEGIN
    SELECT CASE WHEN NOT EXISTS(SELECT 1 FROM users WHERE id=NEW.user_id) THEN RAISE(ABORT,'المواطن غير موجود') END;
    SELECT CASE WHEN NEW.source='treasury' AND NOT EXISTS(SELECT 1 FROM z_state_treasury WHERE id=1 AND balance>=NEW.amount) THEN RAISE(ABORT,'خزينة الدولة غير كافية') END;
    SELECT CASE WHEN NEW.source='bank' AND NOT EXISTS(SELECT 1 FROM z_savings WHERE user_id=NEW.actor_id AND balance>=NEW.amount+2*COALESCE((SELECT SUM(credit_used) FROM z_card_profiles WHERE user_id=NEW.actor_id AND collateral_type='savings'),0)) THEN RAISE(ABORT,'توفير الرئيس غير كاف أو مرهون') END;
   END`).run();
  await db.prepare(`CREATE TRIGGER IF NOT EXISTS z37_sovereign_transfer_apply AFTER INSERT ON z37_sovereign_transfers BEGIN
   UPDATE z_state_treasury SET balance=balance-NEW.amount WHERE id=1 AND NEW.source='treasury';
   UPDATE z_savings SET balance=balance-NEW.amount WHERE user_id=NEW.actor_id AND NEW.source='bank';
   INSERT INTO transactions(id,user_id,amount,note,created_at) SELECT lower(hex(randomblob(16))),NEW.actor_id,-NEW.amount,'تحويل من توفير القيادة: '||NEW.reason,NEW.created_at WHERE NEW.source='bank';
   UPDATE users SET points=points+NEW.amount WHERE id=NEW.user_id;
   INSERT INTO transactions(id,user_id,amount,note,created_at) VALUES(lower(hex(randomblob(16))),NEW.user_id,NEW.amount,'تحويل خاص مسجل: '||NEW.reason,NEW.created_at);
   INSERT INTO z_state_ledger(id,delta,reason,actor,created_at) SELECT lower(hex(randomblob(16))),-NEW.amount,'تحويل خاص معتمد: '||NEW.reason,u.name,NEW.created_at FROM users u WHERE u.id=NEW.actor_id AND NEW.source='treasury';
  END`).run();
 })().catch(e=>{z37AccessReady=null;throw e});
 return z37AccessReady;
}
async function zWarAuthorized(db,u,req){
 if(!u||!req||await prisonActive(db,u.id))return false;
 if(/وزير الدفاع|الدفاع الجوي|مسؤول الدفاع/i.test(String(u.job||''))){const season=await db.prepare('SELECT season FROM z39_season_meta WHERE id=1').first();if(Number(season?.season)===2)return true;}
 await z37AccessEnsure(db);
 const pass=cookieValue(req,'z37_defense');if(!/^[a-f0-9]{64}$/.test(pass))return false;
 const row=await db.prepare('SELECT 1 AS ok FROM z37_defense_passes WHERE token_hash=? AND user_id=? AND expires_at>?').bind(await digest(pass),u.id,Date.now()).first();
 return !!row;
}
async function zWarAccess(req,db){
 const u=await getMe(req,db);if(!u)return json({authorized:false,logged_in:false,role:'visitor'});
 const authorized=await zWarAuthorized(db,u,req);
 return json({authorized,logged_in:true,role:authorized?'defense':'locked',account:u.name});
}
async function zWarUnlock(req,db,p){
 const u=await getMe(req,db);if(!u)return err(401,'سجّل الدخول أولًا');
 if(await prisonActive(db,u.id))return err(403,'لا يمكن فتح الدفاع خلال السجن');
 await z37AccessEnsure(db);
 const code=String(p.code||'');if(code.length<3||code.length>100)return err(400,'أدخل كود وزير الدفاع');
 const now=Date.now(),attempt=await db.prepare('SELECT failures,blocked_until FROM z_war_unlock_attempts WHERE user_id=?').bind(u.id).first();
 if(Number(attempt?.blocked_until||0)>now)return err(429,'محاولات كثيرة؛ حاول بعد 15 دقيقة');
 if(!eqSecure(await digest(code),Z_WAR_DEFENSE_CODE_HASH)){
  const n=Number(attempt?.failures||0)+1;
  await db.prepare('INSERT INTO z_war_unlock_attempts(user_id,failures,blocked_until) VALUES(?,?,?) ON CONFLICT(user_id) DO UPDATE SET failures=excluded.failures,blocked_until=excluded.blocked_until').bind(u.id,n,n>=5?now+900000:0).run();
  return err(403,'كود الدفاع غير صحيح');
 }
 await db.prepare('DELETE FROM z_war_unlock_attempts WHERE user_id=?').bind(u.id).run();
 const raw=hex(crypto.getRandomValues(new Uint8Array(32))),ttl=12*3600000;
 await db.prepare('INSERT INTO z37_defense_passes(token_hash,user_id,expires_at) VALUES(?,?,?)').bind(await digest(raw),u.id,now+ttl).run();
 return json({ok:true,authorized:true,role:'defense'},200,{'Set-Cookie':`z37_defense=${raw}; HttpOnly; Secure; SameSite=Lax; Path=/; Max-Age=${ttl/1000}`});
}
function zWarSignal(now){return ['excellent','good','good','medium','weak','critical'][Math.floor(now/25000)%6];}
async function zWarAdvance(db,now=Date.now()){return []; // Update 62: no scheduled missile impacts

 let newlyCreated=false;
 // Use the last *actual* launch, not an hourly calendar bucket. Existing attacks delay the next by 17m.
 const interval=17*60000;
 const recent=await db.prepare('SELECT started_at FROM z_war_threats ORDER BY started_at DESC LIMIT 1').first();
 if(!recent || now-Number(recent.started_at)>=interval){
  // Slot identifier is unique for each 17-minute bucket. INSERT OR IGNORE protects against parallel cron requests.
  const slot=Math.floor(now/interval);
  const angle=Math.floor(10+Math.random()*340);
  const created=await db.prepare("INSERT OR IGNORE INTO z_war_threats(hour_slot,angle,started_at,ends_at,status) VALUES(?,?,?,?,'inbound') RETURNING hour_slot").bind(slot,angle,now,now+4*60000).first();
  if(created){newlyCreated=true;await zWarEvent(db,'detected','رادار الدفاع رصد صاروخًا افتراضيًا جديدًا (كل 17 دقيقة)');
   await db.prepare('INSERT OR IGNORE INTO z_push_dispatch(hour_slot,created_at) VALUES(?,?)').bind(slot,now).run();}
 }
 const expired=await db.prepare("UPDATE z_war_threats SET status='hit',resolved_at=? WHERE status='inbound' AND ends_at<=? RETURNING hour_slot").bind(now,now).all();
 for(const row of expired.results){
  const before=await zTreasuryBalance(db);const charged=await db.prepare('UPDATE z_state_treasury SET balance=MAX(0,balance-2000) WHERE id=1 RETURNING balance').first();
  if(charged)await zTreasuryLedger(db,-Math.min(2000,before),'ضرر هجوم افتراضي غير معترض','المركز',now);
  await zWarEvent(db,'hit','وصول هدف معادٍ افتراضي؛ خسارة 2,000 زنجر من خزينة الدولة','النظام',now);
 }
 return newlyCreated;
}
async function zWarStatus(req,db,env,waitUntil){
 const now=Date.now();
 const u=await getMe(req,db),auth=(await zWarAuthorized(db,u,req))&&!(u&&await prisonActive(db,u.id));
 // Any citizen or visitor can observe the shared radar; mutations are checked in zWarAction.
 const created=await zWarAdvance(db,now);
 if(created){const task=zPushDrain(db,env).catch(e=>console.error('Push background:',e));if(waitUntil)waitUntil(task);else await task;}
 const state=await db.prepare('SELECT * FROM z_war_state WHERE id=1').first(),treasury=await zTreasuryBalance(db);
 const threat=await db.prepare('SELECT * FROM z_war_threats ORDER BY hour_slot DESC LIMIT 1').first();
 const feed=await db.prepare('SELECT kind,text,actor,created_at FROM z_war_events ORDER BY created_at DESC LIMIT 25').all();for(const entry of feed.results){if(String(entry.text||'').includes('800,000'))entry.text='تنبيه قديم من إصدار سابق؛ الأرقام المذكورة حينها لم تكن مكافأة مؤكدة. قواعد Update 43 تنطبق على الانتصارات الجديدة فقط.';}
 const planned=await db.prepare('SELECT minutes,arrival_at,created_at FROM z_war_planned_alerts WHERE arrival_at>? ORDER BY created_at DESC LIMIT 1').bind(now).first();
 return json({ok:true,planned_warning:planned||null,now,treasury,authorized:auth,account:u?.name||'',cannon:Number(state.cannon),missiles:Number(state.missiles),armed:!!state.armed,shots_left:Number(state.shots_left??10),protection_until:Number(state.protection_until),emergency_until:Number(state.emergency_until),signal:zWarSignal(now),threat:threat?.status==='inbound'&&Number(threat.ends_at)>now?threat:null,events:feed.results});
}
async function zWarAction(req,db,p,env,waitUntil){return err(403,Z62_PEACE_MESSAGE);

 const u=await getMe(req,db);if(!u)return err(401,'سجّل دخولك أولًا للتحكم في غرفة العمليات');
 if(!(await zWarAuthorized(db,u,req)))return err(403,'التحكم للرؤساء المخوّلين فقط');
 if(await prisonActive(db,u.id))return err(403,'لا يمكن تشغيل الدفاع أثناء السجن');
 const now=Date.now(),type=crop(p.type,26),state=await db.prepare('SELECT * FROM z_war_state WHERE id=1').first();
 const created=await zWarAdvance(db,now);
 if(created){const task=zPushDrain(db,env).catch(e=>console.error('Push action:',e));if(waitUntil)waitUntil(task);else await task;}
 if(type==='buyCannon'){
  if(state.cannon&&state.shots_left>0)return err(409,'المدفعية الحالية ما زال بها طلقات');if(await zTreasuryBalance(db)<1000)return err(409,'خزينة الدولة لا تكفي شراء المدفعية');
  const changed=await db.prepare('UPDATE z_war_state SET cannon=1,shots_left=10 WHERE id=1 AND (cannon=0 OR shots_left<=0) RETURNING cannon').first();if(!changed)return err(409,'تم تجهيز المدفعية بالفعل');
  await zTreasurySpend(db,1000,'شراء مدفعية دفاعية افتراضية',u.name,now);await zWarEvent(db,'purchase','تجهيز مدفعية دفاعية واحدة مقابل 1,000 زنجر',u.name,now);
 }else if(type==='buyMissile'){
  if(!state.cannon)return err(400,'يجب شراء المدفعية أولًا');
  const qty=Math.trunc(Number(p.quantity||1));if(qty<1||qty>5)return err(400,'اختار من 1 إلى 5 صواريخ');if(await zTreasuryBalance(db)<800*qty)return err(409,'الخزينة لا تكفي لشراء الصواريخ');
  const added=await db.prepare('UPDATE z_war_state SET missiles=missiles+? WHERE id=1 AND cannon=1 AND missiles+?<=MAX(10,shots_left) RETURNING missiles').bind(qty,qty).first();if(!added)return err(409,'المخزن ممتلئ أو المدفعية غير متوفرة');
  await zTreasurySpend(db,800*qty,'شراء '+qty+' صاروخ لعبة للدفاع',u.name,now);await zWarEvent(db,'purchase','تزويد المخزن بـ'+qty+' صاروخ دفاع افتراضي',u.name,now);
 }else if(type==='activation'||type==='completion'||type==='stop'){
  const isOn=type!=='stop';await db.prepare('UPDATE z_war_state SET armed=? WHERE id=1').bind(isOn?1:0).run();
  await zWarEvent(db,'control',isOn?'تفعيل نظام الرصد والإطلاق الافتراضي':'إيقاف إطلاق الصواريخ مؤقتًا',u.name,now);
 }else if(type==='protect'){
  await db.prepare('UPDATE z_war_state SET protection_until=? WHERE id=1').bind(now+5*60000).run();
  await zWarEvent(db,'protection','تفعيل الدرع الدفاعي لمدة 5 دقائق',u.name,now);
 }else if(type==='plannedWarning'){
  const minutes=Number(p.minutes);if(!Number.isInteger(minutes)||minutes<1||minutes>120)return err(400,'اختار وقتًا بين دقيقة وساعتين');
  const previous=await db.prepare('SELECT created_at,arrival_at FROM z_war_planned_alerts ORDER BY created_at DESC LIMIT 1').first();
  if(previous&&Number(previous.arrival_at)>now)return err(409,'يوجد إنذار مجدول حاليًا، انتظر انتهاءه');
  if(previous&&now-Number(previous.created_at)<60000)return err(429,'انتظر دقيقة قبل إرسال إنذار جديد');
  const arrives=now+minutes*60000;await db.prepare('INSERT INTO z_war_planned_alerts(id,creator_id,minutes,created_at,arrival_at) VALUES(?,?,?,?,?)').bind(id(),u.id,minutes,now,arrives).run();
  await zWarEvent(db,'planned','إنذار تدريبي مجدول: هدف افتراضي بعد '+minutes+' دقيقة',u.name,now);
  const all=await db.prepare('SELECT id FROM users LIMIT 500').all();
  for(const member of all.results)await zNotify(db,member.id,'🚨 إنذار زنجر مجدول','في صاروخ افتراضي جاي بعد '+minutes+' دقيقة — تدريب داخل اللعبة','war');
 }else if(type==='emergency'){
  const updated=await db.prepare('UPDATE z_war_state SET emergency_until=?,last_alert=? WHERE id=1 AND last_alert<=? RETURNING emergency_until').bind(now+90000,now,now-60000).first();
  if(!updated)return err(429,'تم إعلان الطوارئ مؤخرًا؛ انتظر دقيقة');
  await zWarEvent(db,'emergency','إنذار عام! رُصد خطر افتراضي؛ انتبهوا إلى شاشة الدفاع',u.name,now);
  const all=await db.prepare('SELECT id FROM users LIMIT 500').all();
  for(const member of all.results)await zNotify(db,member.id,'🚨 إنذار طوارئ زنجر','تحذير خيالي في لعبة الدفاع؛ تابع الرادار','war');
  // Enqueued per citizen via zNotify; the request/cron dispatcher sends category-specific encrypted alerts.
 }else if(type==='fire'){
  if(!state.cannon||!state.armed)return err(403,'يجب تجهيز المدفعية وتشغيل نظام الإطلاق');
  const sector=Number(p.sector);if(!Number.isInteger(sector)||sector<0||sector>359)return err(400,'اختر اتجاهًا على الرادار أولًا');
  const threat=await db.prepare("SELECT * FROM z_war_threats WHERE status='inbound' AND ends_at>? ORDER BY started_at DESC LIMIT 1").bind(now).first();
  if(!threat||now>=threat.ends_at)return err(409,'لا يوجد صاروخ معادٍ نشط الآن');
  const shot=await db.prepare('UPDATE z_war_state SET missiles=missiles-1,shots_left=shots_left-1 WHERE id=1 AND missiles>=1 AND shots_left>=1 AND armed=1 RETURNING missiles,shots_left').first();if(!shot)return err(409,'مخزن الصواريخ فارغ');
  const difference=Math.abs(((sector-threat.angle+540)%360)-180),signal=zWarSignal(now);
  const protectedMode=state.protection_until>now;
  // Accurate angular alignment always wins; signal is visual only, not hidden random failure.
  const intercepted=difference<=24;
  await db.prepare('UPDATE z_war_threats SET shots=shots+1 WHERE hour_slot=?').bind(threat.hour_slot).run();
  if(intercepted){
   const done=await db.prepare("UPDATE z_war_threats SET status='intercepted',resolved_at=? WHERE hour_slot=? AND status='inbound' RETURNING hour_slot").bind(now,threat.hour_slot).first();
   if(done){
    await z33Ensure(db);
    await db.prepare('INSERT OR IGNORE INTO z37_war_payouts(battle_id,actor_id,created_at) VALUES(?,?,?)').bind('radar-'+String(threat.hour_slot),u.id,now).run();
    const verified=await db.prepare('SELECT event_id,treasury_added,leader_added FROM z43_war_rewards WHERE event_id=?').bind('radar-'+String(threat.hour_slot)).first();
    if(!verified)console.error('Radar payout ledger not confirmed for',threat.hour_slot);
    // No public event or financial alert for the private radar interception reward.
   }
  }else await zWarEvent(db,'miss','اعتراض لم ينجح؛ راجع اتجاه الهدف وجودة الإشارة',u.name,now);
  const receipt=intercepted?await db.prepare('SELECT event_id FROM z43_war_rewards WHERE event_id=?').bind('radar-'+String(threat.hour_slot)).first():null;
  return json({ok:true,intercepted,reward_confirmed:!!receipt,defender_reward:intercepted?3000:0,treasury_reward:intercepted?5000:0,correct_sector:intercepted?sector:null,remaining:shot.missiles,shots_left:shot.shots_left});
 }else return err(400,'أمر دفاعي غير معروف');
 return json({ok:true});
}

// UPDATE 33: Independent strategy simulation. Legacy radar, 17min rockets and U32 economy untouched.

let z34Ready=null;
async function z34Ensure(db){
 if(z34Ready)return z34Ready;
 z34Ready=(async()=>{
  const v=await db.prepare("SELECT value FROM site_settings WHERE key='u34_war_victory_ready'").first();
  if(v?.value==='1'){await z35Ensure(db);return;}
  await db.batch([db.prepare('DROP TRIGGER IF EXISTS z33_battle_check'),db.prepare('DROP TRIGGER IF EXISTS z33_battle_apply'),
  await db.prepare(`CREATE TRIGGER z33_battle_check BEFORE INSERT ON z33_battles WHEN NEW.attacker='home' BEGIN
    SELECT CASE WHEN NOT EXISTS(SELECT 1 FROM z33_military WHERE id=1 AND soldiers>=NEW.soldiers AND planes>=NEW.planes AND ships>=NEW.ships AND missiles>=NEW.missiles AND NEW.created_at>=last_attack_at+1800000) THEN RAISE(ABORT,'الجيش غير كاف أو الهجوم لم يحن موعده') END;
    SELECT CASE WHEN NOT EXISTS(SELECT 1 FROM z33_countries WHERE id=NEW.target AND id<>'home') THEN RAISE(ABORT,'الدولة المستهدفة غير متاحة') END;
   END`),
  await db.prepare(`CREATE TRIGGER z33_battle_apply AFTER INSERT ON z33_battles WHEN NEW.attacker='home' BEGIN
    UPDATE z33_military SET soldiers=soldiers-NEW.loss_soldiers,planes=planes-NEW.loss_planes,ships=ships-NEW.loss_ships,missiles=missiles-NEW.missiles,last_attack_at=NEW.created_at WHERE id=1;
    UPDATE z33_countries SET treasury=MAX(0,treasury-NEW.reward),soldiers=MAX(40,soldiers-CASE WHEN NEW.result='victory' THEN 65 ELSE 20 END),planes=MAX(0,planes-CASE WHEN NEW.result='victory' THEN 2 ELSE 0 END) WHERE id=NEW.target;
    UPDATE z_state_treasury SET balance=balance+NEW.reward WHERE id=1;
    INSERT INTO z_state_ledger(id,delta,reason,actor,created_at) SELECT lower(hex(randomblob(16))),NEW.reward,'مكافأة انتصار محاكاة الحرب',u.name,NEW.created_at FROM users u WHERE u.id=NEW.actor_id AND NEW.result='victory';
    UPDATE users SET points=points+1500 WHERE NEW.result='victory';
    INSERT INTO transactions(id,user_id,amount,note,created_at) SELECT lower(hex(randomblob(16))),id,1500,'مكافأة انتصار دولة الزنجر في الحرب',NEW.created_at FROM users WHERE NEW.result='victory';
   END`),
  db.prepare(`CREATE TRIGGER IF NOT EXISTS z34_defended_bonus AFTER INSERT ON z33_battles WHEN NEW.attacker<>'home' AND NEW.result='defended' BEGIN
    UPDATE z_state_treasury SET balance=balance+500000 WHERE id=1;
    INSERT INTO z_state_ledger(id,delta,reason,actor,created_at) VALUES(lower(hex(randomblob(16))),500000,'مكافأة الدفاع عن دولة الزنجر في الحرب الدولية','النظام العسكري',NEW.created_at);
    UPDATE users SET points=points+1500;
    INSERT INTO transactions(id,user_id,amount,note,created_at) SELECT lower(hex(randomblob(16))),id,1500,'مكافأة الدفاع الناجح عن الدولة في الحرب الدولية',NEW.created_at FROM users;
   END`),
  db.prepare("INSERT OR IGNORE INTO site_settings(key,value,updated_at) VALUES('u34_war_victory_ready','1',?)").bind(Date.now())]);
  await z35Ensure(db);
 })().catch(e=>{z34Ready=null;throw e});
 return z34Ready;
}

let z35Ready=null;
async function z35Ensure(db){
 if(z35Ready)return z35Ready;
 z35Ready=(async()=>{
  const flag=await db.prepare("SELECT value FROM site_settings WHERE key='u35_economy_controls_ready'").first();
  if(flag?.value==='1'){await z37EnsureWar(db);return;}
  const citizenBonus="CASE WHEN NEW.reward>=500000 THEN 1500+CAST((NEW.reward-500000)/100000 AS INTEGER)*500 ELSE 0 END";
  const statementList=[
   `CREATE TABLE IF NOT EXISTS z35_state_debts(ledger_id TEXT PRIMARY KEY,actor TEXT NOT NULL,amount INTEGER NOT NULL CHECK(amount>0),reason TEXT NOT NULL,created_at INTEGER NOT NULL,status TEXT NOT NULL DEFAULT 'open' CHECK(status IN ('open','cleared')),cleared_at INTEGER NOT NULL DEFAULT 0,cleared_by TEXT NOT NULL DEFAULT '',clear_reason TEXT NOT NULL DEFAULT '')`,
   `CREATE INDEX IF NOT EXISTS idx_z35_state_debts_recent ON z35_state_debts(status,created_at DESC)`,
   `CREATE TRIGGER IF NOT EXISTS z35_state_debts_capture AFTER INSERT ON z_state_ledger WHEN NEW.delta<0 BEGIN
      INSERT OR IGNORE INTO z35_state_debts(ledger_id,actor,amount,reason,created_at) VALUES(NEW.id,COALESCE(NEW.actor,'غير محدد'),-NEW.delta,COALESCE(NEW.reason,'صرف من الخزينة'),NEW.created_at);
    END`,
   `DROP TRIGGER IF EXISTS z33_battle_apply`,
   `CREATE TRIGGER z33_battle_apply AFTER INSERT ON z33_battles WHEN NEW.attacker='home' BEGIN
      UPDATE z33_military SET soldiers=soldiers-NEW.loss_soldiers,planes=planes-NEW.loss_planes,ships=ships-NEW.loss_ships,missiles=missiles-NEW.missiles,last_attack_at=NEW.created_at WHERE id=1;
      UPDATE z33_countries SET treasury=MAX(0,treasury-NEW.reward),soldiers=MAX(40,soldiers-CASE WHEN NEW.result='victory' THEN 65 ELSE 20 END),planes=MAX(0,planes-CASE WHEN NEW.result='victory' THEN 2 ELSE 0 END) WHERE id=NEW.target;
      UPDATE z_state_treasury SET balance=balance+NEW.reward WHERE id=1;
      INSERT INTO z_state_ledger(id,delta,reason,actor,created_at) SELECT lower(hex(randomblob(16))),NEW.reward,'مكافأة حرب دولية متدرجة حسب قوة الدولة',u.name,NEW.created_at FROM users u WHERE u.id=NEW.actor_id AND NEW.result='victory';
      UPDATE users SET points=points+(${citizenBonus}) WHERE NEW.result='victory';
      INSERT INTO transactions(id,user_id,amount,note,created_at) SELECT lower(hex(randomblob(16))),id,(${citizenBonus}),'مكافأة انتصار حرب دولية متدرجة',NEW.created_at FROM users WHERE NEW.result='victory';
    END`,
   `DROP TRIGGER IF EXISTS z34_defended_bonus`,
   `CREATE TRIGGER z34_defended_bonus AFTER INSERT ON z33_battles WHEN NEW.attacker<>'home' AND NEW.result='defended' BEGIN
      UPDATE z_state_treasury SET balance=balance+NEW.reward WHERE id=1;
      INSERT INTO z_state_ledger(id,delta,reason,actor,created_at) VALUES(lower(hex(randomblob(16))),NEW.reward,'مكافأة الدفاع الناجح عن الحرب الدولية المتدرجة','النظام العسكري',NEW.created_at);
      UPDATE users SET points=points+(${citizenBonus});
      INSERT INTO transactions(id,user_id,amount,note,created_at) SELECT lower(hex(randomblob(16))),id,(${citizenBonus}),'مكافأة الدفاع الناجح حسب قوة العدو',NEW.created_at FROM users;
    END`,
   `INSERT OR IGNORE INTO site_settings(key,value,updated_at) VALUES('u35_economy_controls_ready','1',${Date.now()})`
  ];
  await db.batch(statementList.map(x=>db.prepare(x)));await z37EnsureWar(db);
 })().catch(e=>{z35Ready=null;throw e});
 return z35Ready;
}


let z37WarReady=null;
async function z37EnsureWar(db){
 if(z37WarReady)return z37WarReady;
 const latest=await db.prepare("SELECT value FROM site_settings WHERE key='z45_migrated'").first();
 if(latest?.value==='1'){z37WarReady=Promise.resolve();return z37WarReady;}
 z37WarReady=(async()=>{
  await z37AccessEnsure(db);
  const f=await db.prepare("SELECT value FROM site_settings WHERE key='u37_war_rewards_ready'").first();
  if(f?.value==='1')return;
  const sql=[
   `DROP TRIGGER IF EXISTS z33_battle_apply`,
   `DROP TRIGGER IF EXISTS z34_defended_bonus`,
   `CREATE TRIGGER z33_battle_apply AFTER INSERT ON z33_battles WHEN NEW.attacker='home' BEGIN
    UPDATE z33_military SET soldiers=soldiers-NEW.loss_soldiers,planes=planes-NEW.loss_planes,ships=ships-NEW.loss_ships,missiles=missiles-NEW.missiles,last_attack_at=NEW.created_at WHERE id=1;
    UPDATE z33_countries SET treasury=MAX(0,treasury-NEW.reward),soldiers=MAX(40,soldiers-CASE WHEN NEW.result='victory' THEN 65 ELSE 20 END),planes=MAX(0,planes-CASE WHEN NEW.result='victory' THEN 2 ELSE 0 END) WHERE id=NEW.target;
   END`,
   `CREATE TRIGGER z34_defended_bonus AFTER INSERT ON z33_battles WHEN NEW.attacker<>'home' AND NEW.result='defended' BEGIN SELECT 1; END`,
   `CREATE TABLE IF NOT EXISTS z37_war_payouts(battle_id TEXT PRIMARY KEY,actor_id TEXT,created_at INTEGER NOT NULL)`,
   `CREATE TRIGGER IF NOT EXISTS z37_war_payout_apply AFTER INSERT ON z37_war_payouts BEGIN
     UPDATE z_state_treasury SET balance=balance+MAX(0,800000-1500*(SELECT COUNT(*) FROM users)) WHERE id=1;
     INSERT INTO z_state_ledger(id,delta,reason,actor,created_at) VALUES(lower(hex(randomblob(16))),MAX(0,800000-1500*(SELECT COUNT(*) FROM users)),'مكافأة حرب: 800000 إجماليًا منها 1500 لكل مواطن','نظام المحاكاة',NEW.created_at);
     UPDATE users SET points=points+1500;
     INSERT INTO transactions(id,user_id,amount,note,created_at) SELECT lower(hex(randomblob(16))),id,1500,'حصة مواطن من مكافأة 800000 للمعركة',NEW.created_at FROM users;
     UPDATE users SET points=points+50000 WHERE id=NEW.actor_id;
     INSERT INTO transactions(id,user_id,amount,note,created_at) SELECT lower(hex(randomblob(16))),NEW.actor_id,50000,'مكافأة تنفيذ أو صد حرب مسجلة',NEW.created_at WHERE NEW.actor_id IS NOT NULL AND EXISTS(SELECT 1 FROM users WHERE id=NEW.actor_id);
     UPDATE users SET points=points+20000 WHERE id=(SELECT user_id FROM z37_sovereign_owner WHERE id=1);
     INSERT INTO transactions(id,user_id,amount,note,created_at) SELECT lower(hex(randomblob(16))),user_id,20000,'مكافأة الرئاسة الدولية الخاصة',NEW.created_at FROM z37_sovereign_owner WHERE id=1;
   END`,
   `CREATE TRIGGER IF NOT EXISTS z37_war_payout_battle AFTER INSERT ON z33_battles WHEN (NEW.attacker='home' AND NEW.result='victory') OR (NEW.attacker<>'home' AND NEW.result='defended') BEGIN
     INSERT OR IGNORE INTO z37_war_payouts(battle_id,actor_id,created_at) VALUES(NEW.id,CASE WHEN NEW.actor_id='system' THEN NULL ELSE NEW.actor_id END,NEW.created_at);
   END`,
   `INSERT OR IGNORE INTO site_settings(key,value,updated_at) VALUES('u37_war_rewards_ready','1',${Date.now()})`
  ];
  await db.batch(sql.map(x=>db.prepare(x)));
 })().catch(e=>{z37WarReady=null;throw e});
 return z37WarReady;
}



