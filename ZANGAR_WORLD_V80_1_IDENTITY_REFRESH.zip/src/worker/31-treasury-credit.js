// UPDATE 45: stable reward tiers, rate/credit configuration and authenticated treasury mint.
async function z45LoanConfig(db){
 const rows=await db.prepare("SELECT key,value FROM site_settings WHERE key IN ('z45_loan_open','z45_loan_max')").all();
 const settings=Object.fromEntries((rows.results||[]).map(x=>[x.key,x.value]));
 return {open:settings.z45_loan_open!=='0',max:Math.min(1000000,Math.max(3000,Number(settings.z45_loan_max)||25000))};
}
let z45Ready=null;
async function z45Ensure(db){
 if(z45Ready)return z45Ready;
 z45Ready=(async()=>{
  const migrated=await db.prepare("SELECT value FROM site_settings WHERE key='z45_migrated'").first();
  if(migrated?.value==='1'){
   const check=await db.prepare("SELECT COUNT(*) AS n FROM sqlite_master WHERE type='trigger' AND name IN ('z43_war_reward','z43_radar_reward','z45_treasury_topups_apply')").first();
   const legacy=await db.prepare("SELECT name FROM sqlite_master WHERE type='trigger' AND name='z37_war_payout_apply' LIMIT 1").first();
   if(Number(check?.n)===3&&!legacy)return;
  }
  await db.batch([
    db.prepare('CREATE TABLE IF NOT EXISTS z45_treasury_topups(id TEXT PRIMARY KEY,amount INTEGER NOT NULL CHECK(amount>0 AND amount<=10000000),reason TEXT NOT NULL,actor TEXT NOT NULL,created_at INTEGER NOT NULL)'),
    db.prepare('DROP TRIGGER IF EXISTS z45_treasury_topups_apply'),
    db.prepare(`CREATE TRIGGER z45_treasury_topups_apply AFTER INSERT ON z45_treasury_topups BEGIN
      UPDATE z_state_treasury SET balance=balance+NEW.amount WHERE id=1;
      INSERT INTO z_state_ledger(id,delta,reason,actor,created_at) VALUES(lower(hex(randomblob(16))),NEW.amount,'دعم رئاسي لخزينة الدولة: '||NEW.reason,NEW.actor,NEW.created_at);
    END`),
    db.prepare('DROP TRIGGER IF EXISTS z37_war_payout_apply'),
    db.prepare('DROP TRIGGER IF EXISTS z43_war_reward'),
    db.prepare(`CREATE TRIGGER z43_war_reward AFTER INSERT ON z37_war_payouts WHEN NEW.battle_id NOT LIKE 'radar-%' BEGIN
      INSERT OR IGNORE INTO z43_war_rewards(event_id,kind,treasury_added,citizen_added,leader_added,created_at)
      SELECT NEW.battle_id,'battle',CASE (CASE WHEN b.target='home' THEN b.attacker ELSE b.target END) WHEN 'oasis' THEN 30000 WHEN 'mountains' THEN 36000 WHEN 'falcons' THEN 43200 WHEN 'islands' THEN 51840 WHEN 'sands' THEN 62208 ELSE 0 END,CASE (CASE WHEN b.target='home' THEN b.attacker ELSE b.target END) WHEN 'oasis' THEN 2000 WHEN 'mountains' THEN 2400 WHEN 'falcons' THEN 2880 WHEN 'islands' THEN 3456 WHEN 'sands' THEN 4147 ELSE 0 END,
       CASE WHEN NEW.actor_id IS NULL THEN 0 ELSE CASE (CASE WHEN b.target='home' THEN b.attacker ELSE b.target END) WHEN 'oasis' THEN 5000 WHEN 'mountains' THEN 6000 WHEN 'falcons' THEN 7200 WHEN 'islands' THEN 8640 WHEN 'sands' THEN 10368 ELSE 0 END END,NEW.created_at
      FROM z33_battles b WHERE b.id=NEW.battle_id AND b.result IN ('victory','defended');
      UPDATE z_state_treasury SET balance=balance+(SELECT treasury_added FROM z43_war_rewards WHERE event_id=NEW.battle_id) WHERE id=1;
      INSERT INTO z_state_ledger(id,delta,reason,actor,created_at)
       SELECT lower(hex(randomblob(16))),treasury_added,'مكافأة انتصار حرب Update 45','نظام الحروب',NEW.created_at FROM z43_war_rewards WHERE event_id=NEW.battle_id;
      UPDATE users SET points=points+(SELECT citizen_added FROM z43_war_rewards WHERE event_id=NEW.battle_id);
      INSERT INTO transactions(id,user_id,amount,note,created_at)
       SELECT lower(hex(randomblob(16))),u.id,r.citizen_added,'مكافأة انتصار حرب Update 45',NEW.created_at FROM users u JOIN z43_war_rewards r ON r.event_id=NEW.battle_id WHERE r.citizen_added>0;
      UPDATE users SET points=points+(SELECT leader_added FROM z43_war_rewards WHERE event_id=NEW.battle_id) WHERE id=NEW.actor_id;
      INSERT INTO transactions(id,user_id,amount,note,created_at)
       SELECT lower(hex(randomblob(16))),NEW.actor_id,leader_added,'مكافأة قيادة حرب Update 45',NEW.created_at FROM z43_war_rewards WHERE event_id=NEW.battle_id AND leader_added>0;
      INSERT OR IGNORE INTO z_notifications(id,user_id,title,body,kind,created_at)
       SELECT 'z45-victory-'||NEW.battle_id||'-'||u.id,u.id,'🏆 انتصار دولة الزنجر',
       'مكافأة انتصار: '||r.citizen_added||' زنجر'||CASE WHEN u.id=NEW.actor_id THEN '، وقيادة المعركة +'||r.leader_added ELSE '' END||' · خزينة الدولة +'||r.treasury_added,
       'war',NEW.created_at FROM users u JOIN z43_war_rewards r ON r.event_id=NEW.battle_id;
    END`),
    db.prepare('DROP TRIGGER IF EXISTS z43_radar_reward'),
    db.prepare(`CREATE TRIGGER z43_radar_reward AFTER INSERT ON z37_war_payouts WHEN NEW.battle_id LIKE 'radar-%' BEGIN
      INSERT OR IGNORE INTO z43_war_rewards(event_id,kind,treasury_added,leader_added,created_at)
       VALUES(NEW.battle_id,'radar',5000,CASE WHEN NEW.actor_id IS NULL THEN 0 ELSE 3000 END,NEW.created_at);
      UPDATE z_state_treasury SET balance=balance+5000 WHERE id=1;
      INSERT INTO z_state_ledger(id,delta,reason,actor,created_at)
       VALUES(lower(hex(randomblob(16))),5000,'مكافأة صد صاروخ افتراضي ناجح','رادار الدولة',NEW.created_at);
      UPDATE users SET points=points+3000 WHERE id=NEW.actor_id;
      INSERT INTO transactions(id,user_id,amount,note,created_at)
       SELECT lower(hex(randomblob(16))),NEW.actor_id,3000,'مكافأة اعتراض صاروخ افتراضي Update 45',NEW.created_at WHERE NEW.actor_id IS NOT NULL;
      INSERT OR IGNORE INTO z_notifications(id,user_id,title,body,kind,created_at)
       SELECT 'z45-radar-'||NEW.battle_id,NEW.actor_id,'🛡️ صد صاروخ ناجح','تم إضافة 3,000 زنجر لك و5,000 زنجر لخزينة الدولة','war',NEW.created_at WHERE NEW.actor_id IS NOT NULL;
    END`),
    db.prepare('DROP TRIGGER IF EXISTS z43_finance_transactions'),
    db.prepare(`CREATE TRIGGER z43_finance_transactions AFTER INSERT ON transactions
      WHEN NEW.note NOT LIKE 'مكافأة انتصار Update 43%'
      AND NEW.note NOT LIKE 'قرار رئاسي خاص%'
      AND NEW.note NOT LIKE 'تحويل خاص%'
      AND NEW.note NOT LIKE 'تحويل من توفير القيادة%'
      AND NEW.note NOT LIKE 'مكافأة الرئاسة%'
      AND NEW.note NOT LIKE 'مكافأة خاصة للرئاسة%'
      AND NEW.note NOT LIKE 'مكافأة تنفيذ أو صد حرب%'
      BEGIN INSERT OR IGNORE INTO z_notifications(id,user_id,title,body,kind,created_at)
      SELECT 'z43-fin-tx-'||NEW.id||'-'||fm.id,fm.id,'💰 حركة مالية',
       CASE WHEN NEW.note LIKE 'تحويل إلى %' THEN 'المرسل: '||COALESCE(owner.name,'مواطن')||' · المستلم: '||SUBSTR(NEW.note,11)||' · المبلغ: '||ABS(NEW.amount)||' زنجر'
        WHEN NEW.note LIKE 'تحويل من %' THEN 'المرسل: '||SUBSTR(NEW.note,10)||' · المستلم: '||COALESCE(owner.name,'مواطن')||' · المبلغ: '||ABS(NEW.amount)||' زنجر'
        ELSE 'المواطن: '||COALESCE(owner.name,'مواطن')||' · المبلغ: '||CASE WHEN NEW.amount>0 THEN '+' ELSE '' END||NEW.amount||' زنجر · السبب: '||SUBSTR(NEW.note,1,105) END,
       'money',NEW.created_at FROM users fm LEFT JOIN users owner ON owner.id=NEW.user_id WHERE fm.job='وزير المالية'; END`),
    db.prepare('DROP TRIGGER IF EXISTS z43_finance_treasury'),
    db.prepare(`CREATE TRIGGER z43_finance_treasury AFTER INSERT ON z_state_ledger
      WHEN NEW.reason NOT LIKE 'دعم رئاسي لخزينة الدولة%' AND NEW.reason NOT LIKE 'صد صاروخ سري%'
       AND NEW.reason NOT LIKE 'تحويل خاص%' AND NEW.reason NOT LIKE 'مكافأة خاصة%'
       AND NEW.reason NOT LIKE 'مكافأة الرئاسة%' BEGIN
       INSERT OR IGNORE INTO z_notifications(id,user_id,title,body,kind,created_at)
       SELECT 'z43-fin-ledger-'||NEW.id||'-'||fm.id,fm.id,'🏦 حركة خزينة الدولة',
       CASE WHEN NEW.delta>=0 THEN '+' ELSE '' END||NEW.delta||' زنجر · السبب: '||SUBSTR(NEW.reason,1,115)||' · بواسطة '||COALESCE(NEW.actor,'النظام'),
       'money',NEW.created_at FROM users fm WHERE fm.job='وزير المالية'; END`),
    db.prepare('DROP TRIGGER IF EXISTS z43_notifications_push'),
    db.prepare(`CREATE TRIGGER z43_notifications_push AFTER INSERT ON z_notifications BEGIN
      INSERT OR IGNORE INTO z_push_outbox(id,dedupe,endpoint,user_id,kind,title,body,url,created_at)
      SELECT lower(hex(randomblob(16))),NEW.id,s.endpoint,s.user_id,NEW.kind,NEW.title,NEW.body,
       CASE WHEN NEW.id LIKE 'z44-loan-%' OR NEW.id LIKE 'z44-collected-%' THEN '/loans44.html' WHEN NEW.kind='war' THEN '/war.html'
        WHEN NEW.kind='money' THEN '/#/notifications' WHEN NEW.kind='chat' THEN '/#/chat' ELSE '/#/notifications' END,NEW.created_at
      FROM z_push_subscriptions s LEFT JOIN z_push_prefs pp ON pp.user_id=s.user_id
      WHERE s.user_id=NEW.user_id AND COALESCE(CASE WHEN NEW.kind='war' THEN pp.war WHEN NEW.kind='money' THEN pp.money
       WHEN NEW.kind='chat' THEN pp.chat WHEN NEW.kind='government' THEN pp.government ELSE pp.system END,1)=1;
    END`),
    db.prepare("INSERT INTO site_settings(key,value,updated_at) VALUES('z45_migrated','1',?) ON CONFLICT(key) DO UPDATE SET value=excluded.value,updated_at=excluded.updated_at").bind(Date.now())
  ]);
 })().catch(e=>{z45Ready=null;throw e});return z45Ready;
}

