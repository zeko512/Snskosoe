// V72 — add-only migration, server authoritative rewards, notifications, orphan cleanup.
// DO NOT remove archived account audit rows, financial ledgers, or valid current accounts.
let z72Ready=null;
async function z72CleanOneArchived(db,userId){
  const gone=await db.prepare('SELECT 1 FROM z64_archived_users WHERE user_id=? AND restored_at=0').bind(userId).first();
  if(!gone)return;
  await db.batch([
    db.prepare('DELETE FROM z_homes WHERE user_id=?').bind(userId),
    db.prepare('DELETE FROM z_furniture WHERE user_id=?').bind(userId),
    db.prepare('DELETE FROM z42_presence WHERE user_id=?').bind(userId),
    db.prepare('DELETE FROM z_push_subscriptions WHERE user_id=?').bind(userId),
    db.prepare('DELETE FROM z_push_prefs WHERE user_id=?').bind(userId),
    db.prepare('DELETE FROM z71'+'1_code_entitlements WHERE user_id=?').bind(userId)
  ]);
}
async function z72Ensure(db){
 if(z72Ready)return z72Ready;
 z72Ready=(async()=>{
  // All archived accounts stay archived; physically purge only residential data and stale push subscriptions.
  const existing=await db.prepare("SELECT value FROM site_settings WHERE key='z72_migrated'").first();
  if(existing?.value==='1')return;
  const q=[
   `DROP TRIGGER IF EXISTS z660_air_shot_apply`,
   `CREATE TRIGGER z660_air_shot_apply AFTER INSERT ON z660_air_shots BEGIN
      -- The launcher pays 500. On a successful interception they receive 1500; on miss another 600 is charged.
      -- Negative wallet amounts remain represented as durable z660_air_debts, retaining the legacy wallet CHECK(points>=0).
      INSERT INTO z660_air_debts(user_id,amount)
       SELECT NEW.user_id,MAX(0,CASE WHEN NEW.hit=0 THEN 1100 ELSE 0 END-u.points)
        FROM users u WHERE u.id=NEW.user_id
       ON CONFLICT(user_id) DO UPDATE SET amount=amount+excluded.amount;
      UPDATE users SET points=CASE WHEN NEW.hit=1 THEN points+1000 ELSE MAX(0,points-1100) END WHERE id=NEW.user_id;
      INSERT INTO transactions(id,user_id,amount,note,created_at)
       VALUES(lower(hex(randomblob(16))),NEW.user_id,-500,'الدفاع الجوي: تكلفة إطلاق الصاروخ',NEW.created_at);
      INSERT INTO transactions(id,user_id,amount,note,created_at)
       SELECT lower(hex(randomblob(16))),NEW.user_id,1500,'الدفاع الجوي: مكافأة اعتراض ناجح',NEW.created_at WHERE NEW.hit=1;
      INSERT INTO transactions(id,user_id,amount,note,created_at)
       SELECT lower(hex(randomblob(16))),NEW.user_id,-600,'الدفاع الجوي: غرامة إخفاق',NEW.created_at WHERE NEW.hit=0;
      UPDATE z659_air_tracks SET status='intercepted',resolved_by=NEW.user_id,resolved_at=NEW.created_at
       WHERE id=NEW.target_id AND NEW.hit=1;
      UPDATE z_state_treasury SET balance=balance+3000 WHERE id=1 AND NEW.hit=1;
      INSERT INTO z_state_ledger(id,delta,reason,actor,created_at)
       SELECT lower(hex(randomblob(16))),3000,'مكافأة نجاح الدفاع الجوي','نظام الدفاع الجوي',NEW.created_at WHERE NEW.hit=1;
      -- ONLY present, active citizens (presence heartbeat within 90 seconds), not archived/deleted accounts.
      UPDATE users SET points=points+500
       WHERE NEW.hit=1 AND EXISTS(SELECT 1 FROM z42_presence p WHERE p.user_id=users.id AND p.active=1 AND p.last_seen BETWEEN NEW.created_at-90000 AND NEW.created_at+1000)
       AND NOT EXISTS(SELECT 1 FROM z64_archived_users ax WHERE ax.user_id=users.id AND ax.restored_at=0);
      INSERT INTO transactions(id,user_id,amount,note,created_at)
       SELECT lower(hex(randomblob(16))),u.id,500,'مكافأة مواطن نشط لاعتراض ناجح',NEW.created_at
       FROM users u JOIN z42_presence p ON p.user_id=u.id AND p.active=1 AND p.last_seen BETWEEN NEW.created_at-90000 AND NEW.created_at+1000
       WHERE NEW.hit=1 AND NOT EXISTS(SELECT 1 FROM z64_archived_users ax WHERE ax.user_id=u.id AND ax.restored_at=0);
      INSERT OR IGNORE INTO z_notifications(id,user_id,title,body,kind,created_at)
       SELECT 'z72-air-citizen-'||NEW.id||'-'||u.id,u.id,'🛡️ مكافأة حماية الدولة',
       'اعتراض ناجح — حصلت على 500 زنجر لأنك كنت حاضرًا وقت الاعتراض.','money',NEW.created_at
       FROM users u JOIN z42_presence p ON p.user_id=u.id AND p.active=1
        AND p.last_seen BETWEEN NEW.created_at-90000 AND NEW.created_at+1000
       WHERE NEW.hit=1 AND NOT EXISTS(SELECT 1 FROM z64_archived_users a WHERE a.user_id=u.id AND a.restored_at=0);
      INSERT OR IGNORE INTO z_notifications(id,user_id,title,body,kind,created_at)
       VALUES('z72-air-action-'||NEW.id,NEW.user_id,
         CASE WHEN NEW.hit=1 THEN '🎯 اعتراض ناجح' ELSE '⚠️ فشل الاعتراض' END,
         CASE WHEN NEW.hit=1 THEN 'مكافأة مطلق الصاروخ +1500؛ تكلفة الإطلاق -500؛ الخزينة +3000.'
              ELSE 'تكلفة الإطلاق -500 وغرامة إخفاق إضافية -600 زنجر.' END,'war',NEW.created_at);
    END`,
   'DROP TRIGGER IF EXISTS z43_grant_alert',
   `CREATE TRIGGER z43_grant_alert AFTER INSERT ON z43_grant_notified BEGIN
      INSERT OR IGNORE INTO z_notifications(id,user_id,title,body,kind,created_at)
      VALUES('z43-grant-'||NEW.user_id||'-'||NEW.claim_at,NEW.user_id,'🪙 المنحة جاهزة للاستلام',
      'المنحة جاهزة للاستلام — حتى 500 زنجر. افتح الصفحة الرئيسية واستلمها.','money',NEW.created_at);
    END`,
   'DROP TRIGGER IF EXISTS z43_notifications_push',
   `CREATE TRIGGER z43_notifications_push AFTER INSERT ON z_notifications BEGIN
     INSERT OR IGNORE INTO z_push_outbox(id,dedupe,endpoint,user_id,kind,title,body,url,created_at)
     SELECT lower(hex(randomblob(16))),NEW.id,s.endpoint,s.user_id,NEW.kind,NEW.title,NEW.body,
       CASE WHEN NEW.kind='war' THEN '/air-defense.html'
            WHEN NEW.kind='money' THEN '/#/bank' WHEN NEW.kind IN ('job','jobs') THEN '/#/companies'
            WHEN NEW.kind='chat' THEN '/#/chat' WHEN NEW.kind IN ('market','property','trade') THEN '/#/market-pro'
            ELSE '/#/notifications' END,NEW.created_at
     FROM z_push_subscriptions s LEFT JOIN z_push_prefs pp ON pp.user_id=s.user_id
     WHERE s.user_id=NEW.user_id AND NOT EXISTS(SELECT 1 FROM z64_archived_users ax WHERE ax.user_id=s.user_id AND ax.restored_at=0)
       AND COALESCE(CASE WHEN NEW.kind='war' THEN pp.war WHEN NEW.kind='money' THEN pp.money
         WHEN NEW.kind='chat' THEN pp.chat WHEN NEW.kind IN ('job','jobs') THEN pp.jobs
         WHEN NEW.kind IN ('market','trade','property') THEN pp.market
         WHEN NEW.kind IN ('government','fine') THEN pp.government
         WHEN NEW.kind='social' THEN pp.social ELSE pp.system END,1)=1;
   END`,
   `CREATE TRIGGER IF NOT EXISTS z72_fine_notice AFTER INSERT ON transactions
    WHEN NEW.amount<0 AND (NEW.note LIKE '%غرامة%' OR NEW.note LIKE '%مخالفة%')
    BEGIN
      INSERT OR IGNORE INTO z_notifications(id,user_id,title,body,kind,created_at)
       VALUES('z72-fine-'||NEW.id,NEW.user_id,'⚖️ تم تسجيل غرامة على حسابك',
        'المبلغ: '||NEW.amount||' زنجر. السبب: '||SUBSTR(NEW.note,1,130),'government',NEW.created_at);
    END`,
   `CREATE TRIGGER IF NOT EXISTS z72_stock_rise AFTER UPDATE OF price ON z_stock_state
    WHEN NEW.price>=OLD.price*1.08 AND NEW.price>OLD.price
    BEGIN
      INSERT OR IGNORE INTO z_notifications(id,user_id,title,body,kind,created_at)
       SELECT 'z72-stock-'||NEW.symbol||'-'||CAST(NEW.updated_at/3600000 AS INT)||'-'||s.user_id,
         s.user_id,'📈 ارتفاع في بورصة زنجر',
         'سهم '||NEW.symbol||' ارتفع من '||OLD.price||' إلى '||NEW.price||' زنجر.',
         'market',NEW.updated_at
       FROM econ_shares s JOIN users u ON u.id=s.user_id
       WHERE s.symbol=NEW.symbol AND s.quantity>0
         AND NOT EXISTS(SELECT 1 FROM z64_archived_users ax WHERE ax.user_id=s.user_id AND ax.restored_at=0);
    END`,
   `CREATE TRIGGER IF NOT EXISTS z72_incoming_missile AFTER INSERT ON z659_air_tracks
    WHEN NEW.status='incoming'
    BEGIN
      INSERT OR IGNORE INTO z_notifications(id,user_id,title,body,kind,created_at)
       SELECT 'z72-missile-'||CAST(NEW.started_at/300000 AS INT)||'-'||s.user_id,
       s.user_id,'🚀 هناك صاروخ يقترب',
       'السبب: رصد هدف جوي قادم على رادار الدفاع. افتح الرادار لمعرفة الحالة.','war',NEW.started_at
       FROM z_push_subscriptions s JOIN users u ON u.id=s.user_id
       LEFT JOIN z_push_prefs p ON p.user_id=s.user_id
       WHERE COALESCE(p.war,1)=1 AND NOT EXISTS(SELECT 1 FROM z64_archived_users ax WHERE ax.user_id=s.user_id AND ax.restored_at=0);
    END`,
   'DELETE FROM z_homes WHERE user_id NOT IN (SELECT id FROM users) OR user_id IN (SELECT user_id FROM z64_archived_users WHERE restored_at=0)',
   'DELETE FROM z_furniture WHERE user_id NOT IN (SELECT id FROM users) OR user_id IN (SELECT user_id FROM z64_archived_users WHERE restored_at=0)',
   'DELETE FROM z_push_subscriptions WHERE user_id NOT IN (SELECT id FROM users) OR user_id IN (SELECT user_id FROM z64_archived_users WHERE restored_at=0)',
   "INSERT OR REPLACE INTO site_settings(key,value,updated_at) VALUES('z72_migrated','1',strftime('%s','now')*1000)"
  ];
  await db.batch(q.map(x=>db.prepare(x)));
 })().catch(e=>{z72Ready=null;throw e});
 return z72Ready;
}
async function z72ReminderSweep(db,now=Date.now()){
 // Non-spam reminders. The stable notification id prevents repeated delivery.
 await db.prepare(`INSERT OR IGNORE INTO z_notifications(id,user_id,title,body,kind,created_at)
   SELECT 'z72-rent-'||r.id,r.tenant_id,'🏠 إيجار مستحق قريبًا',
   'إيجار العقار المستأجر يقترب موعد انتهائه. راجع قسم العقارات.', 'property',?
   FROM z_property_rentals r JOIN users u ON u.id=r.tenant_id
   WHERE r.rent_until BETWEEN ? AND ?
    AND NOT EXISTS(SELECT 1 FROM z64_archived_users ax WHERE ax.user_id=r.tenant_id AND ax.restored_at=0)
   LIMIT 200`).bind(now,now,now+7200000).run();
}

