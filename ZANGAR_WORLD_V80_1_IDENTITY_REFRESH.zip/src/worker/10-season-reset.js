// Update 39: deliberate one-time season reset; NEVER runs during deployment or schema initialization.
const Z39_PRESIDENT_HASH='c8d0e97195d8c22a5f47630eea87f7198f7840e1c2e873d41a2064ef5041e60f';
let z39SchemaReady=null;
async function z39Ensure(db){
 if(z39SchemaReady)return z39SchemaReady;
 z39SchemaReady=(async()=>{
  await db.batch([
   db.prepare("CREATE TABLE IF NOT EXISTS z39_season_meta(id INTEGER PRIMARY KEY CHECK(id=1),season INTEGER NOT NULL DEFAULT 1,started_at INTEGER NOT NULL DEFAULT 0,started_by TEXT NOT NULL DEFAULT '')"),
   db.prepare('CREATE TABLE IF NOT EXISTS z39_war_wins(payout_id TEXT PRIMARY KEY,seq INTEGER NOT NULL,created_at INTEGER NOT NULL)'),
   db.prepare('CREATE TABLE IF NOT EXISTS z39_reset_audit(id TEXT PRIMARY KEY,admin_id TEXT NOT NULL,started_at INTEGER NOT NULL,accounts INTEGER NOT NULL,description TEXT NOT NULL)'),
   db.prepare('CREATE TABLE IF NOT EXISTS z39_president_grants(user_id TEXT PRIMARY KEY,created_at INTEGER NOT NULL)'),
   db.prepare('CREATE TABLE IF NOT EXISTS z39_reset_guard(id INTEGER PRIMARY KEY CHECK(id=1),started_at INTEGER NOT NULL)'),
   db.prepare('INSERT OR IGNORE INTO z39_season_meta(id) VALUES(1)')
  ]);
 })().catch(e=>{z39SchemaReady=null;throw e});return z39SchemaReady;
}
let z39WarUpgraded=false;
async function z39WarUpgrade(db){
 if(z39WarUpgraded)return;
 // Newer season payout takes precedence; never reinstall legacy 800k / 30% trigger.
 const current=await db.prepare("SELECT value FROM site_settings WHERE key='z45_migrated'").first();
 if(current?.value==='1'){z39WarUpgraded=true;return;}
 await z39Ensure(db);await z38WarEnsure(db);
 const meta=await db.prepare('SELECT season FROM z39_season_meta WHERE id=1').first();if(Number(meta?.season)!==2)return;
 const flag=await db.prepare("SELECT value FROM site_settings WHERE key='u39_war_payout_upgraded'").first();if(flag?.value==='1'){z39WarUpgraded=true;return;}
 // Atomic replacement of the old 800,000-coin award schedule.
 await db.batch([
  db.prepare('DROP TRIGGER IF EXISTS z37_war_payout_apply'),
  db.prepare(`CREATE TRIGGER z37_war_payout_apply AFTER INSERT ON z37_war_payouts BEGIN
    INSERT OR IGNORE INTO z39_war_wins(payout_id,seq,created_at) VALUES(NEW.battle_id,(SELECT COUNT(*)+1 FROM z39_war_wins),NEW.created_at);
    UPDATE z_state_treasury SET balance=balance+CAST(((SELECT seq FROM z39_war_wins WHERE payout_id=NEW.battle_id)*1000)*.30 AS INTEGER)+CASE WHEN (SELECT COUNT(*) FROM users)=0 THEN CAST((SELECT seq*1000 FROM z39_war_wins WHERE payout_id=NEW.battle_id)*.70 AS INTEGER) ELSE CAST((SELECT seq*1000 FROM z39_war_wins WHERE payout_id=NEW.battle_id)*.70 AS INTEGER) % (SELECT COUNT(*) FROM users) END WHERE id=1;
    INSERT INTO z_state_ledger(id,delta,reason,actor,created_at) VALUES(lower(hex(randomblob(16))),CAST((SELECT seq*1000 FROM z39_war_wins WHERE payout_id=NEW.battle_id)*.30 AS INTEGER)+CASE WHEN (SELECT COUNT(*) FROM users)=0 THEN CAST((SELECT seq*1000 FROM z39_war_wins WHERE payout_id=NEW.battle_id)*.70 AS INTEGER) ELSE CAST((SELECT seq*1000 FROM z39_war_wins WHERE payout_id=NEW.battle_id)*.70 AS INTEGER) % (SELECT COUNT(*) FROM users) END,'30% للخزينة مع بواقي التقسيم','النظام',NEW.created_at);
    UPDATE users SET points=points+CAST(((SELECT seq*1000 FROM z39_war_wins WHERE payout_id=NEW.battle_id)*.70)/(SELECT COUNT(*) FROM users) AS INTEGER) WHERE (SELECT COUNT(*) FROM users)>0;
    INSERT INTO transactions(id,user_id,amount,note,created_at) SELECT lower(hex(randomblob(16))),id,CAST(((SELECT seq*1000 FROM z39_war_wins WHERE payout_id=NEW.battle_id)*.70)/(SELECT COUNT(*) FROM users) AS INTEGER),'70% مكافأة انتصار الموسم الثاني موزعة على المواطنين',NEW.created_at FROM users WHERE (SELECT COUNT(*) FROM users)>0;
  END`),
  db.prepare("INSERT OR REPLACE INTO site_settings(key,value,updated_at) VALUES('u39_war_payout_upgraded','1',?)").bind(Date.now())
 ]); z39WarUpgraded=true;
}
// U40: resumable D1-safe season transition. Each request clears at most 10 tables.
// Do not send >100 SQL statements in one D1 batch as in v39, which may hit Worker D1 limits.
let z40SchemaReady=null;
async function z40Ensure(db){
 if(z40SchemaReady)return z40SchemaReady;
 z40SchemaReady=db.prepare("CREATE TABLE IF NOT EXISTS z40_reset_progress(id INTEGER PRIMARY KEY CHECK(id=1),admin_id TEXT NOT NULL,started_at INTEGER NOT NULL,phase TEXT NOT NULL,tables_json TEXT NOT NULL,next_idx INTEGER NOT NULL DEFAULT 0,old_maintenance TEXT NOT NULL DEFAULT '0',finished_at INTEGER NOT NULL DEFAULT 0)").run().catch(e=>{z40SchemaReady=null;throw e});
 return z40SchemaReady;
}
const Z40_KEEP_TABLES=new Set(['users','sessions','site_settings','admin_grants','z39_president_grants','z39_reset_guard','z40_reset_progress','z34_head_owner','z37_sovereign_owner','chat_rooms','chat_members','chat_messages','z_chat_voice','z_chat_images','z_chat_room_prefs','z_push_subscriptions','z_push_preferences','z39_season_meta','z39_reset_audit','maintenance_attempts','admin_unlock_attempts','z639_guest_slots','z639_attempts','z711_code_entitlements']);
const Z40_RESET_BASE=new Set(['transactions','activity','applications','cases','cards','votes','announcements','telecom_reviews','department_grants','department_attempts','police_grants','police_unlock_attempts','grant_penalties','suspensions','prison_requests','z39_war_wins']);
const Z40_RESET_KEEP_DATA=new Set(['z_state_treasury','z33_countries','z33_military','z38_billing_config','z_war_state','z36_edu_config']);
function z40ResetTableName(n){return /^[a-z_][a-z0-9_]*$/.test(n)&&!Z40_KEEP_TABLES.has(n)&&!Z40_RESET_KEEP_DATA.has(n)&&(/^(econ_|z33_|z34_|z35_|z36_|z37_|z38_|z_)/.test(n)||Z40_RESET_BASE.has(n));}
async function z40Progress(db){await z40Ensure(db);return db.prepare('SELECT * FROM z40_reset_progress WHERE id=1').first()}
async function z40ResetIsActive(db){const r=await z40Progress(db);return !!(r&&r.phase==='clearing'||r&&r.phase==='finalizing');}
// U41: the long presidential code is verified once by /api/admin/unlock.
// Season reset uses the authenticated presidential account plus a short-lived,
// session-bound confirmation token: never ask mobile users to retype the long code.
const Z41_BUILD='1.64.0';
async function z41ResetToken(req,slot=Math.floor(Date.now()/600000)){
 const session=cookieValue(req,'zangar_session');
 if(!/^[a-f0-9]{64}$/.test(session))return '';
 return digest('zangar-season-2-confirm-v41|'+session+'|'+slot);
}
async function z41ValidResetToken(req,value){
 if(typeof value!=='string'||!/^[a-f0-9]{64}$/.test(value))return false;
 const slot=Math.floor(Date.now()/600000);
 return eqSecure(value,await z41ResetToken(req,slot))||eqSecure(value,await z41ResetToken(req,slot-1));
}
async function z39SeasonStatus(req,db){
 await z39Ensure(db);const u=await getMe(req,db),meta=await db.prepare('SELECT * FROM z39_season_meta WHERE id=1').first();const season=Number(meta?.season||1),authorized=isAdmin(u);
 let progress=null,accounts=null;
 if(authorized){const r=await z40Progress(db);if(r){const len=JSON.parse(r.tables_json).length;progress={phase:r.phase,cleared:r.next_idx,total:len,started_at:r.started_at,can_resume:r.admin_id===u.id};}const c=await db.prepare('SELECT COUNT(*) AS n FROM users WHERE NOT EXISTS (SELECT 1 FROM z64_archived_users ax WHERE ax.user_id=users.id AND ax.restored_at=0)').first();accounts=Number(c?.n||0);}
 return json({version:Z41_BUILD,season,started_at:Number(meta?.started_at||0),authorized,can_reset:authorized&&season!==2,accounts,progress,reset_token:authorized?await z41ResetToken(req):null,notice:'تصفير الموسم محفوظ على مراحل؛ الأسماء والحسابات والشات محفوظة والتأكيد منفصل'});
}
async function z40SeasonReset(req,db,p){
 // Safety lockdown: both starting and resuming destructive resets are disabled.
 return err(423,'حماية بيانات المواطنين: التصفير موقوف تمامًا. لا يتم مسح الأرصدة أو الحسابات عند تحديث الموقع.');
 await z39Ensure(db);await z40Ensure(db);
 const u=await getMe(req,db);if(!u||!isAdmin(u))return err(403,'سجل الدخول ثم افتح الرئاسة بالكود الجديد من آخر الصفحة الرئيسية');
 if(!await z41ValidResetToken(req,p.reset_token))return err(403,'انتهت جلسة تأكيد التصفير أو الصفحة قديمة؛ حدّث صفحة الموسم الثاني، وتأكد أن إصدار السيرفر 1.41.0');
 const meta=await db.prepare('SELECT season FROM z39_season_meta WHERE id=1').first();if(Number(meta?.season)===2)return err(409,'تم بدء الموسم الثاني بالفعل، والتصفير مقفل ولن يتكرر');
 const now=Date.now();let current=await z40Progress(db),step=String(p.step||'start');
 if(!current){
  return err(423,'حماية حسابات المواطنين: تم إيقاف بدء أي تصفير جديد للمواسم. لا يتم تغيير أرصدة المواطنين عند تحديث الموقع.');
  if(step!=='start')return err(409,'ابدأ عملية التصفير أولًا بعد عمل نسخة احتياطية');
  if(p.confirm!=='بدء الموسم الثاني'||p.backup_confirmed!==true)return err(400,'أكّد أخذ نسخة D1 احتياطية واكتب عبارة بدء الموسم الثاني حرفيًا');
  // Old v39 attempted a single huge D1 batch. If its guard exists, do not risk a second reset.
  const oldGuard=await db.prepare('SELECT started_at FROM z39_reset_guard WHERE id=1').first();if(oldGuard)return err(409,'توجد محاولة تصفير قديمة غير مكتملة. يلزم مراجعة قاعدة D1 قبل الإعادة للحفاظ على بيانات المواطنين');
  // Complete related schemas before starting maintenance and irreversible deletion.
  await z33Ensure(db);await z38BillEnsure(db);await z37AccessEnsure(db);await z36EducationEnsure(db);
  const tables=await db.prepare("SELECT name FROM sqlite_master WHERE type='table' AND name NOT LIKE 'sqlite_%' ORDER BY name").all();
  const pending=tables.results.map(x=>x.name).filter(z40ResetTableName);
  const old=await stateSettingGet(db,'maintenance','0');
  // Atomic checkpoint plus downtime gate; a failed start makes no changes.
  await db.batch([
   db.prepare('INSERT INTO z39_reset_guard(id,started_at) VALUES(1,?)').bind(now),
   db.prepare("INSERT INTO z40_reset_progress(id,admin_id,started_at,phase,tables_json,next_idx,old_maintenance) VALUES(1,?,?,'clearing',?,0,?)").bind(u.id,now,JSON.stringify(pending),old),
   db.prepare("INSERT INTO site_settings(key,value,updated_at) VALUES('maintenance','1',?) ON CONFLICT(key) DO UPDATE SET value='1',updated_at=excluded.updated_at").bind(now)
  ]);
  z32PublicCache.clear();current=await z40Progress(db);
  return json({ok:true,done:false,phase:'clearing',cleared:0,total:pending.length,notice:'تم حفظ نقطة بداية التصفير وإيقاف معاملات الدولة مؤقتًا'});
 }
 if(current.admin_id!==u.id)return err(403,'استكمال التصفير يكون من نفس الحساب الرئاسي الذي بدأ العملية');
 if(step!=='continue')return err(409,'التصفير بدأ بالفعل. استخدم استكمال التصفير؛ لا تبدأ عملية جديدة');
 const tables=JSON.parse(current.tables_json),idx=Number(current.next_idx||0);
 if(current.phase==='clearing'&&idx<tables.length){
  const chunk=tables.slice(idx,idx+10);
  if(!chunk.every(z40ResetTableName))return err(500,'يوجد اسم جدول غير معتمد في سجل التصفير');
  // Each batch commits its deletion and progress position in a single D1 transaction.
  await db.batch([...chunk.map(t=>db.prepare('DELETE FROM '+t)),db.prepare("UPDATE z40_reset_progress SET next_idx=? WHERE id=1 AND phase='clearing' AND next_idx=?").bind(idx+chunk.length,idx)]);
  return json({ok:true,done:false,phase:'clearing',cleared:idx+chunk.length,total:tables.length});
 }
 if(current.phase!=='clearing'&&current.phase!=='finalizing')return err(409,'حالة التصفير غير متوقعة؛ راجع المسؤول');
 // All tables have been cleared; finalize the reset in one small atomic D1 batch.
 const count=await db.prepare('SELECT COUNT(*) AS n FROM users WHERE NOT EXISTS (SELECT 1 FROM z64_archived_users ax WHERE ax.user_id=users.id AND ax.restored_at=0)').first(),today=Math.floor(now/86400000);
 const present=new Set((await db.prepare("SELECT name FROM sqlite_master WHERE type='table'").all()).results.map(x=>x.name));
 const s=[
  db.prepare("UPDATE users SET points=0,job='مواطن',role='citizen',rank='مواطن',candidate=0,claim_at=0,game_at=0"),
  db.prepare('DELETE FROM admin_grants WHERE user_id NOT IN (SELECT user_id FROM z39_president_grants)'),
  db.prepare("UPDATE users SET role='admin' WHERE id IN (SELECT user_id FROM z39_president_grants)"),
  db.prepare('UPDATE z_state_treasury SET balance=0 WHERE id=1'),
  db.prepare("UPDATE site_settings SET value='0',updated_at=? WHERE key='state_economy_total'").bind(now),
  db.prepare("UPDATE site_settings SET value='[]',updated_at=? WHERE key='state_economy_log'").bind(now),
 ];
 if(present.has('z33_military'))s.push(db.prepare("UPDATE z33_military SET soldiers=0,planes=0,ships=0,missiles=0,air_defense=0,budget=0,last_attack_at=0,last_invasion_at=0,invasion_id='',invasion_country='',invasion_at=0 WHERE id=1"));
 if(present.has('z38_billing_config'))s.push(db.prepare('INSERT OR REPLACE INTO z38_billing_config(id,start_day,created_at) VALUES(1,?,?)').bind(today,now));
 if(present.has('z36_edu_config'))s.push(db.prepare('UPDATE z36_edu_config SET anchor_at=? WHERE id=1').bind(now));
 if(present.has('z_war_state'))s.push(db.prepare('UPDATE z_war_state SET cannon=0,missiles=0,armed=1,protection_until=0,emergency_until=0,last_alert=0,shots_left=0 WHERE id=1'));
 if(present.has('z33_countries'))s.push(...Z33_COUNTRIES.slice(1).map(c=>db.prepare('UPDATE z33_countries SET soldiers=?,planes=?,ships=?,defense=?,treasury=?,difficulty=? WHERE id=?').bind(c[2],c[3],c[4],c[5],c[6],c[7],c[0])));
 s.push(db.prepare('INSERT INTO z39_reset_audit(id,admin_id,started_at,accounts,description) VALUES(?,?,?,?,?)').bind(id(),u.id,now,Number(count?.n||0),'Update 40: تصفير على مراحل مع الحفاظ على الحسابات والهويات والشات'),
 db.prepare('UPDATE z39_season_meta SET season=2,started_at=?,started_by=? WHERE id=1 AND season=1').bind(now,u.id),
 db.prepare("UPDATE site_settings SET value=?,updated_at=? WHERE key='maintenance'").bind(current.old_maintenance,now),
 db.prepare("UPDATE z40_reset_progress SET phase='done',finished_at=? WHERE id=1 AND phase IN ('clearing','finalizing')").bind(now));
 await db.batch(s);z32PublicCache.clear();z38AccruedLocally.clear();
 // Do not turn a COMMITTED reset into a false error because a later payout migration failed.
 try{await z39WarUpgrade(db)}catch(e){console.error('Z40 post-reset war trigger upgrade:',e)}
 return json({ok:true,done:true,phase:'done',season:2,accounts_preserved:Number(count?.n||0),notice:'اكتمل التصفير وبداية الموسم الثاني؛ الحسابات والهويات والشات محفوظة'});
}
// Legacy endpoint supported as a 40-stage alias; the new page orchestrates the stages.
async function z39SeasonReset(req,db,p){return z40SeasonReset(req,db,p)}

