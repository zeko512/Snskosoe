// Update 47 — Federation presidents appointed directly; elections disabled. Existing campaigns and citizen data remain intact.
const Z46_NAMES={home:'دولة الزنجر الجديدة',oasis:'محافظة الواحة',mountains:'محافظة الجبال',falcons:'محافظة الصقور',islands:'محافظة الجزر',sands:'محافظة الرمال',noor:'محافظة النور',barq:'محافظة البرق'};
const Z46_DAILY_FEE=4000;
const Z46_PROJECTS={farm:{name:'مزرعة حكومية',cost:8000,income:500},factory:{name:'مصنع إنتاج',cost:15000,income:1100},port:{name:'مركز تجارة',cost:30000,income:1900}};
const Z46_UNITS={soldiers:{name:'جندي',cost:200},missiles:{name:'صاروخ',cost:1500},planes:{name:'طائرة حربية',cost:1900},ships:{name:'سفينة حربية',cost:2200}};
let z46Ready=null;
async function z46Ensure(db){
 if(z46Ready)return z46Ready;
 z46Ready=(async()=>{
  const ddl=[
   `CREATE TABLE IF NOT EXISTS z46_provinces(id TEXT PRIMARY KEY,name TEXT NOT NULL,treasury INTEGER NOT NULL DEFAULT 100000 CHECK(treasury>=0),economy INTEGER NOT NULL DEFAULT 100000 CHECK(economy>=0),soldiers INTEGER NOT NULL DEFAULT 1000 CHECK(soldiers>=0),missiles INTEGER NOT NULL DEFAULT 10 CHECK(missiles>=0),planes INTEGER NOT NULL DEFAULT 20 CHECK(planes>=0),ships INTEGER NOT NULL DEFAULT 10 CHECK(ships>=0),governor_id TEXT NOT NULL DEFAULT '',last_fee_day INTEGER NOT NULL DEFAULT 0,war_lock_until INTEGER NOT NULL DEFAULT 0)`,
   `CREATE TABLE IF NOT EXISTS z46_missions(id TEXT PRIMARY KEY,user_id TEXT NOT NULL,day INTEGER NOT NULL,task TEXT NOT NULL,amount INTEGER NOT NULL,created_at INTEGER NOT NULL,UNIQUE(user_id,day,task))`,
   `CREATE TRIGGER IF NOT EXISTS z46_mission_reward AFTER INSERT ON z46_missions BEGIN UPDATE users SET points=points+NEW.amount WHERE id=NEW.user_id; INSERT INTO transactions(id,user_id,amount,note,created_at) VALUES(NEW.id,NEW.user_id,NEW.amount,'مكافأة مهمة يومية: '||NEW.task,NEW.created_at); END`,
   `CREATE TABLE IF NOT EXISTS z46_ai_usage(user_id TEXT NOT NULL,day INTEGER NOT NULL,requests INTEGER NOT NULL DEFAULT 0,PRIMARY KEY(user_id,day))`,
   `CREATE TABLE IF NOT EXISTS z46_members(user_id TEXT PRIMARY KEY,province_id TEXT NOT NULL DEFAULT 'home',joined_at INTEGER NOT NULL DEFAULT 0,changed_at INTEGER NOT NULL DEFAULT 0)`,

   `CREATE TABLE IF NOT EXISTS z48_virtual_clock(province_id TEXT PRIMARY KEY,last_slot INTEGER NOT NULL,created_at INTEGER NOT NULL,total_earned INTEGER NOT NULL DEFAULT 0 CHECK(total_earned>=0))`,
   `DROP TRIGGER IF EXISTS z48_virtual_pay`,
   `CREATE TRIGGER z48_virtual_pay AFTER UPDATE OF last_slot ON z48_virtual_clock WHEN NEW.last_slot>OLD.last_slot BEGIN
     UPDATE z46_provinces SET treasury=treasury+(CASE WHEN NEW.province_id='home' THEN (NEW.last_slot-OLD.last_slot)*5000 ELSE (CAST(NEW.last_slot / 2 AS INTEGER)-CAST(OLD.last_slot / 2 AS INTEGER))*1000 END),
      economy=economy+(CASE WHEN NEW.province_id='home' THEN (NEW.last_slot-OLD.last_slot)*5000 ELSE (CAST(NEW.last_slot / 2 AS INTEGER)-CAST(OLD.last_slot / 2 AS INTEGER))*1000 END) WHERE id=NEW.province_id;
     UPDATE z48_virtual_clock SET total_earned=total_earned+(CASE WHEN NEW.province_id='home' THEN (NEW.last_slot-OLD.last_slot)*5000 ELSE (CAST(NEW.last_slot / 2 AS INTEGER)-CAST(OLD.last_slot / 2 AS INTEGER))*1000 END) WHERE province_id=NEW.province_id;
     INSERT INTO z46_ledger(id,province_id,actor_id,kind,delta,note,created_at)
       SELECT 'staff-'||NEW.province_id||'-'||NEW.last_slot,NEW.province_id,'system','staff-income',
         CASE WHEN NEW.province_id='home' THEN (NEW.last_slot-OLD.last_slot)*5000 ELSE (CAST(NEW.last_slot / 2 AS INTEGER)-CAST(OLD.last_slot / 2 AS INTEGER))*1000 END,
         CASE WHEN NEW.province_id='home' THEN 'إيراد عمل 50 موظفًا في الدولة الأصلية' ELSE 'إيراد 20 موظفًا بنظام الساعة المتبادلة' END,
         NEW.last_slot*3600000
       WHERE NEW.province_id='home' OR (CAST(NEW.last_slot / 2 AS INTEGER)-CAST(OLD.last_slot / 2 AS INTEGER))>0;
   END`,

   `CREATE TABLE IF NOT EXISTS z46_elections(id INTEGER PRIMARY KEY CHECK(id=1),round INTEGER NOT NULL DEFAULT 1,opened_at INTEGER NOT NULL,closes_at INTEGER NOT NULL)`,
   `CREATE TABLE IF NOT EXISTS z46_nominees(round INTEGER NOT NULL,user_id TEXT NOT NULL,nominated_at INTEGER NOT NULL,PRIMARY KEY(round,user_id))`,
   `CREATE TABLE IF NOT EXISTS z46_votes(round INTEGER NOT NULL,voter_id TEXT NOT NULL,candidate_id TEXT NOT NULL,voted_at INTEGER NOT NULL,PRIMARY KEY(round,voter_id))`,
   `CREATE TABLE IF NOT EXISTS z46_projects(province_id TEXT NOT NULL,kind TEXT NOT NULL,qty INTEGER NOT NULL DEFAULT 0 CHECK(qty>=0),PRIMARY KEY(province_id,kind))`,
   `CREATE TABLE IF NOT EXISTS z46_ledger(id TEXT PRIMARY KEY,province_id TEXT NOT NULL,actor_id TEXT NOT NULL,kind TEXT NOT NULL,delta INTEGER NOT NULL,note TEXT NOT NULL,created_at INTEGER NOT NULL)`,
   `CREATE INDEX IF NOT EXISTS idx_z46_ledger_province ON z46_ledger(province_id,created_at DESC)`,
   `CREATE TABLE IF NOT EXISTS z46_wars(id TEXT PRIMARY KEY,attacker TEXT NOT NULL,defender TEXT NOT NULL,actor_id TEXT NOT NULL,soldiers INTEGER NOT NULL,missiles INTEGER NOT NULL,planes INTEGER NOT NULL,ships INTEGER NOT NULL,winner TEXT NOT NULL,loot INTEGER NOT NULL,created_at INTEGER NOT NULL)`,
   `CREATE TABLE IF NOT EXISTS z46_funds(id TEXT PRIMARY KEY,province_id TEXT NOT NULL,actor_id TEXT NOT NULL,amount INTEGER NOT NULL CHECK(amount>0),kind TEXT NOT NULL CHECK(kind IN ('donation','aid')),created_at INTEGER NOT NULL)`,
   `CREATE TRIGGER IF NOT EXISTS z46_funds_validate BEFORE INSERT ON z46_funds BEGIN SELECT CASE WHEN NOT EXISTS(SELECT 1 FROM z46_provinces WHERE id=NEW.province_id) THEN RAISE(ABORT,'المحافظة غير موجودة') END; SELECT CASE WHEN NEW.kind='donation' AND NOT EXISTS(SELECT 1 FROM users WHERE id=NEW.actor_id AND points>=NEW.amount) THEN RAISE(ABORT,'رصيد المواطن لا يكفي') END; SELECT CASE WHEN NEW.kind='aid' AND NOT EXISTS(SELECT 1 FROM z_state_treasury WHERE id=1 AND balance>=NEW.amount) THEN RAISE(ABORT,'خزينة الدولة لا تكفي للمساعدة') END; END`,
   `CREATE TRIGGER IF NOT EXISTS z46_funds_apply AFTER INSERT ON z46_funds BEGIN UPDATE users SET points=points-NEW.amount WHERE id=NEW.actor_id AND NEW.kind='donation'; UPDATE z_state_treasury SET balance=balance-NEW.amount WHERE id=1 AND NEW.kind='aid'; UPDATE z46_provinces SET treasury=treasury+NEW.amount WHERE id=NEW.province_id; INSERT INTO transactions(id,user_id,amount,note,created_at) SELECT lower(hex(randomblob(16))),NEW.actor_id,-NEW.amount,'مساهمة في خزينة '||(SELECT name FROM z46_provinces WHERE id=NEW.province_id),NEW.created_at WHERE NEW.kind='donation'; INSERT INTO z_state_ledger(id,delta,reason,actor,created_at) SELECT lower(hex(randomblob(16))),-NEW.amount,'مساعدة محافظة: '||(SELECT name FROM z46_provinces WHERE id=NEW.province_id),(SELECT name FROM users WHERE id=NEW.actor_id),NEW.created_at WHERE NEW.kind='aid'; INSERT INTO z46_ledger(id,province_id,actor_id,kind,delta,note,created_at) VALUES(NEW.id,NEW.province_id,NEW.actor_id,NEW.kind,NEW.amount,CASE WHEN NEW.kind='aid' THEN 'مساعدة من خزينة الدولة' ELSE 'مساهمة مواطن' END,NEW.created_at); END`,
   `CREATE TABLE IF NOT EXISTS z46_recruits(id TEXT PRIMARY KEY,province_id TEXT NOT NULL,actor_id TEXT NOT NULL,unit TEXT NOT NULL,qty INTEGER NOT NULL CHECK(qty BETWEEN 1 AND 2000),cost INTEGER NOT NULL CHECK(cost>=1),created_at INTEGER NOT NULL)`,
   `CREATE TRIGGER IF NOT EXISTS z46_recruits_validate BEFORE INSERT ON z46_recruits BEGIN SELECT CASE WHEN NOT EXISTS(SELECT 1 FROM z46_provinces WHERE id=NEW.province_id AND treasury>=NEW.cost) THEN RAISE(ABORT,'خزينة المحافظة غير كافية') END; END`,
   `CREATE TRIGGER IF NOT EXISTS z46_recruits_apply AFTER INSERT ON z46_recruits BEGIN UPDATE z46_provinces SET treasury=treasury-NEW.cost,soldiers=soldiers+CASE WHEN NEW.unit='soldiers' THEN NEW.qty ELSE 0 END,missiles=missiles+CASE WHEN NEW.unit='missiles' THEN NEW.qty ELSE 0 END,planes=planes+CASE WHEN NEW.unit='planes' THEN NEW.qty ELSE 0 END,ships=ships+CASE WHEN NEW.unit='ships' THEN NEW.qty ELSE 0 END WHERE id=NEW.province_id; INSERT INTO z46_ledger(id,province_id,actor_id,kind,delta,note,created_at) VALUES(NEW.id,NEW.province_id,NEW.actor_id,'recruit',-NEW.cost,'شراء وحدات دفاعية',NEW.created_at); END`,
   `CREATE TABLE IF NOT EXISTS z46_investments(id TEXT PRIMARY KEY,province_id TEXT NOT NULL,actor_id TEXT NOT NULL,kind TEXT NOT NULL,cost INTEGER NOT NULL,created_at INTEGER NOT NULL)`,
   `CREATE TRIGGER IF NOT EXISTS z46_investments_validate BEFORE INSERT ON z46_investments BEGIN SELECT CASE WHEN NOT EXISTS(SELECT 1 FROM z46_provinces WHERE id=NEW.province_id AND treasury>=NEW.cost) THEN RAISE(ABORT,'لا توجد أموال كافية للاستثمار') END; END`,
   `CREATE TRIGGER IF NOT EXISTS z46_investments_apply AFTER INSERT ON z46_investments BEGIN UPDATE z46_provinces SET treasury=treasury-NEW.cost,economy=economy+NEW.cost WHERE id=NEW.province_id; INSERT INTO z46_projects(province_id,kind,qty) VALUES(NEW.province_id,NEW.kind,1) ON CONFLICT(province_id,kind) DO UPDATE SET qty=qty+1; INSERT INTO z46_ledger(id,province_id,actor_id,kind,delta,note,created_at) VALUES(NEW.id,NEW.province_id,NEW.actor_id,'investment',-NEW.cost,'بناء مشروع اقتصادي: '||NEW.kind,NEW.created_at); END`,
   `CREATE TRIGGER IF NOT EXISTS z46_war_validate BEFORE INSERT ON z46_wars BEGIN SELECT CASE WHEN NEW.attacker=NEW.defender OR NOT EXISTS(SELECT 1 FROM z46_provinces WHERE id=NEW.defender) THEN RAISE(ABORT,'الهدف غير صالح') END; SELECT CASE WHEN NOT EXISTS(SELECT 1 FROM z46_provinces WHERE id=NEW.attacker AND war_lock_until<=NEW.created_at AND soldiers>=NEW.soldiers AND missiles>=NEW.missiles AND planes>=NEW.planes AND ships>=NEW.ships) THEN RAISE(ABORT,'القوات غير كافية أو الهدنة لم تنته') END; SELECT CASE WHEN NOT EXISTS(SELECT 1 FROM z46_provinces WHERE id=NEW.defender AND war_lock_until<=NEW.created_at) THEN RAISE(ABORT,'المحافظة المستهدفة في هدنة') END; SELECT CASE WHEN NEW.winner NOT IN (NEW.attacker,NEW.defender) OR NEW.loot<0 OR NEW.loot>130000 OR (NEW.winner!=NEW.attacker AND NEW.loot!=0) OR NEW.loot>COALESCE((SELECT treasury FROM z46_provinces WHERE id=NEW.defender),0) THEN RAISE(ABORT,'نتيجة الحرب غير صالحة') END; END`,
   `CREATE TRIGGER IF NOT EXISTS z46_war_apply AFTER INSERT ON z46_wars BEGIN UPDATE z46_provinces SET soldiers=soldiers-NEW.soldiers,missiles=missiles-NEW.missiles,planes=planes-NEW.planes,ships=ships-NEW.ships,war_lock_until=NEW.created_at+7200000 WHERE id=NEW.attacker; UPDATE z46_provinces SET soldiers=MAX(0,soldiers-CAST(NEW.soldiers/5 AS INTEGER)),planes=MAX(0,planes-CAST(NEW.planes/3 AS INTEGER)),ships=MAX(0,ships-CAST(NEW.ships/4 AS INTEGER)),war_lock_until=NEW.created_at+7200000 WHERE id=NEW.defender; UPDATE z46_provinces SET treasury=treasury-NEW.loot,economy=MAX(0,economy-NEW.loot) WHERE id=NEW.defender; UPDATE z46_provinces SET treasury=treasury+NEW.loot,economy=economy+NEW.loot WHERE id=NEW.attacker; INSERT INTO z46_ledger(id,province_id,actor_id,kind,delta,note,created_at) SELECT NEW.id||'-w',NEW.attacker,NEW.actor_id,'war',NEW.loot,'نتيجة معركة المحافظات',NEW.created_at; INSERT INTO z46_ledger(id,province_id,actor_id,kind,delta,note,created_at) SELECT NEW.id||'-l',NEW.defender,NEW.actor_id,'war',-NEW.loot,'خسائر غنائم معركة',NEW.created_at; END`,
   `CREATE TABLE IF NOT EXISTS z46_fines(id TEXT PRIMARY KEY,province_id TEXT NOT NULL,actor_id TEXT NOT NULL,target_id TEXT NOT NULL,amount INTEGER NOT NULL CHECK(amount BETWEEN 1 AND 500),reason TEXT NOT NULL,created_at INTEGER NOT NULL)`,
   `CREATE TRIGGER IF NOT EXISTS z46_fines_apply AFTER INSERT ON z46_fines BEGIN UPDATE z46_provinces SET treasury=treasury+MIN(NEW.amount,MAX(0,(SELECT points FROM users WHERE id=NEW.target_id))) WHERE id=NEW.province_id; INSERT INTO transactions(id,user_id,amount,note,created_at) SELECT NEW.id,NEW.target_id,-MIN(NEW.amount,MAX(0,points)),'غرامة محافظة: '||NEW.reason,NEW.created_at FROM users WHERE id=NEW.target_id AND points>0; UPDATE users SET points=points-MIN(NEW.amount,MAX(0,points)) WHERE id=NEW.target_id; INSERT INTO z46_ledger(id,province_id,actor_id,kind,delta,note,created_at) VALUES(NEW.id,NEW.province_id,NEW.actor_id,'fine',COALESCE((SELECT -amount FROM transactions WHERE id=NEW.id),0),NEW.reason,NEW.created_at); END`
  ];
  await db.batch(ddl.map(q=>db.prepare(q)));
  const today=Math.floor(Date.now()/86400000);
  for(const [provinceId,name] of Object.entries(Z46_NAMES)){
   const home=provinceId==='home';
   await db.prepare('INSERT OR IGNORE INTO z46_provinces(id,name,treasury,economy,soldiers,missiles,planes,ships,last_fee_day) VALUES(?,?,?,?,?,?,?,?,?)').bind(provinceId,name,100000,100000,home?4000:1000,home?50:10,home?50:20,home?50:10,today).run();
  }
  // Synthetic residents are separate from users: cannot log in, borrow, vote or impersonate citizens.
  // Start their work clock at activation; missed hours are caught up exactly once by SQL.
  await z50TreasuryBridge(db);
  const activationSlot=Math.floor(Date.now()/3600000);
  for(const pid of Object.keys(Z46_NAMES)){
   await db.prepare('INSERT OR IGNORE INTO z48_virtual_clock(province_id,last_slot,created_at,total_earned) VALUES(?,?,?,0)').bind(pid,activationSlot,Date.now()).run();
  }
  await db.prepare('INSERT OR IGNORE INTO z46_elections(id,round,opened_at,closes_at) VALUES(1,1,?,?)').bind(Date.now(),Date.now()+7200000).run();
  await z36EducationEnsure(db);
  const fix=await db.prepare("SELECT value FROM site_settings WHERE key='z46_education_appeal_fixed'").first();
  if(fix?.value!=='1'){
   await db.batch([
    db.prepare('DROP TRIGGER IF EXISTS z36_edu_appeal_apply'),
    db.prepare(`CREATE TRIGGER z36_edu_appeal_apply AFTER UPDATE OF status ON z36_edu_appeals WHEN OLD.status='pending' AND NEW.status='accepted' BEGIN
      UPDATE z36_edu_attempts SET score=score+(CASE WHEN (SELECT json_array_length(questions_json) FROM z36_edu_exams WHERE cycle=NEW.cycle)=5 THEN 1100 ELSE 600 END),correct_count=correct_count+1,wrong_count=MAX(0,wrong_count-1) WHERE cycle=NEW.cycle AND user_id=NEW.user_id;
      UPDATE users SET points=points+(CASE WHEN (SELECT json_array_length(questions_json) FROM z36_edu_exams WHERE cycle=NEW.cycle)=5 THEN 1100 ELSE 600 END) WHERE id=NEW.user_id;
      INSERT INTO transactions(id,user_id,amount,note,created_at) VALUES(NEW.id,NEW.user_id,CASE WHEN (SELECT json_array_length(questions_json) FROM z36_edu_exams WHERE cycle=NEW.cycle)=5 THEN 1100 ELSE 600 END,'تصحيح نتيجة سؤال في امتحان التعليم بعد قبول التظلم',NEW.reviewed_at);
      INSERT OR IGNORE INTO z36_edu_fines(id,cycle,user_id,kind,amount,created_at)
       SELECT lower(hex(randomblob(16))),NEW.cycle,e.author_id,'خطأ في نموذج إجابة السؤال '||NEW.question_no,NEW.fine_amount,NEW.reviewed_at FROM z36_edu_exams e WHERE e.cycle=NEW.cycle AND NEW.fine_amount>0;
     END`),
    db.prepare("INSERT OR REPLACE INTO site_settings(key,value,updated_at) VALUES('z46_education_appeal_fixed','1',?)").bind(Date.now())
   ]);
  }
  // Every existing citizen joins the capital by default. Choosing a province remains free once.
  await db.prepare("INSERT OR IGNORE INTO z46_members(user_id,province_id,joined_at,changed_at) SELECT id,'home',joined,0 FROM users").run();
 })().catch(e=>{z46Ready=null;throw e});return z46Ready;
}
// Update 50 — The home federation country and the original Zangar game share one state treasury.
// No deletion, reinitialization, or reset of existing citizen, loan, or asset data.
async function z50TreasuryBridge(db){
 // Both game interfaces share one balance and one strategic army; existing resources are never discarded.
 await z33Ensure(db);
 const flag=await db.prepare("SELECT value FROM site_settings WHERE key='z50_home_treasury_linked'").first();
 if(flag?.value!=='1'){
  const main=await db.prepare('SELECT balance FROM z_state_treasury WHERE id=1').first();
  if(main){
   await db.prepare("UPDATE z46_provinces SET treasury=?,economy=? WHERE id='home'").bind(Number(main.balance),Number(main.balance)).run();
   await db.prepare("INSERT OR IGNORE INTO site_settings(key,value,updated_at) VALUES('z50_home_treasury_linked','1',?)").bind(Date.now()).run();
  }
 }
 const armyFlag=await db.prepare("SELECT value FROM site_settings WHERE key='z50_home_army_linked'").first();
 if(armyFlag?.value!=='1'){
  const home=await db.prepare("SELECT soldiers,missiles,planes,ships FROM z46_provinces WHERE id='home'").first();
  const original=await db.prepare('SELECT soldiers,missiles,planes,ships FROM z33_military WHERE id=1').first();
  if(home&&original){
   // On this one-time merge retain the greatest stock per unit to avoid losing either previous army.
   const stock=['soldiers','missiles','planes','ships'].map(k=>Math.max(Number(home[k]||0),Number(original[k]||0)));
   await db.prepare("UPDATE z46_provinces SET soldiers=?,missiles=?,planes=?,ships=? WHERE id='home'").bind(stock[0],stock[1],stock[2],stock[3]).run();
   await db.prepare('UPDATE z33_military SET soldiers=?,missiles=?,planes=?,ships=? WHERE id=1').bind(stock[0],stock[1],stock[2],stock[3]).run();
   await db.prepare("INSERT OR IGNORE INTO site_settings(key,value,updated_at) VALUES('z50_home_army_linked','1',?)").bind(Date.now()).run();
  }
 }
 await db.batch([
  db.prepare(`CREATE TRIGGER IF NOT EXISTS z50_main_to_federation AFTER UPDATE OF balance ON z_state_treasury
   WHEN NEW.id=1 AND EXISTS(SELECT 1 FROM z46_provinces WHERE id='home' AND treasury!=NEW.balance)
   BEGIN UPDATE z46_provinces SET treasury=NEW.balance,economy=NEW.balance WHERE id='home'; END`),
  db.prepare(`CREATE TRIGGER IF NOT EXISTS z50_federation_to_main AFTER UPDATE OF treasury ON z46_provinces
   WHEN NEW.id='home' AND EXISTS(SELECT 1 FROM z_state_treasury WHERE id=1 AND balance!=NEW.treasury)
   BEGIN UPDATE z_state_treasury SET balance=NEW.treasury WHERE id=1;
   UPDATE z46_provinces SET economy=NEW.treasury WHERE id='home' AND economy!=NEW.treasury; END`),
  db.prepare(`CREATE TRIGGER IF NOT EXISTS z50_original_army_to_home AFTER UPDATE OF soldiers,missiles,planes,ships ON z33_military
   WHEN NEW.id=1 AND EXISTS(SELECT 1 FROM z46_provinces WHERE id='home' AND (soldiers!=NEW.soldiers OR missiles!=NEW.missiles OR planes!=NEW.planes OR ships!=NEW.ships))
   BEGIN UPDATE z46_provinces SET soldiers=NEW.soldiers,missiles=NEW.missiles,planes=NEW.planes,ships=NEW.ships WHERE id='home'; END`),
  db.prepare(`CREATE TRIGGER IF NOT EXISTS z50_home_army_to_original AFTER UPDATE OF soldiers,missiles,planes,ships ON z46_provinces
   WHEN NEW.id='home' AND EXISTS(SELECT 1 FROM z33_military WHERE id=1 AND (soldiers!=NEW.soldiers OR missiles!=NEW.missiles OR planes!=NEW.planes OR ships!=NEW.ships))
   BEGIN UPDATE z33_military SET soldiers=NEW.soldiers,missiles=NEW.missiles,planes=NEW.planes,ships=NEW.ships WHERE id=1; END`)
 ]);
}
async function z46Tick(db,now=Date.now()){
 // Atomic clock advance, one per province; trigger credits the treasury/economy once
 // for each even UTC hour crossed in other states; capital: 50 × 100 = 5000 every hour.
 const currentSlot=Math.floor(now/3600000);
 await db.prepare('UPDATE z48_virtual_clock SET last_slot=? WHERE last_slot<?').bind(currentSlot,currentSlot).run();
 const today=Math.floor(now/86400000);
 const rows=(await db.prepare('SELECT p.id,p.last_fee_day,p.treasury,p.economy,COALESCE(SUM(CASE WHEN j.kind=\'farm\' THEN 500*j.qty WHEN j.kind=\'factory\' THEN 1100*j.qty WHEN j.kind=\'port\' THEN 1900*j.qty ELSE 0 END),0) income FROM z46_provinces p LEFT JOIN z46_projects j ON j.province_id=p.id GROUP BY p.id').all()).results;
 for(const p of rows){const days=Math.min(60,Math.max(0,today-Number(p.last_fee_day)));if(!days)continue;const revenue=Number(p.income)*days,cost=Z46_DAILY_FEE*days;const delta=revenue-cost;
  const updated=await db.prepare('UPDATE z46_provinces SET treasury=MAX(0,treasury+?),economy=MAX(0,economy+?),last_fee_day=? WHERE id=? AND last_fee_day=? RETURNING id').bind(delta,delta,today,p.id,p.last_fee_day).first();
  if(updated)await db.prepare('INSERT OR IGNORE INTO z46_ledger(id,province_id,actor_id,kind,delta,note,created_at) VALUES(?,?,?,?,?,?,?)').bind('daily-'+p.id+'-'+today,p.id,'system','daily',delta,'مصروفات المحافظة 4,000 يوميًا مقابل دخل المشروعات عن '+days+' يوم',now).run();
 }
}
function z46Governor(u,p){return !!u&&(isAdmin(u)||p.governor_id===u.id);}
async function z46MemberEnsure(db,u){await db.prepare("INSERT OR IGNORE INTO z46_members(user_id,province_id,joined_at,changed_at) VALUES(?,'home',?,0)").bind(u.id,Date.now()).run();}

// Update 54 — opt-in alliances, preparation countdowns, once-per-war cooldown reduction.
const Z55_COOLDOWN_MS=10*60000; // Update 55: 10 minutes after every war
const Z54_PREPARE_MS=10*60000;
const Z54_REST_SHORT_MS=15*60000;
function z54Pair(a,b){return [a,b].sort();}
function z55Angle(planId){let sum=0;for(let i=0;i<planId.length;i++)sum=(sum*31+planId.charCodeAt(i))>>>0;return sum%360;}
const z54Power=v=>Number(v.soldiers||0)+20*Number(v.missiles||0)+15*Number(v.planes||0)+25*Number(v.ships||0);
let z56WarSchemaPromise=null;
async function z54Ensure(db){
 if(z56WarSchemaPromise)return z56WarSchemaPromise;
 z56WarSchemaPromise=(async()=>{
 for(const sql of [
 `CREATE TABLE IF NOT EXISTS z54_alliances(a TEXT NOT NULL,b TEXT NOT NULL,status TEXT NOT NULL CHECK(status IN ('pending','active','ended','rejected')),requested_by TEXT NOT NULL,created_at INTEGER NOT NULL,decided_at INTEGER NOT NULL DEFAULT 0,PRIMARY KEY(a,b),CHECK(a<b))`,
 `CREATE TABLE IF NOT EXISTS z54_plans(id TEXT PRIMARY KEY,attacker TEXT NOT NULL,defender TEXT NOT NULL,actor_id TEXT NOT NULL,soldiers INTEGER NOT NULL,missiles INTEGER NOT NULL,planes INTEGER NOT NULL,ships INTEGER NOT NULL,requested_loot INTEGER NOT NULL,created_at INTEGER NOT NULL,starts_at INTEGER NOT NULL,status TEXT NOT NULL DEFAULT 'pending' CHECK(status IN ('pending','completed','cancelled')),completed_at INTEGER NOT NULL DEFAULT 0,winner TEXT NOT NULL DEFAULT '',loot INTEGER NOT NULL DEFAULT 0)`,
 `CREATE UNIQUE INDEX IF NOT EXISTS z54_one_attack_pending ON z54_plans(attacker) WHERE status='pending'`,
 `CREATE UNIQUE INDEX IF NOT EXISTS z54_one_defense_pending ON z54_plans(defender) WHERE status='pending'`,
 `CREATE TABLE IF NOT EXISTS z54_support(plan_id TEXT NOT NULL,province_id TEXT NOT NULL,side TEXT NOT NULL CHECK(side IN ('attacker','defender')),actor_id TEXT NOT NULL,soldiers INTEGER NOT NULL DEFAULT 0,missiles INTEGER NOT NULL DEFAULT 0,planes INTEGER NOT NULL DEFAULT 0,ships INTEGER NOT NULL DEFAULT 0,created_at INTEGER NOT NULL,PRIMARY KEY(plan_id,province_id))`,
 `CREATE TRIGGER IF NOT EXISTS z54_support_validate BEFORE INSERT ON z54_support BEGIN SELECT CASE WHEN NOT EXISTS(SELECT 1 FROM z54_plans WHERE id=NEW.plan_id AND status='pending' AND starts_at>NEW.created_at) THEN RAISE(ABORT,'انتهت مهلة الاشتراك في الحرب') END; SELECT CASE WHEN NOT EXISTS(SELECT 1 FROM z54_plans w JOIN z54_alliances a ON a.status='active' AND ((a.a=NEW.province_id AND a.b=CASE WHEN NEW.side='attacker' THEN w.attacker ELSE w.defender END) OR (a.b=NEW.province_id AND a.a=CASE WHEN NEW.side='attacker' THEN w.attacker ELSE w.defender END)) WHERE w.id=NEW.plan_id AND w.attacker!=NEW.province_id AND w.defender!=NEW.province_id) THEN RAISE(ABORT,'ليس هناك تحالف نشط') END; SELECT CASE WHEN NOT EXISTS(SELECT 1 FROM z46_provinces WHERE id=NEW.province_id AND soldiers>=NEW.soldiers AND missiles>=NEW.missiles AND planes>=NEW.planes AND ships>=NEW.ships AND war_lock_until<=NEW.created_at) THEN RAISE(ABORT,'القوات غير كافية أو الدولة في فترة راحة') END; END`,
 `CREATE TRIGGER IF NOT EXISTS z54_support_reserve AFTER INSERT ON z54_support BEGIN UPDATE z46_provinces SET soldiers=soldiers-NEW.soldiers,missiles=missiles-NEW.missiles,planes=planes-NEW.planes,ships=ships-NEW.ships WHERE id=NEW.province_id; INSERT INTO z46_ledger(id,province_id,actor_id,kind,delta,note,created_at) VALUES(NEW.plan_id||'-ally-'||NEW.province_id,NEW.province_id,NEW.actor_id,'allied_support',0,'مشاركة عسكرية في حرب الحليف',NEW.created_at); END`,
 `CREATE TRIGGER IF NOT EXISTS z54_cancel_refund AFTER UPDATE OF status ON z54_plans WHEN OLD.status='pending' AND NEW.status='cancelled' BEGIN UPDATE z46_provinces SET soldiers=soldiers+(SELECT COALESCE(SUM(soldiers),0) FROM z54_support WHERE plan_id=NEW.id AND province_id=z46_provinces.id),missiles=missiles+(SELECT COALESCE(SUM(missiles),0) FROM z54_support WHERE plan_id=NEW.id AND province_id=z46_provinces.id),planes=planes+(SELECT COALESCE(SUM(planes),0) FROM z54_support WHERE plan_id=NEW.id AND province_id=z46_provinces.id),ships=ships+(SELECT COALESCE(SUM(ships),0) FROM z54_support WHERE plan_id=NEW.id AND province_id=z46_provinces.id) WHERE id IN (SELECT province_id FROM z54_support WHERE plan_id=NEW.id); END`,
 `CREATE TABLE IF NOT EXISTS z54_rest_reductions(province_id TEXT NOT NULL,battle_id TEXT NOT NULL,used_at INTEGER NOT NULL,new_until INTEGER NOT NULL,PRIMARY KEY(province_id,battle_id))`,
 `CREATE TABLE IF NOT EXISTS z54_allied_rewards(plan_id TEXT NOT NULL,province_id TEXT NOT NULL,amount INTEGER NOT NULL CHECK(amount>=0),PRIMARY KEY(plan_id,province_id))`,
 `CREATE TRIGGER IF NOT EXISTS z54_allied_reward_apply AFTER INSERT ON z54_allied_rewards WHEN NEW.amount>0 BEGIN UPDATE z46_provinces SET treasury=treasury-NEW.amount,economy=MAX(0,economy-NEW.amount) WHERE id=(SELECT attacker FROM z54_plans WHERE id=NEW.plan_id); UPDATE z46_provinces SET treasury=treasury+NEW.amount,economy=economy+NEW.amount WHERE id=NEW.province_id; INSERT INTO z46_ledger(id,province_id,actor_id,kind,delta,note,created_at) VALUES(NEW.plan_id||'-reward-'||NEW.province_id,NEW.province_id,'system','allied_reward',NEW.amount,'حصة دعم الحليف من غنائم الحرب',CAST(strftime('%s','now') AS INTEGER)*1000); END`,
 `CREATE TABLE IF NOT EXISTS z55_intercepts(plan_id TEXT PRIMARY KEY,defender TEXT NOT NULL,actor_id TEXT NOT NULL,aim_angle INTEGER NOT NULL,expected_angle INTEGER NOT NULL,intercepted_count INTEGER NOT NULL DEFAULT 0,created_at INTEGER NOT NULL)`,
 `CREATE TRIGGER IF NOT EXISTS z55_intercept_guard BEFORE INSERT ON z55_intercepts BEGIN SELECT CASE WHEN NOT EXISTS(SELECT 1 FROM z54_plans w JOIN z46_provinces p ON p.id=w.defender WHERE w.id=NEW.plan_id AND w.defender=NEW.defender AND w.status='pending' AND w.starts_at>NEW.created_at AND w.missiles>0 AND p.missiles>=1) THEN RAISE(ABORT,'لا يوجد صاروخ قادم صالح للاعتراض أو مخزون الدفاع غير كاف') END; END`,
 `CREATE TRIGGER IF NOT EXISTS z55_intercept_cost AFTER INSERT ON z55_intercepts BEGIN UPDATE z46_provinces SET missiles=missiles-1 WHERE id=NEW.defender; INSERT INTO z46_ledger(id,province_id,actor_id,kind,delta,note,created_at) VALUES(NEW.plan_id||'-radar',NEW.defender,NEW.actor_id,'radar_intercept',0,'محاولة اعتراض راداري افتراضية',NEW.created_at); END`
 ])await db.prepare(sql).run();
 // Upgrade existing two-hour province cooldowns from earlier releases to the requested ten-minute rule.
 await db.prepare(`UPDATE z46_provinces SET war_lock_until=MIN(war_lock_until,
   (SELECT MAX(created_at)+600000 FROM z46_wars w WHERE w.attacker=z46_provinces.id OR w.defender=z46_provinces.id))
   WHERE war_lock_until>? AND EXISTS(SELECT 1 FROM z46_wars w WHERE w.attacker=z46_provinces.id OR w.defender=z46_provinces.id)`).bind(Date.now()).run();
 })().catch(e=>{z56WarSchemaPromise=null;throw e});
 return z56WarSchemaPromise;
}

let z59InitPromise=null;
const Z59_CHEST_PRIZES=[200,250,300,350,400];
const Z59_BLD={school:{name:'مدرسة',base:2600,gain:200},hospital:{name:'مستشفى',base:4200,gain:330},factory:{name:'مصنع',base:7200,gain:650},military:{name:'قاعدة عسكرية',base:9000,gain:0},port:{name:'ميناء',base:6400,gain:510}};
const Z59_TECH={radar:{name:'الرادار المطوّر',base:5500},training:{name:'تدريب الجنود',base:3600}};
const Z59_KINDS=['defense','trade','peace'];
async function z59Ensure(db){
 if(z59InitPromise)return z59InitPromise;
 z59InitPromise=(async()=>{
  for(const sql of [
   `CREATE TABLE IF NOT EXISTS z59_balance_audit(id TEXT PRIMARY KEY,user_id TEXT NOT NULL,old_points INTEGER NOT NULL,new_points INTEGER NOT NULL,created_at INTEGER NOT NULL)`,
   `CREATE INDEX IF NOT EXISTS idx_z59_balance_audit_user ON z59_balance_audit(user_id,created_at DESC)`,
   `CREATE INDEX IF NOT EXISTS idx_z59_weekly_ledger ON z46_ledger(created_at,kind,province_id)`,
   `CREATE TRIGGER IF NOT EXISTS z59_wallet_audit AFTER UPDATE OF points ON users WHEN OLD.points<>NEW.points BEGIN INSERT INTO z59_balance_audit(id,user_id,old_points,new_points,created_at) VALUES(lower(hex(randomblob(16))),NEW.id,OLD.points,NEW.points,CAST(strftime('%s','now') AS INTEGER)*1000); END`,
   `CREATE TABLE IF NOT EXISTS z59_daily_chests(id TEXT PRIMARY KEY,user_id TEXT NOT NULL,day INTEGER NOT NULL,reward INTEGER NOT NULL CHECK(reward BETWEEN 200 AND 400),created_at INTEGER NOT NULL,UNIQUE(user_id,day))`,
   `CREATE TRIGGER IF NOT EXISTS z59_chest_credit AFTER INSERT ON z59_daily_chests BEGIN UPDATE users SET points=points+NEW.reward WHERE id=NEW.user_id; INSERT INTO transactions(id,user_id,amount,note,created_at) VALUES(NEW.id,NEW.user_id,NEW.reward,'صندوق الزنجر اليومي',NEW.created_at); END`,
   `CREATE TABLE IF NOT EXISTS z59_buildings(id TEXT PRIMARY KEY,province_id TEXT NOT NULL,kind TEXT NOT NULL,level INTEGER NOT NULL CHECK(level BETWEEN 1 AND 5),cost INTEGER NOT NULL CHECK(cost>0),income INTEGER NOT NULL CHECK(income>=0),actor_id TEXT NOT NULL,created_at INTEGER NOT NULL,UNIQUE(province_id,kind,level))`,
   `CREATE TRIGGER IF NOT EXISTS z59_building_validate BEFORE INSERT ON z59_buildings BEGIN SELECT CASE WHEN NEW.level!=(SELECT COALESCE(MAX(level),0)+1 FROM z59_buildings WHERE province_id=NEW.province_id AND kind=NEW.kind) THEN RAISE(ABORT,'لابد من ترقية مستويات المبنى بالتسلسل') END; SELECT CASE WHEN NOT EXISTS(SELECT 1 FROM z46_provinces WHERE id=NEW.province_id AND treasury>=NEW.cost) THEN RAISE(ABORT,'الخزينة لا تكفي لتطوير المبنى') END; END`,
   `CREATE TRIGGER IF NOT EXISTS z59_building_apply AFTER INSERT ON z59_buildings BEGIN UPDATE z46_provinces SET treasury=treasury-NEW.cost,economy=economy+NEW.cost WHERE id=NEW.province_id; INSERT INTO z46_ledger(id,province_id,actor_id,kind,delta,note,created_at) VALUES(NEW.id,NEW.province_id,NEW.actor_id,'building',-NEW.cost,'تطوير مبنى '||NEW.kind||' للمستوى '||NEW.level,NEW.created_at); END`,
   `CREATE TABLE IF NOT EXISTS z59_research(id TEXT PRIMARY KEY,province_id TEXT NOT NULL,kind TEXT NOT NULL,level INTEGER NOT NULL CHECK(level BETWEEN 1 AND 5),cost INTEGER NOT NULL CHECK(cost>0),actor_id TEXT NOT NULL,created_at INTEGER NOT NULL,UNIQUE(province_id,kind,level))`,
   `CREATE TRIGGER IF NOT EXISTS z59_research_validate BEFORE INSERT ON z59_research BEGIN SELECT CASE WHEN NEW.level!=(SELECT COALESCE(MAX(level),0)+1 FROM z59_research WHERE province_id=NEW.province_id AND kind=NEW.kind) THEN RAISE(ABORT,'مستوى بحث غير صالح') END; SELECT CASE WHEN NOT EXISTS(SELECT 1 FROM z46_provinces WHERE id=NEW.province_id AND treasury>=NEW.cost) THEN RAISE(ABORT,'خزينة المحافظة لا تكفي للبحث') END; END`,
   `CREATE TRIGGER IF NOT EXISTS z59_research_apply AFTER INSERT ON z59_research BEGIN UPDATE z46_provinces SET treasury=treasury-NEW.cost,economy=economy+NEW.cost WHERE id=NEW.province_id; INSERT INTO z46_ledger(id,province_id,actor_id,kind,delta,note,created_at) VALUES(NEW.id,NEW.province_id,NEW.actor_id,'research',-NEW.cost,'تطوير أبحاث '||NEW.kind,NEW.created_at); END`,
   `CREATE TABLE IF NOT EXISTS z59_trade_offers(id TEXT PRIMARY KEY,from_id TEXT NOT NULL,to_id TEXT NOT NULL,resource TEXT NOT NULL,price INTEGER NOT NULL CHECK(price BETWEEN 100 AND 50000),actor_id TEXT NOT NULL,created_at INTEGER NOT NULL,status TEXT NOT NULL DEFAULT 'pending',decided_at INTEGER NOT NULL DEFAULT 0)`,
   `CREATE TABLE IF NOT EXISTS z59_trade_shipments(id TEXT PRIMARY KEY,from_id TEXT NOT NULL,to_id TEXT NOT NULL,resource TEXT NOT NULL,price INTEGER NOT NULL CHECK(price BETWEEN 100 AND 50000),actor_id TEXT NOT NULL,created_at INTEGER NOT NULL,CHECK(from_id<>to_id))`,
   `CREATE TRIGGER IF NOT EXISTS z59_trade_guard BEFORE INSERT ON z59_trade_shipments BEGIN SELECT CASE WHEN NOT EXISTS(SELECT 1 FROM z46_provinces WHERE id=NEW.to_id AND treasury>=NEW.price) THEN RAISE(ABORT,'المشتري لا يملك ميزانية الشحنة') END; END`,
   `CREATE TRIGGER IF NOT EXISTS z59_trade_apply AFTER INSERT ON z59_trade_shipments BEGIN UPDATE z46_provinces SET treasury=treasury-NEW.price WHERE id=NEW.to_id; UPDATE z46_provinces SET treasury=treasury+NEW.price WHERE id=NEW.from_id; INSERT INTO z46_ledger(id,province_id,actor_id,kind,delta,note,created_at) VALUES(NEW.id||'-seller',NEW.from_id,NEW.actor_id,'shipment',NEW.price,'بيع شحنة '||NEW.resource,NEW.created_at); INSERT INTO z46_ledger(id,province_id,actor_id,kind,delta,note,created_at) VALUES(NEW.id||'-buyer',NEW.to_id,NEW.actor_id,'shipment',-NEW.price,'استلام شحنة '||NEW.resource,NEW.created_at); END`,
   `CREATE TABLE IF NOT EXISTS z59_events(id TEXT PRIMARY KEY,province_id TEXT NOT NULL,day INTEGER NOT NULL,choice INTEGER NOT NULL CHECK(choice BETWEEN 1 AND 3),cost INTEGER NOT NULL CHECK(cost>=0),growth INTEGER NOT NULL,actor_id TEXT NOT NULL,created_at INTEGER NOT NULL,UNIQUE(province_id,day))`,
   `CREATE TRIGGER IF NOT EXISTS z59_events_guard BEFORE INSERT ON z59_events BEGIN SELECT CASE WHEN NOT EXISTS(SELECT 1 FROM z46_provinces WHERE id=NEW.province_id AND treasury>=NEW.cost) THEN RAISE(ABORT,'لا توجد ميزانية كافية لمعالجة الأزمة') END; END`,
   `CREATE TRIGGER IF NOT EXISTS z59_events_apply AFTER INSERT ON z59_events BEGIN UPDATE z46_provinces SET treasury=treasury-NEW.cost,economy=MAX(0,economy+NEW.growth) WHERE id=NEW.province_id; INSERT INTO z46_ledger(id,province_id,actor_id,kind,delta,note,created_at) VALUES(NEW.id,NEW.province_id,NEW.actor_id,'event',-NEW.cost,'قرار معالجة أزمة رقم '||NEW.choice,NEW.created_at); END`,
   `CREATE TABLE IF NOT EXISTS z59_building_payouts(province_id TEXT NOT NULL,day INTEGER NOT NULL,amount INTEGER NOT NULL,PRIMARY KEY(province_id,day))`,
   `CREATE TRIGGER IF NOT EXISTS z59_payout_apply AFTER INSERT ON z59_building_payouts BEGIN UPDATE z46_provinces SET treasury=treasury+NEW.amount,economy=economy+NEW.amount WHERE id=NEW.province_id; END`,
   `CREATE TABLE IF NOT EXISTS z59_treaty_details(a TEXT NOT NULL,b TEXT NOT NULL,kind TEXT NOT NULL,status TEXT NOT NULL DEFAULT 'pending',requested_by TEXT NOT NULL,created_at INTEGER NOT NULL,expires_at INTEGER NOT NULL DEFAULT 0,PRIMARY KEY(a,b,kind),CHECK(a<b))`
  ])await db.prepare(sql).run();
  const flag=await db.prepare("SELECT value FROM site_settings WHERE key='z59_war_loot_upgraded'").first();
  if(flag?.value!=='1'){
    await db.batch([
      db.prepare('DROP TRIGGER IF EXISTS z46_war_validate'),
      db.prepare(`CREATE TRIGGER IF NOT EXISTS z46_war_validate BEFORE INSERT ON z46_wars BEGIN SELECT CASE WHEN NEW.attacker=NEW.defender OR NOT EXISTS(SELECT 1 FROM z46_provinces WHERE id=NEW.defender) THEN RAISE(ABORT,'الهدف غير صالح') END; SELECT CASE WHEN NOT EXISTS(SELECT 1 FROM z46_provinces WHERE id=NEW.attacker AND war_lock_until<=NEW.created_at AND soldiers>=NEW.soldiers AND missiles>=NEW.missiles AND planes>=NEW.planes AND ships>=NEW.ships) THEN RAISE(ABORT,'القوات غير كافية أو الهدنة لم تنته') END; SELECT CASE WHEN NOT EXISTS(SELECT 1 FROM z46_provinces WHERE id=NEW.defender AND war_lock_until<=NEW.created_at) THEN RAISE(ABORT,'المحافظة المستهدفة في هدنة') END; SELECT CASE WHEN NEW.winner NOT IN (NEW.attacker,NEW.defender) OR NEW.loot<0 OR NEW.loot>130000 OR (NEW.winner!=NEW.attacker AND NEW.loot!=0) OR NEW.loot>COALESCE((SELECT treasury FROM z46_provinces WHERE id=NEW.defender),0) THEN RAISE(ABORT,'نتيجة الحرب غير صالحة') END; END`),
      db.prepare("INSERT OR REPLACE INTO site_settings(key,value,updated_at) VALUES('z59_war_loot_upgraded','1',?)").bind(Date.now())
    ]);
  }
 })().catch(e=>{z59InitPromise=null;throw e});return z59InitPromise;
}
async function z59Tick(db,now=Date.now()){
  const day=Math.floor(now/86400000);
  const rows=(await db.prepare('SELECT province_id,COALESCE(SUM(income),0) amount FROM z59_buildings WHERE income>0 GROUP BY province_id').all()).results;
  for(const row of rows){if(!row.amount)continue;await db.prepare('INSERT OR IGNORE INTO z59_building_payouts(province_id,day,amount) VALUES(?,?,?)').bind(row.province_id,day,row.amount).run();}
}
function z59Level(rows,id,kind){return rows.filter(x=>x.province_id===id&&x.kind===kind).reduce((n,x)=>Math.max(n,Number(x.level||0)),0);}
async function z59State(req,db){
 await z59Ensure(db);const user=await getMe(req,db);await z59Tick(db);const now=Date.now(),day=Math.floor(now/86400000);
 const [pp,build,research,chest,events,alliances,history,wars,ledger,shipments,offers,achievements,weekly]=await Promise.all([
 db.prepare('SELECT id,name,treasury,economy,soldiers,missiles,planes,ships,governor_id FROM z46_provinces').all(),
 db.prepare('SELECT province_id,kind,MAX(level) level,SUM(income) income FROM z59_buildings GROUP BY province_id,kind').all(),
 db.prepare('SELECT province_id,kind,MAX(level) level FROM z59_research GROUP BY province_id,kind').all(),
 user?db.prepare('SELECT reward FROM z59_daily_chests WHERE user_id=? AND day=?').bind(user.id,day).first():Promise.resolve(null),
 db.prepare('SELECT province_id,day,choice,growth FROM z59_events WHERE day=?').bind(day).all(),
 db.prepare("SELECT a.a,a.b,a.status,a.requested_by,COALESCE(t.kind,'defense') kind FROM z54_alliances a LEFT JOIN z59_treaty_details t ON t.a=a.a AND t.b=a.b AND t.status=a.status WHERE a.status IN ('active','pending')").all(),
 user?db.prepare('SELECT old_points,new_points,created_at FROM z59_balance_audit WHERE user_id=? ORDER BY created_at DESC LIMIT 12').bind(user.id).all():Promise.resolve({results:[]}),
 db.prepare('SELECT attacker,defender,winner,loot,created_at FROM z46_wars ORDER BY created_at DESC LIMIT 8').all(),
 db.prepare("SELECT province_id,kind,delta,note,created_at FROM z46_ledger WHERE kind IN ('building','research','shipment','event','investment') ORDER BY created_at DESC LIMIT 12").all(),
 db.prepare('SELECT from_id,to_id,resource,price,created_at FROM z59_trade_shipments ORDER BY created_at DESC LIMIT 12').all(),
 db.prepare("SELECT id,from_id,to_id,resource,price,created_at,status FROM z59_trade_offers WHERE status='pending' ORDER BY created_at DESC LIMIT 35").all(),
 user?db.prepare('SELECT COUNT(*) total FROM transactions WHERE user_id=?').bind(user.id).first():Promise.resolve({total:0}),
 db.prepare("SELECT province_id,SUM(CASE WHEN delta>0 THEN delta ELSE 0 END) earned FROM z46_ledger WHERE created_at>=? AND kind IN ('staff-income','daily','investment','shipment','building') GROUP BY province_id").bind((Math.floor((Math.floor(now/86400000)+3)/7)*7-3)*86400000).all()
 ]);
 const governorIds=pp.results.filter(x=>x.governor_id===user?.id).map(x=>x.id);
 return json({ok:true,now,day,logged_in:!!user,my_id:user?.id||'',my_name:user?.name||'',my_points:user?.points??null,governor_ids:governorIds,admin:!!isAdmin(user),provinces:pp.results,buildings:build.results,research:research.results,chest_claimed:!!chest,chest_reward:chest?.reward||0,events:events.results,alliances:alliances.results,balance_changes:history.results,war_news:wars.results,news:ledger.results,shipments:shipments.results,offers:offers.results,weekly:weekly.results,transactions_count:achievements?.total||0});
}
async function z59AccountAudit(req,db){
 await z59Ensure(db);const head=await getMe(req,db);if(!isAdmin(head))return err(403,'فحص حسابات المواطنين للرئاسة المفعلة فقط');
 const nm=crop(new URL(req.url).searchParams.get('name'),35).trim(),key=norm(nm);if(!key)return err(400,'اكتب اسم المواطن لفحص سجله');
 const user=await db.prepare('SELECT id,name,joined,points FROM users WHERE name_key=?').bind(key).first();if(!user)return err(404,'هذا الاسم غير مسجل في قاعدة البيانات الحالية؛ راجع طريقة كتابة الاسم');
 const [audit,tx]=await Promise.all([
 db.prepare('SELECT old_points,new_points,created_at FROM z59_balance_audit WHERE user_id=? ORDER BY created_at DESC LIMIT 30').bind(user.id).all(),
 db.prepare('SELECT amount,note,created_at FROM transactions WHERE user_id=? ORDER BY created_at DESC LIMIT 45').bind(user.id).all()
 ]);
 return json({ok:true,name:user.name,registered_at:user.joined,current_balance:user.points,audit:audit.results,transactions:tx.results,notice:'التدقيق يبدأ عند تركيب Update 59، ولا يمكن استعادة الأرصدة السابقة دون نسخة احتياطية أو سجلات موثوقة.'});
}
async function z59Action(req,db,p){
 await z59Ensure(db);const u=await getMe(req,db);if(!u)return err(401,'سجّل دخولك من اللعبة الرئيسية أولًا');
 const type=String(p.type||''),now=Date.now(),day=Math.floor(now/86400000),pid=crop(p.province_id,40);
 
 if(type==='treaty_request'||type==='treaty_reply'||type==='treaty_end'){
  await z54Ensure(db);
  const to=crop(p.target,40),kind=crop(p.kind,20);
  if(type==='treaty_request'&&!Z59_KINDS.includes(kind))return err(400,'اختر نوع المعاهدة');
  if(to===pid)return err(400,'لا يمكن إقامة معاهدة مع نفس الدولة');
  const [a,b]=z54Pair(pid,to);
  const actionType=type==='treaty_request'?'alliance_request':type==='treaty_reply'?'alliance_reply':'alliance_end';
  const result=await z54Action(db,u,{...p,type:actionType,province_id:pid,target:to},now);
  if(result.status===200){
   if(type==='treaty_request')await db.prepare("INSERT INTO z59_treaty_details(a,b,kind,status,requested_by,created_at,expires_at) VALUES(?,?,?,'pending',?,?,0) ON CONFLICT(a,b,kind) DO UPDATE SET status='pending',requested_by=excluded.requested_by,created_at=excluded.created_at WHERE status IN ('ended','rejected')").bind(a,b,kind,pid,now).run();
   if(type==='treaty_reply')await db.prepare("UPDATE z59_treaty_details SET status=? WHERE a=? AND b=? AND status='pending'").bind(p.accept===true?'active':'rejected',a,b).run();
   if(type==='treaty_end')await db.prepare("UPDATE z59_treaty_details SET status='ended' WHERE a=? AND b=? AND status='active'").bind(a,b).run();
  }
  return result;
 }
if(type==='chest'){
  const n=Z59_CHEST_PRIZES[(day+Array.from(u.id).reduce((a,c)=>a+c.charCodeAt(0),0))%Z59_CHEST_PRIZES.length];
  const rid=crop(p.request_id,80);if(!/^[a-f0-9-]{36}$/i.test(rid))return err(400,'معرف العملية غير صالح');
  const row=await db.prepare('INSERT OR IGNORE INTO z59_daily_chests(id,user_id,day,reward,created_at) VALUES(?,?,?,?,?) RETURNING reward').bind(rid,u.id,day,n,now).first();if(!row)return err(409,'استلمت صندوق اليوم بالفعل');return json({ok:true,notice:'🎁 ربحت '+n+' زنجر في صندوق اليوم'});
 }
 const pr=await db.prepare('SELECT * FROM z46_provinces WHERE id=?').bind(pid).first();if(!pr)return err(404,'الدولة غير موجودة');
 if(!isAdmin(u)&&pr.governor_id!==u.id)return err(403,'التطوير من صلاحيات رئيس الدولة المعيّن فقط');
 const rid=crop(p.request_id,80);if(!/^[a-f0-9-]{36}$/i.test(rid))return err(400,'رقم عملية غير صالح');
 if(type==='building'||type==='research'){
  const kind=crop(p.kind,25),info=type==='building'?Z59_BLD[kind]:Z59_TECH[kind];if(!info)return err(400,'نوع تطوير غير معروف');
  const tbl=type==='building'?'z59_buildings':'z59_research',prev=await db.prepare('SELECT MAX(level) n FROM '+tbl+' WHERE province_id=? AND kind=?').bind(pid,kind).first(),level=Number(prev?.n||0)+1;
  if(level>5)return err(409,'وصل هذا التطوير إلى المستوى الخامس');const cost=info.base*level,income=type==='building'?info.gain*level:0;
  try{if(type==='building')await db.prepare('INSERT INTO z59_buildings(id,province_id,kind,level,cost,income,actor_id,created_at) VALUES(?,?,?,?,?,?,?,?)').bind(rid,pid,kind,level,cost,income,u.id,now).run();else await db.prepare('INSERT INTO z59_research(id,province_id,kind,level,cost,actor_id,created_at) VALUES(?,?,?,?,?,?,?)').bind(rid,pid,kind,level,cost,u.id,now).run();}
  catch(e){return err(409,'التطوير لم يتم: قد يكون تم شراؤه أو الخزينة لا تكفي. حدّث الصفحة.');}
  return json({ok:true,notice:'تم تطوير '+info.name+' للمستوى '+level+' بتكلفة '+cost+' زنجر'});
 }
 if(type==='shipment'){
  const to=crop(p.to_id,40),resource=crop(p.resource,40),price=Number(p.price);if(!['محاصيل','معادن','معدات','أدوية'].includes(resource)||to===pid||!Number.isSafeInteger(price)||price<100||price>50000)return err(400,'بيانات الشحنة غير صالحة');
  if(!await db.prepare('SELECT 1 FROM z46_provinces WHERE id=?').bind(to).first())return err(404,'الدولة المستلمة غير موجودة');
  await db.prepare("INSERT OR IGNORE INTO z59_trade_offers(id,from_id,to_id,resource,price,actor_id,created_at,status) VALUES(?,?,?,?,?,?,?,'pending')").bind(rid,pid,to,resource,price,u.id,now).run();
  const receiver=await db.prepare('SELECT governor_id FROM z46_provinces WHERE id=?').bind(to).first();
  if(receiver?.governor_id)try{await zNotify(db,receiver.governor_id,'🚚 عرض شحنة من '+pr.name,resource+' بقيمة '+price+' زنجر؛ افتح مركز التطوير وقبّل أو ارفض.','government');}catch(e){}
  return json({ok:true,notice:'تم إرسال عرض الشحنة للمستلم. لن تُخصم أموال منه إلا بعد قبوله.'});
 }
 if(type==='shipment_decide'){
  const offerId=crop(p.offer_id,80),accept=p.accept===true;
  const offer=await db.prepare("SELECT * FROM z59_trade_offers WHERE id=? AND status='pending'").bind(offerId).first();if(!offer)return err(409,'الشحنة تمت الموافقة عليها أو انتهت مسبقًا');
  if(offer.to_id!==pid)return err(403,'صاحب المحافظة المستلمة فقط يوافق على الشحنة');
  try{
   if(accept)await db.batch([
    db.prepare('INSERT INTO z59_trade_shipments(id,from_id,to_id,resource,price,actor_id,created_at) VALUES(?,?,?,?,?,?,?)').bind(offer.id,offer.from_id,offer.to_id,offer.resource,offer.price,u.id,now),
    db.prepare("UPDATE z59_trade_offers SET status='accepted',decided_at=? WHERE id=? AND status='pending'").bind(now,offer.id)
   ]);
   else await db.prepare("UPDATE z59_trade_offers SET status='rejected',decided_at=? WHERE id=? AND status='pending'").bind(now,offer.id).run();
  }catch(e){return err(409,'لم تُخصم أي أموال. تأكد من كفاية خزينة المحافظة، أو أن العرض لم يُنفذ من قبل.');}
  return json({ok:true,notice:accept?'استلمت الشحنة وانتقلت قيمتها بين الخزائن بنجاح':'تم رفض الشحنة دون أي خصم'});
 }
 if(type==='event'){
  const choice=Number(p.choice);if(![1,2,3].includes(choice))return err(400,'اختر القرار المناسب');const cost=[0,800,2000][choice-1],growth=[-500,500,2000][choice-1];
  try{await db.prepare('INSERT INTO z59_events(id,province_id,day,choice,cost,growth,actor_id,created_at) VALUES(?,?,?,?,?,?,?,?)').bind(rid,pid,day,choice,cost,growth,u.id,now).run();}catch(e){return err(409,'تم التعامل مع أزمة اليوم أو الخزينة لا تكفي');}
  return json({ok:true,notice:'تم اعتماد قرار مواجهة الأزمة اليومية'});
 }
 return err(400,'عملية غير معروفة');
}

async function z54Advance(db,now=Date.now()){return []; // Update 62: no scheduled battles

 await z59Ensure(db);
 const due=(await db.prepare("SELECT * FROM z54_plans WHERE status='pending' AND starts_at<=? ORDER BY starts_at ASC LIMIT 8").bind(now).all()).results;
 for(const w of due){
  // Use the existing z46_wars triggers for genuine troop costs and original game balance.
  const past=await db.prepare('SELECT id,winner,loot,created_at FROM z46_wars WHERE id=?').bind(w.id).first();
  if(past){await db.prepare('UPDATE z46_provinces SET war_lock_until=MIN(war_lock_until,?) WHERE id IN (?,?)').bind(Number(past.created_at||now)+Z55_COOLDOWN_MS,w.attacker,w.defender).run();await db.prepare("UPDATE z54_plans SET status='completed',completed_at=?,winner=?,loot=? WHERE id=? AND status='pending'").bind(now,past.winner,past.loot,w.id).run();continue;}
  const [att,def,sup]=(await Promise.all([db.prepare('SELECT * FROM z46_provinces WHERE id=?').bind(w.attacker).first(),db.prepare('SELECT * FROM z46_provinces WHERE id=?').bind(w.defender).first(),db.prepare('SELECT * FROM z54_support WHERE plan_id=?').bind(w.id).all()]));
  if(!att||!def)continue;
  const used={soldiers:w.soldiers,missiles:w.missiles,planes:w.planes,ships:w.ships};
  if(['soldiers','missiles','planes','ships'].some(k=>Number(att[k])<Number(used[k])) || Number(att.war_lock_until)>now || Number(def.war_lock_until)>now){
   // Cancel only when a settlement is impossible; reserved ally units are refunded once.
   const cancelled=await db.prepare("UPDATE z54_plans SET status='cancelled',completed_at=? WHERE id=? AND status='pending' RETURNING id").bind(now,w.id).first();
   // Database trigger refunds every participating ally atomically when a plan is cancelled.
   continue;
  }
  const aSide=sup.results.filter(v=>v.side==='attacker'), dSide=sup.results.filter(v=>v.side==='defender');
  const stopped=await db.prepare('SELECT intercepted_count FROM z55_intercepts WHERE plan_id=?').bind(w.id).first();
  const effective={...used,missiles:Math.max(0,Number(used.missiles)-Number(stopped?.intercepted_count||0))};
  const [trainingA,trainingD,radarD,baseD]=await Promise.all([
   db.prepare("SELECT COALESCE(MAX(level),0) level FROM z59_research WHERE province_id=? AND kind='training'").bind(w.attacker).first(),
   db.prepare("SELECT COALESCE(MAX(level),0) level FROM z59_research WHERE province_id=? AND kind='training'").bind(w.defender).first(),
   db.prepare("SELECT COALESCE(MAX(level),0) level FROM z59_research WHERE province_id=? AND kind='radar'").bind(w.defender).first(),
   db.prepare("SELECT COALESCE(MAX(level),0) level FROM z59_buildings WHERE province_id=? AND kind='military'").bind(w.defender).first()
  ]);
  const ap=(z54Power(effective)+aSide.reduce((v,x)=>v+z54Power(x),0))*(1+Number(trainingA?.level||0)*.04);
  const dp=(z54Power(def)+dSide.reduce((v,x)=>v+z54Power(x),0))*(1+Number(trainingD?.level||0)*.04+Number(radarD?.level||0)*.04+Number(baseD?.level||0)*.025);
  const attackPower=ap*(.85+crypto.getRandomValues(new Uint32Array(1))[0]/4294967295*.30), defendPower=dp*(.70+crypto.getRandomValues(new Uint32Array(1))[0]/4294967295*.30);
  const won=attackPower>defendPower,loot=won?Math.min(130000,Number(w.requested_loot),Number(def.treasury)):0;
  try{
   await db.prepare('INSERT INTO z46_wars(id,attacker,defender,actor_id,soldiers,missiles,planes,ships,winner,loot,created_at) VALUES(?,?,?,?,?,?,?,?,?,?,?)').bind(w.id,w.attacker,w.defender,w.actor_id,w.soldiers,w.missiles,w.planes,w.ships,won?w.attacker:w.defender,loot,now).run();
  }catch(e){console.error('z54 settlement retry',w.id,String(e));continue;}
  await db.prepare('UPDATE z46_provinces SET war_lock_until=MIN(war_lock_until,?) WHERE id IN (?,?)').bind(now+Z55_COOLDOWN_MS,w.attacker,w.defender).run();
  await db.prepare("UPDATE z54_plans SET status='completed',completed_at=?,winner=?,loot=? WHERE id=? AND status='pending'").bind(now,won?w.attacker:w.defender,loot,w.id).run();
  // Award at most 25% of real loot to actively contributing attacking allies.
  if(won&&loot>0&&aSide.length){const powerTotal=aSide.reduce((v,x)=>v+z54Power(x),0);let distributed=0;for(const c of aSide){const amount=Math.max(0,Math.floor(.25*loot*z54Power(c)/powerTotal));if(!amount)continue;distributed+=amount;await db.prepare('INSERT OR IGNORE INTO z54_allied_rewards(plan_id,province_id,amount) VALUES(?,?,?)').bind(w.id,c.province_id,amount).run();}}
  const attackerName=att.name,defenderName=def.name,title='⚔️ نتيجة الحرب';const notice=(won?attackerName:defenderName)+' انتصرت في المعركة بين '+attackerName+' و'+defenderName+'. الغنائم: '+loot+' زنجر.';
  for(const govId of new Set([att.governor_id,def.governor_id,...sup.results.map(x=>x.actor_id)].filter(Boolean)))try{await zNotify(db,govId,title,notice,'war');}catch(e){console.warn('z54 notify',e);}
 }
}
async function z54Action(db,u,p,now=Date.now()){return err(403,Z62_PEACE_MESSAGE); // Update 62 archived military actions

 const type=p.type;const pid=crop(p.province_id,40),province=await db.prepare('SELECT * FROM z46_provinces WHERE id=?').bind(pid).first(),admin=isAdmin(u),governor=province&&(admin||province.governor_id===u.id);
 if(type==='radar_auto57'){
  // A paid virtual anti-missile is auto-guided using the server-side target bearing.
  // Existing stock was already bought; if stock is empty, buy exactly one unit for 1,500 Zangar.
  // D1 batch runs the purchase and intercept in one transaction, so a failed intercept cannot charge a wallet.
  if(!governor)return err(403,'الاعتراض التلقائي متاح لرئيس الدولة المدافعة أو الرئاسة المركزية فقط');
  const planId=crop(p.plan_id,80);
  const war=await db.prepare("SELECT * FROM z54_plans WHERE id=? AND status='pending'").bind(planId).first();
  if(!war||war.defender!==pid||Number(war.missiles)<1||Number(war.starts_at)<=now)return err(409,'لا يوجد هجوم صاروخي نشط يمكن اعتراضه الآن');
  const exists=await db.prepare('SELECT plan_id FROM z55_intercepts WHERE plan_id=?').bind(planId).first();
  if(exists)return err(409,'تم إطلاق صاروخ اعتراض لهذا الهجوم بالفعل؛ لن تخصم أي أموال إضافية');
  const stock=Number(province.missiles||0),needsPurchase=stock<1;
  if(needsPurchase&&Number(province.treasury)<1500)return err(409,'خزينة الدولة لا تكفي لشراء صاروخ الاعتراض (1,500 زنجر)');
  const direction=z55Angle(planId);
  const insert=db.prepare('INSERT INTO z55_intercepts(plan_id,defender,actor_id,aim_angle,expected_angle,intercepted_count,created_at) VALUES(?,?,?,?,?,?,?)').bind(planId,pid,u.id,direction,direction,1,now);
  try{
   if(needsPurchase){
    const buy=db.prepare('INSERT OR IGNORE INTO z46_recruits(id,province_id,actor_id,unit,qty,cost,created_at) VALUES(?,?,?,?,?,?,?)').bind('z57-auto-'+planId,pid,u.id,'missiles',1,1500,now);
    await db.batch([buy,insert]);
   }else await insert.run();
  }catch(e){console.warn('Automatic virtual radar intercept rejected',String(e));return err(409,'لم يُنفذ الاعتراض أو الخصم. ربما انتهت المهلة أو تم الاعتراض بالفعل؛ حدّث الرادار وحاول مرة أخرى');}
  return json({ok:true,success:true,intercepted_count:1,spent:needsPurchase?1500:0,notice:needsPurchase?'🛡️ تم شراء صاروخ دفاعي مقابل 1,500 زنجر وإطلاقه تلقائيًا وصد صاروخ مهاجم!':'🛡️ تم إطلاق صاروخ من المخزون المدفوع سابقًا وصد صاروخ مهاجم تلقائيًا!'});
 }
 if(type==='radar_intercept55'){
  if(!governor)return err(403,'الدفاع بالرادار خاص برئيس الدولة المستهدفة أو الرئاسة المركزية');
  const planId=crop(p.plan_id,80);
  const w=await db.prepare("SELECT * FROM z54_plans WHERE id=? AND status='pending'").bind(planId).first();
  if(!w||w.defender!==pid||Number(w.missiles)<1||Number(w.starts_at)<=now)return err(409,'لا توجد صواريخ واردة في فترة الاستعداد لهذه الدولة');
  const angle=Number(p.angle);
  if(!Number.isSafeInteger(angle)||angle<0||angle>=360)return err(400,'حدد الاتجاه على الرادار أولًا');
  const expected=z55Angle(planId),diff=Math.abs((angle-expected+540)%360-180);
  const count=diff<=20?1:0;
  try{
    const r=await db.prepare('INSERT OR IGNORE INTO z55_intercepts(plan_id,defender,actor_id,aim_angle,expected_angle,intercepted_count,created_at) VALUES(?,?,?,?,?,?,?) RETURNING plan_id').bind(planId,pid,u.id,angle,expected,count,now).first();
    if(!r)return err(409,'تم تنفيذ اعتراض لهذا الهجوم بالفعل');
  }catch(e){console.warn('z55 radar intercept',e);return err(409,'تعذر إطلاق الاعتراض. تحقق من مخزون الصواريخ وحالة الحرب');}
  return json({ok:true,success:!!count,intercepted_count:count,notice:count?'🛡️ اعتراض ناجح! تم تحييد صاروخ مهاجم واحد، وخُصم صاروخ دفاعي من مخزونك.':'🚨 لم يصب الاعتراض الهدف. استُخدم صاروخ دفاعي، وراقب زاوية الهدف في المهمة القادمة.'});
 }
 if(type==='alliance_request'){
  if(!governor)return err(403,'التحالف لرئيس الدولة فقط');const tid=crop(p.target,40),target=await db.prepare('SELECT * FROM z46_provinces WHERE id=?').bind(tid).first();if(!target||tid===pid)return err(400,'اختر دولة أخرى');const [a,b]=z54Pair(pid,tid),existing=await db.prepare('SELECT status FROM z54_alliances WHERE a=? AND b=?').bind(a,b).first();if(existing&&['pending','active'].includes(existing.status))return err(409,'يوجد طلب أو تحالف بالفعل');
  await db.prepare("INSERT INTO z54_alliances(a,b,status,requested_by,created_at,decided_at) VALUES(?,?,'pending',?,?,0) ON CONFLICT(a,b) DO UPDATE SET status='pending',requested_by=excluded.requested_by,created_at=excluded.created_at,decided_at=0 WHERE status IN ('ended','rejected')").bind(a,b,pid,now).run();
  if(target.governor_id)await zNotify(db,target.governor_id,'🤝 طلب تحالف جديد',province.name+' تدعوك إلى تحالف عسكري متبادل. افتح تبويب التحالفات.','war');return json({ok:true,notice:'تم إرسال طلب التحالف'});
 }
 if(type==='alliance_reply'){
  if(!governor)return err(403,'صلاحية رئيس الدولة فقط');const other=crop(p.target,40),[a,b]=z54Pair(pid,other),row=await db.prepare('SELECT * FROM z54_alliances WHERE a=? AND b=?').bind(a,b).first();if(!row||row.status!=='pending'||row.requested_by===pid)return err(409,'لا يوجد طلب تحالف وارد');const ok=p.accept===true;
  await db.prepare("UPDATE z54_alliances SET status=?,decided_at=? WHERE a=? AND b=? AND status='pending'").bind(ok?'active':'rejected',now,a,b).run();const requester=await db.prepare('SELECT governor_id,name FROM z46_provinces WHERE id=?').bind(row.requested_by).first();if(requester?.governor_id)await zNotify(db,requester.governor_id,'🤝 رد التحالف',province.name+(ok?' وافقت على التحالف.':' رفضت طلب التحالف.'),'war');return json({ok:true,notice:ok?'تم تفعيل التحالف المتبادل':'تم رفض الطلب'});
 }
 if(type==='alliance_end'){
  if(!governor)return err(403,'صلاحية رئيس الدولة فقط');const other=crop(p.target,40),[a,b]=z54Pair(pid,other),row=await db.prepare("UPDATE z54_alliances SET status='ended',decided_at=? WHERE a=? AND b=? AND status='active' RETURNING a").bind(now,a,b).first();if(!row)return err(409,'التحالف غير نشط');return json({ok:true,notice:'تم إنهاء التحالف'});
 }
 if(type==='war'||type==='prepare_war'){
  if(!governor)return err(403,'الحرب متاحة لرئيس الدولة فقط');const target=await db.prepare('SELECT * FROM z46_provinces WHERE id=?').bind(crop(p.target,40)).first();if(!target||target.id===pid)return err(400,'اختر دولة أخرى');
  const units={};for(const k of ['soldiers','missiles','planes','ships']){units[k]=Number(p[k]||0);if(!Number.isSafeInteger(units[k])||units[k]<0||units[k]>9999||units[k]>Number(province[k]))return err(400,'عدد القوات غير متاح');}if(units.soldiers<10)return err(400,'اختر على الأقل 10 جنود');
  const loot=Number(p.requested_loot??130000);if(!Number.isSafeInteger(loot)||loot<0||loot>130000)return err(400,'الغنائم حتى 130,000');if(province.war_lock_until>now||target.war_lock_until>now){const left=Math.ceil((Math.max(Number(province.war_lock_until||0),Number(target.war_lock_until||0))-now)/60000);return err(409,'الحرب متاحة بعد '+left+' دقيقة. الدولة المهاجمة أو المستهدفة في فترة راحة.');}
  const alliedTarget=await db.prepare("SELECT 1 FROM z54_alliances WHERE status='active' AND ((a=? AND b=?) OR (a=? AND b=?))").bind(pid,target.id,target.id,pid).first();if(alliedTarget)return err(409,'لا يمكن بدء حرب على دولة بينكم معاهدة نشطة؛ أنهِ المعاهدة أولًا');
  const pending=await db.prepare("SELECT id FROM z54_plans WHERE status='pending' AND (attacker IN (?,?) OR defender IN (?,?)) LIMIT 1").bind(pid,target.id,pid,target.id).first();if(pending)return err(409,'هناك حرب معلقة لإحدى الدولتين');
  const rid=crop(p.request_id,80);if(!/^[0-9a-f-]{36}$/i.test(rid))return err(400,'رقم الطلب غير صحيح');const created=await db.prepare("INSERT OR IGNORE INTO z54_plans(id,attacker,defender,actor_id,soldiers,missiles,planes,ships,requested_loot,created_at,starts_at,status) VALUES(?,?,?,?,?,?,?,?,?,?,?,'pending') RETURNING id").bind(rid,pid,target.id,u.id,units.soldiers,units.missiles,units.planes,units.ships,loot,now,now+Z54_PREPARE_MS).first();if(!created)return err(409,'تم إعلان الحرب من قبل');
  const allied=(await db.prepare("SELECT a,b FROM z54_alliances WHERE status='active' AND (a IN (?,?) OR b IN (?,?))").bind(pid,target.id,pid,target.id).all()).results;const ids=new Set([target.governor_id]);for(const row of allied){const other=row.a===pid||row.a===target.id?row.b:row.a;const pr=await db.prepare('SELECT governor_id FROM z46_provinces WHERE id=?').bind(other).first();if(pr?.governor_id)ids.add(pr.governor_id);}
  for(const gid of ids)if(gid&&gid!==u.id)try{const isDefenseAlly=(await db.prepare("SELECT 1 FROM z46_provinces p JOIN z54_alliances a ON a.status='active' AND ((a.a=p.id AND a.b=?) OR (a.b=p.id AND a.a=?)) WHERE p.governor_id=? LIMIT 1").bind(target.id,target.id,gid).first());await zNotify(db,gid,isDefenseAlly?'🚨 حليفتك تتعرض لهجوم!':'🚨 حرب قادمة',(isDefenseAlly?'حليفتك '+target.name+' تتعرض لهجوم من '+province.name+'. ادخل التحالفات وأرسل قواتك للدفاع قبل بدء المعركة. ':province.name+' أعلنت هجومًا على '+target.name+'. ')+'يبدأ خلال 10 دقائق أو عند ضغط بدء الآن.','war');}catch(e){console.warn('war announce:',e)}
  return json({ok:true,notice:'أُعلن الاستعداد للحرب. 10 دقائق أو اضغط بدء الحرب الآن لتخطي الانتظار.'});
 }
 if(type==='start_war_now'){
  const plan=await db.prepare("SELECT * FROM z54_plans WHERE id=? AND status='pending'").bind(crop(p.plan_id,80)).first();if(!plan)return err(409,'المعركة انتهت أو غير موجودة');const att=await db.prepare('SELECT governor_id FROM z46_provinces WHERE id=?').bind(plan.attacker).first();if(!admin&&att?.governor_id!==u.id)return err(403,'تخطي المهلة لقائد الدولة المهاجمة فقط');
  await db.prepare("UPDATE z54_plans SET starts_at=? WHERE id=? AND status='pending'").bind(now,plan.id).run();await z54Advance(db,now);const after=await db.prepare('SELECT status FROM z54_plans WHERE id=?').bind(plan.id).first();return json({ok:true,notice:after?.status==='completed'?'انتهت المعركة، شاهد النتيجة الآن':'جارٍ حسم المعركة؛ حدّث بعد قليل'});
 }
 if(type==='allied_support'){
  if(!governor)return err(403,'رئيس الدولة فقط');const plan=await db.prepare("SELECT * FROM z54_plans WHERE id=? AND status='pending'").bind(crop(p.plan_id,80)).first();if(!plan||plan.starts_at<=now)return err(409,'انتهت فترة دعم المعركة');if([plan.attacker,plan.defender].includes(pid))return err(400,'دولتا الحرب مشاركتان أساسًا');const side=crop(p.side,20);if(!['attacker','defender'].includes(side))return err(400,'حدد الطرف الذي ستدعمه');const units={};for(const k of ['soldiers','missiles','planes','ships']){units[k]=Number(p[k]||0);if(!Number.isSafeInteger(units[k])||units[k]<0||units[k]>9999)return err(400,'كمية غير صالحة');}if(Object.values(units).every(v=>v===0))return err(400,'اختر قوات للدعم');
  await db.prepare('INSERT INTO z54_support(plan_id,province_id,side,actor_id,soldiers,missiles,planes,ships,created_at) VALUES(?,?,?,?,?,?,?,?,?)').bind(plan.id,pid,side,u.id,units.soldiers,units.missiles,units.planes,units.ships,now).run();return json({ok:true,notice:'تم حجز القوات وإضافتها إلى صف الحليف. القوات المشاركة قد تُستهلك في المعركة.'});
 }
 if(type==='reduce_rest'){
  if(!governor)return err(403,'تقليل الراحة لرئيس الدولة فقط');if(Number(province.war_lock_until)<=now)return err(409,'لا توجد فترة راحة حالية');const last=await db.prepare('SELECT id,created_at FROM z46_wars WHERE attacker=? OR defender=? ORDER BY created_at DESC LIMIT 1').bind(pid,pid).first();if(!last)return err(409,'لا توجد معركة مرتبطة بفترة الراحة');const shorter=Math.min(Number(province.war_lock_until),now+Z54_REST_SHORT_MS);
  const done=await db.prepare('INSERT OR IGNORE INTO z54_rest_reductions(province_id,battle_id,used_at,new_until) VALUES(?,?,?,?) RETURNING battle_id').bind(pid,last.id,now,shorter).first();if(!done)return err(409,'استخدمت زر تقليل الوقت لهذه المعركة بالفعل');await db.prepare('UPDATE z46_provinces SET war_lock_until=MIN(war_lock_until,?) WHERE id=?').bind(shorter,pid).run();return json({ok:true,notice:'تم تقليل فترة الراحة مرة واحدة، المتبقي 15 دقيقة بحد أقصى'});
 }
 return err(400,'إجراء غير معروف');
}

async function z46State(req,db){
 const u=await getMe(req,db);if(u)await z46MemberEnsure(db,u);await z59Ensure(db);await z46Tick(db);await z54Ensure(db);await z54Advance(db);
 const [p,m,events,warRows,candidates,virtualClocks]=await Promise.all([
  db.prepare("SELECT * FROM z46_provinces ORDER BY CASE id WHEN 'home' THEN 0 WHEN 'oasis' THEN 1 WHEN 'mountains' THEN 2 WHEN 'falcons' THEN 3 WHEN 'islands' THEN 4 WHEN 'sands' THEN 5 WHEN 'noor' THEN 6 WHEN 'barq' THEN 7 ELSE 8 END").all(),
  u?db.prepare('SELECT province_id,changed_at FROM z46_members WHERE user_id=?').bind(u.id).first():Promise.resolve(null),
  db.prepare("SELECT e.province_id,e.kind,e.delta,e.note,e.created_at,p.name province_name FROM z46_ledger e JOIN z46_provinces p ON p.id=e.province_id WHERE (?=1 OR e.kind!='central_gift') ORDER BY e.created_at DESC LIMIT 25").bind(isAdmin(u)?1:0).all(),
  db.prepare('SELECT id,attacker,defender,winner,loot,soldiers,missiles,planes,ships,created_at FROM z46_wars ORDER BY created_at DESC LIMIT 30').all(),
  isAdmin(u)?db.prepare('SELECT id,name FROM users ORDER BY name LIMIT 1000').all():Promise.resolve({results:[]}),
  db.prepare('SELECT province_id,last_slot,total_earned FROM z48_virtual_clock').all()
 ]);
 const ids=p.results.map(x=>x.governor_id).filter(Boolean);
 const govs=ids.length?(await db.prepare(`SELECT id,name FROM users WHERE id IN (${ids.map(()=>'?').join(',')})`).bind(...ids).all()).results:[];
 const provinces=p.results.map(x=>{const clock=virtualClocks.results.find(v=>v.province_id===x.id);return {...x,governor_name:govs.find(g=>g.id===x.governor_id)?.name||'',can_manage:z46Governor(u,x),virtual_workers:x.id==='home'?50:20,virtual_total:Number(clock?.total_earned||0),virtual_on_shift:x.id==='home'||Math.floor(Date.now()/3600000)%2===0,virtual_hourly_amount:x.id==='home'?5000:1000,virtual_individual_total:Number(clock?.total_earned||0)/(x.id==='home'?50:20),virtual_individual_hourly:x.id==='home'?100:50};});
 const z54Alliances=(await db.prepare('SELECT * FROM z54_alliances ORDER BY created_at DESC').all()).results;
 const z54Plans=(await db.prepare('SELECT * FROM z54_plans ORDER BY created_at DESC LIMIT 50').all()).results;
 const z54Support=(await db.prepare('SELECT * FROM z54_support ORDER BY created_at DESC LIMIT 100').all()).results;
 const z55Intercepts=u?(await db.prepare('SELECT i.plan_id,i.defender,i.aim_angle,i.intercepted_count,i.created_at FROM z55_intercepts i JOIN z46_provinces p ON p.id=i.defender WHERE (?=1 OR p.governor_id=?) ORDER BY i.created_at DESC LIMIT 30').bind(isAdmin(u)?1:0,u.id).all()).results:[];
 const z54Rest=(await db.prepare('SELECT * FROM z54_rest_reductions ORDER BY used_at DESC LIMIT 40').all()).results;
 const transfers=u?(await db.prepare(`SELECT t.id,t.from_id,t.to_id,t.actor_id,t.unit,t.qty,t.status,t.created_at FROM z49_unit_transfers t WHERE t.status='pending' AND (t.actor_id=? OR t.to_id IN (SELECT id FROM z46_provinces WHERE governor_id=?) OR ?=1) ORDER BY t.created_at DESC LIMIT 40`).bind(u.id,u.id,isAdmin(u)?1:0).all()).results:[];
 const myGovernor=provinces.find(x=>x.governor_id===u?.id)||null;
 const myProvince=m?.province_id||'home';let myMembers=[];
 if(u&&(isAdmin(u)||myGovernor)){
  const wanted=isAdmin(u)?null:myGovernor.id;
  const rs=wanted?await db.prepare('SELECT u.id,u.name,m.province_id FROM z46_members m JOIN users u ON u.id=m.user_id WHERE m.province_id=? ORDER BY u.name LIMIT 200').bind(wanted).all():await db.prepare('SELECT u.id,u.name,m.province_id FROM z46_members m JOIN users u ON u.id=m.user_id ORDER BY u.name LIMIT 300').all();myMembers=rs.results;
 }
 return json({ok:true,version:Z41_BUILD,now:Date.now(),admin:!!isAdmin(u),citizen:!!u,my_id:u?.id||'',my_province:myProvince,my_change_at:m?.changed_at||0,my_governor:myGovernor?.id||'',provinces,alliances:z54Alliances,wars_pending:z54Plans,war_support:z54Support,radar_intercepts:z55Intercepts,rest_shortcuts:z54Rest,member_count:(await db.prepare('SELECT province_id,COUNT(*) num FROM z46_members GROUP BY province_id').all()).results,available_citizens:candidates.results,members:myMembers,ledger:events.results,battles:Array.isArray(warRows?.results)?warRows.results:[],transfers,fee:Z46_DAILY_FEE,treasury_note:'خزينة دولة الزنجر الأصلية موحدة مع رصيد الدولة الرئيسية في الاتحاد؛ باقي خزائن الدول مستقلة عن محافظ المواطنين'});
}
