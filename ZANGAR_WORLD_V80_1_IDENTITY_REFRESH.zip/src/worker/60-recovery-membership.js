// Update 60: assisted recovery of EXISTING accounts only. Never creates users or edits balances.
// Codes are one-time, private, 30 minute tokens approved by an authenticated 2-step president.
async function z60RecoveryEnsure(db){
 await db.batch([
  db.prepare("CREATE TABLE IF NOT EXISTS z60_recovery_requests (id TEXT PRIMARY KEY,user_id TEXT NOT NULL,name TEXT NOT NULL,contact_hint TEXT NOT NULL DEFAULT '',status TEXT NOT NULL DEFAULT 'pending',created_at INTEGER NOT NULL,code_hash TEXT NOT NULL DEFAULT '',expires_at INTEGER NOT NULL DEFAULT 0,attempts INTEGER NOT NULL DEFAULT 0,processed_by TEXT NOT NULL DEFAULT '',processed_at INTEGER NOT NULL DEFAULT 0,redeemed_at INTEGER NOT NULL DEFAULT 0,nonce TEXT NOT NULL DEFAULT '')"),
  db.prepare('CREATE INDEX IF NOT EXISTS z60_recovery_by_user ON z60_recovery_requests(user_id,created_at DESC)'),
  db.prepare('CREATE TABLE IF NOT EXISTS z60_recovery_rate(visitor_hash TEXT PRIMARY KEY,window_start INTEGER NOT NULL,attempts INTEGER NOT NULL)')
 ]);
}
const z60Alphabet='ABCDEFGHJKLMNPQRSTUVWXYZ23456789';
function z60NewCode(){const b=crypto.getRandomValues(new Uint8Array(20));return [...b].map(v=>z60Alphabet[v&31]).join('')}
async function z60RecoveryRequest(req,db,p){
 await z60RecoveryEnsure(db);
 const name=crop(p.name,35),key=norm(name),hint=crop(p.hint,180),now=Date.now();
 if(!key||name.length<2)return err(400,'اكتب اسم المواطن القديم');
 if(hint.length<8)return err(400,'اكتب وسيلة تواصل أو تفاصيل تساعد الإدارة على التأكد أنك صاحب الحساب، بدون أي كلمة مرور');
 const source=crop(req.headers.get('CF-Connecting-IP')||req.headers.get('X-Forwarded-For')||'unknown',100);
 const visitor=await digest('z60|'+source);
 await db.prepare("INSERT INTO z60_recovery_rate(visitor_hash,window_start,attempts) VALUES(?,?,1) ON CONFLICT(visitor_hash) DO UPDATE SET window_start=CASE WHEN ?-window_start>3600000 THEN ? ELSE window_start END,attempts=CASE WHEN ?-window_start>3600000 THEN 1 ELSE attempts+1 END").bind(visitor,now,now,now,now).run();
 const rate=await db.prepare('SELECT attempts FROM z60_recovery_rate WHERE visitor_hash=?').bind(visitor).first();
 if(Number(rate?.attempts||0)>8)return err(429,'طلبات كثيرة من هذا الجهاز. حاول بعد ساعة');
 const user=await db.prepare('SELECT id,name FROM users WHERE name_key=?').bind(key).first();
 if(user){
  const existing=await db.prepare("SELECT id FROM z60_recovery_requests WHERE user_id=? AND created_at>? AND status IN ('pending','approved') LIMIT 1").bind(user.id,now-3600000).first();
  if(!existing)await db.prepare('INSERT INTO z60_recovery_requests(id,user_id,name,contact_hint,created_at) VALUES(?,?,?,?,?)').bind(id(),user.id,user.name,hint,now).run();
 }
 // Same response for existent/missing account names: no account enumeration.
 return json({ok:true,message:'لو الحساب موجود، وصل طلب الاسترجاع للإدارة. تواصل معها بشكل خاص لإثبات الملكية واستلام رمز مؤقت.'});
}
async function z60RecoveryAdmin(req,db,p){
 await z60RecoveryEnsure(db);
 const admin=await getMe(req,db);
 if(!admin||!isAdmin(admin))return err(403,'افتح الرئاسة بالتحقق بخطوتين قبل مراجعة طلبات الاسترجاع');
 const now=Date.now(),type=crop(p?.type||'list',30);
 if(type==='list'){
  const rows=await db.prepare("SELECT id,name,contact_hint,status,created_at,expires_at,attempts,processed_at FROM z60_recovery_requests WHERE created_at>? ORDER BY created_at DESC LIMIT 60").bind(now-14*86400000).all();
  return json({ok:true,requests:rows.results});
 }
 const reqid=crop(p.id,70),item=await db.prepare('SELECT id,status FROM z60_recovery_requests WHERE id=?').bind(reqid).first();
 if(!item||item.status!=='pending')return err(409,'الطلب غير موجود أو تمت مراجعته');
 if(type==='reject'){
  const done=await db.prepare("UPDATE z60_recovery_requests SET status='rejected',processed_by=?,processed_at=? WHERE id=? AND status='pending' RETURNING id").bind(admin.id,now,reqid).first();
  return done?json({ok:true}):err(409,'تمت معالجة الطلب مسبقًا');
 }
 if(type!=='approve')return err(400,'إجراء غير معروف');
 if(p.verified!==true)return err(400,'لابد من التأكد من هوية صاحب الحساب خارج الموقع أولًا');
 const code=z60NewCode(),hash=await digest('z60-code|'+code),expiry=now+30*60000;
 const done=await db.prepare("UPDATE z60_recovery_requests SET status='approved',code_hash=?,expires_at=?,processed_by=?,processed_at=?,attempts=0 WHERE id=? AND status='pending' RETURNING name").bind(hash,expiry,admin.id,now,reqid).first();
 if(!done)return err(409,'تمت معالجة الطلب مسبقًا');
 // Plaintext code is returned only to the authorized admin THIS ONE TIME.
 return json({ok:true,code,expires_at:expiry,name:done.name,notice:'أرسل الرمز إلى صاحب الحساب بشكل خاص فقط بعد إثبات الملكية. لن يظهر الرمز مرة ثانية.'});
}
async function z60RecoveryReset(req,db,p){
 await z60RecoveryEnsure(db);
 const name=crop(p.name,35),code=String(p.code||'').trim().toUpperCase().replace(/\s/g,''),newSalt=String(p.salt||''),proof=String(p.proof||'');
 if(!norm(name)||!/^[A-HJ-NP-Z2-9]{20}$/.test(code)||!/^[a-f0-9]{32}$/.test(newSalt)||!/^[a-f0-9]{64}$/.test(proof))return err(400,'اسم الحساب أو الرمز أو كلمة المرور الجديدة غير صحيحة');
 const user=await db.prepare('SELECT id FROM users WHERE name_key=?').bind(norm(name)).first();
 const now=Date.now();
 if(!user)return err(400,'تعذر التحقق من الرمز؛ اطلب رمزًا جديدًا من الإدارة');
 const request=await db.prepare("SELECT id,code_hash,attempts FROM z60_recovery_requests WHERE user_id=? AND status='approved' AND expires_at>? ORDER BY processed_at DESC LIMIT 1").bind(user.id,now).first();
 if(!request||Number(request.attempts)>=5)return err(400,'الرمز غير صحيح أو منتهي الصلاحية؛ تواصل مع الإدارة');
 if(!eqSecure(request.code_hash,await digest('z60-code|'+code))){
  await db.prepare("UPDATE z60_recovery_requests SET attempts=attempts+1 WHERE id=? AND status='approved'").bind(request.id).run();
  return err(400,'الرمز غير صحيح أو منتهي الصلاحية؛ تواصل مع الإدارة');
 }
 const nonce=id(),hash='v2:'+await digest('zangar-v2|'+newSalt+'|'+proof);
 const out=await db.batch([
  db.prepare("UPDATE z60_recovery_requests SET status='used',nonce=?,redeemed_at=? WHERE id=? AND status='approved' AND code_hash=? AND attempts<5 AND expires_at>? ").bind(nonce,now,request.id,request.code_hash,now),
  db.prepare('UPDATE users SET salt=?,passhash=? WHERE id=? AND EXISTS(SELECT 1 FROM z60_recovery_requests WHERE id=? AND status=\'used\' AND nonce=?)').bind(newSalt,hash,user.id,request.id,nonce),
  db.prepare('DELETE FROM sessions WHERE user_id=? AND EXISTS(SELECT 1 FROM z60_recovery_requests WHERE id=? AND nonce=?)').bind(user.id,request.id,nonce)
 ]);
 if(Number(out[0]?.meta?.changes||0)!==1||Number(out[1]?.meta?.changes||0)!==1)return err(409,'انتهت صلاحية الرمز؛ اطلب رمزًا جديدًا');
 return json({ok:true,message:'تم تغيير كلمة المرور للحساب القديم نفسه. سجّل الدخول الآن بكلمة المرور الجديدة.'});
}


// ZANGAR WORLD Update 62 — peace-first transition, additive civic administration.
// All old combat tables and historical assets are retained. No live D1 is bundled.
const Z62_PEACE_MESSAGE='Update 62: انتهت الحروب والهجمات والصواريخ بين اللاعبين. القوات القديمة محفوظة للأرشيف الوطني.';
const Z62_COMBAT_ACTIONS=new Set(['war','prepare_war','start_war_now','allied_support','reduce_rest','radar_intercept55','radar_auto57','recruit','rebuild','send_units','resolve_units','grant_unit','alliance_request','alliance_reply','alliance_end','attack','launch','fire','shoot','missile','strike','shell','arm','disarm','battle','invasion','defend','intercept','radar','threat','plan','join_war','send_missiles']);
const Z62_CIVIC_TYPES={school:{name:'مدرسة حكومية',cost:12000,service:'education',points:7},hospital:{name:'مركز صحي',cost:18000,service:'health',points:8},road:{name:'تطوير طريق',cost:10000,service:'infrastructure',points:6},park:{name:'حديقة عامة',cost:6500,service:'community',points:5},water:{name:'شبكة مياه',cost:14000,service:'infrastructure',points:7},transport:{name:'خدمة نقل',cost:16000,service:'infrastructure',points:7}};
const Z62_CAPITALS={home:'مدينة الزنجر',oasis:'مدينة الواحة',mountains:'مدينة الجبال',falcons:'مدينة الصقور',islands:'مدينة الجزر',sands:'مدينة الرمال',noor:'مدينة النور',barq:'مدينة البرق'};
let z62InitPromise=null;
async function z62Ensure(db){
 if(z62InitPromise)return z62InitPromise;
 z62InitPromise=(async()=>{
  await z54Ensure(db); // create old archive tables and cancellation/refund triggers before the migration
  for(const ddl of [
   `CREATE TABLE IF NOT EXISTS z62_province_admin(province_id TEXT PRIMARY KEY,capital TEXT NOT NULL,created_at INTEGER NOT NULL)`,
   `CREATE TABLE IF NOT EXISTS z62_council(province_id TEXT NOT NULL,user_id TEXT NOT NULL,office TEXT NOT NULL CHECK(office IN ('deputy','council')),appointed_at INTEGER NOT NULL,PRIMARY KEY(province_id,user_id))`,
   `CREATE UNIQUE INDEX IF NOT EXISTS z62_single_deputy ON z62_council(province_id) WHERE office='deputy'`,
   `CREATE TABLE IF NOT EXISTS z62_civic_projects(id TEXT PRIMARY KEY,province_id TEXT NOT NULL,author_id TEXT NOT NULL,kind TEXT NOT NULL,title TEXT NOT NULL,description TEXT NOT NULL,status TEXT NOT NULL DEFAULT 'proposed' CHECK(status IN ('proposed','completed','rejected')),cost INTEGER NOT NULL CHECK(cost>0),created_at INTEGER NOT NULL,decided_at INTEGER NOT NULL DEFAULT 0,decided_by TEXT NOT NULL DEFAULT '')`,
   `CREATE INDEX IF NOT EXISTS z62_project_lookup ON z62_civic_projects(province_id,created_at DESC)`,
   `CREATE TABLE IF NOT EXISTS z62_council_votes(project_id TEXT NOT NULL,user_id TEXT NOT NULL,vote TEXT NOT NULL CHECK(vote IN ('yes','no')),created_at INTEGER NOT NULL,PRIMARY KEY(project_id,user_id))`,
   `CREATE TABLE IF NOT EXISTS z62_civic_spend(project_id TEXT PRIMARY KEY,province_id TEXT NOT NULL,actor_id TEXT NOT NULL,cost INTEGER NOT NULL CHECK(cost>0),created_at INTEGER NOT NULL)`,
   `CREATE TRIGGER IF NOT EXISTS z62_civic_validate BEFORE INSERT ON z62_civic_spend BEGIN
     SELECT CASE WHEN NOT EXISTS(SELECT 1 FROM z62_civic_projects WHERE id=NEW.project_id AND province_id=NEW.province_id AND status='proposed' AND cost=NEW.cost) THEN RAISE(ABORT,'المشروع غير صالح أو سبق تنفيذه') END;
     SELECT CASE WHEN NOT EXISTS(SELECT 1 FROM z46_provinces WHERE id=NEW.province_id AND treasury>=NEW.cost) THEN RAISE(ABORT,'ميزانية المحافظة لا تكفي') END;
   END`,
   `CREATE TRIGGER IF NOT EXISTS z62_civic_apply AFTER INSERT ON z62_civic_spend BEGIN
     UPDATE z46_provinces SET treasury=treasury-NEW.cost,economy=economy+CAST(NEW.cost/4 AS INTEGER) WHERE id=NEW.province_id AND treasury>=NEW.cost;
     INSERT INTO z46_ledger(id,province_id,actor_id,kind,delta,note,created_at)
       SELECT 'civic-'||NEW.project_id,NEW.province_id,NEW.actor_id,'civic62',-NEW.cost,'مشروع خدمي: '||title,NEW.created_at FROM z62_civic_projects WHERE id=NEW.project_id;
     UPDATE z62_civic_projects SET status='completed',decided_at=NEW.created_at,decided_by=NEW.actor_id WHERE id=NEW.project_id AND status='proposed';
   END`,
   `CREATE TRIGGER IF NOT EXISTS z62_block_province_wars BEFORE INSERT ON z46_wars BEGIN SELECT RAISE(ABORT,'Update 62: الحروب متوقفة'); END`,
   `CREATE TRIGGER IF NOT EXISTS z62_block_new_battles BEFORE INSERT ON z54_plans BEGIN SELECT RAISE(ABORT,'Update 62: الحروب متوقفة'); END`,
   `CREATE TRIGGER IF NOT EXISTS z62_block_old_battles BEFORE INSERT ON z33_battles BEGIN SELECT RAISE(ABORT,'Update 62: الحروب متوقفة'); END`,
   `CREATE TABLE IF NOT EXISTS z37_war_payouts(battle_id TEXT PRIMARY KEY,actor_id TEXT,created_at INTEGER NOT NULL)`,
   `CREATE TRIGGER IF NOT EXISTS z62_block_war_payout BEFORE INSERT ON z37_war_payouts BEGIN SELECT RAISE(ABORT,'Update 62: مكافآت الحروب متوقفة'); END`
  ])await db.prepare(ddl).run();
  const now=Date.now();
  for(const [pid,capital] of Object.entries(Z62_CAPITALS))await db.prepare('INSERT OR IGNORE INTO z62_province_admin(province_id,capital,created_at) SELECT id,?,? FROM z46_provinces WHERE id=?').bind(capital,now,pid).run();
  // Idempotent conversion: pending battles are cancelled, NOT settled. Existing ally reservation trigger refunds units once.
  await db.prepare("UPDATE z54_plans SET status='cancelled',completed_at=? WHERE status='pending'").bind(now).run();
 })().catch(e=>{z62InitPromise=null;throw e});
 return z62InitPromise;
}
async function z62State(req,db){
 await z62Ensure(db);
 const u=await getMe(req,db);
 const [provinces,profiles,roles,projects,votes,projectsOld,members,national]=await Promise.all([
 db.prepare('SELECT id,name,treasury,economy,governor_id FROM z46_provinces').all(),
 db.prepare('SELECT province_id,capital FROM z62_province_admin').all(),
 db.prepare('SELECT c.province_id,c.user_id,c.office,u.name FROM z62_council c JOIN users u ON u.id=c.user_id ORDER BY c.appointed_at').all(),
 db.prepare('SELECT id,province_id,author_id,kind,title,description,status,cost,created_at,decided_at FROM z62_civic_projects ORDER BY created_at DESC LIMIT 250').all(),
 db.prepare("SELECT project_id,SUM(CASE WHEN vote='yes' THEN 1 ELSE 0 END) yes_votes,SUM(CASE WHEN vote='no' THEN 1 ELSE 0 END) no_votes FROM z62_council_votes GROUP BY project_id").all(),
 db.prepare('SELECT province_id,kind,qty FROM z46_projects').all(),
 db.prepare('SELECT province_id,COUNT(*) n FROM z46_members GROUP BY province_id').all(),
 db.prepare('SELECT COUNT(*) AS archived_count FROM z46_provinces').first()
 ]);
 const rows=provinces.results.map(province=>{
  const mine=projects.results.filter(a=>a.province_id===province.id),built=mine.filter(x=>x.status==='completed');
  const old=projectsOld.results.filter(x=>x.province_id===province.id);
  const education=built.filter(x=>x.kind==='school').length*7;
  const health=built.filter(x=>x.kind==='hospital').length*8;
  const infra=built.reduce((a,x)=>a+(Z62_CIVIC_TYPES[x.kind]?.points||0),0);
  const production=old.reduce((a,x)=>a+Number(x.qty||0)*10,0);
  const population=Number(members.results.find(x=>x.province_id===province.id)?.n||0);
  const score=production+infra+population*2;
  const council=roles.results.filter(x=>x.province_id===province.id);
  return {id:province.id,name:province.name,capital:profiles.results.find(x=>x.province_id===province.id)?.capital||'',governor_id:province.governor_id,treasury:province.treasury,economy:province.economy,population,score,education,health,services:infra,production,projects_count:built.length,can_manage:!!(u&&(isAdmin(u)||province.governor_id===u.id)),is_council:!!(u&&council.some(x=>x.user_id===u.id)),council,projects:mine.map(x=>({...x,votes:votes.results.find(v=>v.project_id===x.id)||{yes_votes:0,no_votes:0},voted:!!(u&&false)}))};
 }).sort((a,b)=>b.score-a.score||a.name.localeCompare(b.name,'ar'));
 return json({ok:true,version:'62',peace_mode:true,provinces:rows,national_defense:{archived_assets:true},my_id:u?.id||'',admin:!!isAdmin(u)});
}
async function z62Action(req,db,p){
 await z62Ensure(db);
 const u=await getMe(req,db);if(!u)return err(401,'سجّل الدخول من اللعبة أولًا');
 const type=crop(p.type,40),pid=crop(p.province_id,40),province=await db.prepare('SELECT * FROM z46_provinces WHERE id=?').bind(pid).first();
 if(!province)return err(404,'المحافظة غير موجودة');
 const admin=isAdmin(u),governor=admin||province.governor_id===u.id;
 const council=await db.prepare('SELECT office FROM z62_council WHERE province_id=? AND user_id=?').bind(pid,u.id).first();
 if(type==='council_assign'){
  if(!governor)return err(403,'تعيين المجلس من صلاحية المحافظ أو الرئاسة المركزية');
  const target=crop(p.user_id,90),office=crop(p.office,20);if(!['deputy','council'].includes(office))return err(400,'الدور غير صالح');
  if(!target||target===province.governor_id)return err(400,'اختر مواطنًا آخر غير المحافظ');
  const eligible=await db.prepare('SELECT user_id FROM z46_members WHERE province_id=? AND user_id=?').bind(pid,target).first();if(!eligible)return err(403,'يجب أن يكون عضو المجلس من سكان المحافظة');
  const people=await db.prepare('SELECT COUNT(*) n FROM z62_council WHERE province_id=?').bind(pid).first();
  if(Number(people.n)>=7&&!await db.prepare('SELECT 1 FROM z62_council WHERE province_id=? AND user_id=?').bind(pid,target).first())return err(409,'الحد الأقصى 7 أعضاء');
  if(office==='deputy'){
   const deputy=await db.prepare("SELECT user_id FROM z62_council WHERE province_id=? AND office='deputy'").bind(pid).first();
   if(deputy&&deputy.user_id!==target)return err(409,'يوجد نائب محافظ بالفعل، اعزله قبل تعيين نائب آخر');
  }
  await db.prepare('INSERT INTO z62_council(province_id,user_id,office,appointed_at) VALUES(?,?,?,?) ON CONFLICT(province_id,user_id) DO UPDATE SET office=excluded.office').bind(pid,target,office,Date.now()).run();
  return json({ok:true,notice:'تم اعتماد التعيين داخل المجلس المحلي'});
 }
 if(type==='council_remove'){
  if(!governor)return err(403,'عزل عضو المجلس للمحافظ فقط');
  await db.prepare('DELETE FROM z62_council WHERE province_id=? AND user_id=?').bind(pid,crop(p.user_id,90)).run();return json({ok:true,notice:'تم تحديث عضوية المجلس'});
 }
 if(type==='capital_set'){
  if(!governor)return err(403,'تعديل العاصمة للمحافظ فقط');
  const capital=crop(p.capital,45);if(capital.length<3||/[<>]/.test(capital))return err(400,'الاسم غير صالح');
  await db.prepare('UPDATE z62_province_admin SET capital=? WHERE province_id=?').bind(capital,pid).run();return json({ok:true,notice:'تم تحديث المدينة الرئيسية للمحافظة'});
 }
 if(type==='project_propose'){
  if(!governor&&!council)return err(403,'اقتراح المشاريع للمحافظ أو المجلس المحلي');
  const kind=crop(p.kind,25),project=Z62_CIVIC_TYPES[kind];if(!project)return err(400,'نوع المشروع غير معروف');
  const title=crop(p.title,65),description=crop(p.description,220),rid=crop(p.request_id,80);
  if(title.length<5||description.length<10||!/^[a-f0-9-]{36}$/i.test(rid))return err(400,'أكمل عنوان المشروع والوصف ومعرف العملية');
  const row=await db.prepare("INSERT OR IGNORE INTO z62_civic_projects(id,province_id,author_id,kind,title,description,status,cost,created_at) VALUES(?,?,?,?,? ,?,'proposed',?,?) RETURNING id").bind(rid,pid,u.id,kind,title,description,project.cost,Date.now()).first();
  if(!row)return err(409,'هذا المقترح مسجل بالفعل');return json({ok:true,notice:'تم تسجيل المقترح، والمجلس يستطيع التصويت عليه'});
 }
 if(type==='project_vote'){
  if(!council&&!governor)return err(403,'التصويت لأعضاء المجلس والمحافظ فقط');
  const projectId=crop(p.project_id,90),vote=crop(p.vote,10);if(!['yes','no'].includes(vote))return err(400,'اختيار غير صالح');
  const proposal=await db.prepare("SELECT id FROM z62_civic_projects WHERE id=? AND province_id=? AND status='proposed'").bind(projectId,pid).first();if(!proposal)return err(409,'المشروع غير متاح للتصويت');
  const row=await db.prepare('INSERT OR IGNORE INTO z62_council_votes(project_id,user_id,vote,created_at) VALUES(?,?,?,?) RETURNING project_id').bind(projectId,u.id,vote,Date.now()).first();
  if(!row)return err(409,'صوتك مسجل بالفعل لهذا المشروع');return json({ok:true,notice:'تم تسجيل صوتك مرة واحدة'});
 }
 if(type==='project_approve'||type==='project_reject'){
  if(!governor)return err(403,'اعتماد/رفض المشاريع للمحافظ أو الرئاسة المركزية');
  const projectId=crop(p.project_id,90),proposal=await db.prepare('SELECT * FROM z62_civic_projects WHERE id=? AND province_id=?').bind(projectId,pid).first();
  if(!proposal||proposal.status!=='proposed')return err(409,'المشروع غير متاح أو حُسم بالفعل');
  if(type==='project_reject'){
   const row=await db.prepare("UPDATE z62_civic_projects SET status='rejected',decided_at=?,decided_by=? WHERE id=? AND status='proposed' RETURNING id").bind(Date.now(),u.id,projectId).first();
   return row?json({ok:true,notice:'تم رفض المشروع مع حفظ المقترح في السجل'}):err(409,'المشروع حُسم بالفعل');
  }
  const vote=await db.prepare("SELECT SUM(CASE WHEN vote='yes' THEN 1 ELSE 0 END) yes_votes,SUM(CASE WHEN vote='no' THEN 1 ELSE 0 END) no_votes FROM z62_council_votes WHERE project_id=?").bind(projectId).first();
  if(!admin&&Number(vote?.yes_votes||0)<=Number(vote?.no_votes||0))return err(409,'يلزم تصويت إيجابي من المجلس قبل الاعتماد');
  // The D1 triggers enforce sufficient funds and idempotency in the same SQLite transaction.
  try{const row=await db.prepare('INSERT OR IGNORE INTO z62_civic_spend(project_id,province_id,actor_id,cost,created_at) VALUES(?,?,?,?,?) RETURNING project_id').bind(projectId,pid,u.id,proposal.cost,Date.now()).first();if(!row)return err(409,'تم تنفيذ المشروع سابقًا');}
  catch(e){return err(409,'لم تُخصم أموال؛ قد تكون الميزانية غير كافية أو المشروع منفذًا مسبقًا');}
  return json({ok:true,notice:'تم تنفيذ المشروع وخصم تكلفته مرة واحدة من ميزانية المحافظة'});
 }
 return err(400,'إجراء إداري غير معروف');
}


// ZANGAR WORLD Update 63 — Civil government and constitutional workflows.
// All changes additive. Legacy armies are never activated and their D1 records are left intact.
const Z63_MINISTRIES=['الداخلية','المالية','الاقتصاد والتجارة','التعليم','الصحة','النقل والبنية التحتية','الإسكان','الزراعة','الصناعة','الإعلام','الدفاع','الخدمات العامة','العدل'];
const Z63_BLOCKED_PAGES=new Set(['/governance63.html','/ai46.html','/missions46.html','/recover60.html','/war.html','/warzone55.html','/radar55.html','/campaign.html','/solo61.html','/personal53.html']);
const Z63_COMBAT_APIS=new Set(['/api/war/state','/api/war/alert','/api/war/access','/api/war/action','/api/war/unlock','/api/campaign/state','/api/campaign/action','/api/central53/action']);
let z63InitPromise=null;
async function z63Ensure(db){
 if(z63InitPromise)return z63InitPromise;
 z63InitPromise=(async()=>{
  for(const sql of [
   `CREATE TABLE IF NOT EXISTS z63_elections(id TEXT PRIMARY KEY,office TEXT NOT NULL CHECK(office IN ('president','governor','parliament')),province_id TEXT NOT NULL DEFAULT '',title TEXT NOT NULL,nomination_end INTEGER NOT NULL,voting_end INTEGER NOT NULL,term_days INTEGER NOT NULL,status TEXT NOT NULL DEFAULT 'open' CHECK(status IN ('open','finalized','cancelled')),created_by TEXT NOT NULL,created_at INTEGER NOT NULL,finalized_at INTEGER NOT NULL DEFAULT 0)`,
   `CREATE UNIQUE INDEX IF NOT EXISTS z63_one_live_election ON z63_elections(office,province_id) WHERE status='open'`,
   `CREATE TABLE IF NOT EXISTS z63_candidates(election_id TEXT NOT NULL,user_id TEXT NOT NULL,platform TEXT NOT NULL,created_at INTEGER NOT NULL,PRIMARY KEY(election_id,user_id))`,
   `CREATE TABLE IF NOT EXISTS z63_ballots(election_id TEXT NOT NULL,voter_id TEXT NOT NULL,candidate_id TEXT NOT NULL,created_at INTEGER NOT NULL,PRIMARY KEY(election_id,voter_id),FOREIGN KEY(election_id,candidate_id) REFERENCES z63_candidates(election_id,user_id))`,
   `CREATE TABLE IF NOT EXISTS z63_offices(id TEXT PRIMARY KEY,office TEXT NOT NULL,province_id TEXT NOT NULL DEFAULT '',user_id TEXT NOT NULL,source TEXT NOT NULL,starts_at INTEGER NOT NULL,ends_at INTEGER NOT NULL,appointed_by TEXT NOT NULL DEFAULT '')`,
   `CREATE INDEX IF NOT EXISTS z63_office_user ON z63_offices(user_id,ends_at)`,
   `CREATE TABLE IF NOT EXISTS z63_bills(id TEXT PRIMARY KEY,author_id TEXT NOT NULL,title TEXT NOT NULL,body TEXT NOT NULL,status TEXT NOT NULL DEFAULT 'proposed' CHECK(status IN ('proposed','passed','rejected')),created_at INTEGER NOT NULL,decided_at INTEGER NOT NULL DEFAULT 0)`,
   `CREATE TABLE IF NOT EXISTS z63_bill_votes(bill_id TEXT NOT NULL,voter_id TEXT NOT NULL,vote TEXT NOT NULL CHECK(vote IN ('yes','no')),created_at INTEGER NOT NULL,PRIMARY KEY(bill_id,voter_id))`,
   `CREATE TABLE IF NOT EXISTS z63_questions(id TEXT PRIMARY KEY,author_id TEXT NOT NULL,target_id TEXT NOT NULL,question TEXT NOT NULL,answer TEXT NOT NULL DEFAULT '',status TEXT NOT NULL DEFAULT 'pending' CHECK(status IN ('pending','answered')),created_at INTEGER NOT NULL,answered_at INTEGER NOT NULL DEFAULT 0)`,
   `CREATE TABLE IF NOT EXISTS z63_grants(id TEXT PRIMARY KEY,province_id TEXT NOT NULL,actor_id TEXT NOT NULL,amount INTEGER NOT NULL CHECK(amount BETWEEN 1 AND 1000000),reason TEXT NOT NULL,created_at INTEGER NOT NULL)`,
   `CREATE TRIGGER IF NOT EXISTS z63_grant_validate BEFORE INSERT ON z63_grants BEGIN SELECT CASE WHEN NEW.province_id='home' OR NOT EXISTS(SELECT 1 FROM z46_provinces WHERE id=NEW.province_id) THEN RAISE(ABORT,'المحافظة غير صالحة للتحويل') END; SELECT CASE WHEN NOT EXISTS(SELECT 1 FROM z_state_treasury WHERE id=1 AND balance>=NEW.amount) THEN RAISE(ABORT,'رصيد الخزينة العامة لا يكفي') END; END`,
   `CREATE TRIGGER IF NOT EXISTS z63_grant_apply AFTER INSERT ON z63_grants BEGIN UPDATE z_state_treasury SET balance=balance-NEW.amount WHERE id=1; UPDATE z46_provinces SET treasury=treasury+NEW.amount WHERE id=NEW.province_id; INSERT INTO z46_ledger(id,province_id,actor_id,kind,delta,note,created_at) VALUES(NEW.id,NEW.province_id,NEW.actor_id,'civil_grant',NEW.amount,NEW.reason,NEW.created_at); END`,
   `CREATE TABLE IF NOT EXISTS z63_tenders(id TEXT PRIMARY KEY,province_id TEXT NOT NULL,actor_id TEXT NOT NULL,title TEXT NOT NULL,scope TEXT NOT NULL,ceiling INTEGER NOT NULL CHECK(ceiling BETWEEN 1 AND 1000000),status TEXT NOT NULL DEFAULT 'open' CHECK(status IN ('open','awarded','delivered','completed','cancelled')),winning_bid_id TEXT NOT NULL DEFAULT '',created_at INTEGER NOT NULL,completed_at INTEGER NOT NULL DEFAULT 0)`,
   `CREATE TABLE IF NOT EXISTS z63_bids(id TEXT PRIMARY KEY,tender_id TEXT NOT NULL,company_id TEXT NOT NULL,price INTEGER NOT NULL CHECK(price>0),description TEXT NOT NULL,created_at INTEGER NOT NULL,UNIQUE(tender_id,company_id))`,
   `CREATE TABLE IF NOT EXISTS z63_payments(tender_id TEXT PRIMARY KEY,bid_id TEXT NOT NULL,province_id TEXT NOT NULL,company_id TEXT NOT NULL,actor_id TEXT NOT NULL,amount INTEGER NOT NULL CHECK(amount>0),created_at INTEGER NOT NULL)`,
   `CREATE TRIGGER IF NOT EXISTS z63_payment_validate BEFORE INSERT ON z63_payments BEGIN SELECT CASE WHEN NOT EXISTS(SELECT 1 FROM z63_tenders t JOIN z63_bids b ON b.id=NEW.bid_id AND b.tender_id=t.id WHERE t.id=NEW.tender_id AND t.province_id=NEW.province_id AND t.status='delivered' AND t.winning_bid_id=b.id AND b.company_id=NEW.company_id AND b.price=NEW.amount AND b.price<=t.ceiling) THEN RAISE(ABORT,'المناقصة غير مستحقة للدفع') END; SELECT CASE WHEN NOT EXISTS(SELECT 1 FROM z46_provinces WHERE id=NEW.province_id AND treasury>=NEW.amount) THEN RAISE(ABORT,'ميزانية المحافظة لا تكفي') END; SELECT CASE WHEN NOT EXISTS(SELECT 1 FROM z_companies WHERE id=NEW.company_id) THEN RAISE(ABORT,'الشركة لم تعد موجودة') END; END`,
   `CREATE TRIGGER IF NOT EXISTS z63_payment_apply AFTER INSERT ON z63_payments BEGIN UPDATE z46_provinces SET treasury=treasury-NEW.amount WHERE id=NEW.province_id AND treasury>=NEW.amount; UPDATE z_companies SET balance=balance+NEW.amount WHERE id=NEW.company_id; UPDATE z63_tenders SET status='completed',completed_at=NEW.created_at WHERE id=NEW.tender_id AND status='delivered'; INSERT INTO z46_ledger(id,province_id,actor_id,kind,delta,note,created_at) VALUES(NEW.tender_id||'-paid',NEW.province_id,NEW.actor_id,'tender63',-NEW.amount,'مستخلص مشروع حكومي',NEW.created_at); END`,
   `CREATE TABLE IF NOT EXISTS z63_reports(id TEXT PRIMARY KEY,reporter_id TEXT NOT NULL,target_id TEXT NOT NULL DEFAULT '',details TEXT NOT NULL,status TEXT NOT NULL DEFAULT 'filed' CHECK(status IN ('filed','investigating','referred','closed')),officer_id TEXT NOT NULL DEFAULT '',resolution TEXT NOT NULL DEFAULT '',created_at INTEGER NOT NULL,updated_at INTEGER NOT NULL)`,
   `CREATE TABLE IF NOT EXISTS z63_appeals(id TEXT PRIMARY KEY,case_id TEXT NOT NULL,appellant_id TEXT NOT NULL,reason TEXT NOT NULL,status TEXT NOT NULL DEFAULT 'pending' CHECK(status IN ('pending','accepted','rejected')),reviewer_id TEXT NOT NULL DEFAULT '',decision TEXT NOT NULL DEFAULT '',created_at INTEGER NOT NULL,decided_at INTEGER NOT NULL DEFAULT 0,UNIQUE(case_id,appellant_id))`,
   `CREATE TABLE IF NOT EXISTS z63_decisions(id TEXT PRIMARY KEY,actor_id TEXT NOT NULL,category TEXT NOT NULL,detail TEXT NOT NULL,created_at INTEGER NOT NULL)`
  ])await db.prepare(sql).run();
 })().catch(e=>{z63InitPromise=null;throw e});
 return z63InitPromise;
}
async function z63ExpireGovernors(db){const now=Date.now();await db.prepare("UPDATE z46_provinces SET governor_id='' WHERE governor_id!='' AND EXISTS(SELECT 1 FROM z63_offices x WHERE x.office='governor' AND x.province_id=z46_provinces.id AND x.user_id=z46_provinces.governor_id AND x.ends_at<=?) AND NOT EXISTS(SELECT 1 FROM z63_offices a WHERE a.office='governor' AND a.province_id=z46_provinces.id AND a.ends_at>?)").bind(now,now).run();}
async function z63Rights(db,u){
 if(!u)return {admin:false,president:false,parliament:false,governor_ids:[],minister_ids:[],judge:false,police:false};
 await z63ExpireGovernors(db);
 const now=Date.now();
 const [o,g,c]=await Promise.all([
  db.prepare('SELECT office,province_id,ends_at FROM z63_offices WHERE user_id=? AND ends_at>?').bind(u.id,now).all(),
  db.prepare('SELECT id FROM z46_provinces WHERE governor_id=?').bind(u.id).all(),
  db.prepare('SELECT province_id,office FROM z62_council WHERE user_id=?').bind(u.id).all()
 ]);
 const offices=o.results,gov=[...new Set([...g.results.map(x=>x.id),...offices.filter(x=>x.office==='governor').map(x=>x.province_id)])];
 return {admin:isAdmin(u),president:offices.some(x=>x.office==='president'),parliament:offices.some(x=>x.office==='parliament'),governor_ids:gov,minister_ids:offices.filter(x=>x.office.startsWith('minister:')).map(x=>x.office.slice(9)),council_ids:c.results.map(x=>x.province_id),judge:await hasDepartment(db,u,'court')||offices.some(x=>x.office==='minister:العدل'||x.office==='judge'),police:await policeGranted(db,u)||offices.some(x=>x.office==='police_chief'||x.office==='minister:الداخلية'),user_id:u.id};
}
const z63Government=r=>r.admin||r.president;
const z63GovProvince=(r,pid)=>z63Government(r)||r.governor_ids.includes(pid);
function z63Summary(row){return {id:row.id,office:row.office,province_id:row.province_id,title:row.title,nomination_end:row.nomination_end,voting_end:row.voting_end,term_days:row.term_days,status:row.status,created_at:row.created_at,finalized_at:row.finalized_at};}
async function z63State(req,db){
 await z63Ensure(db);
 const u=await getMe(req,db),r=await z63Rights(db,u);
 const now=Date.now();
 const [e,c,v,o,b,bv,q,g,t,bi,rep,app,users,provinces,myBallots,decisions]=await Promise.all([
  db.prepare('SELECT * FROM z63_elections ORDER BY created_at DESC LIMIT 80').all(),
  db.prepare('SELECT c.*,u.name FROM z63_candidates c JOIN users u ON u.id=c.user_id ORDER BY c.created_at DESC LIMIT 300').all(),
  db.prepare('SELECT election_id,candidate_id,COUNT(*) n FROM z63_ballots GROUP BY election_id,candidate_id').all(),
  db.prepare('SELECT o.*,u.name FROM z63_offices o JOIN users u ON u.id=o.user_id WHERE o.ends_at>? ORDER BY o.ends_at LIMIT 150').bind(now).all(),
  db.prepare('SELECT * FROM z63_bills ORDER BY created_at DESC LIMIT 100').all(),
  db.prepare('SELECT bill_id,vote,COUNT(*) n FROM z63_bill_votes GROUP BY bill_id,vote').all(),
  db.prepare('SELECT * FROM z63_questions ORDER BY created_at DESC LIMIT 80').all(),
  db.prepare('SELECT * FROM z63_grants ORDER BY created_at DESC LIMIT 80').all(),
  db.prepare('SELECT * FROM z63_tenders ORDER BY created_at DESC LIMIT 120').all(),
  db.prepare('SELECT b.*,c.name company_name,c.owner_id FROM z63_bids b JOIN z_companies c ON c.id=b.company_id ORDER BY b.created_at DESC LIMIT 250').all(),
  db.prepare('SELECT * FROM z63_reports ORDER BY created_at DESC LIMIT 150').all(),
  db.prepare('SELECT a.*,c.target_id,c.user_id reporter_id FROM z63_appeals a JOIN cases c ON c.id=a.case_id ORDER BY a.created_at DESC LIMIT 150').all(),
  db.prepare('SELECT id,name,job FROM users ORDER BY joined DESC LIMIT 350').all(),
  db.prepare('SELECT id,name,treasury,economy,governor_id FROM z46_provinces ORDER BY id').all(),
  db.prepare('SELECT election_id FROM z63_ballots WHERE voter_id=?').bind(u?.id||'').all(),
  db.prepare('SELECT * FROM z63_decisions ORDER BY created_at DESC LIMIT 120').all()
 ]);
 const mine=(rows)=>rows.filter(x=>r.admin||x.appellant_id===u?.id||x.reporter_id===u?.id||x.target_id===u?.id||(r.judge&&!!x.case_id)||(r.police&&!!x.details));
 const cases=u?(await db.prepare('SELECT id,user_id,target_id,kind,status,created_at FROM cases WHERE user_id=? OR target_id=? ORDER BY created_at DESC LIMIT 100').bind(u.id,u.id).all()).results:[];
 return json({ok:true,version:'63',my_id:u?.id||'',rights:r,ministries:Z63_MINISTRIES,users:users.results,provinces:provinces.results,
  elections:e.results.map(x=>({...z63Summary(x),phase:x.status!=='open'?x.status:now<x.nomination_end?'nomination':now<x.voting_end?'voting':'awaiting_results',candidates:c.results.filter(y=>y.election_id===x.id).map(y=>({...y,votes:x.status==='finalized'?(v.results.find(z=>z.election_id===x.id&&z.candidate_id===y.user_id)?.n||0):null})),my_vote:myBallots.results.some(ballot=>ballot.election_id===x.id)})),
  offices:o.results,bills:b.results.map(x=>({...x,yes:bv.results.find(y=>y.bill_id===x.id&&y.vote==='yes')?.n||0,no:bv.results.find(y=>y.bill_id===x.id&&y.vote==='no')?.n||0})),questions:q.results,grants:g.results,tenders:t.results.map(x=>({...x,bids:bi.results.filter(y=>y.tender_id===x.id)})),reports:mine(rep.results),appeals:mine(app.results),cases,decisions:decisions.results,ranking:[]});
}
async function z63Action(req,db,p){
 await z63Ensure(db);
 const u=await getMe(req,db);if(!u)return err(401,'سجّل الدخول أولًا');
 const r=await z63Rights(db,u),now=Date.now(),type=crop(p.type,40);
 const title=crop(p.title,110),details=crop(p.details||p.body||p.scope,2500),rid=crop(p.id||p.election_id||p.tender_id||p.bill_id,100);
 const deny=(msg='ليس لديك صلاحية لهذا الإجراء')=>err(403,msg);
 const changed=(notice)=>json({ok:true,notice});
 if(type==='election_create'){
  if(!z63Government(r))return deny();
  const office=crop(p.office,25),pid=office==='governor'?crop(p.province_id,40):'';
  if(!['president','governor','parliament'].includes(office))return err(400,'نوع الانتخابات غير صالح');
  if(office==='governor'&&!await db.prepare('SELECT 1 FROM z46_provinces WHERE id=?').bind(pid).first())return err(400,'اختر محافظة صحيحة');
  const nominate=Number(p.nomination_hours),vote=Number(p.vote_hours),term=Number(p.term_days);
  if(!Number.isInteger(nominate)||nominate<1||nominate>168||!Number.isInteger(vote)||vote<1||vote>168||!Number.isInteger(term)||term<1||term>180)return err(400,'حدد ساعات الترشح والتصويت (1–168) ومدة المنصب بالأيام (1–180)');
  try{await db.prepare('INSERT INTO z63_elections(id,office,province_id,title,nomination_end,voting_end,term_days,created_by,created_at) VALUES(?,?,?,?,?,?,?,?,?)').bind(id(),office,pid,title||'انتخابات دولة الزنجر',now+nominate*3600000,now+(nominate+vote)*3600000,term,u.id,now).run();}
  catch{return err(409,'توجد انتخابات مفتوحة لنفس المنصب أو حدث تعارض')}
  return changed('تم فتح باب الترشح وتحديد موعد التصويت ومدة المنصب');
 }
 if(type==='election_nominate'){
  const e=await db.prepare('SELECT * FROM z63_elections WHERE id=?').bind(rid).first();
  if(!e||e.status!=='open'||now>=e.nomination_end)return err(409,'باب الترشح مغلق');
  if(e.province_id&&!await db.prepare('SELECT 1 FROM z46_members WHERE province_id=? AND user_id=?').bind(e.province_id,u.id).first())return deny('يشترط الانتماء إلى المحافظة');
  const platform=crop(p.platform,900);if(platform.length<20)return err(400,'اكتب برنامجًا انتخابيًا من 20 حرفًا على الأقل');
  const inserted=await db.prepare('INSERT OR IGNORE INTO z63_candidates(election_id,user_id,platform,created_at) VALUES(?,?,?,?) RETURNING user_id').bind(e.id,u.id,platform,now).first();
  return inserted?changed('تم تسجيل ترشحك وبرنامجك الانتخابي'):err(409,'أنت مرشح بالفعل');
 }
 if(type==='election_vote'){
  const e=await db.prepare('SELECT * FROM z63_elections WHERE id=?').bind(rid).first();
  if(!e||e.status!=='open'||now<e.nomination_end||now>=e.voting_end)return err(409,'التصويت غير مفتوح');
  if(e.province_id&&!await db.prepare('SELECT 1 FROM z46_members WHERE province_id=? AND user_id=?').bind(e.province_id,u.id).first())return deny('لا يمكنك التصويت خارج محافظتك');
  const cid=crop(p.candidate_id,90);
  const candidate=await db.prepare('SELECT 1 FROM z63_candidates WHERE election_id=? AND user_id=?').bind(rid,cid).first();if(!candidate)return err(400,'مرشح غير مسجل');
  const inserted=await db.prepare('INSERT OR IGNORE INTO z63_ballots(election_id,voter_id,candidate_id,created_at) VALUES(?,?,?,?) RETURNING voter_id').bind(rid,u.id,cid,now).first();
  return inserted?changed('تم حفظ صوتك ولا يمكن التصويت مرة أخرى'):err(409,'صوتّ بالفعل في هذه الانتخابات');
 }
 if(type==='election_finalize'){
  if(!z63Government(r))return deny();
  const e=await db.prepare('SELECT * FROM z63_elections WHERE id=?').bind(rid).first();
  if(!e||e.status!=='open'||now<e.voting_end)return err(409,'لا يمكن إعلان النتيجة قبل انتهاء التصويت');
  const winners=(await db.prepare('SELECT c.user_id,COUNT(b.voter_id) AS votes FROM z63_candidates c LEFT JOIN z63_ballots b ON b.election_id=c.election_id AND b.candidate_id=c.user_id WHERE c.election_id=? GROUP BY c.user_id ORDER BY votes DESC,c.created_at ASC,c.user_id ASC LIMIT ?').bind(rid,e.office==='parliament'?3:1).all()).results;
  const real=winners.filter(x=>Number(x.votes)>0);
  // db.batch is transactional in Cloudflare D1. An UPDATE with CAS prevents duplicate finalisation;
  // no office grant can occur if a competing request closed the ballot first.
  const statements=[db.prepare("UPDATE z63_elections SET status='finalized',finalized_at=? WHERE id=? AND status='open' AND voting_end<=?").bind(now,rid,now)];
  if(real.length&&e.office!=='parliament')statements.push(db.prepare("UPDATE z63_offices SET ends_at=? WHERE office=? AND province_id=? AND ends_at>? AND EXISTS(SELECT 1 FROM z63_elections WHERE id=? AND finalized_at=?)").bind(now,e.office,e.province_id,now,rid,now));
  for(const winner of real){
   statements.push(db.prepare("INSERT INTO z63_offices(id,office,province_id,user_id,source,starts_at,ends_at,appointed_by) SELECT ?,?,?,?,?,?,?,? WHERE EXISTS(SELECT 1 FROM z63_elections WHERE id=? AND finalized_at=?)").bind(id(),e.office,e.province_id,winner.user_id,'election:'+rid,now,now+e.term_days*86400000,u.id,rid,now));
   if(e.office==='governor')statements.push(db.prepare("UPDATE z46_provinces SET governor_id=? WHERE id=? AND EXISTS(SELECT 1 FROM z63_elections WHERE id=? AND finalized_at=?)").bind(winner.user_id,e.province_id,rid,now));
  }
  const tx=await db.batch(statements);
  if(!Number(tx[0]?.meta?.changes))return err(409,'تم اعتماد النتيجة بالفعل');
  return changed(real.length?'أُعلنت النتائج ووُثّقت الولايات الجديدة':'أُغلقت الانتخابات دون فائز لعدم وجود أصوات');
 }
 if(type==='office_appoint'){
  if(!z63Government(r))return deny();
  const office=crop(p.office,80),pid=crop(p.province_id,40),uid=crop(p.user_id,90),days=Number(p.term_days);
  if(!(['prime_minister','deputy_president','judge','police_chief'].includes(office)||office.startsWith('minister:')&&Z63_MINISTRIES.includes(office.slice(9))))return err(400,'المنصب غير معتمد');
  if(!Number.isInteger(days)||days<1||days>180||!await db.prepare('SELECT 1 FROM users WHERE id=?').bind(uid).first())return err(400,'اختر مواطنًا ومدة صالحة');
  await db.prepare('UPDATE z63_offices SET ends_at=? WHERE office=? AND province_id=? AND ends_at>?').bind(now,office,'',now).run();
  await db.prepare('INSERT INTO z63_offices(id,office,province_id,user_id,source,starts_at,ends_at,appointed_by) VALUES(?,?,?,?,?,?,?,?)').bind(id(),office,'',uid,'appointment',now,now+days*86400000,u.id).run();
  return changed('تم التعيين مع حفظ نهاية الولاية وسجل التكليف');
 }
 if(type==='bill_create'){
  if(!(r.parliament||z63Government(r)))return deny('اقتراح القوانين لأعضاء البرلمان والرئاسة');
  if(title.length<5||details.length<15)return err(400,'اكتب عنوان القانون ونصه');
  await db.prepare('INSERT INTO z63_bills(id,author_id,title,body,created_at) VALUES(?,?,?,?,?)').bind(id(),u.id,title,details,now).run();
  return changed('تم تقديم مشروع القانون للبرلمان');
 }
 if(type==='bill_vote'){
  if(!r.parliament)return deny('التصويت لأعضاء البرلمان المنتخبين فقط');
  const vote=crop(p.vote,10),b=await db.prepare('SELECT status FROM z63_bills WHERE id=?').bind(rid).first();
  if(!b||b.status!=='proposed'||!['yes','no'].includes(vote))return err(409,'التصويت غير متاح');
  const inserted=await db.prepare('INSERT OR IGNORE INTO z63_bill_votes(bill_id,voter_id,vote,created_at) VALUES(?,?,?,?) RETURNING voter_id').bind(rid,u.id,vote,now).first();
  return inserted?changed('تم تسجيل صوتك في البرلمان'):err(409,'سبق أن صوتّ على هذا القانون');
 }
 if(type==='bill_finalize'){
  if(!z63Government(r))return deny();
  const count=await db.prepare("SELECT COUNT(DISTINCT user_id) n FROM z63_offices WHERE office='parliament' AND ends_at>?").bind(now).first();
  const total=Number(count?.n||0);if(!total)return err(409,'لا يوجد نواب منتخبون حاليًا');
  const votes=await db.prepare("SELECT COUNT(*) n,SUM(CASE WHEN vote='yes' THEN 1 ELSE 0 END) yes,SUM(CASE WHEN vote='no' THEN 1 ELSE 0 END) no FROM z63_bill_votes WHERE bill_id=? AND voter_id IN (SELECT user_id FROM z63_offices WHERE office='parliament' AND ends_at>?)").bind(rid,now).first();
  if(Number(votes?.n||0)<Math.ceil(total/2))return err(409,'لم يكتمل النصاب القانوني');
  const status=Number(votes?.yes||0)>Number(votes?.no||0)?'passed':'rejected';
  const ok=await db.prepare("UPDATE z63_bills SET status=?,decided_at=? WHERE id=? AND status='proposed' RETURNING id").bind(status,now,rid).first();
  return ok?changed(status==='passed'?'تم إقرار القانون':'رفض البرلمان القانون'):err(409,'سبق البت في المشروع');
 }
 if(type==='question_create'){
  if(!r.parliament)return deny('الاستجوابات للنواب فقط');
  const uid=crop(p.target_id,90),question=crop(p.question,1500);
  if(!await db.prepare('SELECT 1 FROM users WHERE id=?').bind(uid).first()||question.length<15)return err(400,'حدد مسؤولًا وسؤالًا واضحًا');
  await db.prepare('INSERT INTO z63_questions(id,author_id,target_id,question,created_at) VALUES(?,?,?,?,?)').bind(id(),u.id,uid,question,now).run();
  return changed('تم إرسال الاستجواب وتوثيقه');
 }
 if(type==='question_answer'){
  const q=await db.prepare('SELECT target_id,status FROM z63_questions WHERE id=?').bind(rid).first();
  if(!q||q.status!=='pending'||!(q.target_id===u.id||z63Government(r)))return deny('الرد من المسؤول المعني أو الرئاسة');
  const answer=crop(p.answer,1500);if(answer.length<10)return err(400,'الرد قصير');
  const ok=await db.prepare("UPDATE z63_questions SET status='answered',answer=?,answered_at=? WHERE id=? AND status='pending'").bind(answer,now,rid).run();
  return Number(ok.meta?.changes)>0?changed('تم توثيق رد الاستجواب'):err(409,'تم الرد بالفعل');
 }
 if(type==='province_grant'){
  if(!(r.admin||r.president||r.minister_ids.includes('المالية')))return deny('تمويل المحافظات للرئاسة أو وزارة المالية');
  const pid=crop(p.province_id,40),amount=Number(p.amount),reason=crop(p.reason,180);
  if(pid==='home'||!Number.isInteger(amount)||amount<1||amount>1000000||reason.length<5)return err(400,'مبلغ التمويل أو سببه غير صالح');
  try{await db.prepare('INSERT INTO z63_grants(id,province_id,actor_id,amount,reason,created_at) VALUES(?,?,?,?,?,?)').bind(id(),pid,u.id,amount,reason,now).run()}
  catch{return err(409,'لم يتم التحويل: خزينة الدولة غير كافية أو المحافظة غير صالحة')}
  return changed('تم تحويل التمويل وتسجيله في الدفاتر المالية');
 }
 if(type==='tender_create'){
  const pid=crop(p.province_id,40),ceiling=Number(p.ceiling);
  if(!z63GovProvince(r,pid))return deny('إنشاء المناقصات للمحافظ أو الحكومة');
  if(title.length<5||details.length<15||!Number.isInteger(ceiling)||ceiling<1||ceiling>1000000)return err(400,'بيانات المناقصة ناقصة');
  if(!await db.prepare('SELECT 1 FROM z46_provinces WHERE id=?').bind(pid).first())return err(404,'المحافظة غير موجودة');
  await db.prepare('INSERT INTO z63_tenders(id,province_id,actor_id,title,scope,ceiling,created_at) VALUES(?,?,?,?,?,?,?)').bind(id(),pid,u.id,title,details,ceiling,now).run();
  return changed('تم نشر المناقصة وأصبح بإمكان الشركات التقديم');
 }
 if(type==='tender_bid'){
  const t=await db.prepare('SELECT status,ceiling FROM z63_tenders WHERE id=?').bind(rid).first();
  const company=await db.prepare('SELECT id,owner_id FROM z_companies WHERE owner_id=?').bind(u.id).first();
  const price=Number(p.price),desc=crop(p.description,600);
  if(!t||t.status!=='open'||!company||!Number.isInteger(price)||price<1||price>t.ceiling||desc.length<10)return err(400,'المناقصة مغلقة أو لا تمتلك شركة أو العرض غير صالح');
  const bid=await db.prepare('INSERT OR IGNORE INTO z63_bids(id,tender_id,company_id,price,description,created_at) VALUES(?,?,?,?,?,?) RETURNING id').bind(id(),rid,company.id,price,desc,now).first();
  return bid?changed('تم تقديم عرض الشركة'):err(409,'شركتك قدمت عرضًا من قبل');
 }
 if(type==='tender_award'){
  const t=await db.prepare('SELECT * FROM z63_tenders WHERE id=?').bind(rid).first();
  if(!t||!z63GovProvince(r,t.province_id))return deny();
  const bid=await db.prepare('SELECT b.*,c.owner_id FROM z63_bids b JOIN z_companies c ON c.id=b.company_id WHERE b.id=? AND b.tender_id=?').bind(crop(p.bid_id,90),rid).first();
  if(!bid||bid.owner_id===u.id)return err(409,'لا يمكنك إرساء مناقصة على شركتك أو اختيار عرض غير موجود');
  const ok=await db.prepare("UPDATE z63_tenders SET status='awarded',winning_bid_id=? WHERE id=? AND status='open' RETURNING id").bind(bid.id,rid).first();
  return ok?changed('تم إرساء المناقصة وبدأ التنفيذ'):err(409,'تم إرساء المناقصة سابقًا');
 }
 if(type==='tender_deliver'){
  const t=await db.prepare('SELECT status,winning_bid_id FROM z63_tenders WHERE id=?').bind(rid).first();
  const owner=await db.prepare('SELECT c.owner_id FROM z63_bids b JOIN z_companies c ON c.id=b.company_id WHERE b.id=?').bind(t?.winning_bid_id||'').first();
  if(!t||t.status!=='awarded'||owner?.owner_id!==u.id)return deny('التسليم من الشركة الفائزة فقط');
  const ok=await db.prepare("UPDATE z63_tenders SET status='delivered' WHERE id=? AND status='awarded' RETURNING id").bind(rid).first();
  return ok?changed('تم تقديم المشروع للاستلام الحكومي'):err(409,'حالة المناقصة تغيرت');
 }
 if(type==='tender_pay'){
  const t=await db.prepare('SELECT * FROM z63_tenders WHERE id=?').bind(rid).first();
  if(!t||!z63GovProvince(r,t.province_id))return deny();
  const bid=await db.prepare('SELECT b.*,c.owner_id FROM z63_bids b JOIN z_companies c ON c.id=b.company_id WHERE b.id=?').bind(t.winning_bid_id).first();
  if(!bid||bid.owner_id===u.id)return err(403,'لا يمكنك صرف مستخلص لشركتك');
  try{const paid=await db.prepare('INSERT OR IGNORE INTO z63_payments(tender_id,bid_id,province_id,company_id,actor_id,amount,created_at) VALUES(?,?,?,?,?,?,?) RETURNING tender_id').bind(rid,bid.id,t.province_id,bid.company_id,u.id,bid.price,now).first();if(!paid)return err(409,'تم صرف المستخلص من قبل')}
  catch{return err(409,'لم يتم الدفع: إما المشروع غير مسلّم أو الميزانية غير كافية')}
  return changed('تم سداد المستخلص للشركة وخصم التكلفة مرة واحدة');
 }
 if(type==='tender_cancel'){
  const t=await db.prepare('SELECT province_id FROM z63_tenders WHERE id=?').bind(rid).first();
  if(!t||!z63GovProvince(r,t.province_id))return deny();
  const ok=await db.prepare("UPDATE z63_tenders SET status='cancelled' WHERE id=? AND status='open' RETURNING id").bind(rid).first();
  return ok?changed('ألغيت المناقصة قبل الإرساء'):err(409,'لا يمكن إلغاء مناقصة بعد إرسائها من هذه الواجهة');
 }
 if(type==='decision_publish'){
  if(!z63Government(r)&&!r.governor_ids.length)return deny();
  const kind=crop(p.category,70),detail=crop(p.detail,1000);
  if(kind.length<3||detail.length<12)return err(400,'اكتب عنوانًا وقرارًا واضحين');
  await db.prepare('INSERT INTO z63_decisions(id,actor_id,category,detail,created_at) VALUES(?,?,?,?,?)').bind(id(),u.id,kind,detail,now).run();
  await db.prepare('INSERT INTO announcements(id,text,created_at) VALUES(?,?,?)').bind(id(),'🏛️ '+kind+': '+detail.slice(0,260),now).run();
  return changed('تم توثيق القرار في سجل الدولة ونشره في الأخبار');
 }
 if(type==='report_create'){
  const target=crop(p.target_id,90),body=crop(p.details,1300);
  if(body.length<15||target&&target===u.id)return err(400,'اكتب تفاصيل البلاغ وحدد الطرف الصحيح');
  if(target&&!await db.prepare('SELECT 1 FROM users WHERE id=?').bind(target).first())return err(400,'المواطن غير موجود');
  await db.prepare('INSERT INTO z63_reports(id,reporter_id,target_id,details,created_at,updated_at) VALUES(?,?,?,?,?,?)').bind(id(),u.id,target,body,now,now).run();
  return changed('تم تسجيل البلاغ لدى الشرطة برقم مستقل');
 }
 if(type==='report_update'){
  if(!(r.police||r.admin))return deny('تحديث البلاغ من صلاحية الشرطة');
  const report=await db.prepare('SELECT reporter_id,target_id FROM z63_reports WHERE id=?').bind(rid).first();
  const status=crop(p.status,20),resolution=crop(p.resolution,800);
  if(!report||report.reporter_id===u.id||report.target_id===u.id||!['investigating','referred','closed'].includes(status)||resolution.length<10)return err(400,'لا يمكن التحقيق في بلاغ يخصك أو إدخال قرار دون سبب');
  const ok=await db.prepare("UPDATE z63_reports SET status=?,officer_id=?,resolution=?,updated_at=? WHERE id=? AND status!='closed' RETURNING id").bind(status,u.id,resolution,now,rid).first();
  return ok?changed('تم تحديث البلاغ مع تسجيل اسم المسؤول والسبب'):err(409,'البلاغ مغلق بالفعل');
 }
 if(type==='appeal_create'){
  const cid=crop(p.case_id,90),reason=crop(p.reason,1200),row=await db.prepare('SELECT * FROM cases WHERE id=?').bind(cid).first();
  if(!row||!['confirmed','rejected','pardoned'].includes(row.status)||![row.user_id,row.target_id].includes(u.id)||reason.length<15)return err(400,'يمكن الاعتراض على قضية تخصك وصدر فيها قرار فقط');
  const a=await db.prepare('INSERT OR IGNORE INTO z63_appeals(id,case_id,appellant_id,reason,created_at) VALUES(?,?,?,?,?) RETURNING id').bind(id(),cid,u.id,reason,now).first();
  return a?changed('تم تقديم الاعتراض للقضاء'):err(409,'توجد مراجعة مسجلة لنفس القضية');
 }
 if(type==='appeal_decide'){
  if(!(r.judge||r.admin))return deny('مراجعة الاعتراض من صلاحيات القضاء');
  const a=await db.prepare('SELECT a.*,c.user_id,c.target_id FROM z63_appeals a JOIN cases c ON c.id=a.case_id WHERE a.id=?').bind(rid).first();
  const status=crop(p.status,12),decision=crop(p.decision,800);
  if(!a||a.status!=='pending'||[a.appellant_id,a.user_id,a.target_id].includes(u.id)||!['accepted','rejected'].includes(status)||decision.length<12)return err(400,'لا يجوز الفصل في قضية طرفك فيها أو دون تسبيب');
  const ok=await db.prepare("UPDATE z63_appeals SET status=?,reviewer_id=?,decision=?,decided_at=? WHERE id=? AND status='pending' RETURNING id").bind(status,u.id,decision,now,rid).first();
  // An accepted appeal marks a ruling review; old point penalties are NOT silently reversed.
  return ok?changed('تم إصدار قرار الاستئناف مع الحفاظ على السجل المالي القديم'):err(409,'تم البت في الاستئناف');
 }
 return err(400,'إجراء غير معروف في الحكومة V63');
}


// V65.5 — Direct membership: no presidential approval, and no new approval records.
// Reuses the existing 30 Guest slots and the same session cookie as all established accounts.
// This code is deliberately independent of the legacy z66 request/approval tables.
let z67BaseReady=null;
async function z67EnsureBase(db){
 if(z67BaseReady)return z67BaseReady;
 z67BaseReady=(async()=>{
   try{
     await db.prepare('SELECT slot FROM z639_guest_slots LIMIT 1').first();
     await db.prepare('SELECT user_id FROM z64_archived_users LIMIT 1').first();
     await db.prepare('SELECT user_id FROM z49_gate_access LIMIT 1').first();
   }catch(e){
     // Only on a truly fresh database; an existing state skips the costly legacy migrations.
     if(!/no such table/i.test(String(e)))throw e;
     await ensureZangarSchema(db);
     await z639Ensure(db);
     await z49Ensure(db);
     await z64Ensure(db);
   }
 })().catch(e=>{z67BaseReady=null;throw e});
 return z67BaseReady;
}
