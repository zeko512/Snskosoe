// V80 — secure bank access, token-gated deposit/withdraw, credential recovery, presidential deduction.
// Everything is enforced on the Worker + D1. The browser only renders screens.
const Z80_UNLOCK_TTL=10*60*1000,Z80_TOKEN_TTL=5*60*1000,Z80_RECOVERY_TTL=24*3600*1000,Z80_PBKDF2=100000;
let z80Ready=null;
async function z80Ensure(db){
 if(!z80Ready)z80Ready=(async()=>{
  await db.batch([
   db.prepare('CREATE TABLE IF NOT EXISTS z80_bank_creds(user_id TEXT PRIMARY KEY,pass_hash TEXT NOT NULL,pass_salt TEXT NOT NULL,pin_hash TEXT NOT NULL,pin_salt TEXT NOT NULL,created_at INTEGER NOT NULL,updated_at INTEGER NOT NULL)'),
   db.prepare('CREATE TABLE IF NOT EXISTS z80_bank_unlock(user_id TEXT NOT NULL,session_hash TEXT NOT NULL,expires_at INTEGER NOT NULL,PRIMARY KEY(user_id,session_hash))'),
   db.prepare('CREATE TABLE IF NOT EXISTS z80_bank_tokens(token_hash TEXT PRIMARY KEY,user_id TEXT NOT NULL,kind TEXT NOT NULL,expires_at INTEGER NOT NULL,used INTEGER NOT NULL DEFAULT 0)'),
   db.prepare('CREATE TABLE IF NOT EXISTS z80_bank_attempts(user_id TEXT PRIMARY KEY,failures INTEGER NOT NULL DEFAULT 0,blocked_until INTEGER NOT NULL DEFAULT 0)'),
   db.prepare("CREATE TABLE IF NOT EXISTS z80_recovery(id TEXT PRIMARY KEY,user_id TEXT NOT NULL,mode TEXT NOT NULL CHECK(mode IN ('password','pin','both')),status TEXT NOT NULL CHECK(status IN ('pending','approved','rejected','used')),created_at INTEGER NOT NULL,decided_at INTEGER NOT NULL DEFAULT 0,decided_by TEXT NOT NULL DEFAULT '',expires_at INTEGER NOT NULL DEFAULT 0)"),
   db.prepare('CREATE INDEX IF NOT EXISTS z80_recovery_user ON z80_recovery(user_id,created_at)'),
   db.prepare('CREATE TABLE IF NOT EXISTS z80_deductions(id TEXT PRIMARY KEY,actor_id TEXT NOT NULL,target_id TEXT NOT NULL,amount INTEGER NOT NULL CHECK(amount BETWEEN 1 AND 10000000),reason TEXT NOT NULL,created_at INTEGER NOT NULL)'),
   db.prepare("CREATE TRIGGER IF NOT EXISTS z80_deduct_check BEFORE INSERT ON z80_deductions BEGIN SELECT CASE WHEN NOT EXISTS(SELECT 1 FROM users WHERE id=NEW.target_id AND points>=NEW.amount) THEN RAISE(ABORT,'رصيد المواطن لا يكفي لهذا الخصم') END; END"),
   db.prepare("CREATE TRIGGER IF NOT EXISTS z80_deduct_apply AFTER INSERT ON z80_deductions BEGIN UPDATE users SET points=points-NEW.amount WHERE id=NEW.target_id; UPDATE z_state_treasury SET balance=balance+NEW.amount WHERE id=1; INSERT INTO transactions(id,user_id,amount,note,created_at) VALUES(NEW.id,NEW.target_id,-NEW.amount,'خصم رئاسي: '||NEW.reason,NEW.created_at); END")
  ]);
 })().catch(e=>{z80Ready=null;throw e});
 return z80Ready;
}
function z80FromHex(h){const a=new Uint8Array(h.length/2);for(let i=0;i<a.length;i++)a[i]=parseInt(h.substr(i*2,2),16);return a}
async function z80Hash(secret,saltHex){
 const key=await crypto.subtle.importKey('raw',enc.encode(secret),'PBKDF2',false,['deriveBits']);
 return hex(await crypto.subtle.deriveBits({name:'PBKDF2',hash:'SHA-256',salt:z80FromHex(saltHex),iterations:Z80_PBKDF2},key,256));
}
const z80Salt=()=>hex(crypto.getRandomValues(new Uint8Array(16)));
const z80OkPass=v=>typeof v==='string'&&v.length>=8&&v.length<=72&&!/[\x00-\x1f]/.test(v);
const z80OkPin=v=>typeof v==='string'&&/^[0-9]{4,8}$/.test(v);
async function z80Sess(req){const t=cookieValue(req,'zangar_session');return /^[a-f0-9]{64}$/.test(t)?await digest(t):''}
async function z80Card(db,userId){
 const q=()=>db.prepare('SELECT card_no,card_code FROM z76_identity_cards WHERE user_id=?').bind(userId).first();
 let c=null;
 try{c=await q();}catch(e){if(!/no such table/i.test(String(e?.message||e)))throw e;}
 if(!c){await z76EnsureIdentityCards(db);c=await q();}
 return c;
}
function z80CardOk(card,p){
 return !!card&&z78Digits(p.card_no).replace(/\s+/g,'')===String(card.card_no)&&String(p.card_code||'').replace(/\s+/g,'').toUpperCase()===String(card.card_code).toUpperCase();
}
async function z80Blocked(db,userId,now){
 const r=await db.prepare('SELECT blocked_until FROM z80_bank_attempts WHERE user_id=?').bind(userId).first();
 return Number(r?.blocked_until||0)>now;
}
async function z80Fail(db,userId,now){
 await db.prepare('INSERT INTO z80_bank_attempts(user_id,failures,blocked_until) VALUES(?,1,0) ON CONFLICT(user_id) DO UPDATE SET failures=failures+1,blocked_until=CASE WHEN failures+1>=5 THEN ? ELSE 0 END').bind(userId,now+15*60000).run();
}
const z80Clear=(db,userId)=>db.prepare('DELETE FROM z80_bank_attempts WHERE user_id=?').bind(userId).run();
async function z80Unlocked(db,userId,sessionHash,now){
 if(!sessionHash)return false;
 const r=await db.prepare('UPDATE z80_bank_unlock SET expires_at=? WHERE user_id=? AND session_hash=? AND expires_at>? RETURNING expires_at').bind(now+Z80_UNLOCK_TTL,userId,sessionHash,now).first();
 return !!r;
}
async function z80Unlock(db,userId,sessionHash,now){
 await db.batch([
  db.prepare('DELETE FROM z80_bank_unlock WHERE expires_at<?').bind(now),
  db.prepare('INSERT INTO z80_bank_unlock(user_id,session_hash,expires_at) VALUES(?,?,?) ON CONFLICT(user_id,session_hash) DO UPDATE SET expires_at=excluded.expires_at').bind(userId,sessionHash,now+Z80_UNLOCK_TTL)
 ]);
}
async function z80Presidents(db){
 try{return (await db.prepare("SELECT user_id FROM z711_code_entitlements WHERE scope='presidency' AND granted_at>0 AND revoked_at=0").all()).results.map(r=>r.user_id);}catch(e){return [];}
}

// Deposit/withdraw/interest must pass through this gate instead of calling z68BankAction directly.
async function z80BankGate(req,db,env,p){
 const u=await getMe(req,db);if(!u)return err(401,'سجّل الدخول أولًا');
 await z80Ensure(db);
 const type=String(p.type||''),now=Date.now(),sh=await z80Sess(req);
 const creds=await db.prepare('SELECT 1 FROM z80_bank_creds WHERE user_id=?').bind(u.id).first();
 if(!creds)return err(403,'أنشئ بيانات البنك أولًا');
 if(!(await z80Unlocked(db,u.id,sh,now)))return err(403,'سجّل دخولك إلى البنك بكلمة المرور والرمز السري أولًا');
 if(type==='savingInterest')return await z68BankAction(req,db,env,p);
 const kind=type==='savingDeposit'?'deposit':type==='savingWithdraw'?'withdraw':'';
 if(!kind)return err(400,'نوع عملية البنك غير صحيح');
 // Safe replay: a receipt already recorded for this request id is returned as-is.
 const rid=String(p.request_id||'');
 if(/^[a-zA-Z0-9-]{8,85}$/.test(rid)){
  await z68BankEnsure(db);
  const old=await z68BankReceipt(db,rid,u.id);
  if(old)return await z68BankAction(req,db,env,p);
 }
 const tok=String(p.bank_token||''),th=/^[a-f0-9]{64}$/.test(tok)?await digest(tok):'';
 const claim=th?await db.prepare('UPDATE z80_bank_tokens SET used=1 WHERE token_hash=? AND user_id=? AND kind=? AND used=0 AND expires_at>? RETURNING token_hash').bind(th,u.id,kind,now).first():null;
 if(!claim)return err(403,'انتهت صلاحية التحقق أو استُخدمت من قبل؛ أعد إدخال بيانات التحقق');
 let res;
 try{res=await z68BankAction(req,db,env,p);}
 catch(e){await db.prepare('UPDATE z80_bank_tokens SET used=0 WHERE token_hash=?').bind(th).run();throw e;}
 if(!res.ok)await db.prepare('UPDATE z80_bank_tokens SET used=0 WHERE token_hash=?').bind(th).run();
 return res;
}

async function z80State(db,u,sh,now){
 const creds=await db.prepare('SELECT 1 FROM z80_bank_creds WHERE user_id=?').bind(u.id).first();
 const unlocked=creds?await z80Unlocked(db,u.id,sh,now):false;
 const rec=await db.prepare('SELECT id,mode,status,expires_at FROM z80_recovery WHERE user_id=? ORDER BY created_at DESC LIMIT 1').bind(u.id).first();
 let recovery=null;
 if(rec&&(rec.status==='pending'||rec.status==='rejected'||(rec.status==='approved'&&Number(rec.expires_at)>now)))recovery={status:rec.status,mode:rec.mode};
 return {ok:true,has_creds:!!creds,unlocked,recovery};
}

async function z80Route(request,db,env,method,path){
 const u=await getMe(request,db);if(!u)return err(401,'سجّل دخولك الأول');
 await z80Ensure(db);
 const now=Date.now(),sh=await z80Sess(request);
 if(method==='GET'){
  if(path==='/api/v80/bank/state')return json(await z80State(db,u,sh,now));
  if(path==='/api/v80/recovery/list'){
   if(!isAdmin(u))return err(403,'طلبات الاسترجاع لصاحب كود الرئاسة المفتوح فقط');
   const rows=(await db.prepare("SELECT r.id,r.mode,r.status,r.created_at,r.decided_at,us.name,c.card_no FROM z80_recovery r JOIN users us ON us.id=r.user_id LEFT JOIN z76_identity_cards c ON c.user_id=r.user_id ORDER BY (r.status='pending') DESC,r.created_at DESC LIMIT 60").all()).results;
   return json({ok:true,requests:rows});
  }
  if(path==='/api/v80/deductions'){
   if(!isAdmin(u))return err(403,'السجل لصاحب كود الرئاسة المفتوح فقط');
   const rows=(await db.prepare('SELECT d.id,d.amount,d.reason,d.created_at,t.name AS citizen,a.name AS actor FROM z80_deductions d LEFT JOIN users t ON t.id=d.target_id LEFT JOIN users a ON a.id=d.actor_id ORDER BY d.created_at DESC LIMIT 100').all()).results;
   return json({ok:true,log:rows});
  }
  return err(404,'غير موجود');
 }
 if(method!=='POST')return err(405,'طريقة غير مسموحة');
 const origin=request.headers.get('Origin'),site=new URL(request.url).origin;
 if(origin&&origin!==site)return err(403,'المصدر غير مسموح');
 let p={};try{const raw=await request.text();if(raw.length>MAX_BODY)return err(413,'الطلب أكبر من المسموح');p=JSON.parse(raw||'{}')}catch(e){return err(400,'طلب غير صالح')}

 if(path==='/api/v80/deduct'){
  if(!isAdmin(u))return err(403,'خصم الأموال لصاحب كود الرئاسة المصرّح له فقط');
  const rid=crop(p.request_id,80),amount=Number(p.amount),reason=crop(p.reason,120),targetId=crop(p.user_id,90);
  if(!/^[0-9a-f-]{36}$/i.test(rid))return err(400,'رقم الطلب غير صالح');
  if(!Number.isSafeInteger(amount)||amount<1||amount>10000000)return err(400,'المبلغ يجب أن يكون بين 1 و10,000,000 زنجر');
  if(reason.length<3)return err(400,'اكتب سبب الخصم');
  const target=await db.prepare('SELECT id,name FROM users WHERE id=?').bind(targetId).first();
  if(!target)return err(404,'المواطن غير موجود');
  let receipt;
  try{receipt=await db.prepare('INSERT OR IGNORE INTO z80_deductions(id,actor_id,target_id,amount,reason,created_at) VALUES(?,?,?,?,?,?) RETURNING id').bind(rid,u.id,target.id,amount,reason,now).first();}
  catch(e){if(/رصيد المواطن/.test(String(e?.message||e)))return err(409,'رصيد المواطن لا يكفي لهذا الخصم؛ لم يتم أي خصم');throw e;}
  if(!receipt)return err(409,'تم تنفيذ هذا الخصم مسبقًا');
  try{await zNotify(db,target.id,'⚖️ خصم رئاسي من محفظتك',amount.toLocaleString('en-US')+' زنجر أُعيدت إلى خزينة الدولة. السبب: '+reason,'government');}catch(e){}
  return json({ok:true,notice:'تم خصم '+amount.toLocaleString('en-US')+' زنجر من '+target.name+' وإعادتها إلى خزينة الدولة'});
 }

 if(path==='/api/v80/bank/setup'){
  if(await db.prepare('SELECT 1 FROM z80_bank_creds WHERE user_id=?').bind(u.id).first())return err(409,'بيانات البنك موجودة بالفعل');
  const pass=String(p.password??''),pin=String(p.pin??'');
  if(!z80OkPass(pass))return err(400,'كلمة مرور البنك من 8 إلى 72 حرفًا');
  if(!z80OkPin(pin))return err(400,'الرمز السري للبنك من 4 إلى 8 أرقام');
  if(pass===pin)return err(400,'كلمة المرور والرمز السري يجب أن يختلفا');
  const card=await z80Card(db,u.id);
  if(card&&[String(card.card_no),String(card.card_code).toUpperCase()].includes(pass.toUpperCase())||card&&[String(card.card_no),String(card.card_code).toUpperCase()].includes(pin.toUpperCase()))return err(400,'بيانات البنك يجب أن تختلف عن بيانات الهوية');
  const ps=z80Salt(),ns=z80Salt();
  try{await db.prepare('INSERT INTO z80_bank_creds(user_id,pass_hash,pass_salt,pin_hash,pin_salt,created_at,updated_at) VALUES(?,?,?,?,?,?,?)').bind(u.id,await z80Hash(pass,ps),ps,await z80Hash(pin,ns),ns,now,now).run();}
  catch(e){return err(409,'بيانات البنك موجودة بالفعل');}
  await z80Unlock(db,u.id,sh,now);
  return json({ok:true,notice:'تم حفظ بيانات البنك'});
 }

 if(path==='/api/v80/bank/login'){
  const c=await db.prepare('SELECT * FROM z80_bank_creds WHERE user_id=?').bind(u.id).first();
  if(!c)return err(403,'أنشئ بيانات البنك أولًا');
  if(await z80Blocked(db,u.id,now))return err(429,'محاولات كثيرة؛ انتظر 15 دقيقة');
  const [h1,h2]=await Promise.all([z80Hash(String(p.password??''),c.pass_salt),z80Hash(String(p.pin??''),c.pin_salt)]);
  if(!(eqSecure(h1,c.pass_hash)&eqSecure(h2,c.pin_hash))){await z80Fail(db,u.id,now);return err(403,'كلمة المرور أو الرمز السري غير صحيح');}
  await z80Clear(db,u.id);await z80Unlock(db,u.id,sh,now);
  return json({ok:true});
 }

 if(path==='/api/v80/bank/lock'){
  await db.prepare('DELETE FROM z80_bank_unlock WHERE user_id=?').bind(u.id).run();
  return json({ok:true});
 }

 if(path==='/api/v80/bank/verify'){
  const kind=p.kind==='deposit'?'deposit':p.kind==='withdraw'?'withdraw':'';
  if(!kind)return err(400,'نوع العملية غير صحيح');
  if(!(await z80Unlocked(db,u.id,sh,now)))return err(403,'سجّل دخولك إلى البنك أولًا');
  if(await z80Blocked(db,u.id,now))return err(429,'محاولات كثيرة؛ انتظر 15 دقيقة');
  const c=await db.prepare('SELECT pin_hash,pin_salt FROM z80_bank_creds WHERE user_id=?').bind(u.id).first();
  if(!c)return err(403,'أنشئ بيانات البنك أولًا');
  const card=await z80Card(db,u.id);
  const pinOk=eqSecure(await z80Hash(String(p.bank_pin??''),c.pin_salt),c.pin_hash);
  if(!(z80CardOk(card,p)&&pinOk)){await z80Fail(db,u.id,now);return err(400,'بيانات التحقق غير صحيحة');}
  await z80Clear(db,u.id);
  const token=hex(crypto.getRandomValues(new Uint8Array(32)));
  await db.batch([
   db.prepare('DELETE FROM z80_bank_tokens WHERE expires_at<? OR (user_id=? AND used=0)').bind(now,u.id),
   db.prepare('INSERT INTO z80_bank_tokens(token_hash,user_id,kind,expires_at,used) VALUES(?,?,?,?,0)').bind(await digest(token),u.id,kind,now+Z80_TOKEN_TTL)
  ]);
  return json({ok:true,token,expires_in:Z80_TOKEN_TTL});
 }

 if(path==='/api/v80/bank/recovery/request'){
  const mode=['password','pin','both'].includes(p.mode)?p.mode:'';
  if(!mode)return err(400,'اختر ما نسيته: كلمة المرور أو الرمز السري أو الاثنين');
  if(!(await db.prepare('SELECT 1 FROM z80_bank_creds WHERE user_id=?').bind(u.id).first()))return err(409,'لم تنشئ بيانات بنك بعد؛ أنشئها مباشرة');
  if(await z80Blocked(db,u.id,now))return err(429,'محاولات كثيرة؛ انتظر 15 دقيقة');
  const card=await z80Card(db,u.id);
  const nameOk=z78NameKey(p.name)!==''&&z78NameKey(p.name)===z78NameKey(u.name);
  if(!(nameOk&&z80CardOk(card,p))){await z80Fail(db,u.id,now);return err(400,'بيانات التحقق غير صحيحة');}
  await z80Clear(db,u.id);
  const pending=await db.prepare("SELECT 1 FROM z80_recovery WHERE user_id=? AND status='pending'").bind(u.id).first();
  if(pending)return json({ok:true,notice:'طلبك تحت التنفيذ'});
  await db.prepare("INSERT INTO z80_recovery(id,user_id,mode,status,created_at) VALUES(?,?,?,'pending',?)").bind(crypto.randomUUID(),u.id,mode,now).run();
  const label={password:'نسيان كلمة المرور',pin:'نسيان الرمز السري',both:'نسيان كلمة المرور والرمز السري'}[mode];
  for(const pid of await z80Presidents(db)){try{await zNotify(db,pid,'🔐 طلب استرجاع بيانات البنك',u.name+' — رقم الهوية '+card.card_no+' — '+label,'government');}catch(e){}}
  return json({ok:true,notice:'طلبك تحت التنفيذ'});
 }

 if(path==='/api/v80/recovery/decide'){
  if(!isAdmin(u))return err(403,'القرار لصاحب كود الرئاسة المصرّح له فقط');
  const rid=crop(p.id,80),approve=p.approve===true;
  const row=await db.prepare("SELECT id,user_id FROM z80_recovery WHERE id=? AND status='pending'").bind(rid).first();
  if(!row)return err(409,'الطلب غير موجود أو تم البت فيه');
  if(row.user_id===u.id&&(await z80Presidents(db)).some(x=>x!==u.id))return err(403,'لا يمكنك البت في طلبك بنفسك؛ يقرره رئيس آخر');
  const done=await db.prepare("UPDATE z80_recovery SET status=?,decided_at=?,decided_by=?,expires_at=? WHERE id=? AND status='pending' RETURNING id").bind(approve?'approved':'rejected',now,u.id,approve?now+Z80_RECOVERY_TTL:0,rid).first();
  if(!done)return err(409,'تم البت في الطلب من قبل');
  try{await zNotify(db,row.user_id,approve?'✅ تمت الموافقة على طلبك':'❌ تم رفض طلبك',approve?'ادخل بنك الزنجر المركزي واختر بيانات جديدة. الموافقة سارية 24 ساعة.':'تم رفض طلب استرجاع بيانات البنك.','government');}catch(e){}
  return json({ok:true,notice:approve?'تمت الموافقة؛ سيختار المواطن بياناته الجديدة بنفسه':'تم رفض الطلب'});
 }

 if(path==='/api/v80/bank/reset'){
  const rec=await db.prepare("SELECT id,mode FROM z80_recovery WHERE user_id=? AND status='approved' AND expires_at>? ORDER BY created_at DESC LIMIT 1").bind(u.id,now).first();
  if(!rec)return err(403,'لا توجد موافقة سارية على طلبك');
  const wantPass=rec.mode!=='pin',wantPin=rec.mode!=='password';
  const pass=String(p.password??''),pin=String(p.pin??'');
  if(wantPass&&!z80OkPass(pass))return err(400,'كلمة مرور البنك من 8 إلى 72 حرفًا');
  if(wantPin&&!z80OkPin(pin))return err(400,'الرمز السري للبنك من 4 إلى 8 أرقام');
  if(wantPass&&wantPin&&pass===pin)return err(400,'كلمة المرور والرمز السري يجب أن يختلفا');
  const card=await z80Card(db,u.id),bad=[String(card.card_no),String(card.card_code).toUpperCase()];
  if((wantPass&&bad.includes(pass.toUpperCase()))||(wantPin&&bad.includes(pin.toUpperCase())))return err(400,'بيانات البنك يجب أن تختلف عن بيانات الهوية');
  const claim=await db.prepare("UPDATE z80_recovery SET status='used' WHERE id=? AND status='approved' AND expires_at>? RETURNING id").bind(rec.id,now).first();
  if(!claim)return err(409,'تم استخدام الموافقة من قبل');
  try{
   const sets=[],vals=[];
   if(wantPass){const s=z80Salt();sets.push('pass_hash=?','pass_salt=?');vals.push(await z80Hash(pass,s),s);}
   if(wantPin){const s=z80Salt();sets.push('pin_hash=?','pin_salt=?');vals.push(await z80Hash(pin,s),s);}
   await db.prepare('UPDATE z80_bank_creds SET '+sets.join(',')+',updated_at=? WHERE user_id=?').bind(...vals,now,u.id).run();
  }catch(e){await db.prepare("UPDATE z80_recovery SET status='approved' WHERE id=?").bind(rec.id).run();throw e;}
  await db.prepare('DELETE FROM z80_bank_unlock WHERE user_id=?').bind(u.id).run();
  return json({ok:true,notice:'تم تحديث بيانات البنك؛ ادخل بها الآن'});
 }
 return err(404,'غير موجود');
}
