// V71: separate login username + public display name. users.name/name_key stay the DISPLAY name
// (unique, used everywhere else in the game); users.username/username_key are the login identifier.
// Old accounts have username NULL and keep logging in with their registered name.
let z67UserColsReady=null;
async function z67EnsureUsernameCols(db){
 if(z67UserColsReady)return z67UserColsReady;
 z67UserColsReady=(async()=>{
  const cols=((await db.prepare('PRAGMA table_info(users)').all()).results)||[];
  for(const c of ['username','username_key']){
   if(!cols.some(x=>x.name===c)){
    try{await db.prepare('ALTER TABLE users ADD COLUMN '+c+' TEXT').run();}
    catch(e){if(!/duplicate column/i.test(String(e&&e.message||e)))throw e;}
   }
  }
  await db.prepare('CREATE UNIQUE INDEX IF NOT EXISTS users_username_key_uq ON users(username_key) WHERE username_key IS NOT NULL').run();
 })().catch(e=>{z67UserColsReady=null;throw e});
 return z67UserColsReady;
}
// Arabic or Latin letters, digits, _ . - ; 3-24 chars; diacritics and tatweel are removed so look-alikes collide.
const z67Clean=v=>String(v??'').normalize('NFKC').replace(/[\u0640\u064B-\u065F\u0670]/g,'').trim();
const z67Username=v=>{const s=z67Clean(v);return /^[\p{L}\p{N}_.\-]{3,24}$/u.test(s)?s:''};
const z67UserKey=v=>z67Clean(v).toLocaleLowerCase('ar');
async function z67Register(req,db,p){
 await z67EnsureBase(db);await z67EnsureUsernameCols(db);
 const username=z67Username(p.username),name=z66Name(p.display_name??p.name),password=p.password,avatar=String(p.avatar||''),now=Date.now();
 if(!username)return err(400,'اسم المستخدم من 3 إلى 24 حرفًا: حروف عربية أو إنجليزية أو أرقام أو نقطة أو شرطة أو شرطة سفلية، بدون مسافات');
 if(!name)return err(400,'اكتب الاسم الظاهر من حرفين إلى 35 حرفًا');
 if(!z66Pass(password))return err(400,'كلمة المرور من 8 إلى 72 حرفًا');
 if(password===username)return err(400,'لا تجعل كلمة المرور نفس اسم المستخدم');
 if(avatar&&(!/^data:image\/jpeg;base64,[A-Za-z0-9+/]+={0,2}$/.test(avatar)||avatar.length>58000))return err(400,'الصورة كبيرة أو غير مدعومة');
 const key=norm(name),ukey=z67UserKey(username),ip=z66IP(req);
 // Bound the signup attempt budget without forcing existing players through new admin schemas.
 if(!(await z67Rate(db,'signup:'+ip+':'+ukey)))return err(429,'محاولات كثيرة؛ جرّب بعد قليل');
 // A username must not equal another username, nor the login name of an old account (username NULL) that still signs in by its name.
 const userTaken=await db.prepare('SELECT id FROM users WHERE username_key=? OR (username_key IS NULL AND name_key=?) LIMIT 1').bind(ukey,norm(username)).first();
 if(userTaken)return err(409,'اسم المستخدم مستخدم بالفعل؛ اختر اسم مستخدم آخر');
 const nameTaken=await db.prepare('SELECT id FROM users WHERE name_key=? LIMIT 1').bind(key).first();
 if(nameTaken)return err(409,'الاسم الظاهر مستخدم بالفعل؛ اختر اسمًا ظاهرًا آخر');
 const free=await db.prepare('SELECT slot FROM z639_guest_slots WHERE user_id IS NULL ORDER BY slot LIMIT 1').first();
 if(!free)return err(409,'اكتمل عدد الحسابات الثلاثين؛ تواصل مع مدير اللعبة');
 const uid=id(),s=salt(),verifier=Z66_PW_SCHEME+await pwHash(password,s),identity='ZG-NEW-'+crypto.randomUUID(),token=hex(crypto.getRandomValues(new Uint8Array(32))),tokenHash=await digest(token);
 try{
  // D1 batch is transactional: if inserting a duplicate username fails, the slot reservation rolls back.
  await db.batch([
   db.prepare('UPDATE z639_guest_slots SET user_id=?,claimed_at=? WHERE slot=(SELECT slot FROM z639_guest_slots WHERE user_id IS NULL ORDER BY slot LIMIT 1) AND user_id IS NULL').bind(uid,now),
   db.prepare("INSERT INTO users(id,name,name_key,passhash,salt,role,rank,job,points,identity_no,joined,avatar,username,username_key) SELECT ?,?,?,?,?, 'citizen','مواطن','مواطن',0,?,?,?,?,? WHERE EXISTS(SELECT 1 FROM z639_guest_slots WHERE user_id=?)").bind(uid,name,key,verifier,s,identity,now,avatar,username,ukey,uid),
   db.prepare('INSERT INTO sessions(token_hash,user_id,expires_at) SELECT ?,id,? FROM users WHERE id=?').bind(tokenHash,now+SESSION_LIFETIME,uid)
  ]);
 }catch(e){console.error('Z67 registration conflict:',String(e));return err(409,'تعذّر إنشاء الحساب أو أن الاسم مستخدم؛ حدّث الصفحة وأعد المحاولة');}
 const saved=await db.prepare('SELECT slot FROM z639_guest_slots WHERE user_id=?').bind(uid).first();
 if(!saved)return err(409,'الأماكن ممتلئة؛ لم يُنشأ حساب جديد');
 z32PublicCache.delete('bootstrap-users');
 return json({ok:true,logged_in:true,slot:saved.slot},200,{'Set-Cookie':sessionCookie(token)});
}
async function z67Rate(db,key){
 // No new schema: rate-limit per process/isolate as additional protection; D1 enforces 30 total slots.
 const now=Date.now(),last=z67LocalRates.get(key)||{start:now,count:0};
 if(now-last.start>60000){last.start=now;last.count=0;}
 last.count++;z67LocalRates.set(key,last);
 if(z67LocalRates.size>2000)z67LocalRates.clear();
 return last.count<=8;
}
const z67LocalRates=new Map();
async function z67Login(req,db,p){
 await z67EnsureBase(db);await z67EnsureUsernameCols(db);
 const ident=String(p.username??p.name??'').trim(),password=p.password;
 if(!ident||ident.length>80||typeof password!=='string')return err(400,'اكتب اسم المستخدم وكلمة المرور');
 // New accounts sign in by username; old accounts (username NULL) still sign in by their registered name.
 const ukey=z67UserKey(ident),lkey=norm(ident),ip=z66IP(req),attemptKey=await digest('z67-login:'+ip+':'+ukey),now=Date.now();
 const attempts=await db.prepare('SELECT failures,blocked_until FROM z639_attempts WHERE key=?').bind(attemptKey).first();
 if(Number(attempts?.blocked_until||0)>now)return err(429,'محاولات كثيرة؛ انتظر 15 دقيقة قبل إعادة الدخول');
 const rows=((await db.prepare('SELECT u.id,u.passhash,u.salt FROM users u JOIN z639_guest_slots gs ON gs.user_id=u.id WHERE (u.username_key=? OR (u.username_key IS NULL AND u.name_key=?)) AND NOT EXISTS(SELECT 1 FROM z64_archived_users a WHERE a.user_id=u.id AND a.restored_at=0) LIMIT 2').bind(ukey,lkey).all()).results)||[];
 if(!rows.length)return err(401,'اسم المستخدم أو كلمة المرور غير صحيحين');
 if(rows.every(r=>r.passhash==='guest-slot-managed'))return err(400,'هذا حساب ضيف قديم؛ استخدم تبويب حساب ضيف قديم');
 let valid=null,legacySalt=null;
 for(const row of rows){
  if(row.passhash==='guest-slot-managed')continue;
  if(row.passhash.startsWith(Z66_PW_SCHEME)&&z66Pass(password)){
   if(eqSecure(Z66_PW_SCHEME+await pwHash(password,row.salt),row.passhash)){valid=row;break;}
  }else if(/^[a-f0-9]{64}$/.test(row.passhash)){
   if(!/^[a-f0-9]{64}$/.test(String(p.legacy_proof||''))){legacySalt=legacySalt||row.salt;continue;}
   if(eqSecure(String(p.legacy_proof),row.passhash)){valid=row;break;}
  }
 }
 if(!valid&&legacySalt)return json({error:'مطلوب التحقق من كلمة مرورك القديمة',legacy_salt:legacySalt},428);
 if(!valid){
  const failCount=Number(attempts?.failures||0)+1;
  await db.prepare('INSERT INTO z639_attempts(key,failures,blocked_until,updated_at) VALUES(?,?,?,?) ON CONFLICT(key) DO UPDATE SET failures=excluded.failures,blocked_until=excluded.blocked_until,updated_at=excluded.updated_at').bind(attemptKey,failCount>=6?0:failCount,failCount>=6?now+15*60000:0,now).run();
  return err(401,'اسم المستخدم أو كلمة المرور غير صحيحين');
 }
 await db.prepare('DELETE FROM z639_attempts WHERE key=?').bind(attemptKey).run();
 const token=hex(crypto.getRandomValues(new Uint8Array(32)));
 await db.prepare('INSERT INTO sessions(token_hash,user_id,expires_at) VALUES(?,?,?)').bind(await digest(token),valid.id,Date.now()+SESSION_LIFETIME).run();
 return json({ok:true,logged_in:true},200,{'Set-Cookie':sessionCookie(token)});
}
// V65 membership approvals — 30 existing Guest slots, user-chosen password, explicit presidential admission.
// The presidency code ALONE opens ONLY the admissions inbox. Treasury, account deletion,
// and full presidency still require the separate PIN and normal authenticated session.
const Z66_ADMISSION_CODE_HASH='7dd50fcb1d342d3c66594c099cdc284cdbb35e106f5a2ad3ef16d136d5a368b6';
const Z66_WAIT_COOKIE='zangar_join', Z66_ADMIN_COOKIE='zangar_admissions';
let z66Ready=null;
async function z66Ensure(db){
 if(z66Ready)return z66Ready;
 z66Ready=(async()=>{
  await db.batch([
   db.prepare("CREATE TABLE IF NOT EXISTS z66_requests(id TEXT PRIMARY KEY,name TEXT NOT NULL,name_key TEXT NOT NULL UNIQUE,passhash TEXT NOT NULL,salt TEXT NOT NULL,avatar TEXT NOT NULL DEFAULT '',status TEXT NOT NULL DEFAULT 'pending' CHECK(status IN ('pending','approved','rejected')),created_at INTEGER NOT NULL,reviewed_at INTEGER NOT NULL DEFAULT 0,retry_after INTEGER NOT NULL DEFAULT 0,request_hash TEXT NOT NULL UNIQUE,request_expires INTEGER NOT NULL,user_id TEXT NOT NULL DEFAULT '',slot INTEGER NOT NULL DEFAULT 0,reviewer TEXT NOT NULL DEFAULT '')"),
   db.prepare("CREATE INDEX IF NOT EXISTS z66_requests_status ON z66_requests(status,created_at)"),
   db.prepare("CREATE TABLE IF NOT EXISTS z66_approvals(request_id TEXT PRIMARY KEY,user_id TEXT NOT NULL UNIQUE,slot INTEGER NOT NULL UNIQUE,identity_no TEXT NOT NULL UNIQUE,reviewer TEXT NOT NULL,created_at INTEGER NOT NULL)"),
   db.prepare(`CREATE TRIGGER IF NOT EXISTS z66_approval_guard BEFORE INSERT ON z66_approvals BEGIN
      SELECT CASE WHEN NOT EXISTS(SELECT 1 FROM z66_requests WHERE id=NEW.request_id AND status='pending') THEN RAISE(ABORT,'الطلب غير متاح') END;
      SELECT CASE WHEN NOT EXISTS(SELECT 1 FROM z639_guest_slots WHERE slot=NEW.slot AND user_id IS NULL) THEN RAISE(ABORT,'لا يوجد مكان متاح') END;
      SELECT CASE WHEN EXISTS(SELECT 1 FROM users WHERE name_key=(SELECT name_key FROM z66_requests WHERE id=NEW.request_id)) THEN RAISE(ABORT,'اسم المواطن مستخدم') END;
    END`),
   db.prepare(`CREATE TRIGGER IF NOT EXISTS z66_approval_apply AFTER INSERT ON z66_approvals BEGIN
      INSERT INTO users(id,name,name_key,passhash,salt,role,rank,job,points,identity_no,joined,avatar)
       SELECT NEW.user_id,name,name_key,passhash,salt,'citizen','مواطن','مواطن',0,NEW.identity_no,NEW.created_at,avatar FROM z66_requests WHERE id=NEW.request_id;
      UPDATE z639_guest_slots SET user_id=NEW.user_id,claimed_at=NEW.created_at WHERE slot=NEW.slot AND user_id IS NULL;
      UPDATE z66_requests SET status='approved',reviewed_at=NEW.created_at,reviewer=NEW.reviewer,user_id=NEW.user_id,slot=NEW.slot WHERE id=NEW.request_id AND status='pending';
    END`),
   db.prepare("CREATE TABLE IF NOT EXISTS z66_admin_sessions(token_hash TEXT PRIMARY KEY,expires_at INTEGER NOT NULL,created_at INTEGER NOT NULL)"),
   db.prepare("CREATE TABLE IF NOT EXISTS z66_attempts(key TEXT PRIMARY KEY,failures INTEGER NOT NULL DEFAULT 0,blocked_until INTEGER NOT NULL DEFAULT 0,updated_at INTEGER NOT NULL DEFAULT 0)"),
   db.prepare("CREATE TABLE IF NOT EXISTS z66_reviewer_devices(user_id TEXT PRIMARY KEY,expires_at INTEGER NOT NULL,updated_at INTEGER NOT NULL)"),
  ]);
 })().catch(e=>{z66Ready=null;throw e});return z66Ready;
}
function z66Cookie(key,value,maxAge){return `${key}=${value}; HttpOnly; Secure; SameSite=Lax; Path=/; Max-Age=${maxAge}`;}
function z66Name(v){const s=crop(v,35);return s.length>=2&&s.length<=35&&!/[<>\x00-\x1f]/.test(s)?s:''}
async function z66Rate(db,key,failed=false){
 const now=Date.now(),k=await digest('z66:'+key),r=await db.prepare('SELECT failures,blocked_until FROM z66_attempts WHERE key=?').bind(k).first();
 if(Number(r?.blocked_until||0)>now)return false;
 if(failed){const count=Number(r?.failures||0)+1;await db.prepare('INSERT INTO z66_attempts(key,failures,blocked_until,updated_at) VALUES(?,?,?,?) ON CONFLICT(key) DO UPDATE SET failures=excluded.failures,blocked_until=excluded.blocked_until,updated_at=excluded.updated_at').bind(k,count>=7?0:count,count>=7?now+15*60000:0,now).run();}
 else await db.prepare('DELETE FROM z66_attempts WHERE key=?').bind(k).run();return true;
}
const z66IP=req=>crop(req.headers.get('CF-Connecting-IP')||'local',90);
function z66Pass(s){return typeof s==='string'&&s.length>=8&&s.length<=72&&!/[\x00-\x1f]/.test(s)}
async function z66Session(db,userId){const token=hex(crypto.getRandomValues(new Uint8Array(32))),now=Date.now();await db.prepare('INSERT INTO sessions(token_hash,user_id,expires_at) VALUES(?,?,?)').bind(await digest(token),userId,now+SESSION_LIFETIME).run();return z66Cookie('zangar_session',token,30*86400)}
// Limited, time-bound reviewer binding for the EXISTING in-game mailbox / optional Web Push.
// It does not grant presidency, treasury or player-management rights.
async function z66RememberReviewer(req,db,expiresAt){
 const u=await getMe(req,db);if(!u)return false;
 // Keep optional push subscriptions useful beyond the 8-hour code session.
 // Code-only approval rights still expire on the original 8-hour admin cookie.
 const now=Date.now(),renewUntil=now+30*86400000;
 const old=await db.prepare('SELECT expires_at FROM z66_reviewer_devices WHERE user_id=?').bind(u.id).first();
 if(Number(old?.expires_at||0)>=now+23*86400000)return true;
 await db.prepare('INSERT INTO z66_reviewer_devices(user_id,expires_at,updated_at) VALUES(?,?,?) ON CONFLICT(user_id) DO UPDATE SET expires_at=excluded.expires_at,updated_at=excluded.updated_at').bind(u.id,renewUntil,now).run();
 return true;
}
async function z66NotifyReviewers(db,requestId,name){
 try{
  const now=Date.now(),nameSafe=crop(name,35);
  // Existing z_notifications trigger respects each subscribed device's "government" push preference.
  await db.prepare(`INSERT OR IGNORE INTO z_notifications(id,user_id,title,body,kind,created_at)
   SELECT 'z66-join-'||?||'-'||?||'-'||d.user_id,d.user_id,'👤 طلب انضمام جديد',?, 'government',?
   FROM z66_reviewer_devices d JOIN users u ON u.id=d.user_id
   WHERE d.expires_at>? AND NOT EXISTS(SELECT 1 FROM z64_archived_users a WHERE a.user_id=d.user_id AND a.restored_at=0)`)
   .bind(requestId,now,'اللاعب '+nameSafe+' أرسل طلب انضمام. افتح إشعارات الدولة أو البريد لقبوله أو رفضه.',now,now).run();
 }catch(e){console.warn('Admission notice could not be queued (request remains saved):',String(e));}
}
async function z66Apply(req,db,p){
 await z66Ensure(db);const now=Date.now(),name=z66Name(p.name),password=p.password,avatar=String(p.avatar||''),nameKey=norm(name),ip=z66IP(req);
 if(!name)return err(400,'اكتب اسمًا صحيحًا من حرفين إلى 35 حرفًا');
 if(!z66Pass(password))return err(400,'اختار كلمة مرور من 8 إلى 72 حرفًا');
 if(avatar&&(!/^data:image\/jpeg;base64,[A-Za-z0-9+/]+={0,2}$/.test(avatar)||avatar.length>58000))return err(400,'الصورة كبيرة أو غير مدعومة');
 if(!(await z66Rate(db,'apply:'+ip)))return err(429,'طلبات كثيرة من الجهاز؛ حاول بعد 15 دقيقة');
 const myTicket=cookieValue(req,Z66_WAIT_COOKIE);if(/^[a-f0-9]{64}$/.test(myTicket)){
  const prior=await db.prepare('SELECT status,retry_after FROM z66_requests WHERE request_hash=? AND request_expires>?').bind(await digest(myTicket),now).first();
  if(prior?.status==='pending')return err(409,'عندك طلب انتظار بالفعل؛ افتح حالة الطلب');
  if(prior?.status==='rejected'&&prior.retry_after>now)return err(429,'تم رفض طلبك؛ تقدر تعيد الطلب بعد ساعتين',);
 }
 const used=await db.prepare('SELECT id FROM users WHERE name_key=?').bind(nameKey).first();
 if(used)return err(409,'الاسم مستخدم بالفعل؛ اختر اسمًا آخر أو ادخل لحسابك القديم');
 const slots=await db.prepare('SELECT COUNT(*) AS n FROM z639_guest_slots WHERE user_id IS NULL').first();
 if(!Number(slots?.n))return err(409,'اكتمل عدد الحسابات الثلاثين حاليًا، تواصل مع الرئاسة');
 const existing=await db.prepare('SELECT id,status,retry_after FROM z66_requests WHERE name_key=?').bind(nameKey).first();
 if(existing?.status==='approved')return err(409,'الاسم مسجل؛ استخدم تبويب تسجيل الدخول');
 if(existing?.status==='pending')return err(409,'هذا الاسم له طلب قيد المراجعة بالفعل');
 if(existing?.status==='rejected'&&existing.retry_after>now)return json({error:'تم رفض طلب الاسم سابقًا؛ حاول بعد انتهاء المهلة',retry_after:existing.retry_after},429);
 const token=hex(crypto.getRandomValues(new Uint8Array(32))),requestHash=await digest(token),s=salt(),hash=Z66_PW_SCHEME+await pwHash(password,s),expires=now+7*86400000,requestId=existing?.id||id();
 if(existing){
  await db.prepare("UPDATE z66_requests SET status='pending',name=?,passhash=?,salt=?,avatar=?,created_at=?,reviewed_at=0,retry_after=0,request_hash=?,request_expires=?,reviewer='' WHERE id=? AND status='rejected' AND retry_after<=?").bind(name,hash,s,avatar,now,requestHash,expires,existing.id,now).run();
 }else{
  await db.prepare("INSERT INTO z66_requests(id,name,name_key,passhash,salt,avatar,status,created_at,request_hash,request_expires) VALUES(?,?,?,?,?,?,'pending',?,?,?)").bind(requestId,name,nameKey,hash,s,avatar,now,requestHash,expires).run();
 }
 await z66NotifyReviewers(db,requestId,name);
 return json({ok:true,status:'pending',message:'تم إرسال طلبك للرئاسة؛ انتظر الموافقة'},200,{'Set-Cookie':z66Cookie(Z66_WAIT_COOKIE,token,7*86400)});
}
async function z66Check(req,db){
 await z66Ensure(db);const token=cookieValue(req,Z66_WAIT_COOKIE),now=Date.now();
 if(!/^[a-f0-9]{64}$/.test(token))return json({status:'none'});
 const row=await db.prepare('SELECT status,retry_after,user_id,slot FROM z66_requests WHERE request_hash=? AND request_expires>?').bind(await digest(token),now).first();
 if(!row)return json({status:'none'});
 if(row.status==='approved'&&row.user_id){
  if(await db.prepare('SELECT user_id FROM z64_archived_users WHERE user_id=? AND restored_at=0').bind(row.user_id).first())return err(403,'تم إيقاف الحساب من الرئاسة');
  const headers=new Headers({'Content-Type':'application/json; charset=utf-8','Cache-Control':'no-store'});
  headers.append('Set-Cookie',z66Cookie(Z66_WAIT_COOKIE,'',0));
  headers.append('Set-Cookie',await z66Session(db,row.user_id));
  return new Response(JSON.stringify({status:'approved',logged_in:true,slot:row.slot}),{status:200,headers});
 }
 return json({status:row.status,retry_after:row.retry_after||0});
}
async function z66Login(req,db,p){
 await z66Ensure(db);const name=z66Name(p.name),password=p.password,key=norm(name),ip=z66IP(req);
 if(!name||typeof password!=='string')return err(400,'اكتب الاسم وكلمة المرور');
 if(!(await z66Rate(db,'login:'+ip+':'+key)))return err(429,'محاولات كثيرة؛ انتظر 15 دقيقة');
 // Read the current password from users, not from the original admission request.
 const row=await db.prepare("SELECT r.user_id,u.salt,u.passhash FROM z66_requests r JOIN users u ON u.id=r.user_id WHERE r.name_key=? AND r.status='approved' AND r.user_id<>''").bind(key).first();
 let valid=false;
 if(row&&z66Pass(password)){
  if(row.passhash.startsWith(Z66_PW_SCHEME)){
   valid=eqSecure(Z66_PW_SCHEME+await pwHash(password,row.salt),row.passhash);
  }else if(/^[0-9a-f]{64}$/.test(row.passhash)){
   // Rare 65.1 160k records: ask the browser to derive the legacy proof.
   // NEVER attempt the unsupported 160k operation inside a Worker.
   if(!/^[0-9a-f]{64}$/.test(String(p.legacy_proof||'')))return json({error:'يحتاج الحساب تحققًا متوافقًا مع كلمة مروره القديمة',legacy_salt:row.salt},428);
   valid=eqSecure(String(p.legacy_proof),row.passhash);
  }
 }
 if(!valid){await z66Rate(db,'login:'+ip+':'+key,true);return err(401,'الاسم أو كلمة المرور غير صحيحين، أو الحساب لم تتم الموافقة عليه');}
 if(await db.prepare('SELECT user_id FROM z64_archived_users WHERE user_id=? AND restored_at=0').bind(row.user_id).first())return err(403,'هذا الحساب أوقفته الرئاسة');
 await z66Rate(db,'login:'+ip+':'+key);return json({ok:true},200,{'Set-Cookie':await z66Session(db,row.user_id)});
}
async function z66AdminCheck(req,db){const token=cookieValue(req,Z66_ADMIN_COOKIE);if(!/^[a-f0-9]{64}$/.test(token))return false;const r=await db.prepare('SELECT expires_at FROM z66_admin_sessions WHERE token_hash=? AND expires_at>?').bind(await digest(token),Date.now()).first();return !!r;}
async function z66AdminLogin(req,db,p){
 await z66Ensure(db);const ip=z66IP(req),k='admin:'+ip,code=String(p.code||'');
 if(!(await z66Rate(db,k)))return err(429,'تم إيقاف محاولات الرئاسة 15 دقيقة');
 if(!eqSecure(await digest(code),Z66_ADMISSION_CODE_HASH)){
  await z66Rate(db,k,true);return err(403,'كود الرئاسة غير صحيح');
 }
 await z66Rate(db,k);const token=hex(crypto.getRandomValues(new Uint8Array(32))),now=Date.now();
 await db.prepare('INSERT INTO z66_admin_sessions(token_hash,expires_at,created_at) VALUES(?,?,?)').bind(await digest(token),now+8*3600000,now).run();
 await z66RememberReviewer(req,db,now+8*3600000);
 return json({ok:true},200,{'Set-Cookie':z66Cookie(Z66_ADMIN_COOKIE,token,8*3600)});
}
async function z66AdminList(req,db){
 await z66Ensure(db);if(!(await z66AdminCheck(req,db)))return err(403,'افتح مراجعة الانضمام بكود الرئاسة أولًا');
 const rows=await db.prepare("SELECT id,name,avatar,created_at,status FROM z66_requests WHERE status='pending' ORDER BY created_at ASC LIMIT 100").all();
 const slots=await db.prepare('SELECT COUNT(*) AS n FROM z639_guest_slots WHERE user_id IS NULL').first();
 return json({ok:true,requests:rows.results.map(x=>({...x,avatar:x.avatar||''})),free_slots:Number(slots?.n||0)});
}
async function z66AdminInbox(req,db){
 await z66Ensure(db);if(!(await z66AdminCheck(req,db)))return err(403,'أدخل كود الرئاسة لمراجعة الطلبات');
 // Ensure a logged-in code holder receives in-game inbox notifications and opt-in push on this account.
 const token=cookieValue(req,Z66_ADMIN_COOKIE),until=await db.prepare('SELECT expires_at FROM z66_admin_sessions WHERE token_hash=?').bind(await digest(token)).first();
 await z66RememberReviewer(req,db,Number(until?.expires_at||Date.now()));
 const pending=await db.prepare("SELECT id,name,status,created_at,reviewed_at FROM z66_requests WHERE status='pending' ORDER BY created_at ASC LIMIT 30").all();
 const history=await db.prepare("SELECT id,name,status,created_at,reviewed_at,retry_after FROM z66_requests WHERE status IN ('approved','rejected') ORDER BY reviewed_at DESC LIMIT 15").all();
 const free=await db.prepare('SELECT COUNT(*) AS n FROM z639_guest_slots WHERE user_id IS NULL').first();
 return json({ok:true,pending:pending.results,history:history.results,pending_count:pending.results.length,free_slots:Number(free?.n||0)});
}
async function z66Decision(req,db,p){
 await z66Ensure(db);if(!(await z66AdminCheck(req,db)))return err(403,'مراجعة الطلبات تحتاج كود الرئاسة');
 const rid=crop(p.request_id,100),decision=String(p.decision||''),now=Date.now();
 if(!['approve','reject'].includes(decision))return err(400,'اختار موافقة أو رفض');
 const row=await db.prepare("SELECT id,name FROM z66_requests WHERE id=? AND status='pending'").bind(rid).first();if(!row)return err(409,'الطلب سبق مراجعته أو لم يعد متاحًا');
 if(decision==='reject'){
  const done=await db.prepare("UPDATE z66_requests SET status='rejected',reviewed_at=?,retry_after=?,reviewer='presidency-admissions' WHERE id=? AND status='pending' RETURNING id").bind(now,now+2*3600000,rid).first();
  return done?json({ok:true,message:'تم رفض الطلب؛ إعادة التقديم بعد ساعتين'}):err(409,'الطلب سبق مراجعته');
 }
 const free=await db.prepare('SELECT slot FROM z639_guest_slots WHERE user_id IS NULL ORDER BY slot LIMIT 1').first();if(!free)return err(409,'الـ30 حساب اكتملت؛ لا يمكن الموافقة قبل إتاحة مكان');
 try{
  await db.prepare('INSERT INTO z66_approvals(request_id,user_id,slot,identity_no,reviewer,created_at) VALUES(?,?,?,?,?,?)').bind(rid,id(),free.slot,'ZG-APP-'+crypto.randomUUID(),'presidency-admissions',now).run();
  return json({ok:true,message:'تم قبول اللاعب، وسيدخل تلقائيًا عند تحديث صفحة الانتظار'});
 }catch(e){return err(409,'تعذر الموافقة؛ قد يكون الحساب قُبل أو المكان حُجز بالفعل. حدّث القائمة');}
}
async function z66AdminLogout(req,db){const t=cookieValue(req,Z66_ADMIN_COOKIE);if(/^[a-f0-9]{64}$/.test(t)){if(await z66AdminCheck(req,db)){const u=await getMe(req,db);if(u)await db.prepare('DELETE FROM z66_reviewer_devices WHERE user_id=?').bind(u.id).run();}await db.prepare('DELETE FROM z66_admin_sessions WHERE token_hash=?').bind(await digest(t)).run();}return json({ok:true},200,{'Set-Cookie':z66Cookie(Z66_ADMIN_COOKIE,'',0)});}

