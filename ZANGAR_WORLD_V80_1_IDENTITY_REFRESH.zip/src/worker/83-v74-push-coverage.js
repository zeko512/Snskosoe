// V74 — universal push coverage. Additive and idempotent: income pushes, stock rises, incoming missiles.
const Z74_MAX_AIR_DEBT=50000;  // firing is refused once a shooter owes this much
const Z74_STOCK_PUSH_MIN_PCT=10;   // push only when a stock rose at least this many percent in one tick
const Z74_AIR_PUSH_BUCKET_MS=300000; // at most one "missile approaching" push per 5 minutes
let z74Ready=null;
async function z74Ensure(db){
 if(z74Ready)return z74Ready;
 z74Ready=(async()=>{
  const done=await db.prepare("SELECT value FROM site_settings WHERE key='z74_tx_push2'").first();
  if(done?.value==='1')return;
  await db.batch([
   db.prepare('DROP TRIGGER IF EXISTS z74_tx_income_push'),
   // Every credit to a citizen's account becomes a push (transfers already have their own notice).
   db.prepare(`CREATE TRIGGER z74_tx_income_push AFTER INSERT ON transactions WHEN NEW.amount>0 AND NEW.note NOT LIKE 'تحويل من %' AND NEW.note NOT LIKE 'الدفاع الجوي:%' AND NEW.note NOT LIKE 'مكافأة مواطن نشط%' BEGIN
     INSERT OR IGNORE INTO z_push_outbox(id,dedupe,endpoint,user_id,kind,title,body,url,created_at)
     SELECT lower(hex(randomblob(16))),'z74tx-'||NEW.id,s.endpoint,s.user_id,'money','💰 وصلك '||NEW.amount||' زنجر',substr(NEW.note,1,200),'/#/bank',NEW.created_at
     FROM z_push_subscriptions s LEFT JOIN z_push_prefs pp ON pp.user_id=s.user_id
     WHERE s.user_id=NEW.user_id AND COALESCE(pp.money,1)=1;
   END`),
   db.prepare("INSERT INTO site_settings(key,value,updated_at) VALUES('z74_tx_push2','1',?) ON CONFLICT(key) DO UPDATE SET value='1',updated_at=excluded.updated_at").bind(Date.now())
  ]);
 })().catch(e=>{z74Ready=null;console.warn('z74 ensure',String(e));});
 return z74Ready;
}
async function z74StockPush(db,moves){
 const ups=moves.map(m=>({...m,pct:m.from>0?Math.round((m.to-m.from)/m.from*100):0})).filter(m=>m.pct>=Z74_STOCK_PUSH_MIN_PCT).sort((a,b)=>b.pct-a.pct);
 if(!ups.length)return;
 const name=sym=>ECON_STOCKS[sym]?.name||sym,top=ups[0];
 const more=ups.slice(1,3).map(m=>name(m.symbol)+' +'+m.pct+'%').join(' · ');
 await zPushEnqueueAll(db,'📈 البورصة زادت!',name(top.symbol)+' ارتفع +'+top.pct+'% وسعره الآن '+top.to+' زنجر'+(more?' — وكمان: '+more:''),'market','/#/market-pro','stock-up-'+Math.max(...moves.map(m=>m.at)));
}
async function z74AirPush(db,now=Date.now()){
 await zPushEnqueueAll(db,'🚀 صاروخ يقترب من الغلاف الجوي','رصد الرادار هدفًا معاديًا قادمًا — افتح الدفاع الجوي وشارك في الاعتراض قبل ما يوصل!','war','/air-defense.html','air-incoming-'+Math.floor(now/Z74_AIR_PUSH_BUCKET_MS));
}
// Cron-side check only reads game state; it never spawns tracks, so the game itself is unchanged.
async function z74AirSweep(db,now=Date.now()){
 try{const live=await db.prepare("SELECT id FROM z659_air_tracks WHERE status='incoming' AND expires_at>? AND id NOT LIKE 'alert-%' LIMIT 1").bind(now).first();if(live)await z74AirPush(db,now);}
 catch(e){console.warn('z74 air sweep',String(e));}
}
async function zPushRequest(req,db,env,action,p={}){
 if(action==='config')return json({enabled:zPushConfigured(env),publicKey:env.VAPID_PUBLIC_KEY||'',can_test:true});
 const u=await getMe(req,db);if(!u)return err(401,'سجّل الدخول أولًا لتفعيل إشعارات الدولة');
 if(action==='status'){
  const current=await db.prepare('SELECT COUNT(*) AS n FROM z_push_subscriptions WHERE user_id=?').bind(u.id).first();
  const prefs=await db.prepare('SELECT * FROM z_push_prefs WHERE user_id=?').bind(u.id).first();
  return json({enabled:zPushConfigured(env),devices:Number(current?.n||0),preferences:Object.fromEntries(Z_PUSH_TOPICS.map(k=>[k,!prefs||Number(prefs[k])===1]))});
 }
 if(action==='preferences'){
  const kind=String(p.kind||'');if(!Z_PUSH_TOPICS.includes(kind)||typeof p.enabled!=='boolean')return err(400,'نوع الإشعار غير صالح');
  await db.prepare('INSERT OR IGNORE INTO z_push_prefs(user_id,updated_at) VALUES(?,?)').bind(u.id,Date.now()).run();
  await db.prepare(`UPDATE z_push_prefs SET ${kind}=?,updated_at=? WHERE user_id=?`).bind(p.enabled?1:0,Date.now(),u.id).run();
  return json({ok:true,kind,enabled:p.enabled});
 }
 if(!zPushConfigured(env))return err(503,'الإشعارات تحتاج مفاتيح VAPID في إعدادات Cloudflare');
 if(action==='subscribe'){
  const endpoint=String(p.subscription?.endpoint||'');const keys=p.subscription?.keys||{};
  const p256dh=String(keys.p256dh||''),auth=String(keys.auth||'');
  if(!zPushValidEndpoint(endpoint)||p256dh.length>150||auth.length>80||!p256dh||!auth)return err(400,'اشتراك الإشعار غير صالح');
  try{if(Z_PUSH_DECODE(p256dh).length!==65||Z_PUSH_DECODE(auth).length!==16)return err(400,'مفاتيح المتصفح غير صالحة');}
  catch{return err(400,'مفاتيح المتصفح غير صحيحة');}
  const now=Date.now();await z74Ensure(db);
  await db.prepare(`INSERT INTO z_push_subscriptions(endpoint,user_id,p256dh,auth,created_at,updated_at)
  VALUES(?,?,?,?,?,?) ON CONFLICT(endpoint) DO UPDATE SET user_id=excluded.user_id,p256dh=excluded.p256dh,auth=excluded.auth,updated_at=excluded.updated_at`).bind(endpoint,u.id,p256dh,auth,now,now).run();
  await db.prepare(`DELETE FROM z_push_subscriptions WHERE endpoint IN (SELECT endpoint FROM z_push_subscriptions WHERE user_id=? ORDER BY updated_at DESC LIMIT -1 OFFSET 5)`).bind(u.id).run();
  return json({ok:true});
 }
 if(action==='unsubscribe'){
  const endpoint=String(p.endpoint||'');if(!zPushValidEndpoint(endpoint))return err(400,'اشتراك غير صالح');
  await db.prepare('DELETE FROM z_push_subscriptions WHERE endpoint=? AND user_id=?').bind(endpoint,u.id).run();return json({ok:true});
 }
 if(action==='test'){
  const now=Date.now();const allowed=await db.prepare(`INSERT INTO z_push_test_limits(user_id,last_test_at) VALUES(?,?)
  ON CONFLICT(user_id) DO UPDATE SET last_test_at=excluded.last_test_at
  WHERE last_test_at<=? RETURNING last_test_at`).bind(u.id,now,now-120000).first();
  if(!allowed)return err(429,'انتظر دقيقتين قبل إعادة اختبار الإشعارات');
  const result=await zPushBroadcast(db,env,u.id,{id:id(),kind:'system',title:'🔔 تجربة إشعارات الزنجر',body:'مبروك! إشعارات الدولة بتوصلك على الموبايل. افتح الصفحة للاطلاع على الجديد.',url:'/#/notifications'});
  if(result.accepted<1)return err(502,'تعذّر تسليم الإشعار. راجع إذن المتصفح ومفاتيح Cloudflare.');
  return json({ok:true,...result});
 }
 return err(404,'عملية إشعارات غير معروفة');
}

