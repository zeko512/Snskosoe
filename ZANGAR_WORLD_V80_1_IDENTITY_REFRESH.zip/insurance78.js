/* V78 — التأمين وبطاقة المواطن (client). Server is the source of truth; this only renders and sends requests. */
let z78={state:null,loading:false,err:'',tab:'main',form:{name:'',card_no:'',card_code:'',expiry:''},verified:false,verifyBusy:false,pending:null,busy:false,clock:null};
const Z78_EMOJI={citizen:'🪪',plus:'🥈',premium:'🥇',gov:'🏛️',president:'👑'};
function z78Clock(){const el=document.getElementById('z78-clock');if(!el){clearInterval(z78.clock);z78.clock=null;return;}
 const d=new Date();el.textContent=new Intl.DateTimeFormat('ar-EG',{timeZone:'Asia/Riyadh',dateStyle:'full',timeStyle:'medium'}).format(d);}
async function z78Load(force){if(z78.loading||mode!=='online'||!me())return;if(z78.state&&!force)return;z78.loading=true;
 try{z78.state=await fetchJSON('/api/v78/state');z78.err='';}catch(e){z78.err=String(e.message||e);}
 z78.loading=false;if(page==='insurance')render();}
function z78FormOk(){const f=z78.form;return !!(f.name.trim()&&f.card_no.trim()&&f.card_code.trim()&&f.expiry.trim());}
function z78Left(ms){const d=Math.ceil((ms-Date.now())/86400000);return d<=0?'ينتهي اليوم':d+' يوم';}
function z78Name(kind,tier){const l=z78.state?.catalog?.[kind==='card'?'cards':'insurance']||[];return (l.find(x=>x.tier===tier)||{}).name||tier;}
function renderInsurance78(){
 const u=me();if(!u)return gate('التأمين وبطاقة المواطن');
 if(mode!=='online')return `<section>${title('التأمين وبطاقة المواطن','متاح على الموقع المنشور فقط','shield')}<div class="panel center spaced"><p class="sub">الوظيفة دي تحتاج الموقع المنشور على Cloudflare.</p></div></section>`;
 if(!z78.state){z78Load();return `<section>${title('التأمين وبطاقة المواطن','','shield')}<div class="panel center spaced"><p class="sub">${esc(z78.err||'جارِ التحميل…')}</p>${z78.err?'<button class="btn primary" data-z78="reload">إعادة المحاولة</button>':''}</div></section>`;}
 const s=z78.state;
 const tabs=[['main','🛡️ الرئيسية'],['monthly','📅 التأمين الشهري'],['annual','🗓️ التأمين السنوي'],['cards','🪪 بطاقة المواطن']];
 const tabsHtml=`<div class="z78-tabs" role="tablist">${tabs.map(([k,t])=>`<button class="z78-tab${z78.tab===k?' on':''}" data-z78-tab="${k}" role="tab">${t}</button>`).join('')}</div>`;
 let body='';
 if(z78.tab==='main')body=z78Main(u,s);else if(z78.tab==='cards')body=z78Cards(s);else body=z78Insurance(s,z78.tab);
 setTimeout(()=>{z78Clock();if(!z78.clock)z78.clock=setInterval(z78Clock,1000);},0);
 return `<section class="z78-page">${title('التأمين وبطاقة المواطن','التوقيت الرسمي: الرياض','shield')}<div class="panel compact z78-clock-box"><small>الوقت الآن (الرياض)</small><strong id="z78-clock">—</strong></div>${tabsHtml}${body}${z78.pending?z78Confirm():''}</section>`;}
function z78Main(u,s){
 const ins=s.insurance,card=s.card;
 const exp=s.identity?.expires_date||'—';
 return `<div class="identity-card z76-id-card">${identityInner(u)}</div>
 <div class="panel compact z78-meta"><div class="record"><small>انتهاء الهوية</small><strong>${esc(exp)}</strong></div><div class="record"><small>الرسوم الحالية</small><strong>${(s.rates?.tax_pct??10).toFixed(2).replace(/\.?0+$/,'')}%</strong></div><div class="record"><small>أرباح التوفير / 3 ساعات</small><strong>${s.rates?.interest_pct??10}%</strong></div></div>
 <button class="z78-row" data-z78-tab="monthly"><span>📅 التأمين الشهري</span><small>${ins&&ins.period==='monthly'?'✅ '+esc(z78Name('insurance',ins.tier))+' • باقي '+z78Left(ins.expires_at):'غير مفعّل'}</small></button>
 <button class="z78-row" data-z78-tab="annual"><span>🗓️ التأمين السنوي</span><small>${ins&&ins.period==='annual'?'✅ '+esc(z78Name('insurance',ins.tier))+' • باقي '+z78Left(ins.expires_at):'غير مفعّل'}</small></button>
 <button class="z78-row" data-z78-tab="cards"><span>🪪 بطاقة المواطن</span><small>${card?'✅ '+esc(z78Name('card',card.tier))+' • باقي '+z78Left(card.expires_at):'غير مفعّلة'}</small></button>
 ${z78History(s)}`;}
function z78History(s){const h=s.history||[];if(!h.length)return '';
 return `<div class="panel spaced"><h3>📜 سجل الاشتراكات</h3>${h.slice(0,12).map(x=>`<div class="z78-hist"><span>${x.kind==='card'?'🪪 ':'🛡️ '}${esc(z78Name(x.kind,x.tier))}${x.period==='annual'?' (سنوي)':x.period==='monthly'?' (شهري)':''}</span><small>${fmt(x.price)} زنجر • ${dateFmt(x.started_at)} → ${dateFmt(x.expires_at)} • ${x.status==='active'?'نشط':x.status==='expired'?'منتهي':'مستبدل'}</small></div>`).join('')}</div>`;}
function z78Verify(){const f=z78.form;
 return `<div class="panel spaced z78-verify"><h3>🔐 التحقق من الهوية</h3><p class="sub">اكتب بيانات هويتك (موجودة في صفحة «هويتي») عشان تقدر تشتري التأمين.</p>
 <label>الاسم</label><input class="input" data-z78-f="name" value="${esc(f.name)}" autocomplete="off">
 <label>رقم الهوية</label><input class="input" data-z78-f="card_no" value="${esc(f.card_no)}" inputmode="numeric" autocomplete="off">
 <label>الكود السري</label><input class="input" data-z78-f="card_code" type="password" value="${esc(f.card_code)}" autocomplete="off">
 <label>تاريخ الانتهاء (سنة-شهر-يوم)</label><input class="input" data-z78-f="expiry" value="${esc(f.expiry)}" placeholder="2027-01-31" inputmode="numeric" autocomplete="off">
 <button class="btn block z78-verify-btn ${z78.verified?'ok':''}" data-z78="verify" ${z78FormOk()&&!z78.verifyBusy?'':'disabled'}>${z78.verified?'✅ تم التحقق':'تحقق'}</button></div>`;}
function z78Insurance(s,period){
 const list=s.catalog?.insurance||[];
 return `${z78Verify()}<div class="z78-grid">${list.map(p=>{
  const price=period==='annual'?p.annual:p.monthly,cur=s.insurance,active=cur&&cur.tier===p.tier&&cur.period===period;
  const locked=!p.eligible;
  return `<article class="panel z78-plan${active?' active':''}"><h3>${esc(p.name)}</h3><div class="z78-price">${fmt(price)} <small>زنجر / ${period==='annual'?'سنة (120 يوم)':'شهر (10 أيام)'}</small></div>
  <ul><li>رسوم الدولة: ${p.tax}%</li><li>أرباح البنك كل 3 ساعات: ${p.interest}%</li>${p.restricted?'<li>للمناصب الحكومية والرئاسية فقط</li>':''}</ul>
  ${active?`<span class="pill green">مفعّل • باقي ${z78Left(cur.expires_at)}</span>`:locked?'<span class="pill red">غير متاح لمنصبك</span>':`<button class="btn primary block" data-z78-buy="insurance|${p.tier}|${period}" ${z78.verified?'':'disabled'}>${cur?'ترقية':'اشتراك'}</button>`}</article>`;}).join('')}</div>${z78History(s)}`;}
function z78Cards(s){
 const list=s.catalog?.cards||[],cur=s.card;
 return `<div class="z78-grid">${list.map(p=>{const active=cur&&cur.tier===p.tier;
  return `<article class="panel z78-plan z78-card-${p.tier}${active?' active':''}"><h3>${Z78_EMOJI[p.tier]||''} ${esc(p.name)}</h3><div class="z78-price">${fmt(p.price)} <small>زنجر / 10 أيام</small></div>
  <ul><li>خصم ${p.discount}% على رسوم الدولة</li>${p.reward?`<li>مكافأة يومية ${fmt(p.reward)} زنجر</li>`:''}${p.tier==='gov'||p.tier==='president'?'<li>أولوية في الخدمات الحكومية</li>':''}${p.tier==='president'?'<li>للمناصب الرئاسية فقط</li>':p.tier==='gov'?'<li>للمناصب الحكومية فقط</li>':''}</ul>
  ${active?`<span class="pill green">مفعّلة • باقي ${z78Left(cur.expires_at)}</span>`:!p.eligible?'<span class="pill red">غير متاحة لمنصبك</span>':`<button class="btn primary block" data-z78-buy="card|${p.tier}|">${cur?'ترقية':'شراء'}</button>`}</article>`;}).join('')}</div>${z78History(s)}`;}
function z78Confirm(){const p=z78.pending;
 return `<div class="z78-modal" role="dialog"><div class="panel"><h3>تأكيد الشراء</h3><p>${esc(p.label)}</p><p class="sub">سيتم خصم المبلغ مرة واحدة من رصيدك.</p><div class="flex"><button class="btn primary" data-z78="confirm" ${z78.busy?'disabled':''}>تأكيد</button><button class="btn" data-z78="cancel">إلغاء</button></div></div></div>`;}
async function z78DoVerify(){z78.verifyBusy=true;render();
 try{await fetchJSON('/api/v78/verify',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify(z78.form)});z78.verified=true;toast('✅ تم التحقق من الهوية');}
 catch(e){z78.verified=false;toast(String(e.message||'هناك خطأ في البيانات'));}
 z78.verifyBusy=false;render();}
async function z78DoBuy(){const p=z78.pending;if(!p||z78.busy)return;z78.busy=true;render();
 const body={kind:p.kind,tier:p.tier,request_id:p.rid};if(p.kind==='insurance'){body.period=p.period;Object.assign(body,z78.form);}
 try{const r=await fetchJSON('/api/v78/buy',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify(body)});
  toast('✅ تم الاشتراك');z78.pending=null;z78.state=null;z78.busy=false;try{await reloadLive();}catch(e){}z78Load(true);return;}
 catch(e){toast(String(e.message||e));}
 z78.busy=false;z78.pending=null;render();}
document.addEventListener('click',e=>{
 const t=e.target.closest('[data-z78-tab],[data-z78],[data-z78-buy]');if(!t)return;
 if(t.dataset.z78Tab){z78.tab=t.dataset.z78Tab;render();window.scrollTo(0,0);return;}
 if(t.dataset.z78Buy){const [kind,tier,period]=t.dataset.z78Buy.split('|');const plans=kind==='card'?z78.state.catalog.cards:z78.state.catalog.insurance;const p=plans.find(x=>x.tier===tier);
  const price=kind==='card'?p.price:(period==='annual'?p.annual:p.monthly);
  z78.pending={kind,tier,period,rid:(crypto?.randomUUID?.()||('z78-'+Date.now()+Math.random())),label:`${p.name} — ${fmt(price)} زنجر`};render();return;}
 const a=t.dataset.z78;if(a==='reload'){z78.err='';z78Load(true);render();}else if(a==='verify')z78DoVerify();else if(a==='confirm')z78DoBuy();else if(a==='cancel'){z78.pending=null;render();}
});
document.addEventListener('input',e=>{const k=e.target?.dataset?.z78F;if(!k)return;z78.form[k]=e.target.value;z78.verified=false;
 const b=document.querySelector('.z78-verify-btn');if(b){b.disabled=!z78FormOk();b.classList.remove('ok');b.textContent='تحقق';}
 document.querySelectorAll('[data-z78-buy]').forEach(x=>x.disabled=true);});
