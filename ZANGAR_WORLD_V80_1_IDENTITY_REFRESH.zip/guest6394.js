// V63.9: Browser derives proof; the Worker holds only password verifiers, never plaintext passwords.
(()=>{'use strict';
const $=id=>document.getElementById(id),enc=new TextEncoder();
let nextSlot=null,selectedSlot=null,existing=false,busy=false,avatar='';
const hex=b=>Array.from(new Uint8Array(b)).map(v=>v.toString(16).padStart(2,'0')).join('');
async function read(url,opts={}){
 const controller=new AbortController(),timeout=setTimeout(()=>controller.abort(),18000);
 try{
  const r=await fetch(url,{credentials:'same-origin',cache:'no-store',...opts,signal:controller.signal});
  const d=await r.json().catch(()=>({}));
  if(!r.ok)throw Error(d.error||'تعذر إكمال الطلب ('+r.status+')');
  return d;
 }catch(e){if(e.name==='AbortError')throw Error('الاتصال استغرق وقتًا طويلًا. اضغط إعادة المحاولة.');throw e}
 finally{clearTimeout(timeout)}
}
function error(message){$('guest-error').textContent=message||'';$('guest-error').hidden=!message}
function currentSlot(){return existing?Number($('slot-choice').value):nextSlot}
function refreshView(){selectedSlot=currentSlot();$('slot-banner').textContent=selectedSlot||'—';$('help-guest').textContent=selectedSlot?'Guest '+String(selectedSlot).padStart(2,'0'):'Guest غير متاح';$('new-only-fields').hidden=existing;$('existing-slot-field').hidden=!existing;$('new-tab').classList.toggle('active',!existing);$('existing-tab').classList.toggle('active',existing);$('enter-button').textContent=existing?'دخول إلى حسابي':'إنشاء حساب والدخول';$('enter-button').disabled=!selectedSlot||busy;$('citizen-name').required=!existing;$('guest-status').textContent=existing?'اكتب رقم حسابك وكلمة مروره للدخول من أي جهاز':selectedSlot?'اكتب اسمك وكلمة المرور المخصصة لهذا الرقم':'كل الحسابات اتسجلت بالفعل. استخدم زر عندي حساب Guest.';}
function switchTo(wantExisting){existing=wantExisting;refreshView();error('')}
async function status(){let d=await read('/api/z639/slots');nextSlot=d.next_slot||null;let choice=$('slot-choice');choice.innerHTML=Array.from({length:30},(_,i)=>`<option value="${i+1}">Guest ${String(i+1).padStart(2,'0')}</option>`).join('');if(nextSlot)choice.value=String(nextSlot);if(!nextSlot)existing=true;refreshView()}
async function prepareAvatar(file){if(!file)return '';if(!/^image\/(png|jpeg|webp)$/.test(file.type)||file.size>6*1024*1024)throw Error('اختر صورة PNG/JPEG/WebP بحجم لا يزيد عن 6 ميجابايت');let url=URL.createObjectURL(file);try{let img=await new Promise((resolve,reject)=>{let i=new Image();i.onload=()=>resolve(i);i.onerror=()=>reject(Error('تعذر قراءة الصورة'));i.src=url});let canvas=document.createElement('canvas'),ctx=canvas.getContext('2d');canvas.width=160;canvas.height=160;let crop=Math.min(img.width,img.height);ctx.drawImage(img,(img.width-crop)/2,(img.height-crop)/2,crop,crop,0,0,160,160);let quality=.66,result=canvas.toDataURL('image/jpeg',quality);if(result.length>58000)result=canvas.toDataURL('image/jpeg',.40);if(result.length>58000)throw Error('الصورة كبيرة، اختار صورة أبسط');return result}finally{URL.revokeObjectURL(url)}}
async function proof(password,salt){let key=await crypto.subtle.importKey('raw',enc.encode(password),'PBKDF2',false,['deriveBits']);return hex(await crypto.subtle.deriveBits({name:'PBKDF2',salt:enc.encode(salt),iterations:160000,hash:'SHA-256'},key,256))}
$('new-tab').addEventListener('click',()=>switchTo(false));$('existing-tab').addEventListener('click',()=>switchTo(true));$('slot-choice').addEventListener('change',refreshView);
$('toggle-password').addEventListener('click',()=>{$('citizen-password').type=$('citizen-password').type==='password'?'text':'password'});
$('citizen-image').addEventListener('change',async e=>{try{avatar=await prepareAvatar(e.target.files?.[0]);let p=$('image-preview');p.hidden=!avatar;p.style.backgroundImage=avatar?`url("${avatar}")`:'';error('')}catch(err){avatar='';error(err.message)}});
$('guest-form').addEventListener('submit',async e=>{e.preventDefault();if(busy)return;error('');let slot=currentSlot(),password=$('citizen-password').value,name=$('citizen-name').value.trim();
 // Allow pasting either the exact password or the full line 'Guest 01: password'.
 const pasted=/^\s*Guest\s*(\d{1,2})\s*[:：]\s*(\S+)\s*$/i.exec(password);
 if(pasted){if(Number(pasted[1])!==slot)return error('كلمة المرور المنسوخة تخص Guest '+pasted[1]+'؛ اختار رقم Guest الصحيح');password=pasted[2]}
 password=password.replace(/[\u200B-\u200D\uFEFF]/g,'').trim();if(!slot)return error('لا توجد خانة جديدة متاحة');if(!existing&&name.length<2)return error('اكتب اسمًا من حرفين على الأقل');if(!password)return error('اطلب كلمة المرور من منشئ اللعبة');busy=true;refreshView();$('enter-button').textContent='جارِ الدخول…';try{let challenge=await read('/api/z639/challenge?slot='+slot);if(existing&&!challenge.claimed)throw Error('Guest ده لسه محدش سجله. اختار حساب جديد أو اطلب من المنشئ');if(!existing&&challenge.claimed)throw Error('الرقم اتحجز من لاعب آخر، حدث الصفحة عشان تختار رقم جديد');if(!challenge.claimed&&challenge.credential_ready===false)throw Error('كلمات المرور غير متزامنة على السيرفر. تأكد من رفع الإصدار V64 كاملًا');
 // V63.9.4: send both the old secure proof and a TLS-only fallback.
 // On any browser that cannot derive PBKDF2, the Worker verifies the plain
 // credential using its existing salted PBKDF2 hash (never saves plaintext).
 let p='';try{p=await proof(password,challenge.salt)}catch(e){console.warn('Browser proof unavailable; using secure server verification')}
 let result=await read('/api/z639/enter',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({slot:Number(slot),proof:p,password,name:existing?'':name,avatar:existing?'':avatar})});
 // Confirm the HttpOnly session cookie reached this browser before leaving login.
 const check=await read('/api/session60');
 if(!check.logged_in){existing=true;refreshView();throw Error('تم قبول كلمة المرور لكن المتصفح لم يحفظ جلسة الدخول. تأكد من السماح بملفات تعريف الارتباط وأعد الدخول من زر عندي حساب Guest.');}
 location.replace('/state.html#/home')}catch(err){error(err.message);if(/اتحجز|لحدش سجله|another/.test(err.message))status().catch(()=>{});}finally{busy=false;refreshView();if($('guest-error').textContent)$('guest-error').hidden=false}});
async function start(){
 const retry=$('guest-retry');retry.hidden=true;error('');
 try{const s=await read('/api/session60');if(s.logged_in){location.replace('/state.html#/home');return}}catch(e){console.warn('Session status temporarily unavailable:',e.message)}
 try{await status()}catch(e){
  nextSlot=null;refreshView();
  error('تعذر تحميل حسابات Guest مؤقتًا: '+(e.message||'مشكلة اتصال')+'. اضغط إعادة المحاولة.');
  $('guest-status').textContent='مشكلة مؤقتة في تحميل الحسابات';
  retry.hidden=false;
 }
}
$('guest-retry').addEventListener('click',start);
start();
})();
