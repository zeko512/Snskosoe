/* ZANGAR WORLD V80 — شاشات بنك الزنجر المركزي. التحقق الفعلي كله على الخادم (Worker + D1). */
"use strict";
const Z80={st:null,uid:null,loading:false,view:'main',kind:'',token:'',rid:'',amount:0,err:'',busy:false,count:0,timer:null,result:null,inbox:null,inboxAt:0,
 async api(path,body){const r=await fetch(path,{cache:'no-store',credentials:'same-origin',...(body!==undefined?{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify(body)}:{})});let d={};try{d=await r.json()}catch(e){}if(!r.ok||d.ok===false)throw Error(d.error||'تعذر الاتصال بالخادم');return d},
 redraw(){const y=window.scrollY;render();window.scrollTo(0,y)},
 reset(){clearInterval(Z80.timer);Object.assign(Z80,{st:null,view:'main',kind:'',token:'',rid:'',amount:0,err:'',busy:false,count:0,result:null})},
 async load(){if(Z80.loading)return;Z80.loading=true;try{Z80.st=await Z80.api('/api/v80/bank/state');Z80.err=''}catch(e){Z80.st={error:e.message}}finally{Z80.loading=false}Z80.redraw()},
 lock(quiet){clearInterval(Z80.timer);if(Z80.st)Z80.st.unlocked=false;Z80.view='main';Z80.token='';Z80.result=null;Z80.api('/api/v80/bank/lock',{}).catch(()=>{})},
 shell(inner){return `<section><div class="panel spaced z80"><h3>🏦 بنك الزنجر المركزي</h3><p class="sub">زنجر افتراضية لا تمثل أموالًا حقيقية</p>${Z80.err?`<p class="z80-err" role="alert">⚠️ ${esc(Z80.err)}</p>`:''}${inner}</div></section>`},
 field(label,name,type,extra=''){return `<label>${label}</label><input class="input" name="${name}" type="${type}" ${extra} required autocomplete="off">`},
 gate(){
  if(!me())return '';
  if(Z80.uid!==me().id){Z80.reset();Z80.uid=me().id}
  const s=Z80.st;
  if(!s){Z80.load();return Z80.shell('<p class="sub">⏳ جاري تحميل بيانات البنك…</p>')}
  if(s.error)return Z80.shell(`<p class="sub">${esc(s.error)}</p><button class="btn" type="button" data-z80="reload">إعادة المحاولة</button>`);
  if(!s.has_creds)return Z80.shell(`<h4>إنشاء بيانات البنك</h4><p class="sub">أنشئ كلمة مرور ورمزًا سريًا خاصين بالبنك. هما مختلفان عن بيانات الهوية، وستحتاجهما في كل مرة تفتح فيها البنك.</p><form class="stack" data-z80-form="setup">${Z80.field('إنشاء كلمة مرور البنك','password','password','minlength="8" maxlength="72"')}${Z80.field('إنشاء الرمز السري للبنك (4 إلى 8 أرقام)','pin','password','inputmode="numeric" pattern="[0-9]{4,8}" maxlength="8"')}<button class="btn primary" ${Z80.busy?'disabled':''}>حفظ ودخول البنك</button></form>`);
  if(!s.unlocked){
   if(s.recovery&&s.recovery.status==='approved'){
    const m=s.recovery.mode;
    return Z80.shell(`<h4>✅ تمت الموافقة على طلبك</h4><p class="sub">اختر بياناتك الجديدة بنفسك. لا أحد يطّلع عليها.</p><form class="stack" data-z80-form="reset">${m!=='pin'?Z80.field('كلمة مرور البنك الجديدة','password','password','minlength="8" maxlength="72"'):''}${m!=='password'?Z80.field('الرمز السري الجديد (4 إلى 8 أرقام)','pin','password','inputmode="numeric" pattern="[0-9]{4,8}" maxlength="8"'):''}<button class="btn primary" ${Z80.busy?'disabled':''}>حفظ البيانات الجديدة</button></form>`);
   }
   if(Z80.view==='forgot')return Z80.shell(`<h4>🔐 نسيت كلمة المرور أو الرمز السري؟</h4><form class="stack" data-z80-form="forgot"><label>ماذا نسيت؟</label><select class="input" name="mode" required><option value="">اختر</option><option value="password">كلمة المرور</option><option value="pin">الرمز السري</option><option value="both">الاثنين</option></select>${Z80.field('الاسم الكامل','name','text','maxlength="60"')}${Z80.field('رقم الهوية','card_no','text','inputmode="numeric" maxlength="14"')}${Z80.field('الرمز السري الخاص بالهوية','card_code','text','maxlength="14"')}<button class="btn primary" id="z80Send" disabled>إرسال طلب</button><button class="btn" type="button" data-z80="back">رجوع</button></form>`);
   const note=s.recovery?.status==='pending'?'<p class="pill gold">طلبك تحت التنفيذ</p>':s.recovery?.status==='rejected'?'<p class="pill red">تم رفض طلب الاسترجاع الأخير</p>':'';
   return Z80.shell(`<h4>تسجيل الدخول إلى البنك</h4>${note}<form class="stack" data-z80-form="login">${Z80.field('كلمة مرور البنك','password','password','maxlength="72"')}${Z80.field('الرمز السري للبنك','pin','password','inputmode="numeric" maxlength="8"')}<button class="btn primary" ${Z80.busy?'disabled':''}>دخول</button></form><button class="btn sm" type="button" data-z80="forgot">نسيت كلمة المرور أو الرمز السري؟</button>`);
  }
  const k=Z80.kind==='deposit'?'الإيداع':'السحب';
  if(Z80.view==='verify')return Z80.shell(`<h4>🔐 تحقق قبل ${k}</h4><form class="stack" data-z80-form="verify">${Z80.field('رقم الهوية','card_no','text','inputmode="numeric" maxlength="14"')}${Z80.field('الرمز السري الخاص بالهوية','card_code','text','maxlength="14"')}${Z80.field('الرمز السري للبنك','bank_pin','password','inputmode="numeric" maxlength="8"')}<button class="btn primary" ${Z80.busy?'disabled':''}>تحقق</button><button class="btn" type="button" data-z80="back">رجوع</button></form>`);
  if(Z80.view==='amount')return Z80.shell(`<h4>${k}</h4><form class="stack" data-z80-form="amount"><label>مبلغ ${k}</label><input class="input" name="amount" type="number" min="100" max="100000" required autofocus><button class="btn primary">تم</button><button class="btn" type="button" data-z80="back">إلغاء</button></form>`);
  if(Z80.view==='counting')return Z80.shell(`<h4>جاري تأكيد عملية ${k}</h4><div class="z80-count" id="z80Count">${Z80.count}</div><p class="sub">لا تغلق الصفحة…</p><button class="btn" type="button" data-z80="cancel">إلغاء العملية</button>`);
  if(Z80.view==='sending')return Z80.shell('<p class="sub">⏳ جاري تسجيل العملية على الخادم…</p>');
  if(Z80.view==='done')return Z80.shell(`<div class="z80-ok">✅ تمت العملية بنجاح</div><p class="sub">${Z80.kind==='deposit'?'تم إيداع':'تم سحب'} ${fmt(Z80.amount)} زنجر. رصيد التوفير الآن: ${fmt(world.savings)} زنجر.</p><button class="btn primary" type="button" data-z80="back">رجوع للبنك</button>`);
  if(Z80.view==='fail')return Z80.shell(`<div class="z80-bad">❌ لم تتم العملية</div><p class="sub">${esc(Z80.result||'حدث خطأ')}</p><button class="btn" type="button" data-z80="back">رجوع للبنك</button>`);
  return '';
 },
 async run(kind,fn){Z80.busy=true;Z80.err='';Z80.redraw();try{await fn()}catch(e){Z80.err=e.message}finally{Z80.busy=false;Z80.redraw()}},
 startCount(){
  Z80.view='counting';Z80.count=5;Z80.redraw();clearInterval(Z80.timer);
  Z80.timer=setInterval(()=>{Z80.count--;const el=document.getElementById('z80Count');if(el)el.textContent=Math.max(0,Z80.count);if(Z80.count<=0){clearInterval(Z80.timer);Z80.submit()}},1000);
 },
 async submit(){
  Z80.view='sending';Z80.redraw();
  const type=Z80.kind==='deposit'?'savingDeposit':'savingWithdraw';
  try{
   let res;
   try{res=await Z80.api('/api/world/action',{type,amount:Z80.amount,request_id:Z80.rid,bank_token:Z80.token})}
   catch(e){if(/تعذر الاتصال|انتهت مهلة/.test(e.message))res=await Z80.api('/api/bank/receipt?id='+encodeURIComponent(Z80.rid));else throw e}
   const rec=await Z80.api('/api/bank/receipt?id='+encodeURIComponent(Z80.rid)); // confirm it is really recorded
   if(!rec||!rec.receipt_id)throw Error('لم نتأكد من تسجيل العملية، راجع رصيدك قبل إعادة المحاولة');
   world.savings=Number(rec.savings||0);world.interest_at=Number(rec.interest_at||0);if(me())me().points=Number(rec.points||0);
   Z80.token='';Z80.view='done';
  }catch(e){Z80.view='fail';Z80.result=e.message}
  Z80.redraw();
 },
 // Presidential inbox: recovery requests (the president only approves; the citizen picks new data).
 async loadInbox(force){if(!isAdmin()||(!force&&Date.now()-Z80.inboxAt<15000))return;Z80.inboxAt=Date.now();try{Z80.inbox=(await Z80.api('/api/v80/recovery/list')).requests}catch(e){Z80.inbox=[]}Z80.redraw()},
 inboxHtml(){
  if(!isAdmin())return '';Z80.loadInbox();
  const rows=Z80.inbox||[],L={password:'كلمة المرور',pin:'الرمز السري',both:'كلمة المرور والرمز السري'};
  return `<section class="panel spaced"><h3>🔐 طلبات استرجاع بيانات البنك</h3>${rows.length?rows.map(r=>`<div class="panel compact inbox-item"><strong>${esc(r.name)}</strong> · رقم الهوية ${esc(r.card_no||'')}<br><small>النوع: نسيان ${L[r.mode]} · ${dateFmt(r.created_at)}</small><br>${r.status==='pending'?`<div class="filter-row"><button class="btn green sm" data-z80="decide" data-id="${esc(r.id)}" data-ok="1">موافقة</button><button class="btn danger sm" data-z80="decide" data-id="${esc(r.id)}" data-ok="0">رفض</button></div>`:`<span class="pill">${{approved:'تمت الموافقة',rejected:'مرفوض',used:'تم تعيين بيانات جديدة'}[r.status]||r.status}</span>`}</div>`).join(''):'<p class="sub">لا توجد طلبات.</p>'}</section>`;
 }
};
document.addEventListener('click',e=>{
 const b=e.target.closest&&e.target.closest('[data-z80]');if(!b)return;const a=b.dataset.z80;
 if(a==='reload'){Z80.st=null;Z80.redraw()}
 else if(a==='forgot'){Z80.view='forgot';Z80.err='';Z80.redraw()}
 else if(a==='back'){clearInterval(Z80.timer);Z80.view='main';Z80.token='';Z80.err='';Z80.redraw()}
 else if(a==='cancel'){clearInterval(Z80.timer);Z80.view='main';Z80.token='';Z80.redraw()}
 else if(a==='open-deposit'||a==='open-withdraw'){Z80.kind=a==='open-deposit'?'deposit':'withdraw';Z80.view='verify';Z80.err='';Z80.redraw()}
 else if(a==='lock'){Z80.lock();Z80.redraw()}
 else if(a==='decide'){Z80.api('/api/v80/recovery/decide',{id:b.dataset.id,approve:b.dataset.ok==='1'}).then(d=>{toast(d.notice||'تم');Z80.loadInbox(true)}).catch(x=>toast(x.message))}
});
document.addEventListener('input',e=>{
 const f=e.target.closest&&e.target.closest('[data-z80-form="forgot"]');if(!f)return;
 const v=Object.fromEntries(new FormData(f));f.querySelector('#z80Send').disabled=!(v.mode&&String(v.name).trim().length>1&&String(v.card_no).trim().length>=8&&String(v.card_code).trim().length>=8);
});
document.addEventListener('submit',e=>{
 const f=e.target.closest&&e.target.closest('[data-z80-form]');if(!f)return;e.preventDefault();e.stopImmediatePropagation();
 const v=Object.fromEntries(new FormData(f)),t=f.dataset.z80Form;
 if(t==='setup')Z80.run(t,async()=>{await Z80.api('/api/v80/bank/setup',v);Z80.st=await Z80.api('/api/v80/bank/state')});
 else if(t==='login')Z80.run(t,async()=>{await Z80.api('/api/v80/bank/login',v);Z80.st=await Z80.api('/api/v80/bank/state')});
 else if(t==='reset')Z80.run(t,async()=>{const d=await Z80.api('/api/v80/bank/reset',v);Z80.st=await Z80.api('/api/v80/bank/state');toast(d.notice||'تم')});
 else if(t==='forgot')Z80.run(t,async()=>{const d=await Z80.api('/api/v80/bank/recovery/request',v);Z80.st=await Z80.api('/api/v80/bank/state');Z80.view='main';toast(d.notice||'طلبك تحت التنفيذ')});
 else if(t==='verify')Z80.run(t,async()=>{const d=await Z80.api('/api/v80/bank/verify',{...v,kind:Z80.kind});Z80.token=d.token;Z80.view='amount'});
 else if(t==='amount'){const n=Number(v.amount);if(!Number.isSafeInteger(n)||n<100||n>100000){Z80.err='اختر مبلغًا بين 100 و100000 زنجر';Z80.redraw();return}Z80.amount=n;Z80.rid=crypto.randomUUID();Z80.err='';Z80.startCount()}
},true);
// Leaving the bank page always locks it again (the server also expires the unlock after 10 idle minutes).
(function(){const orig=window.render;if(typeof orig!=='function')return;window.render=function(){try{if(typeof page!=='undefined'&&page!=='central'&&Z80.st&&Z80.st.unlocked)Z80.lock()}catch(e){}return orig.apply(this,arguments)}})();
window.addEventListener('pagehide',()=>{try{if(Z80.st&&Z80.st.unlocked)navigator.sendBeacon('/api/v80/bank/lock',new Blob(['{}'],{type:'application/json'}))}catch(e){}});
