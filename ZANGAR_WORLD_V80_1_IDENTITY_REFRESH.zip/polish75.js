// ZANGAR WORLD V75 — تحسينات سلاسة خفيفة (لا تغيّر أي منطق في اللعبة).
(()=>{'use strict';
 const app=()=>document.getElementById('app');
 let t;
 const enter=()=>{const a=app();if(!a)return;a.classList.remove('z75-enter');void a.offsetWidth;a.classList.add('z75-enter');clearTimeout(t);t=setTimeout(()=>a.classList.remove('z75-enter'),700);};
 addEventListener('hashchange',()=>{enter();try{scrollTo({top:0,behavior:'smooth'})}catch(e){scrollTo(0,0)}});
 let ticking=false;
 const onScroll=()=>{if(ticking)return;ticking=true;requestAnimationFrame(()=>{const bar=document.querySelector('.topbar');if(bar)bar.classList.toggle('z75-scrolled',scrollY>6);ticking=false;});};
 addEventListener('scroll',onScroll,{passive:true});
 addEventListener('DOMContentLoaded',()=>{enter();onScroll();});
 if(document.readyState!=='loading'){enter();onScroll();}
})();
