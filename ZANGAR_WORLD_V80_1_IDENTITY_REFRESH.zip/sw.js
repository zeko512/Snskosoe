/* دولة الزنجر — encrypted topic-aware Web Push notifications, Android and iOS PWA. */
// Update33: local device vibration preference, no extra D1 requests.
function z33VibrationStore(value){return new Promise(resolve=>{try{const o=indexedDB.open('zangar-push-config',1);o.onupgradeneeded=()=>o.result.createObjectStore('settings');o.onerror=()=>resolve(true);o.onsuccess=()=>{const db=o.result,tx=db.transaction('settings',value===undefined?'readonly':'readwrite');const req=value===undefined?tx.objectStore('settings').get('vibration'):tx.objectStore('settings').put(!!value,'vibration');req.onsuccess=()=>resolve(value===undefined?req.result!==false:true);req.onerror=()=>resolve(true);tx.oncomplete=()=>db.close();tx.onerror=()=>db.close();};}catch(e){resolve(true)}});}
self.addEventListener('message',event=>{if(event.data?.type==='Z33_VIBRATION_SET')event.waitUntil(z33VibrationStore(!!event.data.enabled));if(event.data?.type==='SKIP_WAITING')self.skipWaiting();});
self.addEventListener('push',event=>{
 event.waitUntil((async()=>{
  let data={kind:'system',title:'🔔 دولة الزنجر الجديدة',body:'فيه تنبيه جديد داخل الدولة.',url:'/state.html#/notifications'};
  try{if(event.data){const parsed=event.data.json();if(parsed&&typeof parsed==='object')data={...data,...parsed};}}catch(e){}
  const url=String(data.url||'/state.html#/notifications');const path=url.startsWith('/')&&!url.startsWith('//')?url:'/state.html#/notifications';
  const kind=String(data.kind||'system').replace(/[^a-z]/g,'').slice(0,20);
  const prefix=kind==='chat'?'💬 ':kind==='money'?'💰 ':kind==='tax'?'🧾 ':kind==='fine'?'⚖️ ':kind==='jobs'?'👷 ':kind==='government'||kind==='report'||kind==='request'?'🏛️ ':kind==='market'?'🛒 ':'🔔 ';
  const title=String(data.title||'دولة الزنجر');
  const vibrate=await z33VibrationStore();
  await self.registration.showNotification((title.startsWith(prefix.trim())?title:prefix+title).slice(0,90),{
   body:String(data.body||'افتح الدولة لمعرفة التفاصيل').slice(0,230),
   icon:'/assets/zangar-icon-192.png',badge:'/assets/zangar-icon-192.png',
   tag:'zangar-'+String(data.id||Date.now()).slice(0,80),
   data:{url:path,kind},lang:'ar',dir:'rtl',timestamp:Date.now(),
   // Update 74: one continuous 2-second vibration (Android; iOS web push has no vibration API).
   ...(vibrate?{vibrate:[2000]}:{}),silent:false,renotify:false,
   requireInteraction:kind==='war'
  });
 })());
});
self.addEventListener('notificationclick',event=>{
 event.notification.close();
 event.waitUntil((async()=>{
  const path=String(event.notification.data?.url||'/state.html#/notifications');
  const destination=new URL(path.startsWith('/')&&!path.startsWith('//')?path:'/state.html#/notifications',self.location.origin).href;
  // A real notification *click*, not push arrival, starts the 15-second danger window.
  // Authentication and actual push delivery are rechecked server-side; failures are harmless.
  try{const u=new URL(destination);if(u.pathname==='/air-defense.html'){
   const eventId=u.searchParams.get('alert'),key=u.searchParams.get('key');
   if(eventId&&key)await fetch('/api/air-defense/alert/open',{method:'POST',credentials:'include',
     headers:{'Content-Type':'application/json'},body:JSON.stringify({event:eventId,key})});
  }}catch(_){/* continue normal navigation even if not signed in */}

  const all=await clients.matchAll({type:'window',includeUncontrolled:true});
  for(const client of all){if(new URL(client.url).origin===self.location.origin){
   try{await client.navigate(destination);await client.focus();return;}catch(e){}
  }}
  await clients.openWindow(destination);
 })());
});
