/* Update 43 — UI: one code field, presence, presidential messages and tour. */
'use strict';
// No publicly accessible release notes.

const z42Html = value => String(value??'').replace(/[&<>"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));
function z42AdminMessages(){
 const choices=(users()||[]).map(u=>`<option value="${z42Html(u.id)}">${z42Html(u.name)}</option>`).join('');
 return `<section class="panel spaced z42-official-mail"><h2>📨 رسائل الرئاسة للمواطنين</h2>
 <p class="sub">ابعت رسالة رسمية تظهر للمواطنين في إشعاراتهم (وممكن يصل إشعار للموبايل حسب تفعيل الإشعارات).</p>
 <form id="z42-message-form" class="stack"><label>المستلم</label><select class="input" name="to"><option value="all">👥 جميع المواطنين</option>${choices}</select>
 <label>نص الرسالة</label><textarea class="input textarea" rows="3" name="body" minlength="5" maxlength="400" required placeholder="اكتب رسالة رئاسة الدولة…"></textarea>
 <button class="btn primary block" type="submit">📨 إرسال رسالة رسمية</button></form></section>`;
}
const z42AdminOld=renderAdmin;
renderAdmin=function(isPublic=false){const original=z42AdminOld(isPublic);return !isPublic&&isAdmin()?z42AdminMessages()+original:original};
const z42PersonOld=person;
person=function(u){
 let html=z42PersonOld(u),name=z42Html(u.name);
 return html.replace(`<strong>${name}</strong>`,`<strong>${name} <span class="z42-presence-dot ${u.online?'z42-on':'z42-off'}" title="${u.online?'متصل الآن':'غير متصل'}"></span><small class="z42-presence-label">${u.online?'متصل':'غير متصل'}</small></strong>`);
};
async function z42Post(path,body){const r=await fetch(path,{method:'POST',credentials:'same-origin',cache:'no-store',headers:{'Content-Type':'application/json'},body:JSON.stringify(body)});const d=await r.json().catch(()=>({error:'السيرفر لم يرد بنتيجة صالحة'}));if(!r.ok)throw Error(d.error||'حدث خطأ');return d;}
document.addEventListener('submit',async e=>{
 const f=e.target;
 if(f.id==='z42-role-form'){
  e.preventDefault();e.stopImmediatePropagation();const btn=f.querySelector('button');btn.disabled=true;
  try{const v=await z42Post('/api/roles42/redeem',{code:f.elements.code.value});f.reset();await reloadLive();toast(v.notice||'تم تفعيل المنصب بنجاح');}
  catch(error){toast('تعذر فتح الكود: '+error.message);}finally{if(btn.isConnected)btn.disabled=false;}return;
 }
 if(f.id==='z42-message-form'){
  e.preventDefault();e.stopImmediatePropagation();const to=f.elements.to.value,body=f.elements.body.value.trim();
  if(!confirm('إرسال هذه الرسالة '+(to==='all'?'لكل المواطنين':'إلى المواطن المحدد')+'؟'))return;
  const btn=f.querySelector('button');btn.disabled=true;
  try{const batch=crypto.randomUUID(),sent=[];let cursor='',count=0;
   for(let n=0;n<30;n++){const result=await z42Post('/api/admin/message42',{to,body,batch,cursor});count+=result.sent;sent.push(result.sent);if(!result.next_cursor)break;cursor=result.next_cursor;}
   toast('✅ تم إرسال الرسالة إلى '+count+' مواطن');f.reset();
  }catch(error){toast('تعذر إكمال إرسال الرسالة: '+error.message);}finally{if(btn.isConnected)btn.disabled=false;}return;
 }
},true);
async function z42Presence(active){if(mode!=='online'||!me())return;try{await z42Post('/api/presence42',{active})}catch(e){console.warn('Presence',e.message)}}
window.addEventListener('pagehide',()=>{if(mode==='online'&&me()&&navigator.sendBeacon)navigator.sendBeacon('/api/presence42',new Blob([JSON.stringify({active:false})],{type:'application/json'}));});
document.addEventListener('visibilitychange',()=>{z42Presence(!document.hidden);if(!document.hidden&&mode==='online')reloadLive().catch(()=>{})});
setTimeout(()=>z42Presence(true),2200);setInterval(()=>{if(!document.hidden)z42Presence(true)},35000);
// Release notes are private by owner request. Keep update detection and the refresh control.
function z42ReleaseDialog(){return;}
// Release ID is shared with the actual published Cloudflare Worker (/api/version).
// Only a distinct deployment can open the banner. An acknowledged release never loops.
let z42RemoteVersion='';
const z42AckKey='zangar-update-ack';
function z42ReadAck(){
 try{return localStorage.getItem(z42AckKey)||'';}catch(_){try{return sessionStorage.getItem(z42AckKey)||'';}catch(e){return '';}}
}
function z42WriteAck(value){
 try{localStorage.setItem(z42AckKey,value);}catch(_){}
 try{sessionStorage.setItem(z42AckKey,value);}catch(_){}
}
function z42IsNewerRelease(remote,current){
 const a=remote.split('.').map(Number), b=current.split('.').map(Number);
 for(let i=0;i<Math.max(a.length,b.length);i++){
  const delta=(a[i]||0)-(b[i]||0);if(delta!==0)return delta>0;
 }
 return false;
}
showSiteUpdate=function(){if(document.getElementById('zangar-site-update'))return;
 const el=document.createElement('div');el.id='zangar-site-update';el.className='site-update-banner';el.setAttribute('role','status');
 el.innerHTML='<div class="site-update-copy"><strong>🔄 يوجد إصدار أحدث للموقع</strong><small>اضغط تحميل مرة واحدة؛ سيتم تحميل ملفات الموقع الجديدة بدون حذف البيانات.</small></div><button type="button" class="btn primary site-update-button" id="site-update-refresh">تحميل الجديد ↻</button>';
 document.body.appendChild(el);
 el.querySelector('button').onclick=()=>{
  const v=z42RemoteVersion;
  if(!v)return;
  z42WriteAck(v);
  if(navigator.serviceWorker?.controller)navigator.serviceWorker.controller.postMessage({type:'SKIP_WAITING'});
  const url=new URL(location.href);url.searchParams.set('release',v);location.replace(url.toString());
 };
};
checkForSiteUpdate=async function(){
 if(location.protocol==='file:'||['localhost','127.0.0.1'].includes(location.hostname))return;
 try{
  const r=await fetch('/api/version?check='+Date.now(),{credentials:'same-origin',cache:'no-store'});
  if(!r.ok)return;
  const d=await r.json(),remote=String(d.version||'').trim();
  if(!/^[0-9]+(?:\.[0-9]+){1,3}$/.test(remote))return;
  z42RemoteVersion=remote;
  if(z42IsNewerRelease(remote,VERSION)&&z42ReadAck()!==remote)showSiteUpdate();
  else document.getElementById('zangar-site-update')?.remove();
 }catch(e){console.warn('تعذر فحص تحديث الدولة',e.message)}
};
// Release popup deliberately disabled.
