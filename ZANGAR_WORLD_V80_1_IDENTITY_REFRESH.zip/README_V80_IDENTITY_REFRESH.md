# ZANGAR WORLD V80.1 — Identity refresh

- Refreshed the Zangar identity card into a cleaner, compact modern layout.
- Replaced the manual copy-verification-link action with a direct **Verify my identity** button.
- The button opens the signed-in member's verification page using the existing Zangar membership record; no manual ID copy/paste is required.
- This is an in-platform fictional membership verification, not verification against Saudi government/National ID databases.

No Worker/D1 schema changes were made.
