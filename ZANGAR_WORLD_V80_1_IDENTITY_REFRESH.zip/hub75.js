(()=>{'use strict';
const $=id=>document.getElementById(id);let st=null,tab='rich',busy=false;
const esc=x=>String(x??'').replace(/[&<>"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));
const fmt=n=>Number(n||0).toLocaleString('ar-EG');
function toast(m,bad){const t=$('toast');t.textContent=m;t.classList.toggle('bad',!!bad);t.classList.add('show');clearTimeout(toast.t);toast.t=setTimeout(()=>t.classList.remove('show'),2800);}
async function api(path,body){const r=await fetch(path,{credentials:'same-origin',cache:'no-store',...(body!==undefined?{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify(body)}:{})});let j={};try{j=await r.json()}catch(e){}if(r.status===401){location.href='/';throw Error('سجّل دخولك الأول')}if(!r.ok||j.ok===false)throw Error(j.error||'تعذر إتمام العملية');return j;}
const medal=i=>['🥇','🥈','🥉'][i]||String(i+1);
function board(){
 const rows=tab==='rich'?st.boards.rich:st.boards.weekly;
 if(!rows.length)return `<div class="z75-empty"><div class="e-ico">🏆</div><b>لسه مفيش ترتيب</b><small>ابدأ بمهمة أو افتح صندوق اليوم وهتظهر هنا.</small></div>`;
 return rows.map((r,i)=>`<div class="row ${r.name===st.me.name?'me':''}"><span class="no">${medal(i)}</span><div class="nm"><b>${esc(r.name)}</b><small>${esc(r.job||'مواطن')}</small></div><span class="sc">${tab==='rich'?fmt(r.points)+' 🪙':fmt(r.score)+' نقطة'}</span></div>`).join('');
}
function mission(m){
 const pct=Math.round(m.current/m.target*100);
 const btn=m.claimed?'<span class="btn" style="opacity:.6">✓ تم</span>':m.done?`<button type="button" class="btn primary" data-mission="${esc(m.id)}">استلم +${m.reward}</button>`:`<span class="btn" style="opacity:.55">+${m.reward} 🪙</span>`;
 return `<div class="mission"><div><h3>${esc(m.title)}</h3><small>${esc(m.desc)} • ${m.current}/${m.target}</small></div>${btn}<div class="bar"><span style="width:${pct}%"></span></div></div>`;
}
function render(){
 const s=st.streak,dots=Array.from({length:s.cap_days},(_,i)=>`<i class="${i<Math.min(s.current,s.cap_days)?'on':''}"></i>`).join('');
 const sBtn=s.claimed_today?'<button type="button" class="btn block" disabled>✓ استلمت مكافأة النهاردة</button>':s.claimable?`<button type="button" class="btn primary block" data-streak>🔥 استلم +${s.bonus_today} زنجر</button>`:`<a class="btn block" href="/growth59.html#chest">🎁 افتح صندوق اليوم الأول</a>`;
 const done=st.missions.filter(m=>m.claimed).length;
 $('root').innerHTML=`<div class="top2"><div class="stat"><small>رصيدك</small><b>${fmt(st.me.points)}</b></div><div class="stat"><small>ترتيبك بين الأغنى</small><b>#${fmt(st.me.rich_rank)}</b></div></div>
 <section class="card"><h2>🔥 الأيام المتتالية <small>سقف المكافأة بعد ${s.cap_days} أيام</small></h2><div class="streak"><span class="flame">${s.current?'🔥':'🌱'}</span><div><b>${fmt(s.current)} يوم</b><small>${s.chest_today?'صندوق النهاردة اتفتح — كمّل بكرة':s.current?'افتح الصندوق النهاردة عشان ماتقطعش السلسلة':'ابدأ سلسلتك بفتح صندوق اليوم'}</small></div></div><div class="days">${dots}</div>${sBtn}</section>
 <section class="card"><h2>🎯 مهام اليوم <small>${done}/${st.missions.length} مستلمة</small></h2>${st.missions.map(mission).join('')}</section>
 <section class="card"><h2>🏆 الترتيب</h2><div class="tabs"><button type="button" class="tab ${tab==='rich'?'on':''}" data-tab="rich">💰 الأغنى</button><button type="button" class="tab ${tab==='weekly'?'on':''}" data-tab="weekly">⚡ الأنشط الأسبوع</button></div><div id="board">${board()}</div></section>
 <button type="button" class="btn block" data-tour>🎓 إعادة الجولة التعريفية</button>`;
}
async function load(){try{st=await api('/api/v75/hub');render();}catch(e){$('root').innerHTML=`<div class="z75-empty"><div class="e-ico">⚠️</div><b>تعذر تحميل المركز</b><small>${esc(e.message)}</small><button type="button" class="btn" data-retry>حاول تاني</button></div>`;}}
document.addEventListener('click',async e=>{
 const t=e.target.closest('[data-tab]');if(t){tab=t.dataset.tab;render();return}
 if(e.target.closest('[data-retry]')){load();return}
 if(e.target.closest('[data-tour]')){window.Z75Tour&&window.Z75Tour.start();return}
 const m=e.target.closest('[data-mission]'),s=e.target.closest('[data-streak]');
 if(!(m||s)||busy)return;busy=true;
 try{const d=m?await api('/api/v75/mission',{mission:m.dataset.mission}):await api('/api/v75/streak',{});toast(d.notice||'تم');await load();}
 catch(err){toast(err.message,true);await load();}finally{busy=false}
});
load();
})();
