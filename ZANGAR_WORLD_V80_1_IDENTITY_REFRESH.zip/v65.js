/* ZANGAR WORLD V65. All sensitive decisions are independently authorized by the Worker. */
(()=>{'use strict';
let data=null,busy=false;const $=id=>document.getElementById(id);
const esc=x=>String(x??'').replace(/[&<>"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));
const fmt=n=>Number(n||0).toLocaleString('ar-EG');
const empty='<p class="z65-muted">لا يوجد شيء هنا حاليًا.</p>';
const line=(a,b='',actions='')=>`<div class="z65-line"><div><strong>${a}</strong><small>${b}</small></div><div class="z65-actions">${actions}</div></div>`;
const btn=(text,act,props={})=>`<button type="button" class="z65-secondary" data-action="${esc(act)}" ${Object.entries(props).map(([k,v])=>`data-${esc(k)}="${esc(v)}"`).join(' ')}>${esc(text)}</button>`;
const person=id=>data?.people.find(x=>x.id===id)?.name||data?.friends.find(x=>x.id===id)?.name||'مواطن';
async function api(url,method='GET',body){const ctl=new AbortController();const timer=setTimeout(()=>ctl.abort(),20000);try{const r=await fetch(url,{method,credentials:'same-origin',cache:'no-store',headers:method==='POST'?{'Content-Type':'application/json'}:{},body:method==='POST'?JSON.stringify(body):undefined,signal:ctl.signal});const t=await r.text();let v;try{v=JSON.parse(t)}catch{throw Error('الخادم لم يرجع بيانات متوقعة')};if(!r.ok||v.ok===false)throw Error(v.error||v.message||'فشل الاتصال');return v}finally{clearTimeout(timer)}}
function flash(s,fail=false){const n=$('z65-notice');n.hidden=false;n.className=fail?'error':'';n.textContent=s;}
function options(items,getKey,getLabel,placeholder='اختار…'){return '<option value="">'+esc(placeholder)+'</option>'+items.map(x=>`<option value="${esc(getKey(x))}">${esc(getLabel(x))}</option>`).join('')}
function render(){if(!data)return;const d=data;const status=$('z65-status');status.hidden=true;
$('z65-people').innerHTML=options(d.people,x=>x.id,x=>x.name,'اختار مواطنًا لإضافته');
$('z65-requests').innerHTML=d.requests.filter(r=>r.status==='pending').map(r=>line(esc(person(r.sender_id)||r.sender_name),r.sender_id===d.me.id?'أرسلت طلبًا — بانتظار الرد':'أرسل لك طلب صداقة',r.recipient_id===d.me.id?btn('قبول','friend_decide',{request:r.id,accept:'yes'})+btn('رفض','friend_decide',{request:r.id,accept:'no'}):'')).join('')||empty;
$('z65-friend-list').innerHTML=d.friends.map(x=>line(esc(x.name),'صديق في دولة الزنجر',btn('إزالة','friend_remove',{user:x.id}))).join('')||empty;
$('z65-groups').innerHTML=d.groups.length?'<h3>مجموعاتي الحالية</h3>'+d.groups.map(g=>line(esc(g.title),fmt(g.members)+' أعضاء','')).join(''):'';
$('z65-task-list').innerHTML=d.tasks.map(t=>`<div class="z65-slab"><strong>${esc(t.title)}</strong><small class="z65-muted">${t.period==='daily'?'يومية':'أسبوعية'} · ${fmt(t.reward)} زنجر</small><div class="z65-progress"><span style="width:${Math.max(0,Math.min(100,100*t.progress/t.target))}%"></span></div><div class="z65-line"><span>${fmt(t.progress)} / ${fmt(t.target)}</span>${t.done?'<span class="z65-tag">✅ تم استلام المكافأة</span>':`<button class="z65-gold" data-action="task_claim" data-task="${esc(t.id)}" ${t.progress<t.target?'disabled':''}>استلام المكافأة</button>`}</div></div>`).join('');
$('z65-week').textContent='الأسبوع الذي يبدأ '+d.week;
$('z65-rank-list').innerHTML=d.rankings.map(p=>line(`${p.rank===1?'🥇':p.rank===2?'🥈':p.rank===3?'🥉':'🏅'} ${esc(p.name)}`,`النقاط ${fmt(p.score)} · المشروعات ${fmt(p.projects)} · التعليم ${fmt(p.education)} · الصحة ${fmt(p.health)} · السكان ${fmt(p.members)} · الأصوات ${fmt(p.votes)}`,d.my_vote?`<span class="z65-tag">${d.my_vote===p.id?'صوّتَّ لهذه المحافظة':'صوّتك مسجّل'}</span>`:btn('صوّت','province_vote',{province:p.id}))).join('')||empty;
const provinces=d.rankings;document.querySelectorAll('[data-provinces]').forEach(sel=>{const old=sel.value;sel.innerHTML=options(provinces,x=>x.id,x=>x.name,'اختار المحافظة');if(old)sel.value=old});
document.querySelectorAll('[data-partners]').forEach(sel=>{const old=sel.value;sel.innerHTML=options(d.partners,x=>x.id,x=>x.name+' — '+x.field,'اختار دولة افتراضية');if(old)sel.value=old});
document.querySelectorAll('[data-people]').forEach(sel=>{const old=sel.value;sel.innerHTML=options(d.people,x=>x.id,x=>x.name,'اختر مواطنًا');if(old)sel.value=old});
$('z65-partners').innerHTML=d.partners.map(x=>line('🌐 '+esc(x.name),'مجال التعاون: '+esc(x.field))).join('');
$('z65-treaties').innerHTML=d.treaties.map(t=>line(esc(t.province_name)+' × '+esc(t.partner_name),esc(t.field)+' · '+esc(t.description)+' · الحالة: '+esc(t.status),d.is_president&&t.status==='pending'?btn('اعتماد','treaty_decide',{treaty:t.id,approve:'yes'})+btn('رفض','treaty_decide',{treaty:t.id,approve:'no'}):'')).join('')||empty;
$('z65-resources').innerHTML='<details><summary class="z65-muted">عرض أرصدة موارد المحافظات (اضغط للتوسيع)</summary><p class="z65-muted">'+d.resources.map(r=>esc(provinces.find(x=>x.id===r.province_id)?.name||r.province_id)+' / '+esc(r.resource)+' '+fmt(r.quantity)).join(' · ')+'</p></details>';
$('z65-trades').innerHTML=d.trades.map(t=>line(esc(t.from_name)+' → '+esc(t.to_name),`${fmt(t.quantity)} ${esc(t.resource)} / ${fmt(t.price)} زنجر · ${esc(t.status)}`,t.status==='pending'?(btn('قبول الاستلام','trade_accept',{trade:t.id})+btn('إلغاء العرض','trade_cancel',{trade:t.id})):'' )).join('')||empty;
$('z65-my-reports').innerHTML=d.reported.map(r=>line(esc(person(r.target_id)),esc(r.reason)+' · '+esc(r.status))).join('')||empty;
$('z65-report-moderation').hidden=!d.is_president;
$('z65-pending-reports').innerHTML=(d.reports||[]).map(r=>line(esc(r.reporter_name)+' ضد '+esc(r.target_name),esc(r.reason),btn('مراجعة','report_decide',{report:r.id}))).join('')||empty;
}
function tab(next){if(!['friends','tasks','ranking','diplomacy','reports'].includes(next))next='friends';document.querySelectorAll('#z65-tabs button').forEach(x=>x.classList.toggle('active',x.dataset.tab===next));document.querySelectorAll('.z65-section').forEach(x=>x.hidden=x.dataset.section!==next);history.replaceState(null,'','#'+next)}
async function refresh(message){try{data=await api('/api/z65/state');render();if(message)flash(message,false)}catch(e){$('z65-status').hidden=false;$('z65-status').textContent='تعذّر تحميل بيانات المجتمع: '+e.message+' — سجّل دخولك من الصفحة الرئيسية ثم جرّب مجددًا.';flash('تعذّر الاتصال: '+e.message,true)}}
async function post(type,body){if(busy)return;busy=true;try{const r=await api('/api/z65/action','POST',{type,...body});await refresh(r.message||'تمت العملية')}catch(e){flash(e.message,true)}finally{busy=false}}
document.getElementById('z65-tabs').addEventListener('click',e=>{const b=e.target.closest('[data-tab]');if(b)tab(b.dataset.tab)});
document.addEventListener('submit',e=>{const f=e.target.closest('[data-form]');if(!f)return;e.preventDefault();const d=Object.fromEntries(new FormData(f));post(f.dataset.form,d)});
document.addEventListener('click',e=>{const b=e.target.closest('[data-action]');if(!b)return;const t=b.dataset.action;
if(t==='friend_decide')return post(t,{request_id:b.dataset.request,accept:b.dataset.accept==='yes'});
if(t==='friend_remove')return confirm('إزالة الصديق؟')&&post(t,{user_id:b.dataset.user});
if(t==='task_claim')return post(t,{task_id:b.dataset.task});
if(t==='province_vote')return confirm('تصويت واحد في الأسبوع، متأكد؟')&&post(t,{province_id:b.dataset.province});
if(t==='treaty_decide')return confirm('تأكيد القرار؟')&&post(t,{treaty_id:b.dataset.treaty,approve:b.dataset.approve==='yes'});
if(t==='trade_accept')return confirm('سيتم تحويل موارد وزنجَر من الخزينة مرة واحدة، هل توافق؟')&&post(t,{trade_id:b.dataset.trade});
if(t==='trade_cancel')return post(t,{trade_id:b.dataset.trade});
if(t==='report_decide'){const decision=prompt('اكتب نتيجة المراجعة مع السبب (8 أحرف على الأقل):');if(decision===null)return;const status=confirm('مراجعة البلاغ؟ موافق = تمت المراجعة / إلغاء = رفض البلاغ')?'reviewed':'dismissed';return post(t,{report_id:b.dataset.report,status,decision});}
});
tab(location.hash.slice(1));refresh();
})();
