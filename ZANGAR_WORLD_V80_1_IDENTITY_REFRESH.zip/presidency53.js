"use strict";
const $=id=>document.getElementById(id),fmt=n=>Number(n||0).toLocaleString('ar-EG'),esc=s=>String(s??'').replace(/[&<>"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));
let busy=false;
async function api(path,body){const r=await fetch(path,{cache:'no-store',credentials:'same-origin',...(body?{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify(body)}:{})});const d=await r.json();if(!r.ok||d.ok===false)throw Error(d.error||'تعذر الاتصال');return d;}
function note(s,bad=false){$('cNotice').textContent=(bad?'⚠️ ':'✅ ')+s;$('cNotice').style.borderColor=bad?'#d8837b':'#679988';}
async function init(){try{const d=await api('/api/federation/state');$('locked').hidden=!!d.admin;$('central').hidden=!d.admin;if(!d.admin){note('الرجاء فتح صلاحية الرئاسة بخطوتين.');return;}
const provinces=d.provinces||[],users=d.available_citizens||[];
$('cStats').innerHTML=`<div><span>عدد الدول</span><b>${fmt(provinces.length)}</b></div><div><span>إجمالي خزائن الدول</span><b>${fmt(provinces.reduce((n,p)=>n+Number(p.treasury||0),0))} زنجر</b></div>`;
const ps=provinces.map(p=>`<option value="${esc(p.id)}">${esc(p.name)}</option>`).join('');
const us=users.map(u=>`<option value="${esc(u.id)}" ${u.id===d.my_id?'selected':''}>${esc(u.name)}${u.id===d.my_id?' (أنا)':''}</option>`).join('');
document.querySelectorAll('.provinces').forEach(x=>x.innerHTML=ps);document.querySelectorAll('.citizens').forEach(x=>x.innerHTML=us);
if(!users.length)note('ليس هناك مواطنون متاحون للاختيار الآن',true);else note('صلاحيات الرئاسة مفعّلة — يمكن اختيار أي دولة أو مواطن');
}catch(e){$('locked').hidden=false;$('central').hidden=true;note(e.message,true)}}
async function grant(form,kind){if(busy)return;const payload=Object.fromEntries(new FormData(form).entries());payload.type=kind;payload.request_id=crypto.randomUUID();if(!confirm('تأكيد منح الهدية للمستفيد المختار؟'))return;busy=true;try{const d=await api(kind==='grant_personal_unit'?'/api/central53/action':'/api/federation/action',payload);note(d.notice||'نجح الإجراء')}catch(e){note(e.message,true)}finally{busy=false}}
[['fundForm','grant_funds'],['walletForm','grant_wallet']].forEach(([id,kind])=>$(id).addEventListener('submit',e=>{e.preventDefault();grant(e.currentTarget,kind)}));
$('cLock').onclick=async()=>{if(!confirm('هل تريد إلغاء صلاحية الرئاسة من حسابك على كل الأجهزة؟ ستحتاج إعادة إدخال الكود والرمز السري.'))return;try{await api('/api/presidency49/gate',{stage:'close'});location.assign('/president49.html')}catch(e){note(e.message,true)}};

const dt=t=>new Date(Number(t)).toLocaleString('ar-EG');
async function loadLog(){try{const d=await api('/api/v80/deductions');$('deductLog').innerHTML=d.log.length?d.log.map(r=>`<div class="row"><b>${esc(r.citizen||'—')}</b> · ${fmt(r.amount)} زنجر · ${esc(r.reason)}<br><small>${dt(r.created_at)} · بواسطة ${esc(r.actor||'—')}</small></div>`).join(''):'لا توجد عمليات خصم بعد.'}catch(e){$('deductLog').textContent=e.message}}
const RL={password:'كلمة المرور',pin:'الرمز السري',both:'كلمة المرور والرمز السري'},RS={pending:'بانتظار القرار',approved:'تمت الموافقة',rejected:'مرفوض',used:'تم تعيين بيانات جديدة'};
async function loadRec(){try{const d=await api('/api/v80/recovery/list');$('recList').innerHTML=d.requests.length?d.requests.map(r=>`<div class="row"><b>${esc(r.name)}</b> · رقم الهوية ${esc(r.card_no||'')} · نسيان ${RL[r.mode]}<br><small>${dt(r.created_at)} · ${RS[r.status]||r.status}</small>${r.status==='pending'?`<div><button class="btn green" data-rec="${esc(r.id)}" data-ok="1">موافقة</button> <button class="btn red" data-rec="${esc(r.id)}" data-ok="0">رفض</button></div>`:''}</div>`).join(''):'لا توجد طلبات.'}catch(e){$('recList').textContent=e.message}}
$('recList').addEventListener('click',async e=>{const b=e.target.closest('[data-rec]');if(!b||busy)return;busy=true;try{const d=await api('/api/v80/recovery/decide',{id:b.dataset.rec,approve:b.dataset.ok==='1'});note(d.notice||'تم')}catch(x){note(x.message,true)}finally{busy=false;loadRec()}});
$('deductForm').addEventListener('submit',async e=>{e.preventDefault();if(busy)return;const f=e.currentTarget,v=Object.fromEntries(new FormData(f).entries());if(!confirm('تأكيد خصم '+fmt(v.amount)+' زنجر من المواطن المختار وإعادتها إلى خزينة الدولة؟'))return;busy=true;try{const d=await api('/api/v80/deduct',{user_id:v.user_id,amount:Number(v.amount),reason:v.reason,request_id:crypto.randomUUID()});note(d.notice||'تم الخصم');f.reset();loadLog()}catch(x){note(x.message,true)}finally{busy=false}});
const _init=init;init=async function(){await _init();if(!$('central').hidden){loadLog();loadRec()}};
init();
