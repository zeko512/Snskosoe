// Calls the game's push cron every minute so notifications arrive even when nobody has the site open.
export default {
  async scheduled(event, env, ctx) {
    const r = await fetch(env.SITE_URL + '/api/push/cron', {
      method: 'POST',
      headers: { 'X-Zangar-Cron-Secret': env.PUSH_CRON_SECRET }
    });
    console.log('zangar cron', r.status);
  }
};
