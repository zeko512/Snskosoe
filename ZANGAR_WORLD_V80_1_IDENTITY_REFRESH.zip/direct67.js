(()=>{'use strict';const $=x=>document.getElementById(x);const forms={'new':$('form-new'),login:$('form-login'),old:$('form-old')};let tab='new',avatar='';const e=$('join-error');
async function api(path,data){const ctl=new AbortController(),t=setTimeout(()=>ctl.abort(),20000);try{let r=await fetch(path,{method:data?'POST':'GET',headers:data?{'Content-Type':'application/json'}:{},body:data?JSON.stringify(data):undefined,credentials:'same-origin',cache:'no-store',signal:ctl.signal});let v=await r.json().catch(()=>({}));if(!r.ok){const ex=new Error(v.error||'حصل خطأ في السيرفر ('+r.status+')');if(r.status===428&&/^[a-f0-9]{32}$/.test(v.legacy_salt||''))ex.legacySalt=v.legacy_salt;throw ex}return v}finally{clearTimeout(t)}}
function showErr(s){e.textContent=s||'';e.hidden=!s}
function select(which){tab=which;Object.entries(forms).forEach(([k,f])=>f.hidden=k!==which);['new','login','old'].forEach(k=>$('tab-'+k).classList.toggle('active',k===which));showErr('')}
for(const k of Object.keys(forms))$('tab-'+k).onclick=()=>select(k);
$('old-slot').innerHTML=Array.from({length:30},(_,i)=>`<option value="${i+1}">ضيف ${String(i+1).padStart(2,'0')}</option>`).join('');
async function pic(file){if(!file)return '';if(!/^image\/(png|jpeg|webp)$/.test(file.type)||file.size>6*1024*1024)throw Error('الصورة لازم تكون PNG أو JPEG أو WebP أقل من 6 ميجا');let url=URL.createObjectURL(file);try{let im=await new Promise((ok,no)=>{let x=new Image();x.onload=()=>ok(x);x.onerror=()=>no(Error('تعذر قراءة الصورة'));x.src=url});let c=document.createElement('canvas');c.width=c.height=160;const x=c.getContext('2d'),d=Math.min(im.width,im.height);x.drawImage(im,(im.width-d)/2,(im.height-d)/2,d,d,0,0,160,160);let out=c.toDataURL('image/jpeg',.65);if(out.length>58000)out=c.toDataURL('image/jpeg',.35);if(out.length>58000)throw Error('الصورة كبيرة');return out}finally{URL.revokeObjectURL(url)}}
forms.new.elements.avatar.onchange=async ev=>{const fn=$('file-name');if(fn)fn.textContent=ev.target.files[0]?ev.target.files[0].name:'لم يتم اختيار صورة';try{avatar=await pic(ev.target.files[0]);$('image-preview').hidden=!avatar;$('image-preview').style.backgroundImage=avatar?`url("${avatar}")`:''}catch(ex){avatar='';showErr(ex.message)}};
async function onSubmit(form,fn){form.onsubmit=async ev=>{ev.preventDefault();showErr('');const b=form.querySelector('[type=submit]');b.disabled=true;try{await fn(new FormData(form))}catch(ex){showErr(ex.message||'تعذر الاتصال')}finally{b.disabled=false}}}
const cleanUser=v=>String(v||'').normalize('NFKC').replace(/[\u0640\u064B-\u065F\u0670]/g,'').trim();
onSubmit(forms.new,async d=>{
 const username=cleanUser(d.get('username')),display=String(d.get('display_name')||'').trim().replace(/\s+/g,' '),pw=String(d.get('password'));
 if(!/^[\p{L}\p{N}_.\-]{3,24}$/u.test(username))throw Error('اسم المستخدم من 3 إلى 24 حرفًا: حروف أو أرقام أو نقطة أو شرطة أو شرطة سفلية، بدون مسافات');
 if(display.length<2||display.length>35||/[<>]/.test(display))throw Error('الاسم الظاهر من حرفين إلى 35 حرفًا');
 if(pw.length<8)throw Error('كلمة المرور 8 أحرف على الأقل');
 if(pw!==String(d.get('confirm')))throw Error('كلمتا المرور غير متطابقتين');
 if(pw===username)throw Error('لا تجعل كلمة المرور نفس اسم المستخدم');
 await api('/api/z67/register',{username,display_name:display,password:pw,avatar});
 location.replace('/state.html#/home');
});
onSubmit(forms.login,async d=>{
 const data={username:String(d.get('username')).trim(),password:String(d.get('password'))};
 try{await api('/api/z67/login',data)}catch(ex){
  if(!ex.legacySalt)throw ex;
  // 160k legacy computations run on the player's browser, never on Cloudflare Workers.
  const key=await crypto.subtle.importKey('raw',new TextEncoder().encode(data.password),'PBKDF2',false,['deriveBits']);
  const buf=await crypto.subtle.deriveBits({name:'PBKDF2',salt:new TextEncoder().encode(ex.legacySalt),iterations:160000,hash:'SHA-256'},key,256);
  data.legacy_proof=Array.from(new Uint8Array(buf),x=>x.toString(16).padStart(2,'0')).join('');
  await api('/api/z67/login',data);
 }
 location.replace('/state.html#/home');
});
onSubmit(forms.old,async d=>{let slot=Number(d.get('slot'));await api('/api/z639/enter',{slot,password:d.get('password')});location.replace('/state.html#/home')});
async function init(){try{const s=await api('/api/session60');if(s.logged_in){location.replace('/state.html#/home');return}}catch(ex){showErr('تعذر التحقق من الجلسة؛ تأكد من الاتصال ثم حاول مجددًا')}}
init();
})();
