/* Zangar Rush: single 2D 16:9 canvas game, verified 3-stage server reward. */
(()=>{'use strict';
const cv=document.getElementById('cg-canvas'),g=cv.getContext('2d'),W=960,H=540;
const q=id=>document.getElementById(id);
const LEVELS=[{name:'شارع العاصمة',sky:['#274f7e','#86b3bf'],road:'#303b52',grass:'#37776b',speed:155},
{name:'الحي الذهبي',sky:['#684b7c','#f0a870'],road:'#50415a',grass:'#a66b65',speed:170},
{name:'ليلة الزنجر',sky:['#111c44','#293e76'],road:'#222d4b',grass:'#236466',speed:185}];
const packPos=[720,1640,2500],stageLimit=3190;
let view3D=true;let mode='menu',session='',seed=1,level=1,items=0,confirmed=0,dist=0,player={x:175,y:285,target:285,invuln:0},lives=3,acc=0,last=0,particles=[],fanfare=[],soundOn=true,requestBusy=false,flash=0,shake=0,gameTime=0,progressLock=false,obstacles=[],floating=[];
const clamp=(x,a,b)=>Math.max(a,Math.min(b,x));
function rnd(n){let x=Math.sin(n*13.414+seed*.1234)*43758.545;return x-Math.floor(x)}
function colorGrad(x,y,r,colors){const grad=g.createLinearGradient(x,y,x,y+r);grad.addColorStop(0,colors[0]);grad.addColorStop(1,colors[1]);return grad;}
function round(x,y,w,h,r,c){g.beginPath();g.roundRect(x,y,w,h,r);g.fillStyle=c;g.fill();}
function text(t,x,y,font,color,align='center'){g.font=font;g.textAlign=align;g.fillStyle=color;g.fillText(t,x,y)}
function sound(freq,dur=.10,type='sine',vol=.07){if(!soundOn)return;try{const c=new (window.AudioContext||window.webkitAudioContext)(),o=c.createOscillator(),a=c.createGain();o.type=type;o.frequency.value=freq;a.gain.setValueAtTime(vol,c.currentTime);a.gain.exponentialRampToValueAtTime(.0001,c.currentTime+dur);o.connect(a);a.connect(c.destination);o.start();o.stop(c.currentTime+dur);o.onended=()=>c.close()}catch{}}
const toast=(message)=>{floating.push({text:message,x:W/2,y:126,t:2});};
function fillWorld(){obstacles=[];for(let n=350;n<stageLimit;n+=300){if(packPos.some(p=>Math.abs(p-n)<175))continue;let lane=Math.floor(rnd(n+level*19)*3);obstacles.push({x:n,y:[213,292,370][lane],kind:rnd(n*2)>.55?'car':'barrier',hit:false});}
 // guarantee not in the same road slot as pickups; packages are lane-specific
}
function putParticles(x,y,colors,n=14){for(let i=0;i<n;i++){particles.push({x,y,vx:(rnd(i+Math.random()*11)-.5)*250,vy:(Math.random()-.5)*240,t:.35+Math.random()*.55,size:3+Math.random()*5,c:colors[i%colors.length]});}}
function updateHud(){q('cg-level').textContent=`المرحلة ${level} / ٣`;q('cg-life').textContent='❤️'.repeat(lives)+'🖤'.repeat(3-lives);q('cg-parcel').textContent=`📦 ${confirmed} / ٣`;q('cg-distance').textContent=`${Math.round(dist/3)} م`;q('cg-progress-bar').style.width=(clamp(dist/stageLimit,0,1)*100)+'%';}
async function api(type,extra={}){const r=await fetch('/api/courier/action',{method:'POST',credentials:'same-origin',headers:{'Content-Type':'application/json'},body:JSON.stringify({type,run:session,stage:level,...extra})});const data=await r.json().catch(()=>({error:'تعذر الاتصال بالدولة'}));if(!r.ok)throw Error(data.error||'فشل الاتصال');return data;}
function overlay(title,message,button){mode='overlay';q('cg-overlay').hidden=false;q('cg-title').textContent=title;q('cg-message').textContent=message;q('cg-start').textContent=button;}
async function start(){if(requestBusy)return;requestBusy=true;q('cg-start').disabled=true;q('cg-start').textContent='جارِ فتح الجولة...';
 try{const start=await api('start');session=start.run;seed=start.seed;level=1;dist=0;items=0;confirmed=0;lives=3;particles=[];player.y=player.target=292;gameTime=0;flash=0;progressLock=false;fillWorld();mode='playing';q('cg-overlay').hidden=true;updateHud();sound(660,.14)}
 catch(e){overlay('تعذر فتح الجولة',e.message,'حاول مرة تانية')}
 finally{q('cg-start').disabled=false;requestBusy=false}
}
function drawBackground(t){const cfg=LEVELS[level-1],sky=colorGrad(0,0,205,cfg.sky);g.fillStyle=sky;g.fillRect(0,0,W,H);
 for(let i=0;i<8;i++){const x=((i*195-dist*.10)%1200+1200)%1200-120,base=155+(i%3)*9;g.fillStyle=level===3?'#10233c99':'#d5c6a850';g.beginPath();g.moveTo(x-125,205);g.lineTo(x,base);g.lineTo(x+30,base-47);g.lineTo(x+135,205);g.fill()}
 // trees, houses and city facades with parallax
 for(let i=0;i<13;i++){const x=((i*135-dist*.44)%1760+1760)%1760-100,house=rnd(i+level*31)>.5;
  if(house){const h=55+rnd(i*3)*39;round(x,152-h,93,h+12,5,level===3?'#293e63':'#c6a08a');g.fillStyle=level===3?'#a8b8e0':'#916f6b';g.beginPath();g.moveTo(x-8,152-h);g.lineTo(x+47,120-h);g.lineTo(x+101,152-h);g.fill();for(let j=0;j<2;j++)round(x+12+j*40,160-h,22,25,2,level===3?'#ffe28b':'#6197af');}
  else {g.fillStyle=cfg.grass;g.beginPath();g.arc(x,123,33,0,Math.PI*2);g.fill();round(x-6,133,11,43,5,'#735846');g.beginPath();g.arc(x+12,132,22,0,Math.PI*2);g.fill();}}
 round(0,165,W,345,0,cfg.road);round(0,168,W,29,0,'#7c8994');round(0,442,W,30,0,'#d9c6a1');round(0,469,W,70,0,cfg.grass);round(0,202,W,236,0,'#2d3c4cd1');
 for(let lane=0;lane<2;lane++){const y=250+lane*78;for(let x=-120+(Math.floor(dist*.65)%115);x<W;x+=115)round(x,y,70,5,3,'#ffffff80')}
 for(let i=0;i<22;i++){const x=((i*73-dist*.7)%1650+1650)%1650;g.fillStyle='#b6c5bd15';g.beginPath();g.ellipse(x,215+(i%3)*80,29,3,0,0,Math.PI*2);g.fill()}
 if(level===3){g.fillStyle='#e7e7ffbb';for(let i=0;i<22;i++){const x=(i*139+Math.sin(i)*23)%960,y=(i*67)%145;g.fillRect(x,y,2,2)}}
}
function drawScooter(x,y,tt){g.save();g.translate(x,y);if(player.invuln>0&&Math.floor(tt*14)%2===0)g.globalAlpha=.45;
 // tail dust and shadow
 g.fillStyle='#070b17aa';g.beginPath();g.ellipse(0,33,63,10,0,0,Math.PI*2);g.fill();for(let i=0;i<4;i++){g.fillStyle='#c0d0d34a';g.beginPath();g.ellipse(-65-i*19-Math.sin(tt*15+i)*14,21+i%2*7,7+i*3,3+i,0,0,7);g.fill()}
 for(let k of [-32,37]){g.fillStyle='#131a28';g.beginPath();g.arc(k,23,18,0,7);g.fill();g.fillStyle='#a9d9dd';g.beginPath();g.arc(k,23,9,0,7);g.fill();g.fillStyle='#405269';g.beginPath();g.arc(k,23,3,0,7);g.fill();}
 g.fillStyle='#ffb945';g.beginPath();g.moveTo(-42,0);g.quadraticCurveTo(-65,-26,-40,-19);g.lineTo(17,-15);g.quadraticCurveTo(43,-9,45,13);g.lineTo(3,16);g.lineTo(-12,8);g.closePath();g.fill();g.fillStyle='#fff1cc';round(-19,-11,32,10,4,'#ffe58d');
 round(-50,-49,32,38,6,'#9452b4');round(-47,-45,26,26,5,'#c28be0');text('Z',-35,-25,'900 25px Georgia','#fcebb4');g.fillStyle='#f4a45e';g.beginPath();g.arc(0,-29,15,0,7);g.fill();round(-15,-52,37,23,10,'#3c6de6');round(4,-49,20,11,6,'#b4e9ff');
 g.strokeStyle='#fddca0';g.lineWidth=7;g.lineCap='round';g.beginPath();g.moveTo(5,-10);g.lineTo(27,8);g.stroke();g.fillStyle='#ffffa7';g.beginPath();g.arc(49,2,8,0,7);g.fill();g.restore();}
function drawCar(x,y,idx){g.save();g.translate(x,y);round(-49,-26,96,51,13,idx?'#4f78ca':'#d95f7b');round(-31,-34,51,29,9,idx?'#b4d6ed':'#faafbd');round(-38,19,20,15,4,'#142336');round(24,19,19,15,4,'#142336');round(33,-18,12,15,3,'#ffe9a9');g.restore()}
function drawBarrier(x,y){g.save();g.translate(x,y);round(-35,-21,67,48,7,'#ffb03a');for(let k=0;k<3;k++){g.strokeStyle='#513e36';g.lineWidth=7;g.beginPath();g.moveTo(-22+k*21,-20);g.lineTo(-13+k*21,25);g.stroke()}round(-42,27,82,8,3,'#f2d287');g.restore()}
function drawParcel(x,y,n){g.save();g.translate(x,y);const hover=Math.sin(gameTime*5+n)*5;g.translate(0,hover);g.fillStyle='#0d1c32bb';g.beginPath();g.ellipse(0,34,22,7,0,0,7);g.fill();round(-25,-26,50,50,7,'#fdca61');round(-25,-26,50,12,5,'#fff0a7');round(-5,-26,10,50,2,'#bd7447');text('Z',0,14,'900 23px Georgia','#7f4d35');g.restore()}
function drawDistanceArrows(){for(let n=0;n<7;n++){const x=((n*179-dist*.55)%1350+1350)%1350-100,y=438;g.fillStyle='#7df6e655';g.beginPath();g.moveTo(x,y);g.lineTo(x+30,y);g.lineTo(x+38,y-11);g.lineTo(x+30,y-21);g.lineTo(x,y-21);g.lineTo(x+12,y-11);g.fill()}}

// ZANGAR 25: original pseudo-3D third-person street view. Same verified server
// course/reward and hitboxes as the existing 2D version, without third-party assets.
function poly(coords,color){g.beginPath();g.moveTo(coords[0][0],coords[0][1]);for(let i=1;i<coords.length;i++)g.lineTo(coords[i][0],coords[i][1]);g.closePath();g.fillStyle=color;g.fill()}
function roadProject(rel,laneY){const d=clamp(rel/900,0,1),zoom=1/(1+d*6.2),horizon=181,y=horizon+(523-horizon)*zoom,offset=(laneY-292)/78;return {x:480+offset*260*zoom,y,scale:zoom,visible:rel>-65&&rel<900}}
function deliveryRoad3D(tt){const cfg=LEVELS[level-1],dark=level===3;
 g.fillStyle=colorGrad(0,0,H,cfg.sky);g.fillRect(0,0,W,H);
 g.fillStyle=dark?'#f5f4b8':'#fff2d1';g.beginPath();g.arc(783,71,dark?30:43,0,Math.PI*2);g.fill();
 for(let i=0;i<12;i++){const x=i*100-100,y=140+Math.sin(i*.72)*24;poly([[x,191],[x+100,191],[x+55,y-55],[x+32,y]],dark?'#334364':'#72968a')}
 round(0,188,960,H-188,0,cfg.grass);
 // blocks behind road: perspective city sides
 for(let i=19;i>=0;i--){const d=((i*153+105-(dist%153)+20000)%3400),pr=roadProject(d,292);if(!pr.visible)continue;
  const scale=pr.scale,size=clamp(36+188*scale,8,164),onRight=i%2===0;
  const x=onRight?pr.x+310*scale+105:pr.x-310*scale-105-size;
  round(x,pr.y-size,size,size,3,dark?'#263a5c':i%3?'#d5b59d':'#9bb8aa');
  round(x+size*.24,pr.y-size*.74,size*.19,size*.25,2,dark?'#f5db91':'#6e9ab2');
  round(x+size*.6,pr.y-size*.74,size*.19,size*.25,2,dark?'#e2c083':'#688fa4');
  poly([[x-8,pr.y-size],[x+size+8,pr.y-size],[x+size*.48,pr.y-size*1.25]],dark?'#4b4c72':'#945d55');
 }
 poly([[450,182],[510,182],[927,H],[33,H]],dark?'#1a273f':'#283445');
 poly([[451,182],[465,182],[119,H],[34,H]],'#d5c4aa');poly([[496,182],[510,182],[927,H],[842,H]],'#d5c4aa');
 // lane markers and animated perspective depth cues
 for(let rel=100-(dist%100);rel<900;rel+=100){const pr=roadProject(rel,292);const w=clamp(6*pr.scale,1,8),h=clamp(72*pr.scale,2,68);
  for(const offset of [-1,1])round(pr.x+offset*104*pr.scale-w/2,pr.y-h,w,h,1,'#e4e9eecc');
 }
 const targets=[];
 if(mode==='playing'||mode==='transition'){
  for(const ob of obstacles){if(ob.hit)continue;const rel=ob.x-dist,pr=roadProject(rel,ob.y);if(pr.visible)targets.push({rel,kind:ob.kind==='car'?'car':'barrier',pr,id:ob.x});}
  for(let n=items;n<3;n++){const rel=packPos[n]-dist,pr=roadProject(rel,[215,292,370][(n+level)%3]);if(pr.visible)targets.push({rel,kind:'parcel',pr,id:n});}
 }
 targets.sort((a,b)=>b.rel-a.rel);
 for(const ob of targets){const {x,y,scale}=ob.pr;if(ob.kind==='parcel'){
    g.save();g.translate(x,y-24*scale);g.scale(scale*2.05,scale*2.05);round(-25,-50,50,50,5,'#e4a64a');round(-25,-50,50,12,4,'#ffe7a6');round(-4,-50,8,50,2,'#ae6c3d');text('📦',0,-11,'20px system-ui','#fff');g.restore();
  }else if(ob.kind==='car'){
    const ww=clamp(128*scale,9,140),hh=clamp(125*scale,10,130);
    round(x-ww/2,y-hh,ww,hh,10*scale,'#d2586f');round(x-ww*.36,y-hh*.83,ww*.72,hh*.42,5*scale,'#9cd4e7');
    round(x-ww*.39,y-hh*.22,ww*.24,hh*.13,2,'#ffe7a2');round(x+ww*.16,y-hh*.22,ww*.24,hh*.13,2,'#ffe7a2');
  }else{let ww=clamp(112*scale,7,120),hh=clamp(90*scale,10,90);round(x-ww/2,y-hh,ww,hh,4*scale,'#ffad4d');for(let k=0;k<3;k++)round(x-ww*.4+k*ww*.31,y-hh*.84,ww*.1,hh*.67,1,'#533848')}
 }
 // rear-view scooter avatar, follows the real gameplay lane selected by the player
 const riderX=480+(player.y-292)/78*260;
 g.save();g.translate(riderX,430);if(player.invuln>0&&Math.floor(tt*12)%2===0)g.globalAlpha=.4;
 g.fillStyle='#0c1429a8';g.beginPath();g.ellipse(0,65,95,16,0,0,7);g.fill();
 round(-27,4,54,59,18,'#162338');round(-22,8,44,45,15,'#526e99');
 round(-55,-15,110,33,19,'#dca444');round(-46,-41,92,48,20,'#e9b74d');
 round(-53,-91,106,56,20,'#9a60c7');text('Z',0,-53,'900 33px Georgia','#f4dfab');
 round(-13,-138,28,40,12,'#efb282');round(-37,-157,75,53,20,'#2f68c3');round(-32,-153,65,18,13,'#a5ccfa');
 round(-11,-14,22,18,6,'#ff585e');g.restore();
 if(mode==='menu')text('🏙️ زنجر راش — دليفري بمنظور الطريق',480,240,'800 27px system-ui','#fff6d1');
 text('📍 '+cfg.name,90,139,'800 20px system-ui','#fff4cf','left');
}
function renderFrame(t){if(view3D){g.clearRect(0,0,W,H);deliveryRoad3D(t);if(flash){g.fillStyle=`rgba(255,68,99,${Math.min(.36,flash*.3)})`;g.fillRect(0,0,W,H)}return;}g.clearRect(0,0,W,H);drawBackground(t);drawDistanceArrows();
 if(mode==='playing'||mode==='transition'){
  for(const ob of obstacles){const x=player.x+ob.x-dist;if(x<-150||x>W+160)continue;ob.kind==='car'?drawCar(x,ob.y,Math.floor(ob.x)%2):drawBarrier(x,ob.y);}
  for(let n=0;n<3;n++){if(n<items)continue;const x=player.x+packPos[n]-dist;if(x>-90&&x<W+110)drawParcel(x,[215,292,370][(n+level)%3],n);}
  drawScooter(player.x,player.y,t);
 }
 for(const p of particles){g.globalAlpha=clamp(p.t/.7,0,1);round(p.x,p.y,p.size,p.size,2,p.c);g.globalAlpha=1;}
 for(const f of floating){g.globalAlpha=clamp(f.t,0,1);text(f.text,f.x,f.y,'900 26px system-ui','#fff0a0');g.globalAlpha=1;}
 if(flash){g.fillStyle=`rgba(255,68,99,${Math.min(.36,flash*.3)})`;g.fillRect(0,0,W,H)}
}
function movePlayer(dir){if(mode!=='playing')return;player.target=clamp(player.target+(dir>0?78:-78),211,372);sound(380,.045,'triangle',.025)}
let downY=null;cv.addEventListener('pointerdown',e=>{downY=e.clientY;});cv.addEventListener('pointerup',e=>{if(downY===null)return;const dy=e.clientY-downY;if(Math.abs(dy)>15)movePlayer(dy>0?1:-1);else movePlayer(e.clientY<cv.getBoundingClientRect().top+cv.getBoundingClientRect().height/2?-1:1);downY=null;});
for(let [id,d] of [['cg-up',-1],['cg-down',1]]){q(id).addEventListener('pointerdown',e=>{e.preventDefault();movePlayer(d);});}
addEventListener('keydown',e=>{if(['ArrowUp','ArrowDown','KeyW','KeyS'].includes(e.code)){e.preventDefault();movePlayer(['ArrowUp','KeyW'].includes(e.code)?-1:1)}});
q('cg-view').addEventListener('click',()=>{view3D=!view3D;q('cg-view').textContent=view3D?'👁 منظور 3D':'↔ عرض 2D';});
q('cg-sound').addEventListener('click',()=>{soundOn=!soundOn;q('cg-sound').textContent=soundOn?'🔊':'🔇'});
q('cg-start').addEventListener('click',start);
let pending=null;
async function collect(){if(pending||mode!=='playing'||items>=3)return;const n=items+1;items=n;requestBusy=true;pending=api('item',{count:n});try{await pending;confirmed=n;putParticles(player.x,player.y,['#ffe496','#7df3d4','#ffa6b8'],18);sound(810,.12);setTimeout(()=>sound(1050,.15),70);toast('📦 تم تسليم الطرد '+n+'/3');updateHud()}catch(e){items=n-1;toast('⚠️ '+e.message)}finally{requestBusy=false;pending=null;}}
async function finishStage(){if(progressLock||confirmed<3||mode!=='playing')return;progressLock=true;mode='transition';try{const result=await api('stage');if(result.won){sound(880,.2);setTimeout(()=>sound(1100,.2),130);setTimeout(()=>sound(1310,.4),280);overlay('🏆 مهمة مكتملة!','أكملت 3 مناطق و9 طرود! تمت إضافة 400 زنجر إلى حسابك في دولة الزنجر الجديدة.', 'العب جولة جديدة');q('cg-start').textContent='جولة جديدة';}
 else{level=result.stage;dist=0;items=confirmed=0;player.y=player.target=292;player.invuln=0;obstacles=[];fillWorld();updateHud();flash=0;mode='playing';toast('🏁 المرحلة '+level+' / 3');}}
 catch(e){overlay('مشكلة في احتساب المرحلة',e.message,'ابدأ من جديد')}finally{progressLock=false;}}
function crash(){if(player.invuln>0)return;lives--;player.invuln=2.6;shake=1;flash=1;putParticles(player.x,player.y,['#ff526f','#f9c176','#f6f0dd'],22);sound(130,.3,'sawtooth');updateHud();if(lives<=0){overlay('💥 خلصت المحاولات','اصطدمت 3 مرات قبل نهاية الرحلة. جرّب تاني لتوصل الطرود وتكسب 400 زنجر.', 'حاول مرة تانية');}}
function tick(now){const dt=Math.min(.045,Math.max(0,(now-last)/1000||0));last=now;gameTime+=dt;
 if(mode==='playing'){
  const previous=dist;dist+=LEVELS[level-1].speed*dt;player.y+=(player.target-player.y)*Math.min(1,11*dt);player.invuln=Math.max(0,player.invuln-dt);
  for(const ob of obstacles)if(!ob.hit&&Math.abs(ob.x-dist)<49&&Math.abs(ob.y-player.y)<38){ob.hit=true;crash();break;}
  if(items<3){let idx=items,x=packPos[idx],laneY=[215,292,370][(idx+level)%3];if(Math.abs(x-dist)<52&&Math.abs(laneY-player.y)<41)collect();}
  if(dist>=stageLimit){if(confirmed===3){dist=stageLimit;finishStage()}else{dist=Math.max(previous,stageLimit-170);if(dist>stageLimit-175){toast('📦 ارجع للطرود!');dist=packPos[Math.max(0,items)]-320;}}}
  updateHud();
 }
 particles=particles.filter(p=>p.t>0);for(const p of particles){p.x+=p.vx*dt;p.y+=p.vy*dt;p.t-=dt;p.vy+=75*dt;}
 floating=floating.filter(x=>x.t>0);for(const f of floating){f.t-=dt;f.y-=27*dt;}flash=Math.max(0,flash-dt*2);
 renderFrame(now*.001);requestAnimationFrame(tick);
}
fillWorld();updateHud();requestAnimationFrame(tick);
})();
