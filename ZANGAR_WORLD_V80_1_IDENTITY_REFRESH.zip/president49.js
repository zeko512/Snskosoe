"use strict";
const msg=document.getElementById('notice');async function submitGate(stage,detail){msg.textContent='جار التحقق...';try{const response=await fetch('/api/presidency49/gate',{method:'POST',credentials:'same-origin',cache:'no-store',headers:{'Content-Type':'application/json'},body:JSON.stringify({stage,...detail})});const data=await response.json();if(!response.ok)throw Error(data.error||'فشل التحقق');if(stage==='close'){msg.textContent=data.notice||'تم القفل';return}location.assign(data.next||'/v64.html#accounts');}catch(e){msg.textContent=e.message}}
document.getElementById('gate')?.addEventListener('submit',e=>{e.preventDefault();submitGate('code',{code:document.getElementById('secret').value});document.getElementById('secret').value='';});
document.getElementById('pinForm')?.addEventListener('submit',e=>{e.preventDefault();submitGate('pin',{pin:document.getElementById('pin').value});document.getElementById('pin').value='';});
document.getElementById('close')?.addEventListener('click',()=>submitGate('close',{}));

// V71.1: visiting the presidential gateway must not ask for the code again on a verified account.
(async()=>{
 try{
  const response=await fetch('/api/presidency49/gate',{method:'POST',credentials:'same-origin',cache:'no-store',headers:{'Content-Type':'application/json'},body:JSON.stringify({stage:'status'})});
  if(!response.ok)return;
  const access=await response.json();
  if(access.active){msg.textContent='✅ صلاحية الرئاسة محفوظة بحسابك، جارٍ فتح اللوحة...';
   document.getElementById('gate')?.querySelector('button[type="submit"]')?.setAttribute('disabled','');
   document.getElementById('pinForm')?.querySelector('button[type="submit"]')?.setAttribute('disabled','');
   location.replace('/v64.html#accounts');}
 }catch(_){/* normal two-step verification remains available offline */}
})();
